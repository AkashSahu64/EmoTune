import React, { useRef } from "react";
import { motion, useMotionValue, useTransform } from "framer-motion";

// Drift animation for floating UI elements inside the stack
const driftVariants = {
  animate: {
    y: [0, -6, 0, 4, 0],
    x: [0, 4, -3, 2, 0],
    transition: {
      duration: 7,
      repeat: Infinity,
      ease: "easeInOut",
    },
  },
};

const SocialHeroStack = ({ images }) => {
  // Tilt logic for center card
  const centerCardRef = useRef(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const rotateX = useTransform(y, [-100, 100], [5, -5]);
  const rotateY = useTransform(x, [-100, 100], [-5, 5]);

  const handleMouseMove = (e) => {
    const rect = centerCardRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const mouseX = e.clientX - centerX;
    const mouseY = e.clientY - centerY;
    x.set(mouseX);
    y.set(mouseY);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <div
      className="relative w-full h-full flex items-center justify-center"
      style={{ perspective: "1200px" }}
    >
      {/* Card 1 – left back - z-10 */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="absolute left-6 top-10 w-[220px] h-[420px] rounded-[28px] overflow-hidden shadow-premium rotate-[-10deg] z-10"
      >
        <img src={images[0]} alt="" className="w-full h-full object-cover" />
      </motion.div>

      {/* Card 2 – center main (with tilt & overlays) - z-30 */}
      <motion.div
        ref={centerCardRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        style={{ rotateX, rotateY }}
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="absolute left-[120px] top-0 w-[260px] h-[460px] rounded-[28px] overflow-hidden shadow-premium rotate-0 z-30 group"
      >
        <img src={images[1]} alt="" className="w-full h-full object-cover" />

        {/* Glass reflection overlay - inside card only */}
        <div className="absolute inset-0 bg-gradient-to-tr from-white/10 to-transparent pointer-events-none rounded-[28px]" />

        {/* Social overlay – top left */}
        <div className="absolute top-6 left-6 z-30">
          <div className="flex items-center">
            <span className="text-sm font-semibold text-white drop-shadow-md">@jessica</span>
            <span className="ml-1 w-2 h-2 rounded-full bg-instagram-pink" />
          </div>
          <p className="text-xs text-light-subtext mt-1 drop-shadow-md">
            “Living my best life ✨”
          </p>
        </div>

        {/* Social action bar – bottom */}
        <div className="absolute bottom-0 left-0 right-0 py-4 px-5 bg-gradient-to-t from-black/40 to-transparent z-30">
          <div className="flex items-center gap-4 text-xs text-white/80">
            <span>❤️ 1.2k</span>
            <span>💬 89</span>
            <span>🔗</span>
          </div>
        </div>

        {/* Vertical reel UI – right edge */}
        <div className="absolute right-2 bottom-16 flex flex-col gap-3 z-30">
          <div className="rounded-full bg-black/30 backdrop-blur-sm p-2 text-white">❤️</div>
          <div className="rounded-full bg-black/30 backdrop-blur-sm p-2 text-white">💬</div>
          <div className="rounded-full bg-black/30 backdrop-blur-sm p-2 text-white">🔗</div>
        </div>

        {/* Music label scroll */}
        <div className="absolute bottom-4 left-3 z-30 overflow-hidden w-[120px]">
          <motion.p
            animate={{ x: ["0%", "-100%"] }}
            transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
            className="text-xs text-white/70 whitespace-nowrap"
          >
            🎵 trending sound
          </motion.p>
        </div>
      </motion.div>

      {/* Card 3 – right back - z-20 */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="absolute left-[280px] top-20 w-[220px] h-[420px] rounded-[28px] overflow-hidden shadow-premium rotate-[8deg] z-20"
      >
        <img src={images[2]} alt="" className="w-full h-full object-cover" />
      </motion.div>

      {/* Floating social UI elements - z-40 (inside hero) */}
      <motion.div
        variants={driftVariants}
        animate="animate"
        className="absolute -left-10 top-1/2 text-3xl z-40"
      >
        ❤️
      </motion.div>

      <motion.div
        variants={driftVariants}
        animate="animate"
        transition={{ delay: 0.5 }}
        className="absolute left-[160px] -top-6 bg-light-card/80 backdrop-blur-sm rounded-full px-3 py-1 shadow-premium z-40 text-sm flex items-center gap-1"
      >
        <span>👀</span> <span>😲</span>
      </motion.div>

      {/* Profile story ring – upgraded */}
      <motion.div
        variants={driftVariants}
        animate="animate"
        transition={{ delay: 0.8 }}
        whileHover={{ scale: 1.1 }}
        className="absolute left-[48%] bottom-[20%] z-40"
      >
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="bg-gradient-to-tr from-viral-pink via-viral-orange to-viral-purple p-[2px] rounded-full"
        >
          <div className="w-14 h-14 rounded-full bg-login-hero" />
        </motion.div>
      </motion.div>

      <motion.div
        variants={driftVariants}
        animate="animate"
        transition={{ delay: 1.1 }}
        className="absolute bottom-6 left-10 w-[140px] h-6 rounded-full bg-white/10 backdrop-blur-sm z-40"
      />
    </div>
  );
};

export default SocialHeroStack;