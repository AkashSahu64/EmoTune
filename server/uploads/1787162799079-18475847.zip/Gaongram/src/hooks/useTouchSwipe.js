import { useCallback, useRef } from "react";

export const useTouchSwipe = ({
  onSwipeLeft,
  onSwipeRight,
  threshold = 50,
} = {}) => {
  const touchStartRef = useRef(null);
  const touchEndRef = useRef(null);
  const hasFiredRef = useRef(false);
  const isTrackingRef = useRef(false);

  const reset = useCallback(() => {
    touchStartRef.current = null;
    touchEndRef.current = null;
    hasFiredRef.current = false;
    isTrackingRef.current = false;
  }, []);

  const onTouchStart = useCallback((event) => {
    const touch = event.touches?.[0];
    if (!touch) {
      reset();
      return;
    }

    touchStartRef.current = touch.clientX;
    touchEndRef.current = touch.clientX;
    hasFiredRef.current = false;
    isTrackingRef.current = true;
  }, [reset]);

  const onTouchMove = useCallback((event) => {
    if (!isTrackingRef.current || hasFiredRef.current) return;

    const touch = event.touches?.[0];
    if (!touch) return;

    touchEndRef.current = touch.clientX;
  }, []);

  const onTouchEnd = useCallback(() => {
    if (
      !isTrackingRef.current ||
      hasFiredRef.current ||
      touchStartRef.current === null ||
      touchEndRef.current === null
    ) {
      reset();
      return;
    }

    const diff = touchStartRef.current - touchEndRef.current;
    const distance = Math.abs(diff);

    if (distance >= threshold) {
      hasFiredRef.current = true;

      if (diff > 0) {
        onSwipeLeft?.();
      } else {
        onSwipeRight?.();
      }
    }

    reset();
  }, [onSwipeLeft, onSwipeRight, reset, threshold]);

  return {
    onTouchStart,
    onTouchMove,
    onTouchEnd,
  };
};