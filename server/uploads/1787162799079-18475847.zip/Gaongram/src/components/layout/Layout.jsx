// src/components/layout/Layout.jsx
import React from "react";
import { Outlet, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import TopNavbar from "./TopNavbar.jsx";
import BottomNav from "./BottomNav.jsx";
import Sidebar from "./Sidebar.jsx";
import RightSidebar from "../../features/feed/components/RightSidebar.jsx";
import { useAuthStore } from "../../store/authStore.js";

const Layout = () => {
  const location = useLocation();
  const { user } = useAuthStore();

  const hideTopNavbar =
    location.pathname === "/reels" ||
    location.pathname === "/audio" ||
    location.pathname === "/messages" ||
    location.pathname === "/profile-videos" ||
    location.pathname.startsWith("/messages");
  const hideBottomNav =
    location.pathname === "/messages" ||
    location.pathname.startsWith("/messages");

  const disableMainNegativeMargin =
    location.pathname === "/reels" ||
    location.pathname.startsWith("/reels/") ||
    location.pathname === "/audio";

  return (
    <div className="min-h-screen bg-transparent dark:bg-background-dark">
      {!hideTopNavbar && <TopNavbar />}

      <div className={`flex ${!hideTopNavbar ? "pt-16" : "pt-0"}`}>
        <Sidebar />

        <main
          className={`flex-1 lg:ml-[256px] overflow-y-auto px-0 ${
            disableMainNegativeMargin ? "mt-0" : "-mt-2"
          }`}
        >
          <div className="h-full">
            <Outlet />
          </div>
        </main>
      </div>

      {!hideBottomNav && (
        <>
          <div className="h-16 md:hidden shrink-0" />
          <BottomNav />
        </>
      )}
    </div>
  );
};

export default Layout;
