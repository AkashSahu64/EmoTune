import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

// Import all translation files (using dynamic import for code splitting, but here we'll include them directly for simplicity)
import en from './locales/en/translation.json';
import hi from './locales/hi/translation.json';
import bn from './locales/bn/translation.json';
import te from './locales/te/translation.json';
import mr from './locales/mr/translation.json';
import ta from './locales/ta/translation.json';
import ur from './locales/ur/translation.json';
import gu from './locales/gu/translation.json';
import kn from './locales/kn/translation.json';
import or from './locales/or/translation.json';
import ml from './locales/ml/translation.json';
import pa from './locales/pa/translation.json';
import as from './locales/as/translation.json';
import mai from './locales/mai/translation.json';
import sat from './locales/sat/translation.json';
import ks from './locales/ks/translation.json';
import ne from './locales/ne/translation.json';
import kok from './locales/kok/translation.json';
import sd from './locales/sd/translation.json';
import doi from './locales/doi/translation.json';
import mni from './locales/mni/translation.json';
import brx from './locales/brx/translation.json';
import sa from './locales/sa/translation.json';

export const resources = {
  en: { translation: en },
  hi: { translation: hi },
  bn: { translation: bn },
  te: { translation: te },
  mr: { translation: mr },
  ta: { translation: ta },
  ur: { translation: ur },
  gu: { translation: gu },
  kn: { translation: kn },
  or: { translation: or },
  ml: { translation: ml },
  pa: { translation: pa },
  as: { translation: as },
  mai: { translation: mai },
  sat: { translation: sat },
  ks: { translation: ks },
  ne: { translation: ne },
  kok: { translation: kok },
  sd: { translation: sd },
  doi: { translation: doi },
  mni: { translation: mni },
  brx: { translation: brx },
  sa: { translation: sa },
};

i18n
  .use(LanguageDetector) // detects language from browser, localStorage, etc.
  .use(initReactI18next) // passes i18n instance to react-i18next
  .init({
    resources,
    fallbackLng: 'en', // use English if detected language is not available
    interpolation: {
      escapeValue: false, // react already safes from xss
    },
    detection: {
      order: ['localStorage', 'navigator'],
      caches: ['localStorage'], // save user preference in localStorage
    },
  });

export default i18n;