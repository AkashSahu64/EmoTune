import React from "react";
import { Check, Loader2, X } from "lucide-react";

const PostControls = ({ disabled, isBusy, onCancel, onSave }) => (
  <div className="flex items-center gap-2">
    <button type="button" onClick={onCancel} disabled={isBusy} className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-foreground transition hover:bg-border disabled:opacity-40 dark:bg-muted-dark dark:text-foreground-dark" aria-label="Cancel" title="Cancel">
      <X size={20} />
    </button>
    <button
      type="button"
      onClick={onSave}
      disabled={disabled}
      className="flex h-10 items-center justify-center gap-2 rounded-full bg-primary px-4 text-sm font-semibold text-white shadow-lg transition hover:bg-primary-light disabled:opacity-50"
    >
      {isBusy ? <Loader2 size={18} className="animate-spin" /> : <Check size={18} />}
      Save
    </button>
  </div>
);

export default React.memo(PostControls);
