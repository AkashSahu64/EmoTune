const listeners = new Set();

export const FEED_EVENTS = {
  CREATED: "created",
  UPDATED: "updated",
  DELETED: "deleted",
  BLOCKED_USER: "blocked-user",
  REFRESH: "refresh",
};

export const publishFeedEvent = (event) => {
  const payload =
    typeof event === "string" ? { type: event } : event || { type: FEED_EVENTS.REFRESH };

  listeners.forEach((listener) => {
    listener(payload);
  });
};

export const subscribeToFeedEvents = (listener) => {
  if (typeof listener !== "function") {
    return () => {};
  }

  listeners.add(listener);
  return () => listeners.delete(listener);
};
