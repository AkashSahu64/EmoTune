import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { notificationService } from "../../services/notification.service.js";
import {
  Link,
  useNavigate,
  useLocation,
  useSearchParams,
} from "react-router-dom";

import { Search, MessageCircle, Settings } from "lucide-react";

import { FaBell } from "react-icons/fa";

import { useAuthStore } from "../../store/authStore.js";
import { useUIStore } from "../../store/uiStore.js";

import Avatar from "../common/Avatar.jsx";

import gaonGramLogo from "../../assets/logo.png";

import SettingsPopup from "../common/SettingsPopup.jsx";

import { useTranslation } from "react-i18next";

const TopNavbar = () => {
  const navigate = useNavigate();

  const location = useLocation();

  const { user } = useAuthStore();
  const [showMobileSearch, setShowMobileSearch] = useState(false);

  const { t } = useTranslation();
  const [unreadCount, setUnreadCount] = useState(0);

  const [searchParams, setSearchParams] = useSearchParams();

  const [scrolled, setScrolled] = useState(false);

  const [showSettings, setShowSettings] = useState(false);

  const [searchInput, setSearchInput] = useState(searchParams.get("q") || "");

  const isProfilePage = location.pathname.startsWith("/profile");

  // Right icon
  const rightAction = isProfilePage
    ? {
        icon: Settings,
        action: () => setShowSettings(true),
      }
    : {
        icon: MessageCircle,
        action: () => navigate("/messages"),
      };

  const ActionIcon = rightAction.icon;

  // Scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 5);
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  // Sync URL query
  useEffect(() => {
    const query = searchParams.get("q") || "";

    setSearchInput(query);
  }, [searchParams]);
  // Fetch unread notification count
  useEffect(() => {
    const fetchUnreadCount = async () => {
      try {
        const count = await notificationService.getUnreadCount();

        setUnreadCount(count);
      } catch (error) {
        console.error("Failed to fetch unread count:", error);
      }
    };

    // initial fetch
    fetchUnreadCount();

    // listen notification read event
    const handleNotificationsRead = () => {
      setUnreadCount(0);
    };

    window.addEventListener("notifications-read", handleNotificationsRead);

    return () => {
      window.removeEventListener("notifications-read", handleNotificationsRead);
    };
  }, []);

  // Search handler
  const handleSearchChange = (e) => {
    const value = e.target.value;

    setSearchInput(value);

    // Not on search page
    if (location.pathname !== "/search") {
      if (value.trim()) {
        navigate(`/search?q=${encodeURIComponent(value)}`);
      } else {
        navigate("/search");
      }
    }

    // Already on search page
    else {
      if (value.trim()) {
        setSearchParams({ q: value });
      } else {
        setSearchParams({});
      }
    }
  };

  return (
    <>
      <motion.nav
        initial={{ y: -80 }}
        animate={{ y: 0 }}
        className={`
          fixed top-0 right-0 left-0 lg:left-64 z-50
          bg-card/80 dark:bg-card-dark/80
          backdrop-blur-sm
          ${
            scrolled
              ? "shadow-soft"
              : "border-b border-border dark:border-border-dark"
          }
        `}
      >
        <div className="w-full max-w-7xl mx-auto overflow-hidden">
          {/* ================= MOBILE ================= */}

          <div className="md:hidden">
            <div className="h-14 flex items-center justify-between px-4">
              {/* SEARCH OPEN HONE PAR */}

              {showMobileSearch ? (
                <div className="flex items-center gap-2 w-full">
                  <div
                    className="
                    flex items-center
                    bg-muted dark:bg-muted-dark
                    px-3 py-2
                    rounded-full
                    flex-1
                  "
                  >
                    <Search className="w-4 h-4 mr-2 text-mutedForeground dark:text-mutedForeground-dark" />

                    <input
                      type="text"
                      autoFocus
                      value={searchInput}
                      onChange={handleSearchChange}
                      placeholder={t("search")}
                      className="
                        bg-transparent
                        outline-none
                        w-full
                        text-sm
                        text-foreground
                        dark:text-foreground-dark
                      "
                    />
                  </div>

                  <button
                    onClick={() => {
                      setShowMobileSearch(false);
                      setSearchInput("");
                    }}
                    className="text-sm font-medium"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <>
                  {/* LOGO */}

                  <div className="flex items-center gap-2">
                    <img
                      src={gaonGramLogo}
                      alt="GaonGram"
                      className="w-7 h-7 object-contain"
                    />

                    <span className="text-lg font-semibold text-foreground dark:text-foreground-dark">
                      {t("app_name")}
                    </span>
                  </div>

                  {/* ACTIONS */}

                  <div className="flex items-center gap-5 text-foreground dark:text-foreground-dark">
                    {/* SEARCH ICON */}

                    <button
                      onClick={() => setShowMobileSearch(true)}
                      className="hover:text-primary transition"
                    >
                      <Search className="w-5 h-5" />
                    </button>

                    {/* NOTIFICATION */}

                    <button
                      onClick={() => navigate("/notifications")}
                      className="relative hover:text-primary transition"
                    >
                      <FaBell className="w-5 h-5" />

                      {unreadCount > 0 && (
                        <span
                          className="
                            absolute -top-2 -right-2
                            min-w-[18px] h-[18px]
                            px-1
                            flex items-center justify-center
                            rounded-full
                            bg-red-500 text-white
                            text-[10px] font-semibold
                          "
                        >
                          {unreadCount > 99 ? "99+" : unreadCount}
                        </span>
                      )}
                    </button>

                    {/* MESSAGE / SETTINGS */}

                    <button
                      onClick={rightAction.action}
                      className="hover:text-primary transition"
                    >
                      <ActionIcon className="w-6 h-6" />
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* ================= DESKTOP ================= */}

          <div className="hidden md:grid grid-cols-[1fr_auto_auto] items-center h-14 px-6 gap-4">
            <div />

            {/* SEARCH */}

            <div className="w-[380px] mr-1">
              <div
                className="
                flex items-center gap-3
                bg-muted dark:bg-muted-dark
                border border-border dark:border-border-dark
                rounded-full
                px-4 py-2
                transition
              "
              >
                <Search className="w-4 h-4 text-mutedForeground dark:text-mutedForeground-dark" />

                <input
                  type="text"
                  value={searchInput}
                  onChange={handleSearchChange}
                  onFocus={() => {
                    if (location.pathname !== "/search") {
                      navigate("/search");
                    }
                  }}
                  placeholder={t("search")}
                  className="
                    bg-transparent
                    outline-none
                    w-full
                    text-sm
                    text-foreground
                    dark:text-foreground-dark
                    placeholder:text-mutedForeground
                    dark:placeholder:text-mutedForeground-dark
                  "
                />
              </div>
            </div>

            {/* RIGHT SIDE */}

            <div className="flex items-center gap-6 text-foreground dark:text-foreground-dark">
              <button
                onClick={() => navigate("/notifications")}
                className="relative hover:text-primary transition"
              >
                <FaBell className="w-6 h-6" />

                {unreadCount > 0 && (
                  <span
                    className="
                      absolute -top-2 -right-2
                      min-w-[18px] h-[18px]
                      px-1
                      flex items-center justify-center
                      rounded-full
                      bg-red-500 text-white
                      text-[10px] font-semibold
                    "
                  >
                    {unreadCount > 99 ? "99+" : unreadCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => navigate("/messages")}
                className="hover:text-primary transition"
              >
                <MessageCircle className="w-6 h-6" />
              </button>

              <Link to={`/profile/${user?.username}`}>
                <Avatar
                  src={user?.photo}
                  alt={user?.username}
                  size="md"
                  isStory={user?.has_story}
                  className="
                    w-10 h-10
                    border-2 border-primary
                    rounded-full
                    bg-primary
                    text-white
                    text-lg
                    font-semibold
                    flex items-center justify-center
                    cursor-pointer
                  "
                />
              </Link>
            </div>
          </div>
        </div>
      </motion.nav>

      {showSettings && <SettingsPopup onClose={() => setShowSettings(false)} />}
    </>
  );
};

export default TopNavbar;
