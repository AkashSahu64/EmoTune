import React, { useState } from "react";
import { MoreVertical, Trash2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useUIStore } from "../../../store/uiStore";

const StoryOptionsMenu = ({ isOwner, onDelete, isDeleting }) => {
  const [isOpen, setIsOpen] = useState(false);
  const { openModal } = useUIStore();

  if (!isOwner) return null;

  return (
    <div className="absolute bottom-[calc(env(safe-area-inset-bottom)+1rem)] right-3 z-50 sm:right-4">
      <button
        onClick={(e) => {
          e.stopPropagation();
          setIsOpen(!isOpen);
        }}
        className="flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
        aria-label="Story options"
        aria-expanded={isOpen}
      >
        <MoreVertical size={20} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="absolute right-0 bottom-full mb-2 w-48 bg-white dark:bg-gray-900 rounded-lg shadow-lg overflow-hidden"
          >
            <button
              onClick={(e) => {
                e.stopPropagation();
                setIsOpen(false);
                openModal("confirm-story", {
                  title: "Delete Story",
                  message: "Are you sure you want to delete this story?",
                  confirmText: "Delete",
                  cancelText: "Cancel",
                  type: "danger",

                  onConfirm: async () => {
                    try {
                      await onDelete();
                      setIsOpen(false);
                    } catch (err) {
                      console.error(err);
                    }
                  },
                });
              }}
              disabled={isDeleting}
              className="w-full px-4 py-3 text-left text-red-600 hover:bg-gray-100 dark:hover:bg-gray-800 flex items-center gap-2"
            >
              {isDeleting ? (
                <div className="w-4 h-4 border-2 border-red-600/20 border-t-red-600 rounded-full animate-spin" />
              ) : (
                <Trash2 size={16} />
              )}
              Delete story
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default StoryOptionsMenu;
