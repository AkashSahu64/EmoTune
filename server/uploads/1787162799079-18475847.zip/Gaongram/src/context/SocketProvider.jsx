// src/context/SocketProvider.jsx
import React, {
  createContext,
  useContext,
  useEffect,
  useRef,
  useCallback,
  useState,
} from "react";
import { useAuthStore } from "../store/authStore";
import { useChatStore } from "../store/chatStore";
import { TOKEN_KEYS } from "../config/env";

const SocketContext = createContext(null);
const WS_BASE_URL = import.meta.env.VITE_WS_URL || "ws://192.168.18.5:8000";

// eslint-disable-next-line react-refresh/only-export-components
export const useSocket = () => {
  const ctx = useContext(SocketContext);
  if (!ctx) throw new Error("useSocket must be used within SocketProvider");
  return ctx;
};

export const SocketProvider = ({ children }) => {
  const { user, isAuthenticated } = useAuthStore();
  const [isConnected, setIsConnected] = useState(false);
  const {
    addMessages,
    updateMessage,
    setOnline,
    addTypingUser,
    removeTypingUser,
    updateChatList,
    updateUnreadCount,
  } = useChatStore();

  // Refs
  const socketRef = useRef(null);
  const currentReceiverRef = useRef(null);
  const reconnectTimeoutRef = useRef(null);
  const pingIntervalRef = useRef(null);
  const reconnectAttemptsRef = useRef(0);
  const connectionIdRef = useRef(0);
  const isIntentionalCloseRef = useRef(false);
  const isConnectingRef = useRef(false); // ← prevents duplicate connections

  // Helper to send JSON
  const sendJson = useCallback((data) => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify(data));
      return true;
    }
    return false;
  }, []);

  const emit = useCallback(
    (type, payload = {}) => {
      return sendJson({ type, ...payload });
    },
    [sendJson],
  );

  // Message deduplication
  const isDuplicateMessage = useCallback((newMsg, chatId) => {
    const existingMessages = useChatStore.getState().messages.get(chatId) || [];
    return existingMessages.some((m) => m.id === newMsg.id);
  }, []);

  // Handle incoming WebSocket events
  const handleSocketMessage = useCallback(
    (event) => {
      const data = JSON.parse(event.data);
      const { type, ...payload } = data;
      const currentUserId = user?.id;

      switch (type) {
        case "message": {
          const currentUserId = user?.id;

          // ✅ FULL NORMALIZATION (IMPORTANT)
          const normalizedMessage = {
            ...payload,
            sender: payload.sender_id,
            receiver: payload.receiver_id,
            delivered_at: payload.delivered_at || null,
            seen_at: payload.seen_at || null,
            reply_to: payload.reply_to || null,
          };

          const chatId =
            normalizedMessage.sender === currentUserId
              ? normalizedMessage.receiver
              : normalizedMessage.sender;

          const { tempMessages } = useChatStore.getState();

          let matchedTempId = null;

          for (let [tempId, tempMsg] of tempMessages.entries()) {
            if (
              tempMsg.message === normalizedMessage.message &&
              tempMsg.receiver === normalizedMessage.receiver &&
              Math.abs(
                new Date(tempMsg.created_at) -
                  new Date(normalizedMessage.created_at),
              ) < 5000
            ) {
              matchedTempId = tempId;
              break;
            }
          }

          if (matchedTempId) {
            useChatStore
              .getState()
              .replaceTempMessage(chatId, matchedTempId, normalizedMessage);
          } else if (!isDuplicateMessage(normalizedMessage, chatId)) {
            addMessages(chatId, [normalizedMessage]);
          }

          break;
        }
        case "typing": {
          if (payload.sender_id !== currentUserId) {
            payload.is_typing
              ? addTypingUser(payload.sender_id)
              : removeTypingUser(payload.sender_id);
          }
          break;
        }

        case "typing_list": {
          const currentUserId = user?.id;

          if (payload.user_id !== currentUserId) {
            payload.is_typing
              ? addTypingUser(payload.user_id)
              : removeTypingUser(payload.user_id);
          }
          break;
        }

        case "seen": {
          payload.message_ids.forEach((id) => {
            const { messages } = useChatStore.getState();
            for (let [chatId, msgs] of messages.entries()) {
              const msg = msgs.find((m) => m.id === id);
              if (msg) {
                updateMessage(chatId, id, {
                  seen_at: new Date().toISOString(),
                  read_status: "read",
                });
                break;
              }
            }
          });
          break;
        }
        case "presence": {
          setOnline(payload.user_id, payload.is_online);
          break;
        }
        case "chat_list_update": {
          updateChatList({
            id: payload.user_id,
            last_message: payload.last_message,
            last_message_time: payload.created_at,
          });
          if (payload.unread && payload.user_id !== currentUserId) {
            updateUnreadCount(payload.user_id, (prev) => (prev || 0) + 1);
          }
          break;
        }
        case "chat_list_seen": {
          updateUnreadCount(payload.user_id, 0);
          break;
        }
        case "pong":
          break;
        default:
          console.warn("Unknown WS event:", type);
      }
    },
    [
      user?.id,
      addMessages,
      updateMessage,
      setOnline,
      addTypingUser,
      removeTypingUser,
      updateChatList,
      updateUnreadCount,
      isDuplicateMessage,
    ],
  );

  // Heartbeat
  const startPing = useCallback(() => {
    if (pingIntervalRef.current) clearInterval(pingIntervalRef.current);
    pingIntervalRef.current = setInterval(() => {
      if (socketRef.current?.readyState === WebSocket.OPEN) {
        sendJson({ type: "ping" });
      }
    }, 25000);
  }, [sendJson]);

  const stopPing = useCallback(() => {
    if (pingIntervalRef.current) {
      clearInterval(pingIntervalRef.current);
      pingIntervalRef.current = null;
    }
  }, []);

  // Reconnect with backoff
  const scheduleReconnect = useCallback((receiverId) => {
    if (reconnectTimeoutRef.current) clearTimeout(reconnectTimeoutRef.current);
    const delay = Math.min(1000 * 2 ** reconnectAttemptsRef.current, 30000);
    reconnectTimeoutRef.current = setTimeout(() => {
      reconnectAttemptsRef.current++;
      connect(receiverId);
    }, delay);
    // connect is defined below and read from this closure when the timeout runs.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---------- Main connect function (idempotent) ----------
  const connect = useCallback(
    (receiverId) => {
      const token = localStorage.getItem(TOKEN_KEYS.ACCESS_TOKEN);
      if (!isAuthenticated || !user?.id || !receiverId || !token) return;

      // Already connected to the same receiver and socket is open/connecting
      if (currentReceiverRef.current === receiverId && socketRef.current) {
        const ready = socketRef.current.readyState;
        if (ready === WebSocket.OPEN || ready === WebSocket.CONNECTING) {
          return; // already connected or connecting
        }
      }

      // Prevent multiple simultaneous connection attempts
      if (isConnectingRef.current) return;
      isConnectingRef.current = true;

      // Close existing connection if any
      if (socketRef.current) {
        isIntentionalCloseRef.current = true;
        socketRef.current.close(1000);
        socketRef.current = null;
      }

      const connId = ++connectionIdRef.current;
      const wsUrl = `${WS_BASE_URL}/ws/messages/${receiverId}/?token=${token}`;
      const ws = new WebSocket(wsUrl);
      socketRef.current = ws;
      currentReceiverRef.current = receiverId;
      isIntentionalCloseRef.current = false;

      ws.onopen = () => {
        if (connId !== connectionIdRef.current) return;
        console.log(`✅ WS connected to ${receiverId}`);
        setIsConnected(true);
        isConnectingRef.current = false;
        reconnectAttemptsRef.current = 0;
        startPing();
      };

      ws.onmessage = (event) => {
        if (connId !== connectionIdRef.current) return;
        handleSocketMessage(event);
      };

      ws.onerror = (err) => {
        console.error("❌ WS error", err);
        // Do not close here; onclose will handle reconnect
      };

      ws.onclose = (event) => {
        if (connId !== connectionIdRef.current) return;
        console.log(`❌ WS closed: code=${event.code}`);
        setIsConnected(false);
        isConnectingRef.current = false;
        stopPing();
        socketRef.current = null;

        if (event.code === 1000 || isIntentionalCloseRef.current) {
          // Normal closure, do not reconnect
          return;
        }
        // Unintentional close -> reconnect
        scheduleReconnect(receiverId);
      };
    },
    [
      isAuthenticated,
      user?.id,
      handleSocketMessage,
      startPing,
      stopPing,
      scheduleReconnect,
    ],
  );

  // ---------- Disconnect ----------
  const disconnect = useCallback(() => {
    // Cancel any pending reconnect
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
    stopPing();

    if (socketRef.current) {
      isIntentionalCloseRef.current = true;
      socketRef.current.onopen = null;
      socketRef.current.onmessage = null;
      socketRef.current.onerror = null;
      socketRef.current.onclose = null;
      // If socket is still connecting, wait for it to open then close?
      // Better: just close it – the onclose will handle cleanup.
      socketRef.current.close(1000);
      socketRef.current = null;
    }
    currentReceiverRef.current = null;
    reconnectAttemptsRef.current = 0;
    isConnectingRef.current = false;
    setIsConnected(false);
  }, [stopPing]);

  useEffect(() => {
    if (!isAuthenticated) {
      disconnect();
    }
  }, [disconnect, isAuthenticated]);

  // Cleanup on unmount
  useEffect(() => {
    return () => disconnect();
  }, [disconnect]);

  const value = {
    socket: socketRef.current,
    isConnected,
    connect,
    disconnect,
    emit,
  };

  return (
    <SocketContext.Provider value={value}>{children}</SocketContext.Provider>
  );
};