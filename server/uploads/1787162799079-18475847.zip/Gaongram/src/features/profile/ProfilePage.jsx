import React, {
  startTransition,
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";
import { motion as Motion } from "framer-motion";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { BadgeCheck, Briefcase, Link2, Lock, MapPin } from "lucide-react";
import { useAuth } from "../../hooks/useAuth";
import { useFollow } from "../../hooks/useFollow";
import { useProfile } from "../../hooks/useProfile";
import { showToast } from "../../utils/toast";
import { useReport } from "../../hooks/useReport.js";
import ProfileActions from "./components/ProfileActions";
import ProfileContent from "./components/ProfileContent";
import ProfileCover from "./components/ProfileCover";
import ProfileSkeleton from "./components/ProfileSkeleton";
import ProfileStats from "./components/ProfileStats";
import ProfileTabs from "./components/ProfileTabs";
import EditCoverImageModal from "./components/EditCoverImageModal";
import EditProfileDetailsModal from "./components/EditProfileDetailsModal";
import EditProfileImageModal from "./components/EditProfileImageModal";
import FollowersModal from "./components/FollowersModal";
import FollowingModal from "./components/FollowingModal";
import BlockedProfileView from "./components/BlockedProfileView.jsx";
import ProfileUnavailableView from "./components/ProfileUnavailableView";
import { useBlock } from "../../hooks/useBlock.js";
import { useBlockStore } from "../../store/block.store.js";
import Seo from "../../components/seo/Seo.jsx";
import { buildProfileSeo } from "../../seo/seoBuilders.js";
import ImagePreviewModal from "../../components/common/ImagePreviewModal.jsx";

const EMPTY_STATS = {
  posts: 0,
  followers: 0,
  following: 0,
};

const getFollowButtonState = ({ isFollowing, isRequested }) => {
  if (isRequested) {
    return { label: "Requested", variant: "outline", disabled: false };
  }

  if (isFollowing) {
    return { label: "Following", variant: "outline", disabled: false };
  }

  return { label: "Follow", variant: "primary", disabled: false };
};

const normalizeExternalLink = (value) => {
  if (!value) {
    return { href: "", label: "" };
  }

  const href = value.startsWith("http") ? value : `https://${value}`;
  const label = href.replace(/^https?:\/\/(www\.)?/, "").replace(/\/$/, "");

  return { href, label };
};

const buildFullName = (profile) =>
  profile?.full_name ||
  [profile?.first_name, profile?.last_name].filter(Boolean).join(" ").trim() ||
  profile?.username ||
  "";

const ProfilePage = () => {
  const { identifier } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const { user: currentUser } = useAuth();
  const { openReport } = useReport();
  const {
    profile,
    normalizedProfile,
    isLoading,
    isFetching,
    updateProfile,
    isUpdating,
  } = useProfile(identifier);

  const safeNormalizedProfile = useMemo(
    () =>
      normalizedProfile || {
        id: profile?.id || profile?.user_id || null,
        username: profile?.username || "",
        fullName: buildFullName(profile),
        profileImage: profile?.profile_image || profile?.photo || "",
        coverImage: profile?.cover_image || profile?.background_image || "",
        bio: "",
        location: "",
        externalLink: "",
        userId: profile?.user_id || profile?.id,
        isPrivate: Boolean(profile?.is_private),
        isVerified: Boolean(profile?.is_verified),
        isBusiness: Boolean(profile?.is_business_profile),
        isFollowing: Boolean(profile?.is_following),
        isFollowingRequested: Boolean(profile?.is_following_requested),
        stats: EMPTY_STATS,
      },
    [normalizedProfile, profile],
  );

  const profileUserId =
    safeNormalizedProfile.userId || profile?.user_id || profile?.id || null;
  const {
    hasState: hasFollowState,
    isFollowing: storeFollowing,
    isFollowingRequested: storeRequested,
    isLoading: isFollowLoading,
    toggleFollow,
  } = useFollow(profileUserId, safeNormalizedProfile.isPrivate);

  const {
    toggleBlock,
    isToggling,
    isBlocked: isBlockedInStore,
    isBlockedBy: isBlockedByInStore,
  } = useBlock();
  const hydrateBlockStore = useBlockStore((state) => state.hydrateFromProfile);

  useEffect(() => {
    hydrateBlockStore(profile);
  }, [hydrateBlockStore, profile]);

  const [activeTab, setActiveTab] = useState("posts");
  const [isEditDetailsModalOpen, setIsEditDetailsModalOpen] = useState(false);
  const [isEditProfileImageModalOpen, setIsEditProfileImageModalOpen] =
    useState(false);
  const [isEditCoverImageModalOpen, setIsEditCoverImageModalOpen] =
    useState(false);
  const [isFollowersModalOpen, setIsFollowersModalOpen] = useState(false);
  const [isFollowingModalOpen, setIsFollowingModalOpen] = useState(false);
  const [imagePreviews, setImagePreviews] = useState({
    profile: null,
    cover: null,
  });
  const [previewImage, setPreviewImage] = useState(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [imageRevisions, setImageRevisions] = useState({
    profile: 0,
    cover: 0,
  });
  const [updatingAsset, setUpdatingAsset] = useState(null);

  const isBlocked = useMemo(
    () =>
      Boolean(profile?.is_blocked) ||
      Boolean(profileUserId && isBlockedInStore(profileUserId)),
    [isBlockedInStore, profile?.is_blocked, profileUserId],
  );

  const isBlockedBy = useMemo(
    () =>
      Boolean(profile?.blocked_by) ||
      Boolean(profileUserId && isBlockedByInStore(profileUserId)),
    [isBlockedByInStore, profile?.blocked_by, profileUserId],
  );

  const shouldHideProfileInfo = useMemo(() => {
    // logged out users ke liye profile hide mat karo
    if (!currentUser) {
      return false;
    }

    return isBlocked || isBlockedBy;
  }, [currentUser, isBlocked, isBlockedBy]);

  const hasResolvedProfile = !isLoading && Boolean(profile);

  useEffect(() => {
    if (!profile || isLoading) return;

    const isNumericIdentifier = /^\d+$/.test(String(identifier || ""));
    const username = profile?.username || safeNormalizedProfile?.username;

    // ONLY redirect numeric URLs
    if (
      isNumericIdentifier &&
      username &&
      location.pathname !== `/profile/${username}`
    ) {
      navigate(`/profile/${username}`, {
        replace: true,
      });
    }
  }, [
    profile,
    isLoading,
    identifier,
    navigate,
    location.pathname,
    safeNormalizedProfile?.username,
  ]);

  const isOwnProfile = useMemo(() => {
    if (!currentUser || !safeNormalizedProfile.userId) {
      return false;
    }

    return (
      String(currentUser.user_id || currentUser.id) ===
        String(safeNormalizedProfile.userId) ||
      String(currentUser.profile_id) === String(safeNormalizedProfile.id)
    );
  }, [currentUser, safeNormalizedProfile]);

  const effectiveIsFollowing = hasFollowState
    ? storeFollowing
    : safeNormalizedProfile.isFollowing;
  const effectiveIsRequested = hasFollowState
    ? storeRequested
    : safeNormalizedProfile.isFollowingRequested;

  const followButtonState = useMemo(
    () =>
      getFollowButtonState({
        isFollowing: effectiveIsFollowing,
        isRequested: effectiveIsRequested,
      }),
    [effectiveIsFollowing, effectiveIsRequested],
  );

  const isPrivateLocked =
    !shouldHideProfileInfo &&
    !isOwnProfile &&
    Boolean(safeNormalizedProfile.isPrivate) &&
    !effectiveIsFollowing;

  const displayName =
    safeNormalizedProfile.fullName || safeNormalizedProfile.username;
  const externalLink = useMemo(
    () => normalizeExternalLink(safeNormalizedProfile.externalLink),
    [safeNormalizedProfile.externalLink],
  );

  const stats = useMemo(() => {
    if (shouldHideProfileInfo) {
      return EMPTY_STATS;
    }

    return safeNormalizedProfile.stats || EMPTY_STATS;
  }, [safeNormalizedProfile.stats, shouldHideProfileInfo]);

  const profileSeo = useMemo(
    () =>
      buildProfileSeo(
        {
          ...safeNormalizedProfile,
          stats,
        },
        { identifier, imageVersion: profile?.updated_at || profile?.updatedAt },
      ),
    [
      identifier,
      profile?.updatedAt,
      profile?.updated_at,
      safeNormalizedProfile,
      stats,
    ],
  );

  const profileBadges = useMemo(() => {
    if (shouldHideProfileInfo) {
      return [];
    }

    const badges = [];

    if (safeNormalizedProfile.isVerified) {
      badges.push(
        <span
          key="verified"
          className="inline-flex items-center gap-1 rounded-full bg-[#eef5ff] px-3 py-1 text-xs font-semibold text-[#2453a6]"
        >
          <BadgeCheck className="h-3.5 w-3.5" />
          Verified
        </span>,
      );
    }

    if (safeNormalizedProfile.isBusiness) {
      badges.push(
        <span
          key="business"
          className="inline-flex items-center gap-1 rounded-full bg-[#f6efe0] px-3 py-1 text-xs font-semibold text-[#7a5a20]"
        >
          <Briefcase className="h-3.5 w-3.5" />
          Creator
        </span>,
      );
    }

    if (safeNormalizedProfile.isPrivate) {
      badges.push(
        <span
          key="private"
          className="inline-flex items-center gap-1 text-xs font-semibold text-mutedForeground dark:text-mutedForeground-dark lg:-mb-1"
        >
          <Lock className="h-3 w-3 sm:h-4 sm:w-4" />
        </span>,
      );
    }

    return badges;
  }, [safeNormalizedProfile, shouldHideProfileInfo]);

  const handleShare = useCallback(async () => {
    if (!safeNormalizedProfile.userId) {
      return;
    }

    const shareUrl = `${window.location.origin}/profile/${safeNormalizedProfile.username || safeNormalizedProfile.userId || safeNormalizedProfile.id}`;

    try {
      if (navigator.share) {
        await navigator.share({
          title: `${displayName}'s Profile`,
          text: `Check out ${displayName} on GaonGram`,
          url: shareUrl,
        });
        return;
      }

      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(shareUrl);

        showToast("Profile link copied to clipboard", "success");
        return;
      }

      showToast("Sharing is not available on this device", "error");
    } catch (shareError) {
      if (shareError?.name !== "AbortError") {
        showToast("Unable to share this profile", "error");
      }
    }
  }, [displayName, safeNormalizedProfile.userId]);

  const handleReportUser = useCallback(() => {
    if (!profileUserId) {
      return;
    }

    openReport({
      modelType: "user",
      objectId: profileUserId,
      objectData: {
        username: safeNormalizedProfile.username,
        fullName: displayName,
      },
    });
  }, [displayName, openReport, profileUserId, safeNormalizedProfile.username]);

  const handleMessage = useCallback(() => {
    if (!profileUserId) {
      return;
    }

    if (
      safeNormalizedProfile.isPrivate &&
      !effectiveIsFollowing &&
      !isOwnProfile
    ) {
      showToast("Follow this account to send a message", "error");
      return;
    }

    navigate(`/messages/${profileUserId}`);
  }, [
    effectiveIsFollowing,
    isOwnProfile,
    navigate,
    profileUserId,
    safeNormalizedProfile.isPrivate,
  ]);

  const handleUpdateProfile = useCallback(
    async ({ data, previewUrl, type = "details" }) => {
      const isImageUpdate = type === "profile" || type === "cover";

      if (isImageUpdate) {
        setUpdatingAsset(type);

        if (previewUrl) {
          setImagePreviews((current) => ({
            ...current,
            [type]: previewUrl,
          }));
        }
      }

      try {
        await updateProfile({ data });

        if (isImageUpdate) {
          setImageRevisions((current) => ({
            ...current,
            [type]: current[type] + 1,
          }));
          showToast(
            type === "profile"
              ? "Profile photo updated successfully"
              : "Cover photo updated successfully",
            "success",
          );
        } else {
          showToast("Profile updated successfully", "success");
        }
      } catch (updateError) {
        if (isImageUpdate) {
          setImagePreviews((current) => ({
            ...current,
            [type]: null,
          }));
        }

        throw updateError;
      } finally {
        if (isImageUpdate) {
          setUpdatingAsset(null);
        }
      }
    },
    [updateProfile],
  );

  const handleTabChange = useCallback((nextTab) => {
    startTransition(() => {
      setActiveTab(nextTab);
    });
  }, []);

  const handleStatClick = useCallback(
    (type) => {
      if (shouldHideProfileInfo) {
        return;
      }

      if (type === "followers") {
        setIsFollowersModalOpen(true);
      }

      if (type === "following") {
        setIsFollowingModalOpen(true);
      }
    },
    [shouldHideProfileInfo],
  );

  const handleToggleBlock = useCallback(async () => {
    if (!profileUserId) {
      return;
    }

    await toggleBlock(profileUserId);
  }, [profileUserId, toggleBlock]);

  if (isLoading || isFetching) {
    const prerenderSeo = identifier
      ? buildProfileSeo(
          { username: identifier, full_name: identifier },
          { identifier },
        )
      : null;

    return (
      <>
        {prerenderSeo ? (
          <Seo {...prerenderSeo} />
        ) : (
          <Seo
            title="Profile Not Found"
            description="This GaonGram profile is unavailable or may have been removed."
            canonical={`/profile/${identifier || ""}`}
            noindex
          />
        )}
        <ProfileSkeleton />
      </>
    );
  }

  if (!hasResolvedProfile) {
    return (
      <>
        <Seo {...profileSeo} />
        <ProfileUnavailableView />
      </>
    );
  }

  let profileBody = null;

  if (shouldHideProfileInfo) {
    profileBody = isBlocked ? (
      <BlockedProfileView
        userId={profileUserId}
        username={safeNormalizedProfile.username}
        onUnblock={handleToggleBlock}
        isLoading={isToggling}
      />
    ) : (
      <ProfileUnavailableView />
    );
  } else {
    profileBody = (
      <>
        <div className="mt-0">
          <ProfileTabs activeTab={activeTab} onTabChange={handleTabChange} />
        </div>

        <div className="mt-6">
          <ProfileContent
            activeTab={activeTab}
            profileUserId={profileUserId}
            username={safeNormalizedProfile.username}
            fullName={displayName}
            isOwnProfile={isOwnProfile}
            isPrivateLocked={isPrivateLocked}
          />
        </div>
      </>
    );
  }

  return (
    <>
      <Seo {...profileSeo} />
      <div className="min-h-screen bg-background dark:bg-background-dark text-foreground dark:text-foreground-dark">
        <div className="w-full">
          <div className="overflow-hidden backdrop-blur">
            <ProfileCover
              displayName={displayName}
              username={safeNormalizedProfile.username}
              coverImage={safeNormalizedProfile.coverImage}
              coverPreviewImage={imagePreviews.cover}
              coverImageRevision={imageRevisions.cover}
              avatarImage={safeNormalizedProfile.profileImage}
              avatarPreviewImage={imagePreviews.profile}
              avatarImageRevision={imageRevisions.profile}
              isOwnProfile={isOwnProfile}
              isCoverUpdating={isUpdating && updatingAsset === "cover"}
              isAvatarUpdating={isUpdating && updatingAsset === "profile"}
              onEditCover={() => setIsEditCoverImageModalOpen(true)}
              onEditAvatar={() => setIsEditProfileImageModalOpen(true)}
              onCoverPreviewReady={() =>
                setImagePreviews((current) => ({ ...current, cover: null }))
              }
              onAvatarPreviewReady={() =>
                setImagePreviews((current) => ({ ...current, profile: null }))
              }
              onPreviewCover={(image) => {
                setPreviewImage(image);
                setIsPreviewOpen(true);
              }}
              onPreviewAvatar={(image) => {
                setPreviewImage(image);
                setIsPreviewOpen(true);
              }}
            />

            <div className="px-4 pb-8 pt-20 lg:px-24">
              <Motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.12 }}
                className={
                  shouldHideProfileInfo
                    ? "flex flex-col items-center text-center"
                    : "flex items-start justify-between gap-2 sm:gap-3"
                }
              >
                <div
                  className={`min-w-0 flex-1 leading-tight ${
                    shouldHideProfileInfo
                      ? "flex flex-col items-center text-center"
                      : ""
                  }`}
                >
                  <div
                    className={`flex flex-wrap items-center gap-1 lg:gap-2 ${
                      shouldHideProfileInfo ? "justify-center" : ""
                    }`}
                  >
                    <h1 className="truncate text-[20px] font-semibold tracking-[-0.03em] text-foreground dark:text-foreground-dark sm:text-[28px]">
                      {displayName}
                    </h1>
                    {!shouldHideProfileInfo ? profileBadges : null}
                  </div>

                  <p className="text-xs font-medium text-mutedForeground dark:text-mutedForeground-dark sm:text-sm">
                    @{safeNormalizedProfile.username}
                  </p>

                  {!shouldHideProfileInfo && safeNormalizedProfile.bio ? (
                    <p className="mt-1 text-xs italic leading-5 text-foreground/80 dark:text-foreground-dark/80 sm:text-sm">
                      {safeNormalizedProfile.bio}
                    </p>
                  ) : null}

                  {!shouldHideProfileInfo &&
                  (externalLink.href || safeNormalizedProfile.location) ? (
                    <div
                      className={`mt-1 flex flex-wrap items-center gap-2 ${
                        shouldHideProfileInfo ? "justify-center" : ""
                      }`}
                    >
                      {externalLink.href ? (
                        <a
                          href={externalLink.href}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1 rounded-full bg-muted/50 dark:bg-muted-dark/50 px-2 py-1 text-[11px] font-medium text-foreground dark:text-foreground-dark transition hover:bg-muted/80 sm:text-xs"
                        >
                          <Link2 className="h-3 w-3 text-mutedForeground dark:text-mutedForeground-dark" />
                          {externalLink.label}
                        </a>
                      ) : null}

                      {safeNormalizedProfile.location ? (
                        <span className="inline-flex items-center gap-1 rounded-full bg-muted/50 dark:bg-muted-dark/50 px-2 py-1 text-[11px] font-medium text-foreground dark:text-foreground-dark sm:text-xs">
                          <MapPin className="h-3 w-3 text-mutedForeground dark:text-mutedForeground-dark" />
                          {safeNormalizedProfile.location}
                        </span>
                      ) : null}
                    </div>
                  ) : null}
                </div>

                {!shouldHideProfileInfo ? (
                  <div className="flex shrink-0 justify-end">
                    <div className="flex w-full max-w-max flex-col gap-2">
                      <ProfileActions
                        isOwnProfile={isOwnProfile}
                        followButtonState={followButtonState}
                        isFollowLoading={isFollowLoading}
                        isMessageDisabled={
                          safeNormalizedProfile.isPrivate &&
                          !effectiveIsFollowing
                        }
                        onToggleFollow={toggleFollow}
                        onMessage={handleMessage}
                        onShare={handleShare}
                        onEditProfile={() => setIsEditDetailsModalOpen(true)}
                        onReport={handleReportUser}
                        isBlocked={shouldHideProfileInfo}
                        onToggleBlock={handleToggleBlock}
                      />
                    </div>
                  </div>
                ) : null}
              </Motion.div>

              <div className={shouldHideProfileInfo ? "mt-5" : "mt-3"}>
                <ProfileStats stats={stats} onStatClick={handleStatClick} />
              </div>

              <div className={shouldHideProfileInfo ? "mt-8" : "mt-6"}>
                {profileBody}
              </div>
            </div>
          </div>
        </div>

        <EditProfileDetailsModal
          isOpen={isEditDetailsModalOpen}
          onClose={() => setIsEditDetailsModalOpen(false)}
          profile={profile}
          onUpdate={handleUpdateProfile}
          isUpdating={isUpdating}
        />

        <EditProfileImageModal
          isOpen={isEditProfileImageModalOpen}
          onClose={() => setIsEditProfileImageModalOpen(false)}
          profile={profile}
          onUpdate={handleUpdateProfile}
          isUpdating={isUpdating}
        />

        <EditCoverImageModal
          isOpen={isEditCoverImageModalOpen}
          onClose={() => setIsEditCoverImageModalOpen(false)}
          profile={profile}
          onUpdate={handleUpdateProfile}
          isUpdating={isUpdating}
        />

        {!shouldHideProfileInfo ? (
          <FollowersModal
            isOpen={isFollowersModalOpen}
            onClose={() => setIsFollowersModalOpen(false)}
            userId={profileUserId}
            type="followers"
          />
        ) : null}

        {!shouldHideProfileInfo ? (
          <FollowingModal
            isOpen={isFollowingModalOpen}
            onClose={() => setIsFollowingModalOpen(false)}
            userId={profileUserId}
            type="following"
          />
        ) : null}

        <ImagePreviewModal
          isOpen={isPreviewOpen}
          onClose={() => setIsPreviewOpen(false)}
          image={previewImage}
        />
      </div>
    </>
  );
};

export default ProfilePage;
