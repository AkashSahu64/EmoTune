const profileRootKey = ["profile"];

export const profileKeys = {
  all: profileRootKey,
  byIdentifier: (identifier) => [
    ...profileRootKey,
    "identifier",
    String(identifier),
  ],
  byId: (id) => [...profileRootKey, "id", String(id)],
  followersPrefix: [...profileRootKey, "followers"],
  followers: (userId) => [...profileRootKey, "followers", String(userId)],
  followingPrefix: [...profileRootKey, "following"],
  following: (userId) => [...profileRootKey, "following", String(userId)],
};
