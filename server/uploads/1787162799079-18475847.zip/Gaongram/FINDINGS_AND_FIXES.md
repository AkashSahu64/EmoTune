# Project Analysis: Issues & Fixes

## Issue 1: Build/Release Infinite Loop (Build Hang)

### Root Cause Analysis

The build process defined in [`scripts/build.mjs`](scripts/build.mjs) runs three steps sequentially:
1. Vite production build
2. Generate profile snapshots ([`generate-profile-snapshots.mjs`](scripts/generate-profile-snapshots.mjs))
3. Run react-snap prerender ([`prerender.mjs`](scripts/prerender.mjs) → [`react-snap-runner.cjs`](scripts/react-snap-runner.cjs))

There are **multiple bugs** in [`scripts/generate-profile-snapshots.mjs`](scripts/generate-profile-snapshots.mjs) that cause the build to crash or hang.

---

### Bug 1.1: Undefined Function `fetchPublicProfiles()`

**File:** [`scripts/generate-profile-snapshots.mjs:179`](scripts/generate-profile-snapshots.mjs:179)

```js
usernames = await fetchPublicProfiles();
```

The function `fetchPublicProfiles()` is **never defined** anywhere in the file or imported. This throws a `ReferenceError` at runtime, causing the script to crash.

**✅ Fix Applied:** Added the missing [`fetchPublicProfiles()`](scripts/generate-profile-snapshots.mjs:142) function that fetches from `${API_BASE_URL}/profiles/public/` and handles the response format.

---

### Bug 1.2: Duplicate `fetchProfileData` Function Declaration

**File:** [`scripts/generate-profile-snapshots.mjs:145-165`](scripts/generate-profile-snapshots.mjs:145-165)

```js
// First declaration (line 145) - takes an object with .id
async function fetchProfileData(profile) { ... }

// Second declaration (line 161) - takes a string username
async function fetchProfileData(username) { ... }
```

In JavaScript, the **second function declaration overwrites the first** (function hoisting). The first version is never used. This is confusing and error-prone.

**✅ Fix Applied:** Removed the first duplicate declaration. Kept only the username-based version and added proper JSON response parsing (`json?.data || json`).

---

### Bug 1.3: Variable Name Mismatch in Loop and Catch Block

**File:** [`scripts/generate-profile-snapshots.mjs:193-209`](scripts/generate-profile-snapshots.mjs:193-209)

```js
for (const profile of usernames) {  // 'profile' is a STRING (username)
  // ...
  const targetDir = resolve("dist", "profile", profile.username); // BUG: strings don't have .username
  // ...
  console.error(`❌ Failed for ${username}:`, err.message); // BUG: 'username' not defined
}
```

Two issues:
1. `profile.username` — but `profile` is a **string** (username), not an object. This evaluates to `undefined`.
2. `username` is not defined in this scope. The loop variable is `profile`, not `username`. This causes a `ReferenceError`.

**✅ Fix Applied:** Renamed loop variable to `username` for clarity, changed `profile.username` to just `username`, and fixed the catch block to use the correct variable.

---

### Bug 1.4: Polling Loop in `prerender.mjs` Can Hang Indefinitely

**File:** [`scripts/prerender.mjs:243-263`](scripts/prerender.mjs:243-263)

The `waitForSnapshotsThenFinish()` function polls every 1 second for up to 60 seconds checking if snapshot files exist. However:

1. **Line 270:** The trigger to start polling checks for exact string `crawled ${crawlTotal} out of ${crawlTotal}`. If react-snap outputs a different format, polling **never starts**, and the process hangs until the 120-second global timeout.

2. **Line 200-202:** `snapshotsExist()` calls `writeStaticFallbackSnapshots()` **every time** it's invoked, which means during the 1-second polling loop, it's repeatedly writing files unnecessarily.

**✅ Fix Applied:**
- Added a `staticFallbackWritten` flag to ensure `writeStaticFallbackSnapshots()` runs only once
- Added multiple completion pattern detections instead of relying on a single string match

---

## Issue 2: Profile Page SEO Not Working Properly

### Root Cause Analysis

The profile page SEO has two layers:
1. **Client-side SEO** via [`<Seo>`](src/components/seo/Seo.jsx) component using `react-helmet-async`
2. **Build-time prerendered SEO** via [`generate-profile-snapshots.mjs`](scripts/generate-profile-snapshots.mjs)

Both layers have issues.

---

### Bug 2.1: Profile Query Disabled During Prerendering

**File:** [`src/hooks/useProfile.js:117-119`](src/hooks/useProfile.js:117-119)

```js
enabled:
  Boolean(identifier) &&
  !shouldSkipLiveSeoFetch({ allowConfiguredApi: true }),
```

The function [`shouldSkipLiveSeoFetch`](src/seo/seoUtils.js:15-17) returns `true` when:
- `navigator.userAgent === "ReactSnap"` (prerendering mode) AND
- `VITE_API_BASE_URL` is not configured

During build time, `VITE_API_BASE_URL` may not be set, so `shouldSkipLiveSeoFetch` returns `true`, making `enabled = false`. This means:
- The profile query is **disabled** during react-snap prerendering
- `profile` remains `undefined`
- `isLoading` is `false` (query is disabled, not loading)
- The profile page falls through to the "Profile Not Found" SEO

**✅ Fix Applied:** In [`ProfilePage.jsx`](src/features/profile/ProfilePage.jsx:439-451), added a prerender detection: when `profile` is null but `identifier` exists (from URL params), it generates a basic SEO object using just the username from the URL, so search engines get meaningful metadata instead of "Profile Not Found".

---

### Bug 2.2: Profile Snapshot Generation Script Fails (See Issue 1)

The [`generate-profile-snapshots.mjs`](scripts/generate-profile-snapshots.mjs) script is supposed to generate static HTML files with proper SEO for each profile at `dist/profile/{username}/index.html`. However, due to the bugs documented in Issue 1 (undefined function, variable mismatch, etc.), this script **crashes before generating any snapshots**.

**✅ Fix Applied:** All bugs in the script have been fixed (see Issue 1 fixes above).

---

### Bug 2.3: Data Shape Mismatch Between Normalized and Raw Profile

**File:** [`src/features/profile/ProfilePage.jsx:213-229`](src/features/profile/ProfilePage.jsx:213-229)

The `ProfilePage` passes `safeNormalizedProfile` (camelCase) to `buildProfileSeo`. The [`buildProfileSeo`](src/seo/seoBuilders.js:257-329) function checks both camelCase and snake_case keys, so it mostly works. However, edge cases exist where fields may be `undefined`.

**Status:** This is a minor issue. The `buildProfileSeo` function already has fallback logic for both naming conventions, so it works in most cases.

---

## Issue 3: Dev Server Profile SEO Not Working (ngrok/Social Share)

### Root Cause Analysis

When sharing a profile URL like `https://example.com/profile/abdur_8c60` on social media (WhatsApp, Twitter, etc.), the crawler fetches the page and reads the `<title>` and `<meta>` tags from the **server response**. In a Vite dev server:

1. All routes serve the same `index.html` with **default SEO** tags (site-wide title/description)
2. React's `react-helmet-async` updates SEO tags **client-side** after JavaScript executes
3. Social media crawlers (WhatsApp, Twitter, Facebook) **do not execute JavaScript** — they only read the initial HTML response
4. The build-time profile snapshots only cover profiles that existed during the build, not dynamic/new profiles

### Solution: Vite Middleware Plugin

**File:** [`scripts/vite-profile-seo-plugin.mjs`](scripts/vite-profile-seo-plugin.mjs)

Created a Vite plugin that intercepts `/profile/:identifier` requests **server-side** and injects profile-specific SEO meta tags before the HTML is sent to the client/crawler.

**How it works:**
1. Intercepts GET requests matching `/^\/profile\/([^\/]+)\/?$/` with `Accept: text/html`
2. Tries to fetch real profile data from `https://gaongram.com/api/v1/profiles/username/:identifier` (5s timeout)
3. If API succeeds: builds **rich SEO** with full name, avatar, follower counts, OG tags, Twitter cards, profile metadata
4. If API fails: builds **basic SEO** using the URL identifier with formatted display name
5. Injects the SEO tags before `</head>` in the HTML
6. Passes the modified HTML through `server.transformIndexHtml()` for Vite processing

**Registered in:** [`vite.config.js:22-25`](vite.config.js:22-25)

```js
import viteProfileSeoPlugin from "./scripts/vite-profile-seo-plugin.mjs";
export default defineConfig({
  plugins: [react(), viteProfileSeoPlugin()],
  ...
});
```

**Example output for `/profile/abdur_8c60`:**
```html
<title data-rh="true">Abdur 8c60 (@abdur_8c60) - GaonGram Profile</title>
<meta data-rh="true" name="description" content="View Abdur 8c60's profile on GaonGram..." />
<meta data-rh="true" property="og:type" content="profile" />
<meta data-rh="true" property="og:title" content="Abdur 8c60 (@abdur_8c60) - GaonGram Profile" />
<meta data-rh="true" property="og:description" content="..." />
<meta data-rh="true" property="profile:username" content="abdur_8c60" />
<meta data-rh="true" name="twitter:card" content="summary" />
<meta data-rh="true" name="twitter:title" content="Abdur 8c60 (@abdur_8c60) - GaonGram Profile" />
```

---

## Files Modified/Created

| File | Changes |
|------|---------|
| [`scripts/generate-profile-snapshots.mjs`](scripts/generate-profile-snapshots.mjs) | Added `fetchPublicProfiles()` function, removed duplicate `fetchProfileData`, fixed variable name mismatch in loop/catch |
| [`scripts/prerender.mjs`](scripts/prerender.mjs) | Added `staticFallbackWritten` flag to prevent repeated writes, added multiple completion pattern detections |
| [`src/features/profile/ProfilePage.jsx`](src/features/profile/ProfilePage.jsx) | Added prerender fallback SEO using URL identifier when profile query is disabled |
| [`scripts/profiles.json`](scripts/profiles.json) | **Created** — Fallback profile list when API is unavailable during build |
| [`scripts/vite-profile-seo-plugin.mjs`](scripts/vite-profile-seo-plugin.mjs) | **Created** — Vite middleware plugin for server-side profile SEO injection |
| [`vite.config.js`](vite.config.js) | Added import and registration of `viteProfileSeoPlugin` |
| [`FINDINGS_AND_FIXES.md`](FINDINGS_AND_FIXES.md) | This documentation file |