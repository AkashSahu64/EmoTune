import React, { useState } from "react";
import { ArrowLeft, Check, Sparkles, Palette, Image as ImageIcon } from "lucide-react";
import { CHAT_THEMES } from "../../../utils/chatThemes";
import { useChatThemeStore } from "../../../store/chatThemeStore";

const ThemePicker = ({ onClose }) => {
  const { currentTheme, setTheme } = useChatThemeStore();

  const [selectedTheme, setSelectedTheme] = useState(currentTheme);

  const colorThemes = Object.values(CHAT_THEMES).filter(
    (theme) => !theme.category || theme.category === "color"
  );

  const wallpaperThemes = Object.values(CHAT_THEMES).filter(
    (theme) => theme.category === "wallpaper"
  );

  const animatedThemes = Object.values(CHAT_THEMES).filter(
    (theme) => theme.category === "animated"
  );

  const ThemeCard = ({ theme }) => (
    <button
      onClick={() => setSelectedTheme(theme.id)}
      className={`relative overflow-hidden rounded-2xl border transition-all duration-300 hover:scale-[1.02] ${
        selectedTheme === theme.id
          ? "border-[#00684A] shadow-lg shadow-emerald-100"
          : "border-gray-200"
      }`}
    >
      <div
        className="h-24 p-2 flex flex-col justify-between"
        style={{
          background: theme.wallpaper,
        }}
      >
        <div className="flex justify-between items-start">
          {theme.category === "animated" && (
            <div className="px-2 py-0.5 rounded-full bg-white/80 text-[10px] font-medium">
              Animated
            </div>
          )}

          {selectedTheme === theme.id && (
            <div className="w-6 h-6 rounded-full bg-[#00684A] flex items-center justify-center ml-auto">
              <Check size={14} className="text-white" />
            </div>
          )}
        </div>

        <div className="space-y-1">
          <div
            className="ml-auto w-16 h-4 rounded-full"
            style={{
              background: theme.sentBubble,
            }}
          />

          <div
            className="w-14 h-4 rounded-full"
            style={{
              background: theme.receivedBubble,
            }}
          />
        </div>
      </div>

      <div className="px-3 py-2 bg-white">
        <h4 className="font-medium text-xs text-left">
          {theme.name}
        </h4>
      </div>
    </button>
  );

  return (
    <div className="w-full h-full bg-[#F8FAFC] flex flex-col">

      {/* Header */}

      <div className="sticky top-0 z-20 bg-white border-b border-gray-200">
        <div className="flex items-center gap-3 px-5 py-4">

          <button
            onClick={onClose}
            className="w-10 h-10 rounded-xl border border-gray-200 flex items-center justify-center hover:bg-gray-50"
          >
            <ArrowLeft size={18} />
          </button>

          <div>
            <h2 className="text-lg font-bold text-gray-900">
              Chat Themes
            </h2>

            <p className="text-xs text-gray-500">
              Customize your conversation
            </p>
          </div>
        </div>
      </div>

      {/* Scroll Area */}

      <div className="flex-1 overflow-y-auto p-5">

        {/* Color Themes */}

        <div className="mb-8">
          <div className="flex items-center gap-2 mb-3">
            <Palette size={18} className="text-[#00684A]" />
            <h3 className="font-semibold">
              Color Themes
            </h3>
          </div>

          <div className="grid grid-cols-3 gap-3">
            {colorThemes.map((theme) => (
              <ThemeCard key={theme.id} theme={theme} />
            ))}
          </div>
        </div>

        {/* Wallpapers */}

        {wallpaperThemes.length > 0 && (
          <div className="mb-8">

            <div className="flex items-center gap-2 mb-3">
              <ImageIcon size={18} className="text-[#00684A]" />
              <h3 className="font-semibold">
                Wallpapers
              </h3>
            </div>

            <div className="grid grid-cols-3 gap-3">
              {wallpaperThemes.map((theme) => (
                <ThemeCard key={theme.id} theme={theme} />
              ))}
            </div>
          </div>
        )}

        {/* Animated */}

        {animatedThemes.length > 0 && (
          <div>

            <div className="flex items-center gap-2 mb-3">
              <Sparkles size={18} className="text-[#00684A]" />
              <h3 className="font-semibold">
                Animated Themes
              </h3>
            </div>

            <div className="grid grid-cols-3 gap-3">
              {animatedThemes.map((theme) => (
                <ThemeCard key={theme.id} theme={theme} />
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Apply Button */}

      <div className="border-t bg-white p-4">

        <button
          onClick={() => {
            setTheme(selectedTheme);
            onClose();
          }}
          className="w-full h-12 rounded-xl bg-[#00684A] text-white font-semibold hover:bg-[#00553d] transition"
        >
          Apply Theme
        </button>

      </div>

    </div>
  );
};

export default ThemePicker;