/**
 * Apply image filters using Canvas API
 */

export function applyImageFilters(imageSrc, filters = {}) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(imageSrc);
        return;
      }

      // Apply filters using CSS filter string
      let filterString = '';
      
      if (filters.brightness !== undefined) {
        filterString += `brightness(${filters.brightness}%) `;
      }
      
      if (filters.contrast !== undefined) {
        filterString += `contrast(${filters.contrast}%) `;
      }
      
      if (filters.saturation !== undefined) {
        filterString += `saturate(${filters.saturation}%) `;
      }
      
      if (filters.blur !== undefined) {
        filterString += `blur(${filters.blur}px) `;
      }

      // Apply filters via CSS
      ctx.filter = filterString.trim();
      ctx.drawImage(img, 0, 0);

      // Convert back to blob
      canvas.toBlob((blob) => {
        if (blob) {
          resolve({
            blob,
            url: URL.createObjectURL(blob),
            width: img.width,
            height: img.height,
          });
        }
      }, 'image/jpeg');
    };
    img.src = imageSrc;
  });
}

/**
 * Create filter presets
 */
export const FILTER_PRESETS = {
  none: { brightness: 100, contrast: 100, saturation: 100 },
  vivid: { brightness: 110, contrast: 120, saturation: 130 },
  soft: { brightness: 105, contrast: 95, saturation: 90 },
  dramatic: { brightness: 90, contrast: 130, saturation: 110 },
  warm: { brightness: 105, contrast: 105, saturation: 115 },
  cool: { brightness: 100, contrast: 110, saturation: 85 },
};

/**
 * Generate filter previews
 */
export async function generateFilterPreviews(imageSrc, presets = FILTER_PRESETS) {
  const previews = {};
  
  for (const [name, filters] of Object.entries(presets)) {
    const result = await applyImageFilters(imageSrc, filters);
    previews[name] = result.url;
  }
  
  return previews;
}