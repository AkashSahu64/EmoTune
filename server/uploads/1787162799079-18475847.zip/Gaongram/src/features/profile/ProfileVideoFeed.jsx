// src/pages/ProfileVideoFeed.jsx
import React, { useEffect, useState, useRef, useCallback } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Play, Music, Eye } from "lucide-react";
import { vibeService } from "../../services/vibe.service.js";
import { useAuthStore } from "../../store/authStore.js";
import { useMediaStore } from "../../store/mediaStore.js";
import { useInteractionTracker } from "../../hooks/useInteractionTracker.js";
import { formatNumber } from "../../utils/formatTime.js";
import Avatar from "../../components/common/Avatar.jsx";
import Loader from "../../components/common/Loader.jsx";
import EmptyState from "../../components/common/EmptyState.jsx";
import Seo from "../../components/seo/Seo.jsx";
import FollowButton from "../../components/common/FollowButton.jsx";
import PostActionButtons from "../../components/common/PostActionButtons.jsx";
import SensitiveContentSettingsModal from "../../components/modals/SensitiveContentSettingsModal.jsx";
import AgeRestrictedModal from "../../components/modals/AgeRestrictedModal.jsx";
import SensitiveContentOverlay from "../../components/vibe/SensitiveContentOverlay.jsx";
import { calculateAge } from "../../utils/calculateAge.js";
import { useTranslation } from "react-i18next";
import Hls from "hls.js";

// Direct URL getter – no nested arrays
const getVideoSources = (video) => {
  return {
    hls: video?.hls_playlist || null,
    mp4: video?.video || null,
  };
};

const ReelItem = React.memo(
  ({
    video,
    index,
    isVisible,
    onVideoTap,
    onPostUpdate,
    user,
    isOwner,
    videoUrl,
    thumbnail,
    duration,
    userInteracted,
    navigate,
    preloadRef,
    videoSources,
    videoRefs,
    isSensitiveBlocked,
    onSensitiveClick,
  }) => {
    const videoRef = useRef(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [progress, setProgress] = useState(0);
    const [isSeeking, setIsSeeking] = useState(false);
    const [orientation, setOrientation] = useState("portrait");
    const [currentVideoUrl, setCurrentVideoUrl] = useState(
      videoSources?.hls || videoSources?.mp4 || null,
    );

    useInteractionTracker({
      postId: video.id,
      isVisible,
      mediaType: "video",
      mediaRef: videoRef,
      duration,
    });

    const handleMetadata = () => {
      if (!videoRef.current) return;

      const video = videoRef.current;

      const aspect = video.videoWidth / video.videoHeight;

      setOrientation(aspect < 1 ? "portrait" : "landscape");
    };

    useEffect(() => {
      const video = videoRef.current;

      if (!video || !currentVideoUrl) return;

      let hls;

      const isHls = currentVideoUrl.includes(".m3u8");

      // ---------------- HLS ----------------

      if (isHls) {
        let fallbackTimeout;

        // Safari Native HLS
        if (video.canPlayType("application/vnd.apple.mpegurl")) {
          video.src = currentVideoUrl;

          video.load();

          if (isVisible) {
            video.play().catch((err) => {
              console.error("[SAFARI PLAY ERROR]", err);
            });
          }

          fallbackTimeout = setTimeout(() => {
            if (
              video.readyState < 2 &&
              videoSources?.mp4 &&
              currentVideoUrl !== videoSources.mp4
            ) {
              console.log("[SAFARI FALLBACK TO MP4]");

              setCurrentVideoUrl(videoSources.mp4);
            }
          }, 1000);
        }

        // Chrome / Edge / Firefox
        else if (Hls.isSupported()) {
          hls = new Hls({
            enableWorker: true,
            lowLatencyMode: true,
          });

          hls.loadSource(currentVideoUrl);

          hls.attachMedia(video);

          fallbackTimeout = setTimeout(() => {
            if (
              video.readyState < 2 &&
              videoSources?.mp4 &&
              currentVideoUrl !== videoSources.mp4
            ) {
              console.log("[HLS TIMEOUT FALLBACK]");

              hls.destroy();

              setCurrentVideoUrl(videoSources.mp4);
            }
          }, 1000);

          hls.on(Hls.Events.MANIFEST_PARSED, () => {
            clearTimeout(fallbackTimeout);

            if (isVisible) {
              video.play().catch((err) => {
                console.error("[HLS PLAY ERROR]", err);
              });
            }
          });

          hls.on(Hls.Events.ERROR, (_, data) => {
            console.error("[HLS ERROR]", data);

            if (videoSources?.mp4 && currentVideoUrl !== videoSources.mp4) {
              clearTimeout(fallbackTimeout);

              hls.destroy();

              setCurrentVideoUrl(videoSources.mp4);
            }
          });
        }
      }

      // ---------------- MP4 ----------------
      else {
        video.src = currentVideoUrl;

        video.load();

        if (isVisible) {
          video.play().catch((err) => {
            console.error("[MP4 PLAY ERROR]", err);
          });
        }
      }

      // play state listeners

      const onPlay = () => setIsPlaying(true);

      const onPause = () => setIsPlaying(false);

      let animationFrame;

      const updateProgress = () => {
        if (!video || !video.duration || isSeeking) {
          animationFrame =
            requestAnimationFrame(updateProgress);

          return;
        }

        setProgress(
          (video.currentTime / video.duration) * 100,
        );

        animationFrame =
          requestAnimationFrame(updateProgress);
      };

      animationFrame = requestAnimationFrame(updateProgress);

      video.addEventListener("play", onPlay);

      video.addEventListener("pause", onPause);

      return () => {
        video.removeEventListener("play", onPlay);

        video.removeEventListener("pause", onPause);

        cancelAnimationFrame(animationFrame);

        video.pause();

        video.currentTime = 0;

        video.removeAttribute("src");

        video.load();

        if (hls) {
          hls.destroy();
        }
      };
    }, [currentVideoUrl, isVisible]);

    const handleSeek = (e) => {
      const video = videoRef.current;

      if (!video || !video.duration) return;

      const rect =
        e.currentTarget.getBoundingClientRect();

      const percent =
        (e.clientX - rect.left) / rect.width;

      video.currentTime =
        percent * video.duration;

      setProgress(percent * 100);
    };

    const captionText = video.caption || video.content || "";

    return (
      <div
        ref={preloadRef}
        className="relative h-[calc(100dvh-4rem)] w-full shrink-0 snap-start snap-always overflow-hidden bg-background dark:bg-black md:h-[100dvh]"
        data-video-id={video.id}
      >
        <div
          className={`relative w-full mx-auto flex items-center justify-center overflow-hidden
          ${
            orientation === "portrait"
              ? "h-full max-h-full max-w-[420px]"
              : "h-full max-h-full max-w-[420px]"
          }`}
        >
          <video
            ref={(el) => {
              videoRef.current = el;

              if (el) {
                videoRefs.current[index] = el;
              }
            }}
            className={`w-full h-full bg-black transition-all duration-300
             ${orientation === "portrait" ? "object-cover" : "object-contain"}
             ${isSensitiveBlocked ? " blur-2xl scale-110 brightness-50" : ""}
            `}
            playsInline
            loop
            muted={!userInteracted}
            onLoadedMetadata={handleMetadata}
            onClick={() => {
              if (isSensitiveBlocked) {
                onSensitiveClick?.();
                return;
              }

              onVideoTap(video.id, index, videoRef);
            }}
            poster={thumbnail}
            preload="metadata"
            style={{ touchAction: "manipulation" }}
          />
          {isSensitiveBlocked && (
            <SensitiveContentOverlay onClick={onSensitiveClick} />
          )}
          {/* SEEK BAR */}
          <div className="absolute bottom-0 left-0 w-full z-20 px-2 pb-1">
            <div
              className="relative h-1 w-full cursor-pointer rounded-full bg-primary/25"
              onClick={handleSeek}
            >
              <div
                className="absolute left-0 top-0 h-full rounded-full bg-primary"
                style={{
                  width: `${progress}%`,
                }}
              />

              <div
                className="absolute top-1/2 h-3 w-3 -translate-y-1/2 rounded-full bg-primary shadow-md"
                style={{
                  left: `calc(${progress}% - 6px)`,
                }}
              />
            </div>
          </div>
          {!isPlaying && (
            <div
              className="absolute inset-0 flex items-center justify-center cursor-pointer"
              onClick={() => onVideoTap(video.id, index, videoRef)}
            >
              <div className="p-2.5 rounded-full bg-black/40 backdrop-blur-sm">
                <Play className="w-8 h-8 ml-0.5 text-white/90" fill="white" />
              </div>
            </div>
          )}
          {/* Right action bar */}
          <div className="absolute right-0 bottom-6 flex flex-col items-center gap-5 z-10 pr-1">
            {video.views_count > 0 && (
              <div className="flex flex-col items-center text-white text-xs">
                <Eye className="w-5 h-5 mb-0.5" />
                <span>{formatNumber(video.views_count)}</span>
              </div>
            )}
            <PostActionButtons
              postId={video.feed_post || video.id}
              postType="reels"
              isLiked={video.is_liked}
              likeCount={video.likes_count || 0}
              commentCount={video.comments_count || 0}
              isOwner={isOwner}
              size="large"
              layout="vertical"
              onUpdate={(updates) =>
                onPostUpdate(video.feed_post || video.id, updates)
              }
              showViewCount={false}
              showCommentsCount
              className="space-y-0"
            />
          </div>
          {/* Bottom user info */}
          <div className="absolute bottom-1 lg:bottom-0 left-0 right-0 px-4 z-10 pb-[env(safe-area-inset-bottom)]">
            <div className="flex items-start gap-3 max-w-[90%] pointer-events-auto">
              <div
                className="cursor-pointer"
                onClick={() =>
                  video.user?.id && navigate(`/profile/${video.user.id}`)
                }
              >
                <Avatar
                  src={video.user?.avatar}
                  alt={video.user?.username}
                  size="small"
                  className="border border-white/50"
                />
              </div>
              <div className="flex-1 min-w-0 mb-3">
                <div className="flex items-center gap-2 mb-0 flex-wrap">
                  <h3
                    className="font-semibold text-muted text-sm truncate cursor-pointer"
                    onClick={() =>
                      video.author && navigate(`/profile/${video.author}`)
                    }
                  >
                    @{video.user?.username || "user"}
                  </h3>
                  {video.user?.id !== user?.id && (
                    <FollowButton
                      profileId={video.user?.id}
                      size="extra-small"
                      className="ml-2"
                    />
                  )}
                </div>
                {captionText ? (
                  <p className="text-mutedForeground text-xs mb-1 line-clamp-2 break-words">
                    {captionText}
                  </p>
                ) : (
                  <p className="text-xs text-mutedForeground dark:text-white/50">
                    No caption
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  },
);

const ProfileVideoFeed = () => {
  const { user } = useAuthStore();
  const profileDob = user?.dob || user?.profile?.dob;
  const [showSensitiveSettingsModal, setShowSensitiveSettingsModal] =
    useState(false);

  const [showAgeRestrictedModal, setShowAgeRestrictedModal] = useState(false);

  const age = calculateAge(profileDob);

  const isUnder18 = typeof age === "number" && age < 18;

  const sensitiveAllowed =
    user?.is_sensitive_allowed ?? user?.profile?.is_sensitive_allowed;

  const canViewSensitive =
    sensitiveAllowed === true && typeof age === "number" && !isUnder18;
  const { setUserInteracted, userInteracted } = useMediaStore();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [searchParams] = useSearchParams();
  const startVideoId = searchParams.get("start");
  const targetUserId = searchParams.get("user");

  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [error, setError] = useState(null);
  const [visibilityStates, setVisibilityStates] = useState({});
  const [videoDurations, setVideoDurations] = useState({});

  const videoRefs = useRef([]);
  const observerRef = useRef(null);
  const preloadObserverRef = useRef(null);
  const currentPage = useRef(1);

  const handleSensitiveClick = useCallback(() => {
    if (isUnder18) {
      setShowAgeRestrictedModal(true);
      return;
    }

    setShowSensitiveSettingsModal(true);
  }, [isUnder18]);

  const handlePostUpdate = (postId, updates) => {
    setVideos((prev) =>
      prev.map((v) => {
        const currentPostId = v.feed_post || v.id;

        if (currentPostId === postId) {
          return {
            ...v,

            is_liked:
              typeof updates.is_liked !== "undefined"
                ? updates.is_liked
                : v.is_liked,

            likes_count:
              typeof updates.total_likes !== "undefined"
                ? updates.total_likes
                : v.likes_count,

            comments_count:
              typeof updates.comments_count === "function"
                ? updates.comments_count(v.comments_count || 0)
                : typeof updates.comments_count !== "undefined"
                  ? updates.comments_count
                  : v.comments_count,
          };
        }

        return v;
      }),
    );
  };

  // Fetch raw profile videos – no transformation
  const fetchVideos = async (page, append = false) => {
    if (!targetUserId) return;
    try {
      const res = await vibeService.getProfileUserVideos(targetUserId, {
        page,
      });
      const rawItems = res.data?.results || [];
      const nextUrl = res.data?.next;
      setHasMore(!!nextUrl);
      setVideos((prev) => (append ? [...prev, ...rawItems] : rawItems));
    } catch (err) {
      console.error("[ProfileVideoFeed] fetch error:", err);
      setError(err.message || "Failed to load videos");
    }
  };

  // Initial load
  useEffect(() => {
    const init = async () => {
      if (!targetUserId) {
        setError("No user specified");
        setLoading(false);
        return;
      }
      setLoading(true);
      setError(null);
      setVideos([]);
      currentPage.current = 1;
      setHasMore(true);
      await fetchVideos(1, false);
      setLoading(false);
    };
    init();
  }, [targetUserId]);

  // Auto-scroll to start video
  useEffect(() => {
    if (!loading && startVideoId && videos.length > 0) {
      const timer = setTimeout(() => {
        const el = document.querySelector(`[data-video-id="${startVideoId}"]`);
        if (el) el.scrollIntoView({ behavior: "auto", block: "start" });
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [loading, startVideoId, videos]);

  // Load more
  const loadMore = useCallback(async () => {
    if (loadingMore || !hasMore) return;
    try {
      setLoadingMore(true);
      currentPage.current += 1;
      await fetchVideos(currentPage.current, true);
    } catch (err) {
      console.error("loadMore error:", err);
    } finally {
      setLoadingMore(false);
    }
  }, [loadingMore, hasMore, targetUserId]);

  // Preload sentinel
  const preloadRef = useCallback(
    (node) => {
      if (loadingMore || !hasMore) return;
      if (preloadObserverRef.current) preloadObserverRef.current.disconnect();
      preloadObserverRef.current = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) loadMore();
        },
        { threshold: 0.5, rootMargin: "300px" },
      );
      if (node) preloadObserverRef.current.observe(node);
    },
    [loadingMore, hasMore, loadMore],
  );

  // Play/pause observer
  const handleIntersect = useCallback(
    (entries) => {
      entries.forEach((entry) => {
        const videoContainer = entry.target;
        const videoElement = videoContainer.querySelector("video");
        const videoId = videoContainer.dataset.videoId;
        if (!videoElement || !videoId) return;

        const isVisible =
          entry.isIntersecting && entry.intersectionRatio >= 0.7;
        setVisibilityStates((prev) => ({ ...prev, [videoId]: isVisible }));

        const videoIndex = videos.findIndex((v) => String(v.id) === videoId);
        if (isVisible) {
          videoRefs.current.forEach((other, idx) => {
            if (other && idx !== videoIndex) other.pause();
          });
          videoElement.play().catch((err) => {
            if (err.name === "NotAllowedError") {
              videoElement.muted = true;
              videoElement.play().catch(() => {});
            }
          });
        } else if (!entry.isIntersecting || entry.intersectionRatio < 0.3) {
          videoElement.pause();
        }
      });
    },
    [videos],
  );

  useEffect(() => {
    if (!videos?.length) return;
    if (observerRef.current) observerRef.current.disconnect();
    observerRef.current = new IntersectionObserver(handleIntersect, {
      threshold: 0.7,
      root: null,
      rootMargin: "0px",
    });
    const containers = document.querySelectorAll("[data-video-id]");
    containers.forEach((container) => observerRef.current.observe(container));
    return () => observerRef.current?.disconnect();
  }, [videos, handleIntersect]);

  const handleVideoTap = (videoId, index, videoRef) => {
    const video = videoRef.current;
    if (!video) return;
    if (!userInteracted) {
      setUserInteracted();
      video.muted = false;
    }
    if (video.paused) {
      video.play().catch((err) => {
        if (err.name === "NotAllowedError") {
          video.muted = true;
          video.play().catch(() => {});
        }
      });
      videoRefs.current.forEach((other, idx) => {
        if (other && idx !== index) other.pause();
      });
    } else {
      video.pause();
    }
  };

  useEffect(() => {
    return () => {
      videoRefs.current.forEach((video) => video?.pause());
      observerRef.current?.disconnect();
      preloadObserverRef.current?.disconnect();
    };
  }, []);

  if (loading) {
    return (
      <div className="flex h-[calc(100dvh-4rem)] items-center justify-center bg-background dark:bg-black md:h-[100dvh]">
        <Loader />
      </div>
    );
  }

  if (!loading && videos.length === 0) {
    return (
      <div className="flex h-[calc(100dvh-4rem)] items-center justify-center bg-background dark:bg-black md:h-[100dvh]">
        <EmptyState
          icon="video"
          title="No videos"
          description="This user hasn't uploaded any videos yet."
          darkMode
        />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex h-[calc(100dvh-4rem)] items-center justify-center text-red-500 md:h-[100dvh]">
        Error: {error}
      </div>
    );
  }

  return (
    <>
      <Seo
        title="Profile Videos"
        description={`Videos from user ${targetUserId}`}
      />
      <div className="relative h-[calc(100dvh-4rem)] w-full overflow-hidden bg-background dark:bg-black md:h-[100dvh]">
        <div className="h-full w-full overflow-y-auto snap-y snap-mandatory scroll-smooth overscroll-contain hide-scrollbar">
          {videos.map((video, index) => {
            const isSensitiveBlocked =
              video.is_sensitive === true && !canViewSensitive;
            const videoSources = getVideoSources(video);

            const videoUrl = videoSources.hls || videoSources.mp4;
            if (!videoUrl) return null;
            const isPreloadTrigger = index === videos.length - 3;
            return (
              <ReelItem
                key={`profile-reel-${video.id}-${index}`}
                video={video}
                index={index}
                videoSources={videoSources}
                videoRefs={videoRefs}
                isVisible={!!visibilityStates[video.id]}
                onVideoTap={handleVideoTap}
                onPostUpdate={handlePostUpdate}
                user={user}
                isOwner={String(video.user?.id) === String(user?.id)}
                videoUrl={videoUrl}
                thumbnail={video.thumbnail}
                duration={videoDurations[video.id] || 0}
                userInteracted={userInteracted}
                navigate={navigate}
                preloadRef={isPreloadTrigger ? preloadRef : null}
                isSensitiveBlocked={isSensitiveBlocked}
                onSensitiveClick={handleSensitiveClick}
              />
            );
          })}
          {loadingMore && (
            <div className="flex h-[calc(100dvh-4rem)] shrink-0 snap-start snap-always items-center justify-center bg-background dark:bg-black md:h-[100dvh]">
              <Loader />
              <p className="text-foreground dark:text-white/70 mt-4 text-sm">
                Loading more videos...
              </p>
            </div>
          )}
        </div>
      </div>
      <SensitiveContentSettingsModal
        isOpen={showSensitiveSettingsModal}
        onClose={() => setShowSensitiveSettingsModal(false)}
      />

      <AgeRestrictedModal
        isOpen={showAgeRestrictedModal}
        onClose={() => setShowAgeRestrictedModal(false)}
      />
    </>
  );
};

export default ProfileVideoFeed;
