// src/pages/ProfileFeedPage.jsx
import React, { useEffect, useMemo, useCallback } from "react";
import { useParams } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useProfile } from "../../hooks/useProfile";
import { useProfileContent } from "../../features/profile/useProfileContent";
import { useMediaStore } from "../../store/mediaStore";
import PostFeedList from "../../components/feed/PostFeedList";
import Seo from "../../components/seo/Seo.jsx";
import { buildPostSeo } from "../../seo/seoBuilders.js";
import { shouldSkipLiveSeoFetch } from "../../seo/seoUtils.js";
import { vibeService } from "../../services/vibe.service.js";

const ProfileFeedPage = () => {
  const { username, postId } = useParams();
  const skipLiveFetch = shouldSkipLiveSeoFetch({
    allowConfiguredApi: Boolean(postId),
  });
  const {
    profile,
    normalizedProfile,
    isLoading: profileLoading,
  } = useProfile(username);
  const queryClient = useQueryClient();
  const setActivePost = useMediaStore((s) => s.setActivePost);

  const profileUserId = normalizedProfile?.userId || profile?.id || null;

  const { data: postSeoResponse } = useQuery({
    queryKey: ["post-seo", String(postId || "")],
    queryFn: () => vibeService.getVibePost(postId),
    enabled: Boolean(postId) && !skipLiveFetch,
    staleTime: 5 * 60 * 1000,
  });

  const {
    items,
    isLoading: postsLoading,
    hasNextPage,
    fetchNextPage,
    isFetchingNextPage,
  } = useProfileContent(profileUserId, "posts");

  const enrichedItems = useMemo(() => {
    if (!normalizedProfile) return [];

    const avatar = normalizedProfile.profileImage || "";

    // KEEP CLICKED POST FIRST
    const sortedItems = [...items].sort((a, b) => {
      if (String(a.id) === String(postId)) return -1;
      if (String(b.id) === String(postId)) return 1;
      return 0;
    });

    console.log("PROFILE ITEMS", items);
    return sortedItems.map((item) => ({
      id: item.id,

      user: {
        id: item.userId,
        username,
        avatar,
        is_private: normalizedProfile.isPrivate,
        is_verified: normalizedProfile.isVerified,
      },

      caption: item.caption,

      is_sensitive: item.is_sensitive ?? item.isSensitive ?? false,

      created_at: item.createdAt,

      views_count: item.views_count ?? item.viewsCount ?? 0,

      likes_count: item.likes_count ?? item.likesCount ?? 0,

      comments_count: item.comments_count ?? item.commentsCount ?? 0,

      is_liked: typeof item.is_liked === "boolean" ? item.is_liked : false,

      media_type: item.mediaType,

      media_url: null,

      images: item.images || [],

      videos: item.videos || [],

      audio: item.audio || null,

      poll:
        item.poll ||
        (item.mediaType === "poll"
          ? {
              poll_question: item.poll_question,

              poll_options: item.poll_options || [],

              poll_votes: item.poll_votes || {},

              // ✅ IMPORTANT
              user_vote: item.user_vote ?? item.poll?.user_vote ?? null,

              expires_at: item.expires_at ?? item.poll?.expires_at ?? null,
            }
          : null),

      // ✅ ALSO KEEP ROOT LEVEL
      user_vote: item.user_vote ?? item.poll?.user_vote ?? null,

      is_following: normalizedProfile.isFollowing,
    }));
  }, [items, normalizedProfile, username, postId]);

  const targetPostForSeo = useMemo(() => {
    const directPost = postSeoResponse?.data || postSeoResponse;
    if (directPost?.id) return directPost;
    return enrichedItems.find((item) => String(item.id) === String(postId));
  }, [enrichedItems, postId, postSeoResponse]);

  const postSeo = useMemo(
    () =>
      buildPostSeo(
        targetPostForSeo || { id: postId },
        normalizedProfile || {},
        {
          postId,
          path: `/profile/${username || "user"}/post/${postId || ""}`,
        },
      ),
    [normalizedProfile, postId, targetPostForSeo, username],
  );

  const targetFoundRef = React.useRef(false);
  useEffect(() => {
    if (postsLoading || !postId) return;
    const exists = enrichedItems.some((p) => String(p.id) === String(postId));
    if (exists) {
      targetFoundRef.current = true;
      return;
    }
    if (hasNextPage && !targetFoundRef.current) {
      fetchNextPage();
    }
  }, [enrichedItems, hasNextPage, fetchNextPage, postsLoading, postId]);

  const [hasScrolledToTarget, setHasScrolledToTarget] = React.useState(false);
  useEffect(() => {
    if (
      !hasScrolledToTarget &&
      targetFoundRef.current &&
      enrichedItems.length > 0
    ) {
      const el = document.querySelector(`[data-post-id="${postId}"]`);
      if (el) {
        el.scrollIntoView({ behavior: "auto", block: "center" });
        setHasScrolledToTarget(true);
      } else {
        requestAnimationFrame(() => {
          const el2 = document.querySelector(`[data-post-id="${postId}"]`);
          if (el2) {
            el2.scrollIntoView({ behavior: "auto", block: "center" });
            setHasScrolledToTarget(true);
          }
        });
      }
    }
  }, [enrichedItems, hasScrolledToTarget, postId, setActivePost]);

  const handlePostUpdate = useCallback(
    (updatedPostId, updates) => {
      const queryKey = [
        "profile-content",
        String(profileUserId || ""),
        "posts",
      ];

      queryClient.setQueryData(queryKey, (oldData) => {
        if (!oldData) return oldData;

        return {
          ...oldData,
          pages: oldData.pages.map((page) => ({
            ...page,
            items: page.items.map((item) => {
              if (String(item.id) !== String(updatedPostId)) {
                return item;
              }

              return {
                ...item,

                // preserve all updates
                ...updates,

                // stable normalized fields
                is_liked:
                  typeof updates.is_liked !== "undefined"
                    ? updates.is_liked
                    : item.is_liked,

                likes_count:
                  typeof updates.total_likes !== "undefined"
                    ? updates.total_likes
                    : typeof updates.likes_count !== "undefined"
                      ? updates.likes_count
                      : item.likes_count,

                comments_count:
                  typeof updates.comments_count === "function"
                    ? updates.comments_count(
                        item.comments_count ?? item.commentsCount ?? 0,
                      )
                    : typeof updates.comments_count !== "undefined"
                      ? updates.comments_count
                      : (item.comments_count ?? item.commentsCount ?? 0),

                // ✅ IMPORTANT
                commentsCount:
                  typeof updates.comments_count === "function"
                    ? updates.comments_count(
                        item.commentsCount ?? item.comments_count ?? 0,
                      )
                    : typeof updates.comments_count !== "undefined"
                      ? updates.comments_count
                      : (item.commentsCount ?? item.comments_count ?? 0),
              };
            }),
          })),
        };
      });
    },
    [profileUserId, queryClient],
  );

  if (profileLoading || (!profileUserId && !postsLoading)) {
    return (
      <>
        <Seo {...postSeo} />
        <div className="flex justify-center py-20 text-muted-foreground">
          Loading profile...
        </div>
      </>
    );
  }

  if (!profileUserId) {
    return (
      <>
        <Seo
          title="Post Not Found"
          description="This GaonGram post is unavailable or may have been removed."
          canonical={`/profile/${username || ""}/post/${postId || ""}`}
          noindex
        />
        <div className="flex justify-center py-20 text-muted-foreground">
          Profile not found.
        </div>
      </>
    );
  }

  return (
    <>
      <Seo {...postSeo} />
      <div className="max-w-md mx-auto px-4 pb-2 pt-1">
        <PostFeedList
          items={enrichedItems}
          targetPostId={postId}
          isLoading={postsLoading}
          hasNextPage={hasNextPage}
          isFetchingNextPage={isFetchingNextPage}
          fetchNextPage={fetchNextPage}
          onPostUpdate={handlePostUpdate}
        />
      </div>
    </>
  );
};

export default ProfileFeedPage;
