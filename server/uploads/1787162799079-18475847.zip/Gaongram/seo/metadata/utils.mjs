/* global Intl, URL */
import { SEO_CONFIG, getSiteUrl } from "./config.mjs";

const ABSOLUTE_URL_RE = /^https?:\/\//i;
const LOCAL_HOST_RE = /^(localhost|127(?:\.\d{1,3}){3}|\[?::1\]?)$/i;

const isLocalUrl = (value) => {
  try {
    return LOCAL_HOST_RE.test(new URL(value).hostname);
  } catch {
    return false;
  }
};

export const cleanText = (value = "") =>
  String(value)
    .replace(/<[^>]*>/g, " ")
    .replace(/\s+/g, " ")
    .trim();

export const truncateText = (value = "", maxLength = 160) => {
  const text = cleanText(value);
  if (text.length <= maxLength) return text;
  return `${text.slice(0, Math.max(0, maxLength - 3)).trim()}...`;
};

export const escapeHtml = (value = "") =>
  String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

export const formatCount = (value) => {
  const number = Number(value ?? 0);
  if (!Number.isFinite(number)) return "0";
  if (Math.abs(number) >= 10000000) {
    return `${Number((number / 10000000).toFixed(1))}Cr`;
  }
  if (Math.abs(number) >= 100000) {
    return `${Number((number / 100000).toFixed(1))}L`;
  }
  if (Math.abs(number) >= 1000) {
    return `${Number((number / 1000).toFixed(1))}K`;
  }
  return new Intl.NumberFormat("en-IN", { maximumFractionDigits: 1 }).format(
    number,
  );
};

export const toAbsoluteUrl = (value, fallback = SEO_CONFIG.defaultImage) => {
  const siteUrl = getSiteUrl();
  const rawValue = String(value || fallback || "").trim();

  if (
    !rawValue ||
    rawValue.startsWith("data:") ||
    rawValue.startsWith("blob:")
  ) {
    return new URL(SEO_CONFIG.defaultImage, siteUrl).href;
  }

  if (rawValue.startsWith("//")) return `https:${rawValue}`;
  if (ABSOLUTE_URL_RE.test(rawValue)) {
    if (isLocalUrl(rawValue)) return rawValue;
    return rawValue.replace(/^http:\/\//i, "https://");
  }

  try {
    return new URL(rawValue.startsWith("/") ? rawValue : `/${rawValue}`, siteUrl)
      .href;
  } catch {
    return new URL(SEO_CONFIG.defaultImage, siteUrl).href;
  }
};

export const getSocialImage = (value) => {
  const imageUrl = toAbsoluteUrl(value, SEO_CONFIG.defaultImage);
  if (!imageUrl) return toAbsoluteUrl(SEO_CONFIG.defaultImage);
  if (isLocalUrl(imageUrl)) return imageUrl;
  if (imageUrl.startsWith("https://")) return imageUrl;

  try {
    const siteHost = new URL(getSiteUrl()).host;
    const imageHost = new URL(imageUrl).host;
    if (imageHost === siteHost) return imageUrl.replace(/^http:\/\//i, "https://");
  } catch {
    return toAbsoluteUrl(SEO_CONFIG.defaultImage);
  }

  return toAbsoluteUrl(SEO_CONFIG.defaultImage);
};

export const getImageMimeType = (value = "") => {
  const cleanUrl = String(value).split("?")[0].toLowerCase();
  try {
    const pathname = new URL(cleanUrl, getSiteUrl()).pathname;
    if (pathname.startsWith("/api/og/")) return "image/png";
  } catch {
    // Fall through to extension-based detection.
  }
  if (cleanUrl.endsWith(".jpg") || cleanUrl.endsWith(".jpeg"))
    return "image/jpeg";
  if (cleanUrl.endsWith(".webp")) return "image/webp";
  if (cleanUrl.endsWith(".gif")) return "image/gif";
  if (cleanUrl.endsWith(".svg")) return "image/svg+xml";
  return "image/png";
};

export const addCacheVersion = (value, version) => {
  const absoluteUrl = getSocialImage(value);
  if (!version) return absoluteUrl;

  try {
    const url = new URL(absoluteUrl);
    url.searchParams.set("v", String(version));
    return url.href;
  } catch {
    return absoluteUrl;
  }
};

export const compactObject = (value) => {
  if (Array.isArray(value)) {
    return value
      .map((item) => compactObject(item))
      .filter((item) => item !== undefined && item !== null);
  }

  if (value && typeof value === "object") {
    return Object.entries(value).reduce((acc, [key, item]) => {
      const compacted = compactObject(item);
      const isEmptyArray = Array.isArray(compacted) && compacted.length === 0;
      const isEmptyObject =
        compacted &&
        typeof compacted === "object" &&
        !Array.isArray(compacted) &&
        Object.keys(compacted).length === 0;

      if (
        compacted !== undefined &&
        compacted !== null &&
        compacted !== "" &&
        !isEmptyArray &&
        !isEmptyObject
      ) {
        acc[key] = compacted;
      }

      return acc;
    }, {});
  }

  return value;
};

export const unwrapApiPayload = (payload) => {
  if (payload?.data?.data) return payload.data.data;
  if (payload?.data) return payload.data;
  return payload;
};

export const resolveArrayPayload = (payload) => {
  const unwrapped = unwrapApiPayload(payload);
  if (Array.isArray(unwrapped)) return unwrapped;
  if (Array.isArray(unwrapped?.results)) return unwrapped.results;
  if (Array.isArray(payload?.results)) return payload.results;
  return [];
};

export const firstPresentNumber = (...values) => {
  for (const value of values) {
    if (value !== undefined && value !== null && value !== "") {
      const number = Number(value);
      return Number.isFinite(number) ? number : 0;
    }
  }
  return 0;
};
