import React from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";

import { Hash } from "lucide-react";

import { formatNumber } from "../../../utils/formatTime.js";
import Loader from "../../../components/common/Loader.jsx";

import { hashtagService } from "../../../services/hashtag.service.js";

const SidebarTrending = () => {
  const navigate = useNavigate();
  const { data, isLoading, error } = useQuery({
    queryKey: ["trending-hashtags-sidebar"],
    queryFn: hashtagService.getTrendingHashtags,
  });

  const hashtags = data?.data?.data?.results || [];
  const handleHashtagClick = (
    hashtag
  ) => {
    navigate(`/hashtag/${hashtag}`);
  };

  if (isLoading) {
    return (
      <div className="bg-card dark:bg-card-dark border border-border dark:border-border-dark rounded-xl shadow-soft p-2">
        <Loader size="small" />
      </div>
    );
  }

  if (error || !hashtags.length)
    return null;

  return (
    <div className="bg-card dark:bg-card-dark border border-border dark:border-border-dark rounded-xl shadow-soft p-3">
      <h3 className="font-semibold text-foreground dark:text-foreground-dark mb-1">
        Trending
      </h3>

      <div className="">
        {hashtags.map((hashtag) => (
          <button
            key={hashtag.id}
            onClick={() =>
              handleHashtagClick(
                hashtag.slug
              )
            }
            className=" w-full flex items-center justify-between hover:bg-muted dark:hover:bg-muted-dark rounded-md px-2 py-1.5 transition-colors"
          >
            <div className="flex items-center ">
              <Hash className="w-3 h-3 mr-1 text-mutedForeground dark:text-mutedForeground-dark" />

              <span className="text-sm font-medium text-foreground dark:text-foreground-dark">
                {hashtag.tag}
              </span>
            </div>

            <span className="text-xs text-mutedForeground dark:text-mutedForeground-dark">
              {formatNumber(
                hashtag.global_count
              )}{" "}
              posts
            </span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default SidebarTrending;