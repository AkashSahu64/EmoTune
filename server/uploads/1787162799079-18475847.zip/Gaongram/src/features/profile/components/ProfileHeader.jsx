import React, { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  Flag,
  MoreHorizontal,
  Settings,
  Share2,
} from "lucide-react";

const IconButton = ({ children, onClick, ariaLabel }) => (
  <motion.button
    type="button"
    whileTap={{ scale: 0.94 }}
    onClick={onClick}
    aria-label={ariaLabel}
    className="flex h-10 w-10 items-center justify-center rounded-full border border-border/80 bg-white/80 text-foreground shadow-[0_8px_24px_rgba(15,23,42,0.08)] backdrop-blur transition hover:border-border hover:bg-white"
  >
    {children}
  </motion.button>
);

const ProfileHeader = ({
  isOwnProfile,
  onBack,
  onSettings,
  onShare,
  onReport,
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    if (!isMenuOpen) return undefined;

    const handlePointerDown = (event) => {
      if (!menuRef.current?.contains(event.target)) {
        setIsMenuOpen(false);
      }
    };

    document.addEventListener("pointerdown", handlePointerDown);

    return () => {
      document.removeEventListener("pointerdown", handlePointerDown);
    };
  }, [isMenuOpen]);

  return (
    <header className="sticky top-0 z-40 border-b border-black/5 bg-background/90 backdrop-blur-xl">
      <div className="mx-auto flex h-14 w-full max-w-5xl items-center px-3 sm:h-16 sm:px-4 md:px-6">
        <div className="grid w-full grid-cols-[40px_1fr_40px] items-center">
          <div className="flex items-center">
            {!isOwnProfile ? (
              <IconButton onClick={onBack} ariaLabel="Go back">
                <ArrowLeft className="h-5 w-5" />
              </IconButton>
            ) : (
              <div className="h-10 w-10" />
            )}
          </div>

          <div className="text-center">
            <p className="text-[17px] font-semibold tracking-[-0.02em] text-foreground sm:text-lg">
              Profile
            </p>
          </div>

          <div className="relative flex justify-end" ref={menuRef}>
            {isOwnProfile ? (
              <IconButton onClick={onSettings} ariaLabel="Open settings">
                <Settings className="h-5 w-5" />
              </IconButton>
            ) : (
              <>
                <IconButton
                  onClick={() => setIsMenuOpen((value) => !value)}
                  ariaLabel="Open profile options"
                >
                  <MoreHorizontal className="h-5 w-5" />
                </IconButton>

                <AnimatePresence>
                  {isMenuOpen ? (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.96, y: -8 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.96, y: -8 }}
                      className="absolute right-0 top-12 w-44 overflow-hidden rounded-2xl border border-border bg-card p-1.5 shadow-[0_18px_48px_rgba(15,23,42,0.16)]"
                    >
                      <button
                        type="button"
                        onClick={() => {
                          setIsMenuOpen(false);
                          onShare();
                        }}
                        className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm font-medium text-foreground transition hover:bg-muted"
                      >
                        <Share2 className="h-4 w-4" />
                        Share profile
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setIsMenuOpen(false);
                          onReport();
                        }}
                        className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm font-medium text-danger transition hover:bg-red-50"
                      >
                        <Flag className="h-4 w-4" />
                        Report user
                      </button>
                    </motion.div>
                  ) : null}
                </AnimatePresence>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default React.memo(ProfileHeader);
