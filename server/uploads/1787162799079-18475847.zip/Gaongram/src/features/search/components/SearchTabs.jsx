import React from 'react';
import { motion } from 'framer-motion';
import { useTranslation } from "react-i18next";

const SearchTabs = ({ activeTab, onTabChange }) => {
  const { t } = useTranslation();

  // ✅ Move inside component for re-render on language change
  const tabs = [
    { id: 'hashtags', label: t("hashtags") },
    { id: 'posts', label: t("posts") },
    { id: 'accounts', label: t("accounts") },
    
  ];

  return (
    <div className="flex px-4 gap-6 border-b border-border dark:border-border-dark">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onTabChange(tab.id)}
          className={`relative py-3 text-sm font-medium transition-colors ${
            activeTab === tab.id
              ? 'text-primary dark:text-primary'
              : 'text-mutedForeground dark:text-mutedForeground-dark hover:text-foreground dark:hover:text-foreground-dark'
          }`}
        >
          {tab.label}

          {activeTab === tab.id && (
            <motion.div
              layoutId="activeTabIndicator"
              className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary"
              transition={{ type: 'spring', stiffness: 500, damping: 30 }}
            />
          )}
        </button>
      ))}
    </div>
  );
};

export default SearchTabs;