// src/hooks/useMessages.js
import { useEffect, useCallback, useRef, useState } from 'react';
import { useInfiniteQuery, useQueryClient } from '@tanstack/react-query';
import { messageService } from '../services/message.service';
import { useChatStore } from '../store/chatStore';
import { usePageVisibility } from './useVisibility';
import { useSocket } from '../context/SocketProvider';

export const useMessages = (receiverId) => {
  const queryClient = useQueryClient();
  const { addMessages, updateMessage, updateUnreadCount } = useChatStore();
  const isTabVisible = usePageVisibility();
  const { isConnected, emit } = useSocket();
  const pollingRef = useRef(null);

  // ✅ Reactive subscription to messages for this chat
  const messages = useChatStore((state) => state.messages.get(receiverId) || []);

  useEffect(() => {
    if (!isConnected) {
      // start polling when WS disconnected
      const interval = setInterval(() => {
        if (receiverId && isTabVisible) {
          refetch();
        }
      }, 5000);
      pollingRef.current = interval;
      return () => clearInterval(interval);
    } else {
      if (pollingRef.current) clearInterval(pollingRef.current);
    }
  }, [isConnected, receiverId, isTabVisible]);

  const { data, isLoading, fetchNextPage, hasNextPage, refetch } = useInfiniteQuery({
    queryKey: ['messages', receiverId],
    queryFn: async ({ pageParam = 1 }) => {
      if (!receiverId) return { results: [], next: null };
      const response = await messageService.getMessageHistory(receiverId, pageParam);
      if (response.success && response.data?.results) {
        const newMessages = response.data.results;
        addMessages(receiverId, newMessages);
        return response.data;
      }
      return { results: [], next: null };
    },
    getNextPageParam: (lastPage) => lastPage?.data?.next || undefined,
    enabled: !!receiverId && isTabVisible,
    staleTime: 2000,
  });

  const markAllAsRead = useCallback(() => {
    if (!receiverId) return;

    const unreadMessages = messages.filter(
      (m) =>
        m.sender === receiverId &&
        !m.seen_at &&
        !m.isTemp &&
        !m.deleted_for_me
    );

    if (!unreadMessages.length) return;

    const now = new Date().toISOString();
    unreadMessages.forEach((msg) => {
      updateMessage(receiverId, msg.id, {
        seen_at: now,
        read_status: "read",
      });
    });
    updateUnreadCount(receiverId, 0);

    if (isConnected) {
      emit("seen", {
        message_ids: unreadMessages.map((m) => m.id),
      });
    }
  }, [receiverId, messages, updateMessage, updateUnreadCount, isConnected, emit]);

  return {
    messages,          // ✅ now reactive
    isLoading,
    hasNextPage,
    loadMore: fetchNextPage,
    refetchMessages: refetch,
    markAllAsRead,
  };
};