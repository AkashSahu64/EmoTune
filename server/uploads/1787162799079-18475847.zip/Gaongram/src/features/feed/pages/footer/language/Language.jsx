// src/pages/Language.jsx (refactored)
import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Check, X, AlertCircle, ArrowRight } from "lucide-react";
import { useTranslation } from "react-i18next";
import MinimalLayout from "../../../components/layout/MinimalLayout";
import { LANGUAGES } from "../../../../../constants/languages";
import Seo from "../../../../../components/seo/Seo.jsx";
import { buildStaticPageSeo } from "../../../../../seo/seoBuilders.js";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4, ease: [0.25, 0.1, 0.25, 1] } }
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { staggerChildren: 0.04, delayChildren: 0.1 } }
};

const Language = () => {
  const { t, i18n } = useTranslation();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedLang, setSelectedLang] = useState(i18n.language);
  const [isFocused, setIsFocused] = useState(false);
  const searchInputRef = useRef(null);

  // Sync with i18n language changes (e.g., from modal)
  useEffect(() => {
    setSelectedLang(i18n.language);
  }, [i18n.language]);

  const filteredLanguages = LANGUAGES.filter(
    (lang) =>
      lang.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lang.englishName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const selectedLanguageData = LANGUAGES.find((l) => l.code === selectedLang) || LANGUAGES[0];

  const handleClearSearch = () => {
    setSearchTerm("");
    searchInputRef.current?.focus();
  };

  const handleLanguageSelect = (code) => {
    setSelectedLang(code);
    i18n.changeLanguage(code);
  };

  const previewTexts = {
    hi: { home: "होम", explore: "खोजें" },
    bn: { home: "হোম", explore: "অন্বেষণ" },
    te: { home: "హోమ్", explore: "అన్వేషించండి" },
    mr: { home: "होम", explore: "शोधा" },
    ta: { home: "முகப்பு", explore: "ஆராய்க" },
    gu: { home: "હોમ", explore: "શોધો" },
    kn: { home: "ಮುಖಪುಟ", explore: "ಅನ್ವೇಷಿಸಿ" },
    ml: { home: "ഹോം", explore: "പര്യവേക്ഷണം" },
    en: { home: "Home", explore: "Explore" }
  };
  const currentPreview = previewTexts[selectedLang] || previewTexts.en;

  return (
    <MinimalLayout>
      <Seo {...buildStaticPageSeo("language")} />
      <div className="min-h-screen bg-background dark:bg-background-dark flex flex-col">
        {/* Background gradients unchanged */}
        <div className="fixed inset-0 -z-10 overflow-hidden">
          <div className="absolute top-0 -left-20 w-[600px] h-[600px] bg-primary/10 rounded-full blur-3xl opacity-60" />
          <div className="absolute bottom-0 -right-20 w-[600px] h-[600px] bg-viral-pink/10 rounded-full blur-3xl opacity-60" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-accent/5 rounded-full blur-3xl" />
        </div>

        <div className="flex-1 max-w-6xl mx-auto w-full px-4 py-8 md:py-12">
          <motion.div initial="hidden" animate="visible" variants={staggerContainer} className="text-center mb-10">
            <motion.h1 variants={fadeUp} className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-foreground dark:text-foreground-dark mb-8">
              {t('choose_language')}
            </motion.h1>
            <motion.p
              variants={fadeUp}
              className="text-lg text-mutedForeground dark:text-mutedForeground-dark max-w-2xl mx-auto"
            >
              GaonGram speaks your mother tongue. Select your preferred language
              to enjoy the app in your own voice.
            </motion.p>
          </motion.div>

          {/* Search input unchanged */}
          <div className="max-w-2xl mx-auto mb-8">
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.25 }}
              className={`relative transition-all duration-300 ${isFocused ? "ring-1 ring-primary/20 rounded-full" : ""}`}
            >
              <div className="absolute left-4 top-1/2 -translate-y-1/2 z-10 text-gray-600 dark:text-gray-300 pointer-events-none">
                <Search className="w-5 h-5" />
              </div>
              <input
                ref={searchInputRef}
                type="text"
                placeholder="Search language..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onFocus={() => setIsFocused(true)}
                onBlur={() => setIsFocused(false)}
                className="w-full z-0 pl-12 pr-12 py-3.5 bg-white/70 dark:bg-card-dark/70 backdrop-blur-xl border border-gray-600/20 dark:border-border-dark/30 rounded-full focus:outline-none text-foreground dark:text-foreground-dark placeholder:text-mutedForeground/70 transition"
              />
              {searchTerm && (
                <button onClick={handleClearSearch} className="absolute right-4 top-1/2 -translate-y-1/2 p-1 rounded-full hover:bg-muted/50 transition">
                  <X className="w-4 h-4 text-mutedForeground" />
                </button>
              )}
            </motion.div>
          </div>

          <motion.div initial="hidden" animate="visible" variants={staggerContainer} className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
            <AnimatePresence mode="popLayout">
              {filteredLanguages.map((lang) => (
                <motion.button
                  key={lang.code}
                  variants={fadeUp}
                  initial="hidden"
                  animate="visible"
                  exit={{ opacity: 0, scale: 0.9 }}
                  layout
                  whileHover={{ y: -4, scale: 1.01 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleLanguageSelect(lang.code)}
                  className={`group relative flex flex-col items-start p-3 rounded-2xl border transition-all duration-300 text-left ${
                    selectedLang === lang.code
                      ? "border-primary bg-primary/10 dark:bg-primary/20 shadow-lg shadow-primary/10 ring-1 ring-primary/30"
                      : "border-border/50 dark:border-border-dark/50 bg-white/60 dark:bg-card-dark/60 backdrop-blur-sm hover:border-primary/40 hover:bg-white/80 dark:hover:bg-card-dark/80 shadow-soft"
                  }`}
                >
                  {selectedLang === lang.code && (
                    <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 0.15, scale: 1 }} className="absolute inset-0 rounded-2xl bg-primary pointer-events-none" />
                  )}
                  {selectedLang === lang.code && (
                    <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="absolute top-3 right-3 w-6 h-6 rounded-full bg-primary text-white flex items-center justify-center shadow-md">
                      <Check className="w-4 h-4" />
                    </motion.div>
                  )}
                  <div className="text-3xl mb-3">{lang.flag || "🌐"}</div>
                  <span className="text-xl font-bold text-foreground dark:text-foreground-dark group-hover:text-primary transition-colors">
                    {lang.name}
                  </span>
                  <span className="text-sm text-mutedForeground dark:text-mutedForeground-dark">{lang.englishName}</span>
                  <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-primary/10 via-transparent to-viral-pink/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
                </motion.button>
              ))}
            </AnimatePresence>
          </motion.div>

          {filteredLanguages.length === 0 && (
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="text-center py-16">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted/50 dark:bg-muted-dark/50 mb-4">
                <AlertCircle className="w-8 h-8 text-mutedForeground" />
              </div>
              <p className="text-lg font-medium text-foreground dark:text-foreground-dark mb-1">{t('no_languages_found')}</p>
              <p className="text-mutedForeground">{t('try_different_search')}</p>
            </motion.div>
          )}
        </div>

        {/* Bottom bar unchanged */}
        {/* <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="sticky bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-background dark:from-background-dark via-background/90 dark:via-background-dark/90 to-transparent backdrop-blur-md border-t border-border/30 dark:border-border-dark/30"
        >
          <div className="max-w-2xl mx-auto flex items-center justify-between gap-4">
            <div className="text-left">
              <p className="text-xs text-mutedForeground">{t('selected_language')}</p>
              <p className="font-semibold text-foreground dark:text-foreground-dark flex items-center gap-1">
                {selectedLanguageData.flag} {selectedLanguageData.name}
              </p>
            </div>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="px-8 py-3.5 bg-primary text-white rounded-full font-medium shadow-lg shadow-primary/20 hover:bg-primary-light transition flex items-center gap-2"
            >
              {t('continue_in', { language: selectedLanguageData.englishName })}
              <ArrowRight className="w-4 h-4" />
            </motion.button>
          </div>
        </motion.div> */}
      </div>
    </MinimalLayout>
  );
};

export default Language;
