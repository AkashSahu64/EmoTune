import { create } from 'zustand';

export const useUIStore = create((set) => ({
  // Modal state
  modal: {
    isOpen: false,
    type: null,
    data: null,
  },
  
  // Toast notifications
  toasts: [],
  
  // Loading states
  loading: {
    global: false,
    feed: false,
    comments: false,
  },
  
  // Mobile navigation
  isMobileNavOpen: false,
  
  // Actions
  openModal: (type, data = null) => 
    set({ modal: { isOpen: true, type, data } }),
  
  closeModal: () => 
    set({ modal: { isOpen: false, type: null, data: null } }),

  closeAllModals: () =>
    set({
      modal: { isOpen: false, type: null, data: null },
      isMobileNavOpen: false,
      loading: {
        global: false,
        feed: false,
        comments: false,
      },
    }),
  
  addToast: (toast) => 
    set((state) => ({ 
      toasts: [...state.toasts, { id: Date.now(), ...toast }] 
    })),
  
  removeToast: (id) => 
    set((state) => ({ 
      toasts: state.toasts.filter(toast => toast.id !== id) 
    })),
  
  setLoading: (key, value) => 
    set((state) => ({ 
      loading: { ...state.loading, [key]: value } 
    })),
  
  toggleMobileNav: () => 
    set((state) => ({ isMobileNavOpen: !state.isMobileNavOpen })),
  
  openPostOptions: (postId, isOwner, postData = null) => 
  set({ 
    modal: { 
      isOpen: true, 
      type: 'post-options', 
      data: { postId, isOwner, postData } 
    } 
  }),
  
  closeMobileNav: () => 
    set({ isMobileNavOpen: false }),
}));