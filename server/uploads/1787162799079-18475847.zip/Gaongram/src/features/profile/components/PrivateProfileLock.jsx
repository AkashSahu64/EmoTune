import React from "react";
import { Lock } from "lucide-react";

const PrivateProfileLock = ({ username, fullName }) => (
  <div className="mx-auto flex max-w-lg flex-col items-center px-6 py-12 text-center">
    <div className="flex h-16 w-16 items-center justify-center rounded-full border border-border dark:border-border-dark text-foreground dark:text-foreground-dark">
      <Lock className="h-7 w-7" />
    </div>
    <h3 className="mt-5 text-xl font-semibold tracking-[-0.02em] text-foreground dark:text-foreground-dark">
      This account is private
    </h3>
    <p className="mt-2 max-w-sm text-sm leading-6 text-mutedForeground dark:text-mutedForeground-dark">
      Follow {fullName || username} to see their posts, videos, and audio
      updates.
    </p>
  </div>
);

export default React.memo(PrivateProfileLock);
