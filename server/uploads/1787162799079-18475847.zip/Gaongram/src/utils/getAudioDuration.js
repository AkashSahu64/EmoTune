export const getAudioDuration = (audioUrl) => {
  return new Promise((resolve) => {
    if (!audioUrl) {
      resolve(0);
      return;
    }

    const audio = document.createElement("audio");

    audio.src = audioUrl;
    audio.preload = "metadata";

    const cleanup = () => {
      audio.removeAttribute("src");
      audio.load();
    };

    audio.onloadedmetadata = () => {
      const duration = audio.duration;

      cleanup();

      resolve(
        !isNaN(duration) && isFinite(duration)
          ? Math.floor(duration)
          : 0
      );
    };

    audio.onerror = () => {
      cleanup();
      resolve(0);
    };
  });
};