import React, { useMemo } from "react";
import { Helmet } from "react-helmet-async";
import { useLocation } from "react-router-dom";
import { SEO_CONFIG } from "../../seo/seoConfig.js";
import { cleanText, getImageMimeType } from "../../seo/seoUtils.js";
import { normalizeSeo } from "../../../seo/metadata/render.mjs";

const Seo = ({
  title,
  description,
  keywords,
  ogImage,
  image,
  ogImageAlt,
  ogType = "website",
  ogUrl,
  canonical,
  noindex = false,
  schema,
  profile,
  article,
  video,
  children,
}) => {
  const location = useLocation();
  const currentPath = `${location.pathname}${location.search}`;
  const seo = useMemo(
    () =>
      normalizeSeo(
        {
          title,
          description,
          keywords,
          ogImage,
          image,
          ogImageAlt,
          ogType,
          ogUrl,
          canonical,
          noindex,
          schema,
          profile,
          article,
          video,
        },
        currentPath,
      ),
    [
      article,
      canonical,
      currentPath,
      description,
      image,
      keywords,
      noindex,
      ogImage,
      ogImageAlt,
      ogType,
      ogUrl,
      profile,
      schema,
      title,
      video,
    ],
  );
  const imageType = getImageMimeType(seo.ogImage);
  const ogImages = seo.ogImages?.length
    ? seo.ogImages
    : [
        {
          url: seo.ogImage,
          secureUrl: seo.ogImageSecureUrl || seo.ogImage,
          type: imageType,
          width: SEO_CONFIG.defaultImageWidth,
          height: SEO_CONFIG.defaultImageHeight,
          alt: seo.ogImageAlt,
        },
      ];

  return (
    <Helmet prioritizeSeoTags defer={false}>
      <html lang="en" />
      <title>{seo.title}</title>

      <meta name="description" content={seo.description} />
      <meta name="keywords" content={seo.keywords} />
      <meta name="author" content={SEO_CONFIG.organizationName} />
      <meta name="robots" content={seo.robots} />
      <meta name="googlebot" content={seo.robots} />
      <meta name="theme-color" content={SEO_CONFIG.themeColor} />
      <link rel="preconnect" href="https://gaongram.com" />
      <link rel="dns-prefetch" href="//gaongram.com" />
      <link rel="canonical" href={seo.canonical} />

      <meta property="og:type" content={seo.ogType} />
      <meta property="og:locale" content={SEO_CONFIG.locale} />
      <meta property="og:site_name" content={SEO_CONFIG.siteName} />
      <meta property="og:title" content={seo.title} />
      <meta property="og:description" content={seo.description} />
      <meta property="og:url" content={seo.ogUrl} />
      {ogImages.map((entry) => (
        <React.Fragment key={`og-image-${entry.url}`}>
          <meta property="og:image" content={entry.url} />
          <meta property="og:image:secure_url" content={entry.secureUrl || entry.url} />
          <meta property="og:image:type" content={entry.type || getImageMimeType(entry.url)} />
          <meta
            property="og:image:width"
            content={String(entry.width || SEO_CONFIG.defaultImageWidth)}
          />
          <meta
            property="og:image:height"
            content={String(entry.height || SEO_CONFIG.defaultImageHeight)}
          />
          <meta property="og:image:alt" content={entry.alt || seo.ogImageAlt} />
        </React.Fragment>
      ))}
      {seo.article?.modifiedTime ? (
        <meta property="og:updated_time" content={seo.article.modifiedTime} />
      ) : null}

      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content={SEO_CONFIG.twitterSite} />
      <meta name="twitter:url" content={seo.ogUrl} />
      <meta name="twitter:title" content={seo.title} />
      <meta name="twitter:description" content={seo.description} />
      <meta name="twitter:image" content={seo.ogImage} />
      <meta name="twitter:image:alt" content={seo.ogImageAlt} />

      {seo.profile?.username ? (
        <meta property="profile:username" content={seo.profile.username} />
      ) : null}
      {seo.profile?.firstName ? (
        <meta property="profile:first_name" content={seo.profile.firstName} />
      ) : null}
      {seo.profile?.lastName ? (
        <meta property="profile:last_name" content={seo.profile.lastName} />
      ) : null}

      {seo.article?.publishedTime ? (
        <meta property="article:published_time" content={seo.article.publishedTime} />
      ) : null}
      {seo.article?.modifiedTime ? (
        <meta property="article:modified_time" content={seo.article.modifiedTime} />
      ) : null}
      {seo.article?.author ? (
        <meta property="article:author" content={seo.article.author} />
      ) : null}
      {seo.article?.section ? (
        <meta property="article:section" content={seo.article.section} />
      ) : null}
      {Array.isArray(seo.article?.tags)
        ? seo.article.tags.map((tag) => (
            <meta
              key={`article-tag-${tag?.id || tag?.slug || tag?.name || tag}`}
              property="article:tag"
              content={cleanText(tag?.name || tag?.slug || tag)}
            />
          ))
        : null}

      {seo.video?.url ? <meta property="og:video" content={seo.video.url} /> : null}
      {seo.video?.secureUrl || seo.video?.url ? (
        <meta property="og:video:secure_url" content={seo.video.secureUrl || seo.video.url} />
      ) : null}
      {seo.video?.type ? <meta property="og:video:type" content={seo.video.type} /> : null}
      {seo.video?.width ? (
        <meta property="og:video:width" content={String(seo.video.width)} />
      ) : null}
      {seo.video?.height ? (
        <meta property="og:video:height" content={String(seo.video.height)} />
      ) : null}

      <script type="application/ld+json">{JSON.stringify(seo.schema)}</script>

      {children}
    </Helmet>
  );
};

export default Seo;
