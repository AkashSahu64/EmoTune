import React from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";

import { useMutation, useQueryClient } from "@tanstack/react-query";

import Avatar from "../../../components/common/Avatar";
import Button from "../../../components/common/Button";

import { profileService } from "../../../services/profile.service";

import HighlightText from "./HighlightText";

import { useSearchHistory } from "../../../hooks/useSearchHistory";

import { useTranslation } from "react-i18next";

const UserListItem = ({ user, searchTerm }) => {
  const navigate = useNavigate();

  const queryClient = useQueryClient();

  const { t } = useTranslation();

  // ✅ SEARCH HISTORY HOOK
  const { addToHistory } = useSearchHistory();

  const followMutation = useMutation({
    mutationFn: () => profileService.toggleFollow(user.profile_id),

    onMutate: async () => {
      await queryClient.cancelQueries({
        queryKey: ["search-accounts"],
      });

      const previousUsers = queryClient.getQueriesData({
        queryKey: ["search-accounts"],
      });

      queryClient.setQueriesData(
        { queryKey: ["search-accounts"] },

        (old) => {
          if (!old) return old;

          if (old.pages) {
            return {
              ...old,

              pages: old.pages.map((page) => ({
                ...page,

                users: page.users.map((u) =>
                  u.profile_id === user.profile_id
                    ? {
                        ...u,
                        is_following: !u.is_following,
                      }
                    : u,
                ),
              })),
            };
          }

          return old;
        },
      );

      return { previousUsers };
    },

    onError: (err, _, context) => {
      if (context?.previousUsers) {
        context.previousUsers.forEach(([queryKey, data]) => {
          queryClient.setQueryData(queryKey, data);
        });
      }
    },
  });

  // Follow button
  const handleFollowClick = (e) => {
    e.stopPropagation();

    followMutation.mutate();
  };

  const handleUserClick = () => {
    addToHistory({
      id: user.profile_id,

      profile_id: user.profile_id,

      user_id: user.user_id,

      username: user.username,

      name: user.name,

      avatar: user.avatar,

      is_private: user.is_private,
    });

    navigate(`/profile/${user.user_id}`);
  };

  return (
    <motion.div
      initial={{opacity: 0,
        y: 10,
      }}
      animate={{
        opacity: 1,
        y: 0,
      }}
      exit={{
        opacity: 0,
        y: -10,
      }}
      className="
        flex items-center justify-between
        py-1.5 px-2
        rounded-lg
        hover:bg-muted
        dark:hover:bg-muted-dark
        transition-colors
        cursor-pointer
      "
      onClick={handleUserClick}
    >
      {/* LEFT */}

      <div className="flex items-center gap-3">
        <Avatar src={user.avatar} alt={user.username} size="medium" />

        <div className="min-w-0 leading-tight">
          <div className=" font-semibold text-foreground dark:text-foreground-dark"
          >
            <HighlightText text={user.username} query={searchTerm} />
          </div>

          <div className=" text-xs text-mutedForeground dark:text-mutedForeground-dark"
          >
            <HighlightText text={user.name} query={searchTerm} />
          </div>
        </div>
      </div>

      {/* FOLLOW BUTTON */}

      <Button
        variant={user.is_following ? "outline" : "primary"}
        size="small"
        onClick={handleFollowClick}
        loading={followMutation.isLoading}
        className="min-w-[90px]"
      >
        {user.is_following ? t("following") : t("follow")}
      </Button>
    </motion.div>
  );
};

export default UserListItem;