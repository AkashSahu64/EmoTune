// components/vibe/media/AudioMedia.jsx

import React, { useEffect, useState, useRef } from "react";
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  VolumeX,
  Music2,
} from "lucide-react";
import SensitiveContentOverlay from "../../../../components/vibe/SensitiveContentOverlay.jsx";

const AudioMedia = ({
  audioUrl,
  audioCoverImage,
  audioRef,
  audioProgressBarRef,
  audioCurrentTime,
  audioDuration,
  isMuted,
  onAudioProgressClick,
  onAudioSkipForward,
  onAudioSkipBackward,
  toggleAudioPlay,
  handleGlobalMuteToggle,
  onAudioEnded,
  onAudioLoadStart,
  onAudioCanPlay,
  onAudioMetadataLoad,
  renderViewCount,
  formatPlayerTime,
  title,
  isSensitiveBlocked = false,
  onSensitiveClick,
}) => {
  const [volume, setVolume] = useState(1);
  const [showVolumeSlider, setShowVolumeSlider] =
    useState(false);

  const [hoverProgress, setHoverProgress] =
    useState(null);

  const volumeSliderRef = useRef(null);

  const audioProgressPercentage = audioDuration
    ? (audioCurrentTime / audioDuration) * 100
    : 0;

  const isPlaying =
    audioRef.current && !audioRef.current.paused;

  // 🔥 Dynamic Audio Wave
  const [waveHeights, setWaveHeights] = useState(
    Array(18).fill(30)
  );

  useEffect(() => {
    let interval;

    if (isPlaying && !isSensitiveBlocked) {
      interval = setInterval(() => {
        setWaveHeights(
          Array.from({ length: 18 }, () =>
            Math.floor(Math.random() * 65) + 20
          )
        );
      }, 180);
    }

    return () => clearInterval(interval);
  }, [isPlaying, isSensitiveBlocked]);

  // 🔥 Volume Change
  const handleVolumeChange = (e) => {
    if (isSensitiveBlocked) return;

    const newVolume = parseFloat(e.target.value);

    setVolume(newVolume);

    if (audioRef.current) {
      audioRef.current.volume = newVolume;

      if (newVolume === 0) {
        audioRef.current.muted = true;
      } else {
        audioRef.current.muted = false;
      }
    }
  };

  // 🔥 Sync mute state
  useEffect(() => {
    if (audioRef.current) {
      if (isMuted) {
        audioRef.current.muted = true;
        setVolume(0);
      } else {
        audioRef.current.muted = false;
        setVolume(audioRef.current.volume || 1);
      }
    }
  }, [isMuted, audioRef]);

  // 🔥 Hover Progress
  const handleProgressHover = (e) => {
    if (isSensitiveBlocked) return;

    const rect =
      e.currentTarget.getBoundingClientRect();

    const percent =
      (e.clientX - rect.left) / rect.width;

    setHoverProgress(
      Math.min(Math.max(percent * 100, 0), 100)
    );
  };

  // 🔥 Close volume slider
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        volumeSliderRef.current &&
        !volumeSliderRef.current.contains(
          event.target
        ) &&
        showVolumeSlider
      ) {
        setShowVolumeSlider(false);
      }
    };

    document.addEventListener(
      "mousedown",
      handleClickOutside
    );

    return () =>
      document.removeEventListener(
        "mousedown",
        handleClickOutside
      );
  }, [showVolumeSlider]);

  useEffect(() => {
    if (!isSensitiveBlocked || !audioRef.current) return;

    audioRef.current.pause();
    audioRef.current.muted = true;
  }, [audioRef, isSensitiveBlocked]);

  return (
    <div className="relative w-full h-[550px] min-h-[550px] overflow-hidden  bg-black group">
      {/* 🔥 SAME AUDIO IMAGE BACKGROUND */}
      <div className="absolute inset-0">
        {audioCoverImage ? (
          <>
            <img
              src={audioCoverImage}
              alt={title || "Audio cover"}
              className={`w-full h-full object-cover scale-110 ${
                isSensitiveBlocked ? "blur-xl brightness-75" : "blur-sm"
              }`}
            />

            <div className="absolute inset-0 bg-black/10" />

            <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/50" />
          </>
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-primary/20 to-black" />
        )}
      </div>

      {/* View Count */}
        {renderViewCount("audio")}

      {/* Main Content */}
      <div className="relative z-10 flex flex-col items-center h-full px-5 py-5">
        {/* Cover Image */}
        <div className="relative mt-1">
          <div
            className={`relative w-[310px] h-[310px] rounded-2xl overflow-hidden bg-white/[0.03] border border-white/10 p-0.5 transition-all duration-300 ${
              isSensitiveBlocked ? "blur-xl scale-105 brightness-75" : ""
            }`}
          >
            {audioCoverImage ? (
              <img
                src={audioCoverImage}
                alt={title || "Audio cover"}
                className="w-full h-full object-contain rounded-2xl"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center rounded-[26px] bg-gradient-to-br from-primary/20 to-black">
                <Music2 className="w-20 h-20 text-white/70" />
              </div>
            )}

            {/* 🔥 AUDIO WAVE */}
            <div className="absolute bottom-4 left-0 w-full px-6 flex items-end justify-center gap-[5px] h-16 z-20">
              {waveHeights.map((height, index) => (
                <div
                  key={index}
                  className="flex-1 max-w-[6px] rounded-full bg-white/95"
                  style={{
                    height: `${height}px`,
                    transition:
                      "height 0.18s ease-in-out",
                  }}
                />
              ))}
            </div>
          </div>

          {/* Audio Badge */}
          <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-black/70 backdrop-blur-xl border border-white/10 shadow-lg">
            <div className="flex items-center gap-2 text-white text-sm font-medium">
              <Music2 className="w-4 h-4" />
              <span>Audio</span>
            </div>
          </div>
        </div>

        {/* Title */}
        <div className="text-center mt-7 mb-6 px-2">
          <h3 className="text-[30px] leading-tight font-semibold text-white line-clamp-1">
            {title || "Audio Track"}
          </h3>
        </div>

        {/* Controls */}
        <div
          className={`flex items-center justify-center gap-8 ${
            isSensitiveBlocked ? "pointer-events-none opacity-0" : ""
          }`}
        >
          <button
            type="button"
            aria-label="Skip audio back 5 seconds"
            onClick={onAudioSkipBackward}
            className="relative p-2 bg-black/20 rounded-full border border-white/20 transition-all duration-200 hover:scale-110"
          >
            <RotateCcw className="w-5 h-5 text-white" />

            <span className="absolute inset-0 flex items-center justify-center text-[10px] font-bold text-white pointer-events-none">
              5s
            </span>
          </button>

          <button
            type="button"
            aria-label="Play or pause audio"
            onClick={toggleAudioPlay}
            className="relative p-3 bg-black/20 rounded-full border border-white/30 shadow-2xl transition-all duration-300 hover:scale-110"
          >
            {isPlaying ? (
              <Pause className="w-7 h-7 text-white fill-white" />
            ) : (
              <Play className="w-7 h-7 text-white fill-white ml-0.5" />
            )}
          </button>

          <button
            type="button"
            aria-label="Skip audio forward 5 seconds"
            onClick={onAudioSkipForward}
            className="relative p-2 bg-black/20 rounded-full border border-white/20 transition-all duration-200 hover:scale-110"
          >
            <RotateCw className="w-5 h-5 text-white" />

            <span className="absolute inset-0 flex items-center justify-center text-[10px] font-bold text-white pointer-events-none">
              5s
            </span>
          </button>
        </div>

        {/* Bottom Controls */}
        <div
          className={`absolute bottom-0 left-0 right-0
          pt-6 pb-3 px-3 z-30 ${
            isSensitiveBlocked ? "pointer-events-none opacity-0" : ""
          }`}
          aria-hidden={isSensitiveBlocked}
        >
          {/* Seekbar */}
          <div
            ref={audioProgressBarRef}
            className="relative h-1 bg-white/80 rounded-full cursor-pointer group/progress overflow-visible mb-3"
            onClick={onAudioProgressClick}
            onMouseMove={handleProgressHover}
            onMouseLeave={() =>
              setHoverProgress(null)
            }
          >
            {/* Filled Progress */}
            <div
              className="absolute left-0 top-0 h-full bg-gradient-to-r from-primary to-primary/80 rounded-full transition-all duration-150"
              style={{
                width: `${audioProgressPercentage}%`,
              }}
            />

            {/* Cursor */}
            <div
              className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-lg
              opacity-0 group-hover/progress:opacity-100 transition-all duration-200 hover:scale-125"
              style={{
                left: `${audioProgressPercentage}%`,
              }}
            />

            {/* Hover Time */}
            {hoverProgress !== null && (
              <div
                className="absolute -top-8 -translate-x-1/2 bg-black/80 backdrop-blur-sm text-white text-xs px-2 py-1 rounded-md pointer-events-none whitespace-nowrap"
                style={{
                  left: `${hoverProgress}%`,
                }}
              >
                {formatPlayerTime(
                  (hoverProgress / 100) *
                    audioDuration
                )}
              </div>
            )}
          </div>

          {/* Bottom Row */}
          <div className="flex items-center justify-between">
            {/* Time */}
            <div className="flex items-center space-x-1 text-white/80 text-sm font-mono px-2 py-1 rounded-md">
              <span>
                {formatPlayerTime(
                  audioCurrentTime
                )}
              </span>

              <span className="text-white/40">
                /
              </span>

              <span className="text-white/60">
                {formatPlayerTime(
                  audioDuration
                )}
              </span>
            </div>

            {/* Volume */}
            <div
              className="relative"
              ref={volumeSliderRef}
            >
              <button
                type="button"
                aria-label="Volume control"
                onClick={() => {
                  handleGlobalMuteToggle();
                  setShowVolumeSlider(true);
                }}
                className="p-2 bg-white/10 hover:bg-white/20 rounded-full backdrop-blur-sm transition-all duration-200"
              >
                {isMuted || volume === 0 ? (
                  <VolumeX className="w-4 h-4 text-white" />
                ) : (
                  <Volume2 className="w-4 h-4 text-white" />
                )}
              </button>

              {/* Volume Slider */}
              {showVolumeSlider && (
                <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 flex items-center p-2 bg-black/80 backdrop-blur-xl rounded-xl border border-white/20 shadow-xl z-50">
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.01"
                    value={volume}
                    onChange={
                      handleVolumeChange
                    }
                    className="w-24 h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer
                    [&::-webkit-slider-thumb]:appearance-none
                    [&::-webkit-slider-thumb]:w-3
                    [&::-webkit-slider-thumb]:h-3
                    [&::-webkit-slider-thumb]:rounded-full
                    [&::-webkit-slider-thumb]:bg-primary
                    [&::-webkit-slider-thumb]:shadow-lg"
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Hidden Audio */}
      <audio
        ref={audioRef}
        src={isSensitiveBlocked ? undefined : audioUrl}
        preload="metadata"
        onEnded={onAudioEnded}
        onLoadedMetadata={onAudioMetadataLoad}
        onLoadStart={onAudioLoadStart}
        onCanPlay={onAudioCanPlay}
      />

      {isSensitiveBlocked && (
        <SensitiveContentOverlay onClick={onSensitiveClick} />
      )}
    </div>
  );
};

export default AudioMedia;
