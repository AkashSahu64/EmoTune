// hooks/useRequireAuth.js (unchanged)
import { useCallback } from "react";
import { useAuthStore } from "../store/authStore.js";
import { useUIStore } from "../store/uiStore.js";

export const useRequireAuth = () => {
  const { isAuthenticated } = useAuthStore();
  const { openModal } = useUIStore();

  const requireAuth = useCallback(
    (callback) => {
      if (isAuthenticated) {
        callback();
      } else {
        openModal("login", { onSuccess: callback });
      }
    },
    [isAuthenticated, openModal]
  );

  return requireAuth;
};