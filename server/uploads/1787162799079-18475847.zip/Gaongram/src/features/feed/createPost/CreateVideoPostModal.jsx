// src/features/feed/createPost/CreateVideoPostModal.jsx
import React, { useEffect, useMemo, useState } from "react";
import { X, Pencil } from "lucide-react";
import { useUIStore } from "../../../store/uiStore.js";
import { postCreateService } from "../../../services/postCreate.service.js";
import { showSuccess, showError } from "../../../utils/toast.js";
import Button from "../../../components/common/Button.jsx";
import UploadZone from "./UploadZone.jsx";
import PostCaptionEditor from "./PostCaptionEditor.jsx";
import MediaEditorModal from "./MediaEditorModal.jsx";
import { useAuthStore } from "../../../store/authStore.js";
import { FEED_EVENTS, publishFeedEvent } from "../../../utils/feedEvents.js";
import SensitiveContentCheckbox from "./SensitiveContentCheckbox.jsx";

const VideoPreview = ({ file, className }) => {
  const previewUrl = useMemo(() => URL.createObjectURL(file), [file]);

  useEffect(() => {
    return () => URL.revokeObjectURL(previewUrl);
  }, [previewUrl]);

  return <video src={previewUrl} controls className={className} />;
};

const CreateVideoPostModal = () => {
  const { user } = useAuthStore();
  const { closeModal } = useUIStore();
  const [caption, setCaption] = useState("");
  const [videos, setVideos] = useState([]);
  const [currentEditingIndex, setCurrentEditingIndex] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [privacy] = useState("public");
  const [location, setLocation] = useState("");
  const [isSensitive, setIsSensitive] = useState(false);

  // ✅ FILE SELECT
  const handleFileSelect = (file) => {
    if (!file) return;

    if (videos.length >= 1) {
      showError("Only one video allowed");
      return;
    }

    setVideos([file]);
    // setCurrentEditingIndex(0);
  };

  // ✅ EDIT COMPLETE
  const handleEditComplete = (editedFile) => {
    if (currentEditingIndex !== null) {
      const updated = [...videos];
      updated[currentEditingIndex] = editedFile;
      setVideos(updated);
      setCurrentEditingIndex(null);
    }
  };

  // ✅ REMOVE VIDEO
  const removeVideo = (index) => {
    setVideos(videos.filter((_, i) => i !== index));
  };

  // ✅ SUBMIT
  const handleSubmit = async () => {
    if (videos.length === 0) {
      showError("Please select a video");
      return;
    }

    setIsSubmitting(true);

    const formData = new FormData();

    formData.append("content", caption);
    formData.append("author", user?.id); // ✅ REQUIRED
    formData.append("privacy", privacy);
    formData.append("is_sensitive", isSensitive);

    if (location) formData.append("location", location);

    // ✅ NESTED FORMAT (IMPORTANT)
    videos.forEach((vid, index) => {
      formData.append(`videos[${index}]video`, vid);
    });

    formData.append("show_profile", "false");

    try {
      await postCreateService.createPost(formData);
      showSuccess("Video post created!");
      closeModal();
      publishFeedEvent({ type: FEED_EVENTS.CREATED });
    } catch {
      showError("Failed to create post");
    } finally {
      setIsSubmitting(false);
    }
  };

  const currentEditingFile =
    currentEditingIndex !== null ? videos[currentEditingIndex] : null;

  return (
    <div className="w-full max-w-lg bg-card dark:bg-card-dark rounded-2xl overflow-hidden">
      {/* HEADER */}
      <div className="sticky top-0 z-20 border-b border-border dark:border-border-dark px-4 py-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold">Create Video Post</h2>

          <button
            onClick={closeModal}
            className="p-2 rounded-full hover:bg-mutedForeground/20 dark:hover:bg-mutedForeground-dark/30 transition"
          >
            <X className="w-4 h-4 text-foreground dark:text-foreground-dark" />
          </button>
        </div>
      </div>

      {/* BODY */}
      <div className="max-h-[75vh] overflow-y-auto px-4 py-4 space-y-4 hide-scrollbar">
        {/* CAPTION */}
        <PostCaptionEditor caption={caption} setCaption={setCaption} />

        {/* UPLOAD */}
        <div>
          <p className="text-sm font-medium mb-2">Video</p>

          <UploadZone
            onFileSelect={handleFileSelect}
            accept="video/*"
            maxSizeMB={50}
            multiple={false}
          />
        </div>

        {/* PREVIEW CARD (SAME AS IMAGE STYLE) */}
        {videos.length > 0 && (
          <div className="flex justify-center">
            {videos.map((vid, idx) => (
              <div key={idx} className="relative">
                <VideoPreview
                  file={vid}
                  className=" w-full max-w-56 max-h-64 rounded-lg object-contain bg-black"
                />

                {/* DELETE */}
                <button
                  onClick={() => removeVideo(idx)}
                  className="absolute top-1 right-1 p-1 bg-black/50 text-white rounded-full"
                >
                  <X className="w-3 h-3" />
                </button>

                {/* EDIT */}
                <button
                  onClick={() => setCurrentEditingIndex(idx)}
                  className="absolute bottom-1 right-1"
                >
                  <Pencil className="w-6 h-6 p-1.5 bg-black/50 text-white rounded-full" />
                </button>
              </div>
            ))}
          </div>
        )}

        <SensitiveContentCheckbox
          checked={isSensitive}
          onChange={setIsSensitive}
        />
        {/* SUBMIT */}
        <Button
          variant="primary"
          fullWidth
          onClick={handleSubmit}
          loading={isSubmitting}
          disabled={videos.length === 0}
        >
          Post
        </Button>
      </div>

      {/* MEDIA EDITOR */}
      {currentEditingFile && (
        <MediaEditorModal
          isOpen={true}
          onClose={() => setCurrentEditingIndex(null)}
          mediaFile={currentEditingFile}
          onSave={handleEditComplete}
          mediaType="video"
        />
      )}
    </div>
  );
};

export default CreateVideoPostModal;
