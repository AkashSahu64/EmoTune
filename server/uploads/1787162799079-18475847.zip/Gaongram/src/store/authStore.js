import { create } from "zustand";
import { persist } from "zustand/middleware";
import { queryClient } from "../app/queryClient.js";
import { TOKEN_KEYS } from "../config/env.js";
import { authService } from "../services/auth.service.js";
import { useChatStore } from "./chatStore.js";
import { useUIStore } from "./uiStore.js";
import { showToast } from "../utils/toast.js";

const AUTH_STORAGE_KEY = "auth-storage";

const getInitialAuthState = () => {
  const hasToken = authService.isAuthenticated();
  const user = hasToken ? authService.getCurrentUser() : null;

  return {
    user,
    isAuthenticated: Boolean(hasToken && user),
    loading: false,
    error: null,
  };
};

const clearPersistedAuth = () => {
  if (typeof localStorage === "undefined") return;
  localStorage.removeItem(AUTH_STORAGE_KEY);
};

export const useAuthStore = create(
  persist(
    (set, get) => ({
      ...getInitialAuthState(),
      logoutSequence: 0,

      setUser: (user) => {
        set({ user, isAuthenticated: Boolean(user), error: null });
        if (typeof localStorage === "undefined") return;

        if (user) {
          localStorage.setItem(TOKEN_KEYS.USER_DATA, JSON.stringify(user));
        } else {
          localStorage.removeItem(TOKEN_KEYS.USER_DATA);
        }
      },

      login: async (credentials) => {
        set({ loading: true, error: null });

        try {
          const res = await authService.login(credentials);
          const user = res.data.user;

          set({
            user,
            isAuthenticated: true,
            loading: false,
            error: null,
          });

          return {
            success: true,
            data: res.data,
          };
        } catch (error) {
          const res = error.response?.data;

          set({
            error: res?.message || "Login failed",
            loading: false,
          });

          return {
            success: false,
            message: res?.message || "Login failed",
            errors: res?.errors || null,
          };
        }
      },

      register: async (userData) => {
        set({ loading: true, error: null });

        try {
          const res = await authService.register(userData);

          set({ loading: false });

          return {
            success: true,
            data: res,
          };
        } catch (error) {
          const res = error.response?.data;

          set({
            error: res?.message || "Registration failed",
            loading: false,
          });

          return {
            success: false,
            message: res?.message || "Registration failed",
            errors: res?.errors || null,
          };
        }
      },

      verifyOtp: async (otpData) => {
        set({ loading: true, error: null });
        try {
          const data = await authService.verifyOtp(otpData);
          set({
            user: data.data.user,
            isAuthenticated: true,
            loading: false,
            error: null,
          });
          return { success: true, data };
        } catch (error) {
          set({
            error: error.response?.data?.message || "OTP verification failed",
            loading: false,
          });
          return { success: false, error: error.message };
        }
      },

      googleAuth: async (token) => {
        set({ loading: true, error: null });
        try {
          const data = await authService.googleAuth(token);
          set({
            user: data.data.user,
            isAuthenticated: true,
            loading: false,
            error: null,
          });
          return { success: true, data };
        } catch (error) {
          set({
            error:
              error.response?.data?.message || "Google authentication failed",
            loading: false,
          });
          return { success: false, error: error.message };
        }
      },

      clearSession: ({ notify = false } = {}) => {
        authService.clearLocalAuth();
        useUIStore.getState().closeAllModals();
        useChatStore.getState().clearSession?.();
        queryClient.clear();

        set((state) => ({
          user: null,
          isAuthenticated: false,
          loading: false,
          error: null,
          logoutSequence: state.logoutSequence + 1,
        }));

        clearPersistedAuth();

        if (typeof window !== "undefined") {
          window.dispatchEvent(new Event("gaongram:logout"));
        }

        if (notify) {
          showToast("Logged out successfully", "success");
        }
      },

      logout: async ({ notify = true } = {}) => {
        try {
          await authService.logout();
        } catch (error) {
          console.error("Logout error:", error);
        } finally {
          get().clearSession({ notify });
        }
      },

      logoutAll: async ({ notify = true } = {}) => {
        set({ loading: true, error: null });
        try {
          await authService.logoutAll();
        } catch (error) {
          console.error("Logout all error:", error);
        } finally {
          get().clearSession({ notify });
        }
      },

      clearError: () => set({ error: null }),
    }),
    {
      name: AUTH_STORAGE_KEY,
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated,
      }),
      merge: (persistedState, currentState) => {
        const hasToken = authService.isAuthenticated();
        if (!hasToken) {
          authService.clearLocalAuth();
          clearPersistedAuth();
          return {
            ...currentState,
            user: null,
            isAuthenticated: false,
            loading: false,
            error: null,
          };
        }

        const user = persistedState?.user || authService.getCurrentUser();
        return {
          ...currentState,
          ...persistedState,
          user,
          isAuthenticated: Boolean(user),
          loading: false,
          error: null,
        };
      },
    },
  ),
);