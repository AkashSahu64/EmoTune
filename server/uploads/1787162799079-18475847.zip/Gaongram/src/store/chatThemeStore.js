import { create } from "zustand";
import { persist } from "zustand/middleware";

export const useChatThemeStore = create(
  persist(
    (set) => ({
      currentTheme: "forest",

      setTheme: (theme) =>
        set({
          currentTheme: theme,
        }),
    }),
    {
      name: "chat-theme-storage",
    }
  )
);