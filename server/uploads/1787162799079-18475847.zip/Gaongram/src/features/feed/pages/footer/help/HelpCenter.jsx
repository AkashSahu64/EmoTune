// src/pages/HelpCenter.jsx
import React, { useState, useEffect, useMemo, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, X, ChevronRight, MessageCircle } from "lucide-react";
import { categories, helpArticles } from "./helpData";
import CategoryGrid from "./CategoryGrid";
import FAQAccordion from "./FAQAccordion";
import SearchResults from "./SearchResults";
import KnowledgeSection from "./KnowledgeSection";
import PublicLayout from "../../../components/layout/PublicLayout";
import Seo from "../../../../../components/seo/Seo.jsx";
import { buildStaticPageSeo } from "../../../../../seo/seoBuilders.js";

const HelpCenter = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [expandedArticleId, setExpandedArticleId] = useState(null);
  const searchInputRef = useRef(null);

  // Debounce search
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchQuery);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Filter articles based on debounced query
  const filteredArticles = useMemo(() => {
    if (!debouncedQuery.trim()) return [];
    const query = debouncedQuery.toLowerCase().trim();
    return helpArticles
      .filter((article) => {
        return (
          article.question.toLowerCase().includes(query) ||
          article.answer.toLowerCase().includes(query) ||
          article.keywords.some((kw) => kw.includes(query))
        );
      })
      .sort((a, b) => {
        // Ranking: exact match in question first
        const aExact = a.question.toLowerCase().includes(query);
        const bExact = b.question.toLowerCase().includes(query);
        if (aExact && !bExact) return -1;
        if (!aExact && bExact) return 1;
        return 0;
      });
  }, [debouncedQuery]);

  const showSearchResults = debouncedQuery.trim().length > 0;

  const handleSearchFocus = () => setIsSearching(true);
  const handleSearchBlur = () => setTimeout(() => setIsSearching(false), 200);
  const handleClearSearch = () => {
    setSearchQuery("");
    setDebouncedQuery("");
    searchInputRef.current?.focus();
  };

  const handleArticleClick = (articleId) => {
    setExpandedArticleId(articleId);
    // Scroll to the article (implementation depends on your accordion)
    setTimeout(() => {
      document
        .getElementById(`article-${articleId}`)
        ?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 100);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.05 } },
  };

  return (
    <PublicLayout>
      <Seo {...buildStaticPageSeo("help")} />
      <div className="min-h-screen bg-white dark:bg-background-dark">
        {/* Hero with Search */}
        <section className="pt-12 pb-8 md:pt-20 md:pb-12 bg-gradient-to-b from-muted/30 dark:from-muted-dark/30">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <motion.h1
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-3xl md:text-5xl font-bold text-foreground dark:text-foreground-dark mb-8"
            >
              How can we help you?
            </motion.h1>
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="relative max-w-2xl mx-auto"
            >
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-mutedForeground" />
                <input
                  ref={searchInputRef}
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={handleSearchFocus}
                  onBlur={handleSearchBlur}
                  placeholder="Search for help..."
                  className="w-full pl-12 pr-10 py-4 text-base bg-card dark:bg-card-dark border border-border dark:border-border-dark rounded-full focus:outline-none focus:ring-1 focus:ring-primary/60 transition"
                />
                {searchQuery && (
                  <button
                    onClick={handleClearSearch}
                    className="absolute right-4 top-1/2 -translate-y-1/2 p-1 rounded-full hover:bg-muted dark:hover:bg-muted-dark"
                  >
                    <X className="w-4 h-4 text-mutedForeground" />
                  </button>
                )}
              </div>
              {/* Search Suggestions Dropdown */}
              <AnimatePresence>
                {isSearching &&
                  debouncedQuery &&
                  filteredArticles.length > 0 && (
                    <motion.div
                      initial={{ opacity: 0, y: -5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -5 }}
                      className="absolute top-full left-0 right-0 mt-2 bg-card dark:bg-card-dark border border-border dark:border-border-dark rounded-xl shadow-premium z-50 max-h-80 overflow-y-auto"
                    >
                      {filteredArticles.slice(0, 8).map((article) => (
                        <button
                          key={article.id}
                          onClick={() => {
                            handleArticleClick(article.id);
                            setSearchQuery(article.question);
                            setIsSearching(false);
                          }}
                          className="w-full px-4 py-3 text-left hover:bg-muted dark:hover:bg-muted-dark transition flex items-start gap-3 border-b border-border/50 last:border-0"
                        >
                          <Search className="w-4 h-4 mt-0.5 text-mutedForeground flex-shrink-0" />
                          <span className="text-sm text-foreground dark:text-foreground-dark">
                            {article.question}
                          </span>
                        </button>
                      ))}
                    </motion.div>
                  )}
              </AnimatePresence>
            </motion.div>
          </div>
        </section>

        {/* Main Content */}
        <div className="max-w-6xl mx-auto px-4 py-8">
          <AnimatePresence mode="wait">
            {showSearchResults ? (
              <SearchResults
                key="results"
                articles={filteredArticles}
                query={debouncedQuery}
                onArticleClick={handleArticleClick}
                expandedId={expandedArticleId}
                setExpandedId={setExpandedArticleId}
              />
            ) : (
              <motion.div
                key="normal"
                variants={containerVariants}
                initial="hidden"
                animate="visible"
              >
                {/* Category Grid */}
                <CategoryGrid
                  categories={categories}
                  onSelectCategory={setSelectedCategory}
                  selectedCategory={selectedCategory}
                />

                {/* FAQ Accordion for selected category or popular */}
                <section className="mt-16">
                  <h2 className="text-2xl font-bold text-foreground dark:text-foreground-dark mb-6">
                    {selectedCategory
                      ? `${categories.find((c) => c.id === selectedCategory)?.name} FAQs`
                      : "Frequently Asked Questions"}
                  </h2>
                  <FAQAccordion
                    articles={helpArticles.filter((a) =>
                      selectedCategory ? a.category === selectedCategory : true,
                    )}
                    expandedId={expandedArticleId}
                    setExpandedId={setExpandedArticleId}
                  />
                </section>

                {/* Full Knowledge Base Sections */}
                <KnowledgeSection />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </PublicLayout>
  );
};

export default HelpCenter;
