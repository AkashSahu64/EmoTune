export class HistoryManager {
  constructor(limit = 40) {
    this.limit = limit;
    this.past = [];
    this.future = [];
  }

  push(snapshot) {
    this.past = [...this.past.slice(-(this.limit - 1)), snapshot];
    this.future = [];
  }

  undo(current) {
    if (!this.past.length) return current;
    const previous = this.past.pop();
    this.future.unshift(current);
    return previous;
  }

  redo(current) {
    if (!this.future.length) return current;
    const next = this.future.shift();
    this.push(current);
    return next;
  }
}
