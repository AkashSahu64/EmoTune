import { FFmpeg } from "@ffmpeg/ffmpeg";
import coreURL from "../../../../../node_modules/@ffmpeg/core/dist/umd/ffmpeg-core.js?url";
import wasmURL from "../../../../../node_modules/@ffmpeg/core/dist/umd/ffmpeg-core.wasm?url";
import { normalizeStoryMediaUrl, normalizeStoryMusic } from "../../audio/storyAudioManager.js";

const DEFAULT_STORY_DURATION = 15;
const MAX_STORY_DURATION = 30;
const FFMPEG_LOAD_TIMEOUT_MS = 120_000;
const AUDIO_FETCH_TIMEOUT_MS = 15_000;
const EXPORT_TIMEOUT_MS = 60_000;
const CLEANUP_TIMEOUT_MS = 3_000;
const AUDIO_FETCH_RETRIES = 1;
const DEBUG_PREFIX = "[StoryExport]";

let ffmpegInstance = null;
let ffmpegLoadPromise = null;
let activeExportPromise = null;
let activeExecPromise = null;

const debugLog = (phase, details = {}) => {
  if (!import.meta.env?.DEV) return;
  console.debug(DEBUG_PREFIX, phase, {
    ...details,
    at: Math.round(performance.now()),
  });
};

const clampDuration = (value) => {
  const duration = Number(value);
  if (!Number.isFinite(duration) || duration <= 0) return DEFAULT_STORY_DURATION;
  return Math.min(Math.max(duration, 1), MAX_STORY_DURATION);
};

const safeProgress = (onProgress, progress, message) => {
  onProgress?.({
    progress: Math.min(100, Math.max(0, Math.round(progress))),
    message,
  });
};

const getAudioExtension = (url = "") => {
  const pathname = (() => {
    try {
      return new URL(url, window.location.href).pathname;
    } catch {
      return url;
    }
  })();
  const extension = pathname.split(".").pop()?.toLowerCase() || "mp3";
  if (["mp3", "m4a", "aac", "wav", "ogg", "opus", "flac"].includes(extension)) {
    return extension;
  }
  return "mp3";
};

const wait = (ms) => new Promise((resolve) => window.setTimeout(resolve, ms));

const withTimeout = (promise, timeoutMs, message) => {
  let timer = null;
  const timeoutPromise = new Promise((_, reject) => {
    timer = window.setTimeout(() => {
      reject(new Error(message));
    }, timeoutMs);
  });

  return Promise.race([promise, timeoutPromise]).finally(() => {
    if (timer) window.clearTimeout(timer);
  });
};

const blobToUint8Array = async (blob, timeoutMs, label) => {
  const arrayBuffer = await withTimeout(
    blob.arrayBuffer(),
    timeoutMs,
    `${label} took too long. Please try again.`,
  );
  return new Uint8Array(arrayBuffer);
};

const fetchAudioBytes = async (url, options = {}) => {
  const { timeoutMs = AUDIO_FETCH_TIMEOUT_MS, retries = AUDIO_FETCH_RETRIES } = options;
  let lastError = null;

  for (let attempt = 0; attempt <= retries; attempt += 1) {
    const startedAt = performance.now();
    try {
      debugLog("audio-fetch-start", { attempt: attempt + 1, url });
      const response = await withTimeout(
        fetch(url, {
          cache: "no-store",
          mode: "cors",
        }),
        timeoutMs,
        "Audio loading took too long. Please try another track or retry.",
      );

      if (!response.ok) {
        throw new Error(`Audio request failed (${response.status})`);
      }

      const arrayBuffer = await withTimeout(
        response.arrayBuffer(),
        timeoutMs,
        "Audio processing took too long. Please try another track or retry.",
      );
      debugLog("audio-fetch-done", {
        attempt: attempt + 1,
        ms: Math.round(performance.now() - startedAt),
        bytes: arrayBuffer.byteLength,
      });
      return new Uint8Array(arrayBuffer);
    } catch (error) {
      lastError = error;
      debugLog("audio-fetch-failed", {
        attempt: attempt + 1,
        ms: Math.round(performance.now() - startedAt),
        message: error?.message,
      });
      if (attempt < retries) await wait(450);
    }
  }

  throw lastError || new Error("Unable to load audio");
};

const cleanupFiles = async (ffmpeg, files) => {
  if (!ffmpeg?.loaded || activeExecPromise) return;
  await withTimeout(
    Promise.allSettled(files.map((file) => ffmpeg.deleteFile(file))),
    CLEANUP_TIMEOUT_MS,
    "FFmpeg cleanup timed out",
  ).catch((error) => {
    debugLog("cleanup-skipped", { message: error?.message });
  });
};

const ensureFFmpegLoadStarted = (onProgress) => {
  if (!ffmpegInstance) {
    ffmpegInstance = new FFmpeg();
  }

  if (!ffmpegInstance.loaded && !ffmpegLoadPromise) {
    safeProgress(onProgress, 28, "Preparing video engine...");
    debugLog("ffmpeg-load-start");
    const instance = ffmpegInstance;
    const loadPromise = (async () => {
      try {
        const result = await instance.load({ coreURL, wasmURL });
        debugLog("ffmpeg-load-done");
        return result;
      } catch (error) {
        debugLog("ffmpeg-load-failed", { message: error?.message });
        if (ffmpegInstance === instance && !instance.loaded) {
          ffmpegInstance = null;
        }
        throw error;
      } finally {
        if (ffmpegLoadPromise === loadPromise) {
          ffmpegLoadPromise = null;
        }
      }
    })();
    ffmpegLoadPromise = loadPromise;
  }

  return ffmpegLoadPromise;
};

const getFFmpeg = async (onProgress) => {
  ensureFFmpegLoadStarted(onProgress);

  if (!ffmpegInstance.loaded) {
    const slowLoadTimer = window.setTimeout(() => {
      safeProgress(onProgress, 30, "Preparing video engine...");
    }, 8_000);

    await withTimeout(
      ffmpegLoadPromise,
      FFMPEG_LOAD_TIMEOUT_MS,
      "Media engine is taking too long to start. Please retry.",
    ).finally(() => {
      window.clearTimeout(slowLoadTimer);
    });
  }

  return ffmpegInstance;
};

export const preloadStoryVideoExporter = () => {
  const loadPromise = ensureFFmpegLoadStarted();
  return (loadPromise || Promise.resolve()).catch((error) => {
    debugLog("ffmpeg-preload-failed", { message: error?.message });
  });
};

const runLockedFFmpegExec = (ffmpeg, args) => {
  if (activeExecPromise) {
    return Promise.reject(new Error("A story video export is already encoding. Please wait a moment."));
  }

  let trackedPromise = null;
  trackedPromise = ffmpeg.exec(args).finally(() => {
    if (activeExecPromise === trackedPromise) {
      activeExecPromise = null;
    }
  });
  activeExecPromise = trackedPromise;
  return trackedPromise;
};

export const exportImageMusicStoryVideo = async ({
  imageBlob,
  music,
  fileName = "story.mp4",
  onProgress,
} = {}) => {
  if (activeExportPromise || activeExecPromise) {
    throw new Error("A story export is already running. Please wait a moment.");
  }

  activeExportPromise = exportImageMusicStoryVideoInternal({
    imageBlob,
    music,
    fileName,
    onProgress,
  }).finally(() => {
    activeExportPromise = null;
  });

  return activeExportPromise;
};

const exportImageMusicStoryVideoInternal = async ({
  imageBlob,
  music,
  fileName = "story.mp4",
  onProgress,
} = {}) => {
  const exportStartedAt = performance.now();
  const normalizedMusic = normalizeStoryMusic(music);
  if (!imageBlob) {
    throw new Error("Story image frame is not ready");
  }
  if (!normalizedMusic?.audio) {
    throw new Error("Select a music track before exporting video");
  }

  const audioUrl = normalizeStoryMediaUrl(normalizedMusic.audio);
  const duration = clampDuration(normalizedMusic.duration);
  const startTime = Math.max(0, Number(normalizedMusic.startTime) || 0);
  const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const imageInput = `frame-${id}.jpg`;
  const audioInput = `audio-${id}.${getAudioExtension(audioUrl)}`;
  const output = `story-${id}.mp4`;
  const tempFiles = [imageInput, audioInput, output];
  let ffmpeg = null;
  let imageData = null;
  let audioData = null;
  let execPromise = null;
  let execSettled = false;

  const progressHandler = ({ progress }) => {
    if (Number.isFinite(progress)) {
      safeProgress(onProgress, 55 + progress * 30, "Encoding video...");
    }
  };

  try {
    debugLog("export-start", {
      duration,
      startTime,
      imageBytes: imageBlob.size,
    });

    const ffmpegPromise = getFFmpeg(onProgress);
    safeProgress(onProgress, 34, "Loading audio...");
    const audioPromise = fetchAudioBytes(audioUrl);
    [ffmpeg, audioData] = await Promise.all([ffmpegPromise, audioPromise]);

    safeProgress(onProgress, 45, "Processing media...");
    imageData = await blobToUint8Array(imageBlob, 6_000, "Story frame rendering");
    await ffmpeg.writeFile(imageInput, imageData);
    imageData = null;

    safeProgress(onProgress, 50, "Processing audio...");
    await ffmpeg.writeFile(audioInput, audioData);
    audioData = null;

    safeProgress(onProgress, 55, "Encoding video...");
    ffmpeg.on("progress", progressHandler);
    const execStartedAt = performance.now();
    const execArgs = [
      "-loop",
      "1",
      "-t",
      duration.toFixed(3),
      "-i",
      imageInput,
      "-ss",
      startTime.toFixed(3),
      "-t",
      duration.toFixed(3),
      "-i",
      audioInput,
      "-map",
      "0:v:0",
      "-map",
      "1:a:0",
      "-c:v",
      "libx264",
      "-preset",
      "ultrafast",
      "-tune",
      "stillimage",
      "-crf",
      "32",
      "-r",
      "24",
      "-pix_fmt",
      "yuv420p",
      "-c:a",
      "aac",
      "-b:a",
      "96k",
      "-shortest",
      "-movflags",
      "+faststart",
      output,
    ];
    execPromise = runLockedFFmpegExec(ffmpeg, execArgs).finally(() => {
      execSettled = true;
    });
    const exitCode = await withTimeout(
      execPromise,
      EXPORT_TIMEOUT_MS,
      "Video export took too long. Please retry with a shorter audio clip.",
    );
    debugLog("ffmpeg-exec-done", {
      exitCode,
      ms: Math.round(performance.now() - execStartedAt),
    });

    if (exitCode !== 0) {
      throw new Error("Video export failed");
    }

    safeProgress(onProgress, 88, "Finalizing story...");
    const data = await ffmpeg.readFile(output);
    const blob = new Blob([data], { type: "video/mp4" });
    const file = new File([blob], fileName, {
      type: "video/mp4",
      lastModified: Date.now(),
    });

    debugLog("export-done", {
      ms: Math.round(performance.now() - exportStartedAt),
      outputBytes: blob.size,
    });
    safeProgress(onProgress, 92, "Finalizing story...");
    return {
      blob,
      file,
      duration,
      storyType: "video",
      embeddedAudio: true,
    };
  } catch (error) {
    debugLog("export-failed", {
      ms: Math.round(performance.now() - exportStartedAt),
      message: error?.message,
    });
    throw new Error(
      error?.message?.includes("fetch") || error?.message?.includes("Audio")
        ? "Unable to load the selected audio for video export. Please try another track."
        : error?.message || "Video export failed",
    );
  } finally {
    imageData = null;
    audioData = null;
    ffmpeg?.off("progress", progressHandler);
    if (execPromise && !execSettled) {
      execPromise
        .finally(() => cleanupFiles(ffmpeg, tempFiles))
        .catch(() => undefined);
    } else {
      await cleanupFiles(ffmpeg, tempFiles);
    }
  }
};

export const terminateStoryVideoExporter = () => {
  ffmpegInstance?.terminate();
  ffmpegInstance = null;
  ffmpegLoadPromise = null;
};
