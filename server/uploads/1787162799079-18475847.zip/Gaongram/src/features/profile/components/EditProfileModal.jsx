// components/EditProfileModal.jsx
import React, { useState, useRef } from 'react';
import { X, Camera, Upload, User, Globe, Lock } from 'lucide-react';
import { motion } from 'framer-motion';
import Button from '../../../components/common/Button';
import { showToast } from '../../../utils/toast';

const EditProfileModal = ({ 
  isOpen, 
  onClose, 
  profile, 
  onUpdate, 
  isUpdating 
}) => {
  const [formData, setFormData] = useState({
    first_name: profile?.first_name || '',
    last_name: profile?.last_name || '',
    username: profile?.username || '',
    bio: profile?.bio || '',
    city: profile?.city || '',
    state: profile?.state || '',
    country: profile?.country || '',
    pin_code: profile?.pin_code || '',
    address: profile?.address || '',
    external_link: profile?.external_link || '',
    is_private: profile?.is_private || false,
  });

  const [profileImage, setProfileImage] = useState(null);
  const [coverImage, setCoverImage] = useState(null);
  const [profileImagePreview, setProfileImagePreview] = useState(profile?.photo || profile?.profile_image);
  const [coverImagePreview, setCoverImagePreview] = useState(profile?.background_image);
  
  const profileInputRef = useRef(null);
  const coverInputRef = useRef(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const data = { ...formData };
    
    // Add images if selected
    if (profileImage) {
      data.photo = profileImage;
    }
    if (coverImage) {
      data.background_image = coverImage;
    }
    
    // Handle reset_photo if needed
    if (!profileImage && profileImagePreview !== (profile?.photo || profile?.profile_image)) {
      data.reset_photo = true;
    }
    
    try {
      await onUpdate({ 
        data, 
        isImageUpdate: profileImage || coverImage 
      });
      onClose();
    } catch (error) {
      showToast('Failed to update profile', 'error');
    }
  };

  const handleImageChange = (e, type) => {
    const file = e.target.files[0];
    if (!file) return;

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      showToast('Image must be less than 5MB', 'error');
      return;
    }

    // Validate file type
    if (!file.type.startsWith('image/')) {
      showToast('Please select an image file', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      if (type === 'profile') {
        setProfileImage(file);
        setProfileImagePreview(reader.result);
      } else {
        setCoverImage(file);
        setCoverImagePreview(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveImage = (type) => {
    if (type === 'profile') {
      setProfileImage(null);
      setProfileImagePreview(null);
    } else {
      setCoverImage(null);
      setCoverImagePreview(null);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center">
        <div 
          className="fixed inset-0 bg-black/70 transition-opacity"
          onClick={onClose}
        />

        <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-2xl overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b">
            <h3 className="text-lg font-semibold text-gray-900">
              Edit Profile
            </h3>
            <button
              onClick={onClose}
              className="p-1 text-gray-400 hover:text-gray-600"
            >
              <X size={20} />
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="max-h-[80vh] overflow-y-auto">
            <div className="p-6 space-y-6">
              {/* Cover Image */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Cover Photo
                </label>
                <div className="h-48 rounded-lg overflow-hidden bg-gradient-to-r from-gray-100 to-gray-200 relative group">
                  {coverImagePreview ? (
                    <img
                      src={coverImagePreview}
                      alt="Cover preview"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center text-gray-400">
                      <Camera size={32} />
                      <p className="mt-2 text-sm">Add cover photo</p>
                    </div>
                  )}
                  
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <input
                      type="file"
                      ref={coverInputRef}
                      accept="image/*"
                      onChange={(e) => handleImageChange(e, 'cover')}
                      className="hidden"
                    />
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        size="small"
                        variant="outline"
                        onClick={() => coverInputRef.current?.click()}
                        className="bg-white/90 hover:bg-white"
                      >
                        <Upload size={14} className="mr-1" />
                        Change
                      </Button>
                      {coverImagePreview && (
                        <Button
                          type="button"
                          size="small"
                          variant="outline"
                          onClick={() => handleRemoveImage('cover')}
                          className="bg-white/90 hover:bg-white text-red-600 border-red-200"
                        >
                          Remove
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Profile Image */}
              <div className="flex justify-center -mt-12 relative">
                <div className="relative">
                  <div className="w-32 h-32 rounded-full border-4 border-white bg-gradient-to-r from-gray-100 to-gray-200 overflow-hidden">
                    {profileImagePreview ? (
                      <img
                        src={profileImagePreview}
                        alt="Profile preview"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <User size={48} className="text-gray-400" />
                      </div>
                    )}
                  </div>
                  
                  <button
                    type="button"
                    onClick={() => profileInputRef.current?.click()}
                    className="absolute bottom-2 right-2 p-2 bg-white rounded-full shadow-lg hover:bg-gray-50"
                  >
                    <Camera size={16} className="text-gray-700" />
                  </button>
                  <input
                    type="file"
                    ref={profileInputRef}
                    accept="image/*"
                    onChange={(e) => handleImageChange(e, 'profile')}
                    className="hidden"
                  />
                </div>
              </div>

              {/* Form Fields */}
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      First Name
                    </label>
                    <input
                      type="text"
                      value={formData.first_name}
                      onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      maxLength={50}
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Last Name
                    </label>
                    <input
                      type="text"
                      value={formData.last_name}
                      onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      maxLength={50}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Username
                  </label>
                  <input
                    type="text"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    maxLength={30}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Bio
                  </label>
                  <textarea
                    value={formData.bio}
                    onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                    rows={3}
                    maxLength={150}
                    placeholder="Tell your story..."
                  />
                  <div className="text-right text-xs text-gray-500 mt-1">
                    {formData.bio.length}/150
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Website
                  </label>
                  <input
                    type="url"
                    value={formData.external_link || ''}
                    onChange={(e) => setFormData({ ...formData, external_link: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="https://example.com"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      City
                    </label>
                    <input
                      type="text"
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Country
                    </label>
                    <input
                      type="text"
                      value={formData.country}
                      onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>
                </div>

                {/* Privacy Toggle */}
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    {formData.is_private ? (
                      <Lock className="w-5 h-5 text-gray-600" />
                    ) : (
                      <Globe className="w-5 h-5 text-gray-600" />
                    )}
                    <div>
                      <p className="font-medium text-gray-900">
                        {formData.is_private ? 'Private Account' : 'Public Account'}
                      </p>
                      <p className="text-sm text-gray-600">
                        {formData.is_private
                          ? 'Only approved followers can see your posts'
                          : 'Anyone can see your posts and follow you'}
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, is_private: !formData.is_private })}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      formData.is_private ? 'bg-blue-600' : 'bg-gray-200'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        formData.is_private ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="sticky bottom-0 bg-white border-t px-6 py-4">
              <div className="flex justify-end gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClose}
                  disabled={isUpdating}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  loading={isUpdating}
                  disabled={isUpdating}
                >
                  {isUpdating ? 'Saving...' : 'Save Changes'}
                </Button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default EditProfileModal;