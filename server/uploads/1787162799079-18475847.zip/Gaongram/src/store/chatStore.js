// src/store/chatStore.js
import { create } from "zustand";
import { devtools } from "zustand/middleware";
import { getCurrentUser } from "../utils/getCurrentUser.js";

export const useChatStore = create(
  devtools((set, get) => ({
    // State
    selectedChat: null,
    messages: new Map(), // chatId -> array of messages
    chatList: [], // array of chat user objects
    unreadCounts: new Map(), // userId -> unread count
    typingUsers: new Set(), // userIds currently typing
    onlineUsers: new Map(), // userId -> { online, lastSeen }
    tempMessages: new Map(), // tempId -> tempMessage
    blockedUsers: new Set(),
    failedMessages: new Map(), // tempId -> { error, retryFn }

    // ---------- Messages ----------
    addMessages: (chatId, newMessages) => {
      const current = get().messages.get(chatId) || [];
      const existingIds = new Set(current.map((m) => m.id || m.tempId));
      const uniqueNew = newMessages.filter((m) => {
        if (!m.id) {
          return false; 
        }

        if (m.isTemp) return !existingIds.has(m.id);
        return !existingIds.has(m.id) && !get().tempMessages.has(m.id);
      });
      if (uniqueNew.length === 0) return;
      const updated = [...current, ...uniqueNew].sort(
        (a, b) => new Date(a.created_at) - new Date(b.created_at),
      );
      get().messages.set(chatId, updated);
      set({ messages: new Map(get().messages) });
    },

    addTempMessage: (chatId, tempMessage) => {
      const temps = get().tempMessages;
      temps.set(tempMessage.tempId, tempMessage);
      set({ tempMessages: new Map(temps) });
      const current = get().messages.get(chatId) || [];
      get().messages.set(chatId, [...current, tempMessage]);
      set({ messages: new Map(get().messages) });
    },

    replaceTempMessage: (chatId, tempId, realMessage) => {
      const temps = get().tempMessages;
      temps.delete(tempId);
      set({ tempMessages: new Map(temps) });
      const messages = get().messages.get(chatId) || [];
      const index = messages.findIndex((m) => m.tempId === tempId);
      if (index !== -1) {
        if (realMessage) {
          messages[index] = realMessage;
        } else {
          messages.splice(index, 1);
        }
        get().messages.set(chatId, [...messages]);
        set({ messages: new Map(get().messages) });
      }
    },

    markMessageFailed: (tempId, retryFn) => {
      const failed = get().failedMessages;
      failed.set(tempId, { error: true, retryFn });
      set({ failedMessages: new Map(failed) });
    },

    clearFailedMessage: (tempId) => {
      const failed = get().failedMessages;
      failed.delete(tempId);
      set({ failedMessages: new Map(failed) });
    },

    updateMessage: (chatId, messageId, updates) => {
      const messages = get().messages.get(chatId);
      if (!messages) return;
      const index = messages.findIndex((m) => m.id === messageId);
      if (index !== -1) {
        messages[index] = { ...messages[index], ...updates };
        get().messages.set(chatId, [...messages]);
        set({ messages: new Map(get().messages) });
      }
    },

    deleteMessage: (chatId, messageId, forEveryone = false) => {
      const messages = get().messages.get(chatId);
      if (!messages) return;
      if (forEveryone) {
        const filtered = messages.filter((m) => m.id !== messageId);
        get().messages.set(chatId, filtered);
      } else {
        const index = messages.findIndex((m) => m.id === messageId);
        if (index !== -1) {
          messages[index].deleted_for_me = true;
          get().messages.set(chatId, [...messages]);
        }
      }
      set({ messages: new Map(get().messages) });
    },

    clearChat: (chatId) => {
      get().messages.set(chatId, []);
      set({ messages: new Map(get().messages) });
    },

    // ---------- Chat List ----------
    setChatList: (chats) => set({ chatList: chats }),

    updateChatList: (updatedChat) => {
      const current = get().chatList;
      const index = current.findIndex((c) => c.id === updatedChat.id);
      let newList;
      if (index !== -1) {
        newList = [...current];
        newList[index] = { ...current[index], ...updatedChat };
      } else {
        newList = [updatedChat, ...current];
      }
      set({ chatList: newList });
    },

    updateUnreadCount: (userId, countOrUpdater) => {
      const counts = get().unreadCounts;
      const current = counts.get(userId) || 0;
      const newCount =
        typeof countOrUpdater === "function"
          ? countOrUpdater(current)
          : countOrUpdater;
      if (newCount === current) return;
      counts.set(userId, newCount);
      set({ unreadCounts: new Map(counts) });
    },

    // ---------- Typing ----------
    addTypingUser: (userId) => {
      const typing = new Set(get().typingUsers);
      typing.add(userId);
      set({ typingUsers: typing });
    },

    removeTypingUser: (userId) => {
      const typing = new Set(get().typingUsers);
      typing.delete(userId);
      set({ typingUsers: typing });
    },

    // ---------- Online ----------
    setOnline: (userId, isOnline, lastSeen = null) => {
      const online = new Map(get().onlineUsers);
      online.set(userId, {
        online: isOnline,
        lastSeen: lastSeen || Date.now(),
      });
      set({ onlineUsers: online });
    },

    // ---------- Block ----------
    addBlockedUser: (userId) => {
      const blocked = new Set(get().blockedUsers);
      blocked.add(userId);
      set({ blockedUsers: blocked });
    },

    removeBlockedUser: (userId) => {
      const blocked = new Set(get().blockedUsers);
      blocked.delete(userId);
      set({ blockedUsers: blocked });
    },

    sendReply: (chatId, originalMessage, replyText) => {
      const currentUser = getCurrentUser();
      if (!currentUser?.id) return;

      const tempId = `temp_${Date.now()}`;
      const replyMessage = {
        id: tempId,
        tempId,
        sender: currentUser.id,
        message: replyText,
        reply_to: originalMessage,
        created_at: new Date().toISOString(),
        isTemp: true,
      };
      get().addTempMessage(chatId, replyMessage);
      // Emit via WebSocket (handled elsewhere)
    },

    setSelectedChat: (chat) => set({ selectedChat: chat }),

    clearSession: () =>
      set({
        selectedChat: null,
        messages: new Map(),
        chatList: [],
        unreadCounts: new Map(),
        typingUsers: new Set(),
        onlineUsers: new Map(),
        tempMessages: new Map(),
        blockedUsers: new Set(),
        failedMessages: new Map(),
      }),
  })),
);