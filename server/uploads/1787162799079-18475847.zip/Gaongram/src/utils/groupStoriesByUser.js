// export const groupStoriesByUser = (stories) => {
//   const groups = [];
//   stories.forEach((story) => {
//     const existing = groups.find((g) => g.userId === story.user_id);
//     if (existing) {
//       existing.stories.push(story);
//     } else {
//       groups.push({
//         userId: story.user_id,
//         username: story.username,
//         profile_image: story.profile_image,
//         has_unseen: false, // you'd compute this
//         stories: [story],
//       });
//     }
//   });
//   return groups;
// };