export function constrainToBounds(object, canvasWidth, canvasHeight) {
  if (!object) return;

  const objWidth = object.getScaledWidth();
  const objHeight = object.getScaledHeight();

  let left = object.left;
  let top = object.top;

  const minLeft = objWidth / 2;
  const maxLeft = canvasWidth - objWidth / 2;
  const minTop = objHeight / 2;
  const maxTop = canvasHeight - objHeight / 2;

  left = Math.max(minLeft, Math.min(left, maxLeft));
  top = Math.max(minTop, Math.min(top, maxTop));

  object.set({ left, top, originX: "center", originY: "center" });
}