// src/features/feed/createPost/components/editor/ImageEditorControls.jsx

import EditorTabs from "./components/EditorTabs";
import CropControls from "./components/CropControls";
import FilterControls from "./components/FilterControls";
import PaintControls from "./components/PaintControls";
import EditorFooter from "./components/EditorFooter";

const ImageEditorControls = (props) => {

  const {
    tab,
    setTab,
  } = props;

  return (

    <div className="border-t">

      <EditorTabs
        tab={tab}
        setTab={setTab}
      />

      <div className="px-2 pb-2 h-[160px] overflow-y-auto">

        {tab === "crop" && (
          <CropControls {...props} />
        )}

        {tab === "filters" && (
          <FilterControls {...props} />
        )}

        {tab === "paint" && (
          <PaintControls {...props} />
        )}

      </div>

      <EditorFooter {...props} />

    </div>

  );

};

export default ImageEditorControls;