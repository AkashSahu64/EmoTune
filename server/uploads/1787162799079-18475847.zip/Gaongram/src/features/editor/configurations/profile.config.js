import { EDITOR_CONFIGS, EDITOR_MODES } from "../core/editorConfig.js";

export const profileEditorConfig = {
  ...EDITOR_CONFIGS[EDITOR_MODES.profile],
  aspectRatios: ["free", "1:1", "4:5", "3:4"],
  crop: {
    shape: "round",
    maxZoom: 4,
    outputQuality: 0.92,
  },
};

export default profileEditorConfig;
