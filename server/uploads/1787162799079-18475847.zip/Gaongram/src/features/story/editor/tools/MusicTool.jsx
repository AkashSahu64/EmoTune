import React, { useEffect, useMemo, useRef, useState } from "react";
import { Check, Music, Pause, Play, Search, X } from "lucide-react";
import Loader from "../../../../components/common/Loader.jsx";
import { vibeAudioService } from "../../../../services/story.service.js";
import { storyAudioManager } from "../../audio/storyAudioManager.js";
import CustomWaveform from "../components/CustomWaveform.jsx";
import { useCanvasStore } from "../useCanvasStore.js";

const DEFAULT_CLIP_DURATION = 15;

const MusicTool = ({ engine }) => {
  const selectedMusic = useCanvasStore((state) => state.music);
  const setMusic = useCanvasStore((state) => state.setMusic);
  const [tracks, setTracks] = useState([]);
  const [query, setQuery] = useState("");
  const [playingId, setPlayingId] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const observerRef = useRef(null);

  const fetchTracks = async (pageNumber = 1) => {
    setIsLoading(true);

    try {
      const res = await vibeAudioService.getAudios(pageNumber);
      const tracksData = res.data.map((item) => ({
        id: item.id,
        audio: item.audio,
        title: item.title || "Untitled audio",
        cover_image: item.cover_image || "",
        artist: item.artist || "GaonGram",
        sourceDuration: Number(item.duration) || null,
      }));

      setTracks((prev) => (pageNumber === 1 ? tracksData : [...prev, ...tracksData]));
      setHasMore(!!res.next);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTracks(1);

    return () => {
      observerRef.current?.disconnect();
      storyAudioManager.pause();
    };
  }, []);

  useEffect(() => {
    const unsubscribeEnded = storyAudioManager.subscribe("segmentended", () => {
      setPlayingId(null);
    });
    const unsubscribeState = storyAudioManager.subscribe("statechange", (event) => {
      if (!event.detail.isPlaying) setPlayingId(null);
    });

    return () => {
      unsubscribeEnded();
      unsubscribeState();
    };
  }, []);

  const lastTrackRef = (node) => {
    if (isLoading) return;

    observerRef.current?.disconnect();
    observerRef.current = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && hasMore) {
        const nextPage = page + 1;
        setPage(nextPage);
        fetchTracks(nextPage);
      }
    });

    if (node) observerRef.current.observe(node);
  };

  const filteredTracks = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return tracks;
    return tracks.filter(
      (track) =>
        track.title.toLowerCase().includes(normalized) ||
        track.artist.toLowerCase().includes(normalized),
    );
  }, [query, tracks]);

  const handlePreview = async (track) => {
    if (playingId === track.id) {
      storyAudioManager.pause();
      setPlayingId(null);
      return;
    }

    const isSelected = selectedMusic?.id === track.id;
    const previewMusic = {
      ...track,
      startTime: isSelected ? selectedMusic.startTime : 0,
      duration: isSelected ? selectedMusic.duration : DEFAULT_CLIP_DURATION,
    };

    setPlayingId(track.id);
    await storyAudioManager.playSegment(previewMusic, {
      loop: false,
      seek: true,
      volume: 0.8,
    });

    if (!storyAudioManager.getSnapshot().isPlaying) {
      setPlayingId(null);
    }
  };

  const handleSelect = (track) => {
    const musicData = {
      id: track.id,
      audio: track.audio,
      title: track.title,
      cover_image: track.cover_image,
      artist: track.artist,
      startTime: 0,
      duration: DEFAULT_CLIP_DURATION,
      sourceDuration: track.sourceDuration || null,
    };

    setMusic(musicData);
    setPlayingId(null);
    storyAudioManager.setSegment(musicData, { seekToStart: true, keepPlaying: false });
  };

  const handleClear = () => {
    storyAudioManager.pause();
    setPlayingId(null);
    setMusic(null);
    engine?.removeMusicLayer();
  };

  const handleTrimChange = ({ startTime, duration }, options = {}) => {
    if (!selectedMusic) return;
    setMusic(
      {
        ...selectedMusic,
        startTime,
        duration,
      },
      { recordHistory: options.recordHistory ?? false },
    );
    storyAudioManager.setSegment(
      {
        ...selectedMusic,
        startTime,
        duration,
      },
      {
        seekToStart: !!options.seekToStart,
        keepPlaying: true,
      },
    );
  };

  return (
    <div className="space-y-2">
      <label className="relative block">
        <Search
          className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-mutedForeground dark:text-mutedForeground-dark"
          size={17}
        />
        <input
          type="search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search music"
          className="h-10 w-full rounded-lg border border-border bg-gray-100 pl-10 pr-3 text-sm text-foreground outline-none transition placeholder:text-mutedForeground focus:border-primary dark:border-border-dark dark:bg-muted-dark dark:text-foreground-dark dark:placeholder:text-mutedForeground-dark"
        />
      </label>

      {selectedMusic && (
        <>
          <div className="flex items-center gap-3 rounded-lg border border-border bg-card px-2 py-1 dark:border-border-dark dark:bg-card-dark">
            <div className="h-10 w-10 overflow-hidden rounded-md bg-gray-100 dark:bg-muted-dark">
              {selectedMusic.cover_image ? (
                <img src={selectedMusic.cover_image} alt="" className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full w-full items-center justify-center">
                  <Music size={18} />
                </div>
              )}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-foreground dark:text-foreground-dark">
                {selectedMusic.title}
              </p>
              <p className="truncate text-xs text-mutedForeground dark:text-mutedForeground-dark">
                {selectedMusic.artist}
              </p>
            </div>
            <button
              type="button"
              onClick={handleClear}
              className="flex h-9 w-9 items-center justify-center rounded-full bg-muted text-foreground transition hover:bg-border dark:bg-muted-dark dark:text-foreground-dark dark:hover:bg-border-dark"
              aria-label="Remove music"
              title="Remove music"
            >
              <X size={16} />
            </button>
          </div>

          <CustomWaveform audioUrl={selectedMusic.audio} onTrimChange={handleTrimChange} />
        </>
      )}

      <div className="space-y-2">
        {isLoading &&
          Array.from({ length: 5 }).map((_, index) => (
            <div
              key={index}
              className="h-12 animate-pulse rounded-md bg-muted dark:bg-muted-dark"
            />
          ))}

        {!isLoading && filteredTracks.length === 0 && (
          <div className="rounded-lg border border-border bg-card p-3 text-center text-sm text-mutedForeground dark:border-border-dark dark:bg-card-dark dark:text-mutedForeground-dark">
            No music found.
          </div>
        )}

        {filteredTracks.map((track, index) => {
          const isSelected = selectedMusic?.id === track.id;
          const isLast = index === filteredTracks.length - 1;
          const isPlaying = playingId === track.id;

          return (
            <div
              ref={isLast ? lastTrackRef : null}
              key={track.id}
              className={`flex items-center gap-3 rounded-lg border px-2 py-1 transition ${
                isSelected
                  ? "border-primary bg-primary/10 dark:bg-primary/20"
                  : "border-border bg-card hover:bg-muted dark:border-border-dark dark:bg-card-dark dark:hover:bg-muted-dark"
              }`}
            >
              <button
                type="button"
                onClick={() => handlePreview(track)}
                className="relative h-10 w-10 shrink-0 overflow-hidden rounded-md bg-gray-100 dark:bg-muted-dark"
                aria-label={isPlaying ? "Pause preview" : "Play preview"}
                title={isPlaying ? "Pause" : "Play"}
              >
                {track.cover_image ? (
                  <img src={track.cover_image} alt="" className="h-full w-full object-cover" />
                ) : (
                  <span className="flex h-full w-full items-center justify-center">
                    <Music size={18} />
                  </span>
                )}
                <span className="absolute inset-0 flex items-center justify-center bg-black/35 text-white">
                  {isPlaying ? <Pause size={18} fill="currentColor" /> : <Play size={18} fill="currentColor" />}
                </span>
              </button>
              <button
                type="button"
                onClick={() => handleSelect(track)}
                className="min-w-0 flex-1 text-left"
              >
                <p className="truncate text-sm font-semibold text-foreground dark:text-foreground-dark">
                  {track.title}
                </p>
                <p className="truncate text-xs text-mutedForeground dark:text-mutedForeground-dark">
                  {track.artist}
                </p>
              </button>
              {isSelected && (
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-white">
                  <Check size={16} />
                </span>
              )}
            </div>
          );
        })}

        {isLoading && tracks.length > 0 && (
          <div className="flex justify-center py-3">
            <Loader size="small" />
          </div>
        )}
      </div>
    </div>
  );
};

export default React.memo(MusicTool);
