import { create } from "zustand";
import { persist } from "zustand/middleware";

const DEFAULT_FOLLOW_STATE = {
  isFollowing: false,
  isRequested: false,
  isLoading: false,
  lastUpdated: 0,
};

const normalizeFollowState = (value = {}) => ({
  isFollowing: Boolean(value.is_following ?? value.isFollowing),
  isRequested: Boolean(
    value.is_following_requested ?? value.isRequested,
  ),
  isLoading: Boolean(value.isLoading),
  lastUpdated: Date.now(),
});

export const useFollowStore = create(
  persist(
    (set, get) => ({
      followMap: {},

      syncFromProfile: (profile) => {
        if (!profile?.user_id) return;

        set((state) => ({
          followMap: {
            ...state.followMap,
            [profile.user_id]: {
              ...(state.followMap[profile.user_id] || DEFAULT_FOLLOW_STATE),
              ...normalizeFollowState(profile),
            },
          },
        }));
      },

      initializeFromProfile: (profile) => get().syncFromProfile(profile),

      syncFromNotification: (notification) => {
        if (!notification?.sender) return;

        set((state) => ({
          followMap: {
            ...state.followMap,
            [notification.sender]: {
              ...(state.followMap[notification.sender] || DEFAULT_FOLLOW_STATE),
              ...normalizeFollowState(notification),
            },
          },
        }));
      },

      syncMultiple: (users) => {
        if (!Array.isArray(users) || !users.length) return;

        const updates = {};

        for (const user of users) {
          if (user.user_id) {
            updates[user.user_id] = {
              ...(get().followMap[user.user_id] || DEFAULT_FOLLOW_STATE),
              ...normalizeFollowState(user),
            };
          }
        }

        set((state) => ({
          followMap: { ...state.followMap, ...updates },
        }));
      },

      getFollowState: (userId) =>
        get().followMap[userId] || DEFAULT_FOLLOW_STATE,

      setFollowState: (userId, nextState) => {
        if (!userId) return;

        set((state) => ({
          followMap: {
            ...state.followMap,
            [userId]: {
              ...(state.followMap[userId] || DEFAULT_FOLLOW_STATE),
              ...nextState,
              lastUpdated: Date.now(),
            },
          },
        }));
      },

      batchUpdateFollowStates: (states) => {
        const updates = {};

        Object.entries(states).forEach(([userId, state]) => {
          updates[userId] = {
            ...(get().followMap[userId] || DEFAULT_FOLLOW_STATE),
            ...state,
            lastUpdated: Date.now(),
          };
        });

        set((state) => ({
          followMap: { ...state.followMap, ...updates },
        }));
      },

      clearAll: () => set({ followMap: {} }),
    }),
    {
      name: "follow-storage",
      partialize: (state) => ({ followMap: state.followMap }),
      merge: (persisted, current) => ({
        ...current,
        followMap: { ...current.followMap, ...(persisted?.followMap || {}) },
      }),
    },
  ),
);
