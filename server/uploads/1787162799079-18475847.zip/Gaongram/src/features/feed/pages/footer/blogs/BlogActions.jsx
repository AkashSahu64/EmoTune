// src/features/blogs/components/BlogActions.jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import Button from "../../../../../components/common/Button";
import { showSuccess, showError } from "../../../../../utils/toast";
import blogService from "../../../../../services/blogService";
import { canDeleteBlog } from "../../../../../utils/blogPermissions";

const BlogActions = ({ blogId, blog, onDelete, isDeleting }) => {
  const navigate = useNavigate();
  const [showConfirm, setShowConfirm] = useState(false);

  const handleEdit = () => {
    navigate(`/blogs/edit/${blogId}`);
  };

  const handleDeleteClick = () => {
    // Additional check: ensure user can delete
    if (blog && !canDeleteBlog(blog)) {
      showError("You are not authorized to delete this blog.");
      return;
    }
    setShowConfirm(true);
  };

  const handleConfirmDelete = async () => {
    if (onDelete) {
      onDelete(blogId);
    } else {
      try {
        const response = await blogService.deleteBlog(blogId);
        if (response.success) {
          showSuccess("Blog deleted successfully");
        }
      } catch (error) {
        showError(error.message || "Failed to delete blog");
      }
    }
    setShowConfirm(false);
  };

  return (
    <>
      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="small"
          onClick={() => navigate(`/blogs/${blogId}`)}
          className="text-foreground dark:text-foreground-dark"
        >
          View
        </Button>
        <Button variant="ghost" size="small" onClick={handleEdit}>
          Edit
        </Button>
        <Button
          variant="ghost"
          size="small"
          onClick={handleDeleteClick}
          disabled={isDeleting}
          className="text-danger hover:bg-danger/10"
        >
          Delete
        </Button>
      </div>

      {showConfirm && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
          onClick={() => setShowConfirm(false)}
        >
          <motion.div
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            className="bg-card dark:bg-card-dark rounded-xl p-6 max-w-sm w-full shadow-premium"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-lg font-semibold mb-2">Delete Blog</h3>
            <p className="text-mutedForeground dark:text-mutedForeground-dark mb-6">
              Are you sure you want to delete this blog? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setShowConfirm(false)}>
                Cancel
              </Button>
              <Button variant="danger" onClick={handleConfirmDelete} loading={isDeleting}>
                Delete
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </>
  );
};

export default BlogActions;