// utils/normalizeMessage.js

export const normalizeMessage = (msg) => ({
  ...msg,
  sender: msg.sender || msg.sender_id,
  receiver: msg.receiver || msg.receiver_id,
  delivered_at: msg.delivered_at || null,
  seen_at: msg.seen_at || null,
});