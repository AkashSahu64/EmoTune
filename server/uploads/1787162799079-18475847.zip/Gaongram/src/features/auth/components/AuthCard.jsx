import React from 'react';
import { motion } from 'framer-motion';

const AuthCard = ({ children, className = '' }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10 ${className}`}
    >
      {children}
    </motion.div>
  );
};

export default AuthCard;