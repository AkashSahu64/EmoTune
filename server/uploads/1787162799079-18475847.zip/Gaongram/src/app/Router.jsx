// src/Router.jsx
import React, { Suspense, lazy, useEffect } from "react";
import { Routes, Route, Navigate, useNavigate } from "react-router-dom";
import { useAuthStore } from "../store/authStore.js";
import Loader from "../components/common/Loader.jsx";
import Layout from "../components/layout/Layout.jsx";
import InitialRouteGuard from "../features/auth/components/InitialRouteGuard.jsx";
import SearchPage from "../features/search/pages/SearchPage.jsx";
import MessagesPage from "../features/messages/pages/MessagesPage.jsx";
import ChatScreen from "../features/messages/pages/ChatScreen.jsx";
import BlogList from "../features/feed/pages/footer/blogs/BlogList.jsx";
import BlogForm from "../features/feed/pages/footer/blogs/BlogForm.jsx";
import BlogDetail from "../features/feed/pages/footer/blogs/BlogDetail.jsx";
import ResetPassword from "../features/auth/pages/ResetPassword.jsx";
import ProfileFeedPage from "../features/profile/ProfileFeedPage.jsx";
import ProfileVideoFeed from "../features/profile/ProfileVideoFeed.jsx";
import HashtagFeedPage from "../features/search/pages/HashtagFeedPage.jsx";
import VibeFeedPage from "../features/search/pages/VibeFeedPage.jsx";

// Lazy load pages (unchanged)
const Login = lazy(() => import("../features/auth/pages/Login.jsx"));
const Register = lazy(() => import("../features/auth/pages/Register.jsx"));
const VerifyOtp = lazy(() => import("../features/auth/pages/VerifyOtp.jsx"));
const GoogleAuth = lazy(() => import("../features/auth/pages/GoogleAuth.jsx"));
const ForgotPassword = lazy(
  () => import("../features/auth/pages/ForgotPassword.jsx"),
);
const ChangePassword = lazy(
  () => import("../features/auth/pages/ChangePassword.jsx"),
);

const Home = lazy(() => import("../features/feed/pages/Home.jsx"));
const Reels = lazy(() => import("../pages/Reels.jsx"));
const Audio = lazy(() => import("../pages/Audio.jsx"));
const PlaylistsPage = lazy(
  () => import("../pages/playlists/PlaylistsPage.jsx"),
);
const PlaylistDetailPage = lazy(
  () => import("../pages/playlists/PlaylistDetailPage.jsx"),
);
const AddAudioPage = lazy(() => import("../pages/playlists/AddAudioPage.jsx"));
const Profile = lazy(() => import("../features/profile/ProfilePage.jsx"));
const StoryViewer = lazy(() => import("../features/story/StoryViewer.jsx"));
const NotificationList = lazy(
  () => import("../features/notifications/NotificationList.jsx"),
);
const TrendingHashtags = lazy(
  () => import("../features/hashtags/TrendingHashtags.jsx"),
);
const About = lazy(
  () => import("../features/feed/pages/footer/about/About.jsx"),
);
const HelpCenter = lazy(
  () => import("../features/feed/pages/footer/help/HelpCenter.jsx"),
);
const Safety = lazy(
  () => import("../features/feed/pages/footer/safety/Safety.jsx"),
);
const CommunityGuidelines = lazy(
  () =>
    import("../features/feed/pages/footer/guidelines/CommunityGuidelines.jsx"),
);
const Privacy = lazy(
  () => import("../features/feed/pages/footer/privacy/Privacy.jsx"),
);
const Terms = lazy(
  () => import("../features/feed/pages/footer/term/Terms.jsx"),
);
const Language = lazy(
  () => import("../features/feed/pages/footer/language/Language.jsx"),
);
const Contact = lazy(
  () => import("../features/feed/pages/footer/contact/Contact.jsx"),
);
const NotFound = lazy(() => import("../pages/NotFound.jsx"));
// const ResetPassword = lazy(() => import("../features/auth/pages/ResetPassword.jsx"));

// Route Guards
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated } = useAuthStore();
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  return children;
};

const GuestRoute = ({ children }) => {
  const { isAuthenticated } = useAuthStore();
  if (isAuthenticated) {
    return <Navigate to="/" replace />;
  }
  return children;
};

const FullscreenRoute = ({ children }) => {
  const { isAuthenticated } = useAuthStore();
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  return children;
};

const AuthLogoutRedirect = () => {
  const navigate = useNavigate();
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const logoutSequence = useAuthStore((state) => state.logoutSequence);

  useEffect(() => {
    if (logoutSequence > 0 && !isAuthenticated) {
      navigate("/login", { replace: true });
    }
  }, [isAuthenticated, logoutSequence, navigate]);

  return null;
};

const Router = () => {
  return (
    <Suspense fallback={<Loader fullScreen />}>
      <AuthLogoutRedirect />
      <Routes>
        {/* Public Auth Routes (guests only) */}
        <Route
          path="/login"
          element={
            <GuestRoute>
              <Login />
            </GuestRoute>
          }
        />
        <Route
          path="/register"
          element={
            <GuestRoute>
              <Register />
            </GuestRoute>
          }
        />
        <Route
          path="/verify-otp"
          element={
            <GuestRoute>
              <VerifyOtp />
            </GuestRoute>
          }
        />
        <Route
          path="/auth/google"
          element={
            <GuestRoute>
              <GoogleAuth />
            </GuestRoute>
          }
        />
        <Route
          path="/forgot-password"
          element={
            <GuestRoute>
              <ForgotPassword />
            </GuestRoute>
          }
        />
        <Route
          path="/reset-password"
          element={
            <GuestRoute>
              <ResetPassword />
            </GuestRoute>
          }
        />

        {/* Fullscreen Story Viewer (requires auth) */}
        <Route
          path="/story/:id"
          element={
            <FullscreenRoute>
              <StoryViewer />
            </FullscreenRoute>
          }
        />

        {/* Public Layout with InitialRouteGuard for "/" */}
        <Route
          path="/"
          element={
            <InitialRouteGuard>
              <Layout />
            </InitialRouteGuard>
          }
        >
          <Route index element={<Home />} />
          <Route path="feed" element={<Home />} />
          <Route path="reels" element={<Reels />} />
          <Route path="reels/:reelId" element={<Reels />} />
          <Route path="audio" element={<Audio />} />
          <Route
            path="profile/:username/post/:postId"
            element={<ProfileFeedPage />}
          />
          <Route path="profile/:identifier" element={<Profile />} />
          <Route path="profile-videos" element={<ProfileVideoFeed />} />
          <Route
            path="notifications"
            element={
              <ProtectedRoute>
                <NotificationList />
              </ProtectedRoute>
            }
          />
          <Route path="trending" element={<TrendingHashtags />} />
          <Route path="explore" element={<div>Explore Page</div>} />
          <Route path="saved" element={<div>Saved Page</div>} />
          <Route path="search" element={<SearchPage />} />
          <Route path="hashtag/:hashtag" element={<HashtagFeedPage />} />
          <Route path="playlists" element={<PlaylistsPage />} />
          <Route path="playlists/:id" element={<PlaylistDetailPage />} />
          <Route path="playlists/:id/add-audio" element={<AddAudioPage />} />
          <Route
            path="vibe-feed/:postId"
            element={<VibeFeedPage />}
          />

          {/* Protected Routes */}
          <Route
            path="messages"
            element={
              <ProtectedRoute>
                <MessagesPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="messages/:userId"
            element={
              <ProtectedRoute>
                <ChatScreen />
              </ProtectedRoute>
            }
          />
          <Route
            path="settings"
            element={
              <ProtectedRoute>
                <div>Settings Page</div>
              </ProtectedRoute>
            }
          />
          <Route
            path="change-password"
            element={
              <ProtectedRoute>
                <ChangePassword />
              </ProtectedRoute>
            }
          />
        </Route>

        {/* 404 */}
        <Route path="*" element={<NotFound />} />
        <Route path="safety" element={<Safety />} />
        <Route path="community-guidelines" element={<CommunityGuidelines />} />
        <Route path="privacy" element={<Privacy />} />
        <Route path="terms" element={<Terms />} />
        <Route path="language" element={<Language />} />
        <Route path="contact" element={<Contact />} />
        <Route path="about" element={<About />} />
        <Route path="help-center" element={<HelpCenter />} />
        <Route path="blogs" element={<BlogList />} />
        <Route
          path="blogs/create"
          element={
            <ProtectedRoute>
              <BlogForm />
            </ProtectedRoute>
          }
        />
        <Route
          path="blogs/edit/:id"
          element={
            <ProtectedRoute>
              <BlogForm />
            </ProtectedRoute>
          }
        />
        <Route path="blogs/:id" element={<BlogDetail />} />
      </Routes>
    </Suspense>
  );
};

export default Router;