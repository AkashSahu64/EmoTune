// 📁 /src/components/block/ProfileUnavailableView.jsx
import React from 'react';
import { motion } from 'framer-motion';
import { EyeOff } from 'lucide-react';

const ProfileUnavailableView = () => (
  <motion.div
    initial={{ opacity: 0, y: 18 }}
    animate={{ opacity: 1, y: 0 }}
    className="flex flex-col items-center justify-center py-16 px-6 text-center"
  >
    <div className="h-20 w-20 rounded-full bg-muted flex items-center justify-center mb-6">
      <EyeOff className="h-8 w-8 text-mutedForeground" />
    </div>
    <h2 className="text-xl font-semibold text-foreground">Profile unavailable</h2>
    <p className="mt-2 text-sm text-mutedForeground max-w-sm">
      This account is either private, deleted, or unavailable to you.
    </p>
  </motion.div>
);

export default React.memo(ProfileUnavailableView);