import React, { useMemo } from "react";
import { getTextGradient } from "../../../../utils/getTextGradient";

const TextMedia = ({ post, renderViewCount }) => {
  const bgStyle = useMemo(() => getTextGradient(post.id), [post.id]);

  return (
    <div
      style={bgStyle}
      className="relative w-full overflow-hidden"
    >
      {/* View Count */}
      {renderViewCount?.("text")}

      <div className="px-3 py-10">
        <div className="max-w-2xl mx-auto text-center">
          <p className="text-white text-lg md:text-2xl font-semibold leading-relaxed break-words whitespace-pre-wrap">
            {post.caption || post.content || "No content"}
          </p>
        </div>
      </div>
    </div>
  );
};

export default TextMedia;