import React from "react";
import { motion as Motion } from "framer-motion";
import { Brush, Image, Layers, Music, Palette, Scissors, Square, Type } from "lucide-react";
import { LuSticker } from "react-icons/lu";

const TOOL_DEFS = [
  { id: "text", label: "Text", icon: Type, feature: "text" },
  { id: "media", label: "Media", icon: Image, feature: "video" },
  { id: "emoji", label: "Stickers", icon: LuSticker, feature: "stickers" },
  { id: "filters", label: "Filters", icon: Palette, feature: "filters" },
  { id: "crop", label: "Crop", icon: Scissors, feature: "crop" },
  { id: "paint", label: "Paint", icon: Brush, feature: "drawing" },
  { id: "frame", label: "Frame", icon: Square, feature: "effects" },
  { id: "music", label: "Music", icon: Music, feature: "music" },
  { id: "layers", label: "Layers", icon: Layers, feature: "layers" },
];

const SharedToolbar = ({ activeTool, onToolChange, features = [] }) => {
  const tools = TOOL_DEFS.filter((tool) => features.includes(tool.feature) || tool.id === "filters");

  return (
    <nav
      className="no-scrollbar max-h-[85vh] flex w-full max-w-full touch-pan-x items-center gap-2 overflow-x-auto overscroll-x-contain rounded-xl border border-border bg-white/90 p-2 shadow-soft backdrop-blur-xl [-webkit-overflow-scrolling:touch] dark:border-border-dark dark:bg-gray-900/90 md:w-[4.75rem] md:flex-col md:gap-2 md:overflow-x-hidden md:overflow-y-auto md:px-2 md:py-3"
      aria-label="Editor tools"
    >
      {tools.map(({ id, label, icon }) => {
        const isActive = activeTool === id;
        return (
          <button
            key={id}
            type="button"
            onClick={() => onToolChange(id)}
            className="relative flex h-14 min-w-[4rem] shrink-0 flex-col items-center justify-center gap-1 rounded-lg px-2 py-2 text-xs font-medium outline-none transition focus-visible:ring-2 focus-visible:ring-primary/70 md:h-16 md:w-full md:min-w-0"
            aria-pressed={isActive}
            aria-label={label}
            title={label}
          >
            {isActive && (
              <Motion.div
                layoutId="shared-editor-active-tool"
                className="absolute inset-0 rounded-lg bg-primary shadow-md"
                transition={{ type: "spring", stiffness: 380, damping: 28 }}
              />
            )}
            <span className={`relative z-10 flex min-w-0 flex-col items-center gap-1 ${isActive ? "text-white" : "text-mutedForeground dark:text-mutedForeground-dark"}`}>
              {React.createElement(icon, { size: 20, strokeWidth: 2.2 })}
              <span className="max-w-full truncate leading-none">{label}</span>
            </span>
          </button>
        );
      })}
    </nav>
  );
};

export default React.memo(SharedToolbar);
