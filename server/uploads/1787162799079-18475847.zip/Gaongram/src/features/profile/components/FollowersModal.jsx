// components/FollowersModal.jsx - PREMIUM REDESIGN
import React, { useState } from "react";
import {
  X,
  Users,
  Search,
  UserCheck,
  UserPlus,
  CheckCircle,
  Lock,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useFollowersList } from "../../../hooks/useFollowersList";
import { useFollow } from "../../../hooks/useFollow";
import Avatar from "../../../components/common/Avatar";
import Button from "../../../components/common/Button";
import Loader from "../../../components/common/Loader";
import { useAuth } from "../../../hooks/useAuth";
import { useNavigate } from "react-router-dom";
import { showToast } from "../../../utils/toast";

const FollowersModal = ({ isOpen, onClose, userId, type = "followers" }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const { user: currentUser } = useAuth();
  const navigate = useNavigate();

  const {
    data,
    isLoading,
    isError,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
  } = useFollowersList(userId, type);

  const allUsers = data?.pages?.flatMap((page) => page.results) || [];

  const filteredUsers = allUsers.filter(
    (user) =>
      user.username?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.full_name?.toLowerCase().includes(searchQuery.toLowerCase()),
  );

  const modalTitle = type === "followers" ? "Followers" : "Following";
  const emptyText =
    type === "followers" ? "No followers yet" : "Not following anyone yet";

  const handleUserClick = (user) => {
    onClose();
    navigate(`/profile/${user.user_id}`);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-y-auto">
        <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center">
          {/* Premium Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm"
            onClick={onClose}
          />

          {/* Premium Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative bg-card dark:bg-card-dark rounded-xl w-full max-w-[400px] max-h-[80vh] overflow-hidden"
          >
            {/* Premium Header */}
            <div className="sticky top-0 z-20 border-b border-border dark:border-border-dark bg-card dark:bg-card-dark backdrop-blur-xl">
              <div className="px-2 pt-2 pb-1">
                {/* ---------- HEADER ---------- */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    {/* Icon */}
                    <div className=" flex h-10 w-10 items-center justify-center rounded-lg bg-primary  text-white">
                      <Users className="h-5 w-5" />
                    </div>

                    {/* Title */}
                    <div className="min-w-0 leading-tight">
                      <h3 className=" truncate text-[17px] font-bold tracking-[-0.01em] text-foreground dark:text-foreground-dark">
                        {modalTitle}
                      </h3>

                      <p className="flex items-center gap-1 text-xs font-medium text-mutedForeground dark:text-mutedForeground-dark">
                        {data?.pages?.[0]?.totalCount || 0} people
                      </p>
                    </div>
                  </div>

                  {/* Close Button */}
                  <button
                    onClick={onClose}
                    className=" flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-border dark:border-border-dark bg-muted dark:bg-muted-dark text-mutedForeground dark:text-mutedForeground-dark transition-all duration-200 hover:scale-[1.03] hover:bg-muted dark:hover:bg-muted-dark hover:text-foreground dark:hover:text-foreground-dark active:scale-95 "
                  >
                    <X size={24} />
                  </button>
                </div>

                {/* ---------- SEARCH ---------- */}
                <div className="relative mt-2">
                  <div className="relative">
                    <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-mutedForeground dark:text-mutedForeground-dark" />

                    <input
                      type="text"
                      placeholder={`Search ${modalTitle.toLowerCase()}...`}
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className=" h-10 w-full rounded-lg border border-border dark:border-border-dark bg-muted/30 dark:bg-muted-dark pl-11 pr-4 text-sm text-foreground dark:text-foreground-dark outline-none placeholder:text-mutedForeground/70 focus:border-primary/50 focus:bg-background focus:ring-1 focus:ring-primary/10"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="overflow-y-auto max-h-[calc(80vh-140px)]">
              {isLoading ? (
                <div className="py-12">
                  <div className="w-12 h-12 mx-auto border-3 border-primary border-t-transparent rounded-full animate-spin" />
                </div>
              ) : isError ? (
                <div className="py-12 text-center">
                  <div className="w-16 h-16 mx-auto mb-4 bg-red-50 rounded-2xl flex items-center justify-center">
                    <Users className="w-8 h-8 text-red-400" />
                  </div>
                  <p className="text-mutedForeground dark:text-mutedForeground-dark mb-4">
                    Failed to load {modalTitle.toLowerCase()}
                  </p>
                  <Button
                    variant="outline"
                    className="border-border dark:border-border-dark hover:bg-muted/50 dark:hover:bg-muted-dark rounded-xl"
                    onClick={() => window.location.reload()}
                  >
                    Retry
                  </Button>
                </div>
              ) : filteredUsers.length === 0 ? (
                <div className="py-12 text-center">
                  <div className="w-20 h-20 mx-auto mb-6 bg-muted rounded-2xl flex items-center justify-center shadow-sm">
                    <Users className="w-10 h-10 text-gray-300" />
                  </div>
                  <h4 className="text-lg font-medium text-foreground mb-2">
                    {searchQuery ? "No results found" : emptyText}
                  </h4>
                  <p className="text-mutedForeground dark:text-mutedForeground-dark text-sm">
                    {searchQuery
                      ? "Try a different search term"
                      : "When people follow you, they'll appear here"}
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-border dark:divide-border-dark">
                  {filteredUsers.map((user) => (
                    <UserListItem
                      key={user.id}
                      user={user}
                      currentUserId={currentUser?.user_id}
                      onUserClick={handleUserClick}
                      type={type}
                    />
                  ))}
                </div>
              )}

              {/* Premium Load More */}
              {hasNextPage && (
                <div className="p-4 text-center">
                  <Button
                    variant="outline"
                    onClick={() => fetchNextPage()}
                    loading={isFetchingNextPage}
                    disabled={isFetchingNextPage}
                    className="border-border dark:border-border-dark hover:bg-muted/50 dark:hover:bg-muted-dark rounded-xl px-8"
                  >
                    {isFetchingNextPage ? "Loading..." : "Load more"}
                  </Button>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </AnimatePresence>
  );
};

// Premium User List Item
const UserListItem = ({ user, currentUserId, onUserClick, type }) => {
  const {
    toggleFollow,
    isFollowing,
    isLoading,
    getFollowButtonState,
    followMap,
  } = useFollow(user.user_id, user.is_private);

  const followState = getFollowButtonState();

  const isOwnProfile = currentUserId === user.user_id;

  const handleFollowClick = (e) => {
    e.stopPropagation();
    toggleFollow();
  };

  return (
    <motion.div
      className="flex items-center justify-between px-3 py-1 hover:bg-gray-50 dark:hover:bg-muted-dark cursor-pointer"
      onClick={() => onUserClick(user)}
    >
      <div className="flex items-center gap-3 flex-1 min-w-0">
        <Avatar
          src={user.photo || user.profile_image}
          alt={user.username}
          size="medium"
          showStatus
          status={user.is_online ? "online" : "offline"}
          borderColor={user.is_verified ? "primary" : "gray-200"}
        />
        <div className="min-w-0 flex-2 leading-tight">
          <div className="flex items-center gap-2">
            <p className="font-medium text-foreground dark:text-foreground-dark truncate">
              {user.full_name || user.username}
            </p>
            {user.is_verified && (
              <span className="flex-shrink-0">
                <CheckCircle size={12} className="text-primary-soft" />
              </span>
            )}
            {user.is_private && (
              <span className="flex-shrink-0">
                <Lock size={13} className="text-mutedForeground dark:text-mutedForeground-dark" />
              </span>
            )}
          </div>
          <p className="text-sm text-mutedForeground dark:text-mutedForeground-dark truncate mr-16">
            @{user.username}
          </p>
        </div>
      </div>

      {/* Premium Follow Button */}
      {!isOwnProfile && followState && (
        <div onClick={handleFollowClick} className="flex-shrink-0">
          <Button
            size="small"
            variant={followState.variant}
            loading={isLoading}
            disabled={followState.disabled || isLoading}
            startIcon={
              followState.label === "Following" ? (
                <UserCheck size={14} />
              ) : (
                <UserPlus size={14} />
              )
            }
            className={`
              rounded-lg px-2 py-1.5 text-sm
              ${
                followState.variant === "primary"
                  ? "bg-primary hover:opacity-90 shadow-sm"
                  : "border border-border hover:bg-muted/50"
              }
            `}
          >
            {isLoading ? "..." : followState.label}
          </Button>
        </div>
      )}
    </motion.div>
  );
};

export default FollowersModal;
