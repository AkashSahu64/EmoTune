import React, { useState } from "react";
import { Send } from "lucide-react";
import { AnimatePresence, motion as Motion } from "framer-motion";

const StoryCommentInput = ({ rightElement }) => {
  const [message, setMessage] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSend = (e) => {
    e.stopPropagation();
    if (!message.trim() || isSending) return;

    setIsSending(true);

    setTimeout(() => {
      setIsSending(false);
      setMessage("");
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 2000);
    }, 500);
  };

  return (
    <div className="absolute bottom-[calc(env(safe-area-inset-bottom)+1rem)] left-3 right-3 z-40 sm:left-4 sm:right-4">
      <div className="flex items-center gap-3 max-w-md mx-auto">

        {/* Input */}
        <div className="relative flex-1">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend(e)}
            placeholder="Send message..."
            className="h-11 w-full rounded-full border border-white/15 bg-black/30 px-4 py-2 pr-12 text-white placeholder-white/60 backdrop-blur-xl focus:outline-none focus:ring-2 focus:ring-white/30 dark:border-white/15 dark:bg-black/35"
            onClick={(e) => e.stopPropagation()}
            aria-label="Send story message"
          />

          <button
            onClick={handleSend}
            disabled={!message.trim() || isSending}
            className="absolute right-1 top-1/2 flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10 disabled:opacity-50"
            aria-label="Send message"
          >
            {isSending ? (
              <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
            ) : (
              <Send size={18} />
            )}
          </button>
        </div>

        {/* Like Button */}
        {rightElement}

        <AnimatePresence>
          {showSuccess && (
            <Motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="absolute -top-10 left-1/2 -translate-x-1/2 bg-green-500 text-white px-4 py-2 rounded-full text-sm"
            >
              Message sent!
            </Motion.div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
};

export default React.memo(StoryCommentInput);
