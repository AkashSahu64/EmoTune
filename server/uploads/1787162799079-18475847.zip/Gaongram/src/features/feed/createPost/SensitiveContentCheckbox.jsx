import React from "react";
import { AlertTriangle } from "lucide-react";

const SensitiveContentCheckbox = ({ checked, onChange }) => {
  return (
    <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-amber-200 bg-amber-50/70 p-3 transition hover:bg-amber-50 dark:border-amber-500/30 dark:bg-amber-500/10">
      <input
        type="checkbox"
        checked={checked}
        onChange={(event) => onChange(event.target.checked)}
        className="mt-1 h-4 w-4 rounded border-amber-300 text-primary focus:ring-primary"
        aria-label="Blur this content for sensitive-content protection"
      />
      <span className="flex min-w-0 flex-1 gap-3">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-amber-100 text-amber-600 dark:bg-amber-500/20 dark:text-amber-300">
          <AlertTriangle className="h-5 w-5" aria-hidden="true" />
        </span>
        <span className="min-w-0">
          <span className="block text-sm font-semibold text-gray-950 dark:text-foreground-dark">
            Sensitive Content
          </span>
          <span className="mt-0.5 block text-xs leading-5 text-gray-600 dark:text-mutedForeground-dark">
            Mark this post as 18+ or sensitive material.
          </span>
          <span className="mt-2 block text-xs font-medium text-gray-800 dark:text-foreground-dark">
            Blur this content for sensitive-content protection
          </span>
        </span>
      </span>
    </label>
  );
};

export default SensitiveContentCheckbox;
