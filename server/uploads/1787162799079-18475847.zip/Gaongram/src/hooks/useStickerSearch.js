import { useState, useCallback } from 'react';
import { searchStickers } from '../services/stickerService';

export const useStickerSearch = () => {
  const [stickers, setStickers] = useState([]);
  const [loading, setLoading] = useState(false);

  const search = useCallback(async (query) => {
    if (!query.trim()) return;
    setLoading(true);
    const results = await searchStickers(query);
    setStickers(results);
    setLoading(false);
  }, []);

  return { stickers, loading, search };
};