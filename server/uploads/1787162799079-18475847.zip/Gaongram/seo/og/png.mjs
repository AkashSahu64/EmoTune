/* eslint-env node */
/* global Buffer */
import { deflateSync } from "node:zlib";

const WIDTH = 1200;
const HEIGHT = 630;

const crcTable = Array.from({ length: 256 }, (_, index) => {
  let value = index;
  for (let bit = 0; bit < 8; bit += 1) {
    value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
  }
  return value >>> 0;
});

const crc32 = (buffer) => {
  let crc = 0xffffffff;
  for (const byte of buffer) {
    crc = crcTable[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
};

const chunk = (type, data) => {
  const typeBuffer = Buffer.from(type, "ascii");
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length, 0);
  const checksum = Buffer.alloc(4);
  checksum.writeUInt32BE(crc32(Buffer.concat([typeBuffer, data])), 0);
  return Buffer.concat([length, typeBuffer, data, checksum]);
};

const colorFromString = (value = "") => {
  let hash = 2166136261;
  for (const char of String(value)) {
    hash ^= char.charCodeAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return [
    80 + (hash & 0x7f),
    100 + ((hash >>> 8) & 0x5f),
    80 + ((hash >>> 16) & 0x7f),
  ];
};

const mix = (a, b, amount) => Math.round(a + (b - a) * amount);

const setPixel = (pixels, x, y, [r, g, b]) => {
  if (x < 0 || y < 0 || x >= WIDTH || y >= HEIGHT) return;
  const index = (y * WIDTH + x) * 3;
  pixels[index] = r;
  pixels[index + 1] = g;
  pixels[index + 2] = b;
};

const fillRect = (pixels, x, y, width, height, color) => {
  for (let row = Math.max(0, y); row < Math.min(HEIGHT, y + height); row += 1) {
    for (let col = Math.max(0, x); col < Math.min(WIDTH, x + width); col += 1) {
      setPixel(pixels, col, row, color);
    }
  }
};

const fillCircle = (pixels, cx, cy, radius, color) => {
  const radiusSq = radius * radius;
  for (let y = cy - radius; y <= cy + radius; y += 1) {
    for (let x = cx - radius; x <= cx + radius; x += 1) {
      const dx = x - cx;
      const dy = y - cy;
      if (dx * dx + dy * dy <= radiusSq) setPixel(pixels, x, y, color);
    }
  }
};

const writePng = (pixels) => {
  const scanlineLength = WIDTH * 3 + 1;
  const raw = Buffer.alloc(scanlineLength * HEIGHT);

  for (let y = 0; y < HEIGHT; y += 1) {
    raw[y * scanlineLength] = 0;
    pixels.copy(raw, y * scanlineLength + 1, y * WIDTH * 3, (y + 1) * WIDTH * 3);
  }

  const header = Buffer.alloc(13);
  header.writeUInt32BE(WIDTH, 0);
  header.writeUInt32BE(HEIGHT, 4);
  header[8] = 8;
  header[9] = 2;
  header[10] = 0;
  header[11] = 0;
  header[12] = 0;

  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk("IHDR", header),
    chunk("IDAT", deflateSync(raw, { level: 6 })),
    chunk("IEND", Buffer.alloc(0)),
  ]);
};

export const renderOgPng = ({
  entity = "GaonGram",
  title = "GaonGram",
  subtitle = "",
  description = "",
  image = "",
  stats = [],
} = {}) => {
  const pixels = Buffer.alloc(WIDTH * HEIGHT * 3);
  const accent = colorFromString(`${entity}:${title}:${image}`);
  const accentDark = accent.map((value) => Math.max(24, value - 52));
  const accentLight = accent.map((value) => Math.min(245, value + 82));

  for (let y = 0; y < HEIGHT; y += 1) {
    const amount = y / HEIGHT;
    const rowColor = [
      mix(248, 236, amount),
      mix(250, 253, amount),
      mix(252, 242, amount),
    ];
    fillRect(pixels, 0, y, WIDTH, 1, rowColor);
  }

  fillRect(pixels, 72, 72, 1056, 486, [255, 255, 255]);
  fillRect(pixels, 72, 72, 1056, 10, accent);
  fillRect(pixels, 72, 548, 1056, 10, accentLight);
  fillCircle(pixels, 190, 230, 126, accentLight);
  fillCircle(pixels, 190, 230, 108, accent);
  fillCircle(pixels, 190, 186, 38, [255, 255, 255]);
  fillRect(pixels, 126, 250, 128, 88, [255, 255, 255]);

  fillRect(pixels, 332, 160, 520, 34, accentLight);
  fillRect(pixels, 332, 222, 640, 44, accentDark);
  fillRect(pixels, 332, 286, 520, 24, [148, 163, 184]);
  fillRect(pixels, 332, 356, Math.min(620, 160 + stats.filter(Boolean).join(" ").length * 8), 32, accent);
  fillRect(pixels, 332, 424, Math.min(700, 220 + String(description || subtitle).length * 4), 24, [100, 116, 139]);
  fillRect(pixels, 88, 500, 170, 30, accentDark);
  fillRect(pixels, 936, 486, 152, 34, accent);

  return writePng(pixels);
};
