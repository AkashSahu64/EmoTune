import React, { useEffect, useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";

import { hashtagService } from "../../../services/hashtag.service";

import Loader from "../../../components/common/Loader";
import EmptyState from "../../../components/common/EmptyState";

import VibeCard from "../../vibe/components/VibeCard.jsx";

const HashtagFeedPage = () => {
  const { hashtag } = useParams();

  const { data, isLoading, error } = useQuery({
    queryKey: ["hashtag-posts", hashtag],

    queryFn: async () => {
      const response = await hashtagService.getPostsByHashtag(hashtag);

      console.log("Hashtag Posts API =>", response);

      return response;
    },

    enabled: !!hashtag,
  });

  // LOCAL POSTS STATE
  const [posts, setPosts] = useState([]);

  // SYNC API DATA TO LOCAL STATE
  useEffect(() => {
    if (data?.data?.results) {
      setPosts(data.data.results);
    }
  }, [data]);

  // INSTANT UI UPDATE HANDLER
  const handlePostUpdate = useCallback((postId, updates) => {
  setPosts((prevPosts) =>
    prevPosts.map((post) => {
      if (post.id !== postId) return post;

      return {
        ...post,

        ...Object.fromEntries(
          Object.entries(updates || {}).filter(
            ([key]) => key !== "comments_count",
          ),
        ),

        comments_count:
          typeof updates?.comments_count === "function"
            ? updates.comments_count(post.comments_count || 0)
            : updates?.comments_count ?? post.comments_count,
      };
    }),
  );
}, []);

  // LOADING
  if (isLoading) {
    return (
      <div className="flex justify-center py-10">
        <Loader />
      </div>
    );
  }

  // ERROR
  if (error) {
    return (
      <EmptyState
        icon="alert"
        title="Failed to load posts"
        description={error.message}
      />
    );
  }

  // EMPTY
  if (posts.length === 0) {
    return <EmptyState icon="hash" title={`No posts found for #${hashtag}`} />;
  }

  return (
    <div className="max-w-md mx-auto">
      {/* HEADER */}
      <div className=" sticky top-0 z-20 bg-background/90 backdrop-blur border-b border-border dark:border-border-dark px-1 py-3 leading-tight">
        <h1 className="text-xl font-bold"># {hashtag}</h1>

        <p className="text-sm text-mutedForeground">{posts.length} posts</p>
      </div>

      {/* POSTS */}
      <div className="pb-6">
        {posts.map((post) => (
          <VibeCard
            key={post.id}
            onUpdate={handlePostUpdate}
            post={{
              ...post,

              likes_count: post.likes_count ?? post.total_likes ?? 0,

              total_likes: post.likes_count ?? post.total_likes ?? 0,

              is_liked: post.is_liked ?? false,

              comments_count: post.comments_count ?? 0,

              views_count: post.views_count ?? 0,

              user: {
                id: post.author,
                username: post.user_name,
                avatar: post.profile_image,
                is_private: post.is_private,
              },

              media_type:
                post.videos?.length > 0
                  ? "video"
                  : post.images?.length > 0
                    ? "image"
                    : post.audio
                      ? "audio"
                      : post.poll_question
                        ? "poll"
                        : "text",
              caption: post.content,
              poll: post.poll_question
                ? {
                    poll_question: post.poll_question,

                    poll_options: post.poll_options,

                    poll_votes: post.poll_votes,

                    total_votes: Object.values(post.poll_votes || {}).reduce(
                      (a, b) => a + b,
                      0,
                    ),
                  }
                : null,
            }}
          />
        ))}
      </div>
    </div>
  );
};

export default HashtagFeedPage;
