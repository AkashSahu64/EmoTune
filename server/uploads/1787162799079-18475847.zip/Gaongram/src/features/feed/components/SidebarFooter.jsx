import React from "react";
import { Link, useLocation } from "react-router-dom";
import { useTranslation } from "react-i18next";

const SidebarFooter = () => {
  const { pathname } = useLocation();
  const { t } = useTranslation(); // ✅ added

  const links = [
    { key: "about", path: "/about" },
    { key: "blog", path: "/blogs" },
    { key: "careers", external: "https://careers.gaongram.in" },
    { key: "help_center", path: "/help-center" },
    { key: "safety", path: "/safety" },
    { key: "community_guidelines", path: "/community-guidelines" },
    { key: "privacy", path: "/privacy" },
    { key: "terms", path: "/terms" },
    { key: "language", path: "/language" },
    { key: "contact", path: "/contact" },
  ];

  return (
    <div className="text-xs text-mutedForeground dark:text-mutedForeground-dark">
      
      {/* Links */}
      <div className="flex flex-wrap gap-x-2 gap-y-1 mb-3">
        {links.map((link) => {
          // 🔗 External Link
          if (link.external) {
            return (
              <a
                key={link.key}
                href={link.external}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:underline hover:text-foreground dark:hover:text-foreground-dark transition-colors"
              >
                {t(link.key)} {/* ✅ translated */}
              </a>
            );
          }

          const isActive = pathname === link.path;

          return (
            <Link
              key={link.key}
              to={link.path}
              className={`transition-colors hover:underline ${
                isActive
                  ? "text-foreground dark:text-foreground-dark font-medium"
                  : "hover:text-foreground dark:hover:text-foreground-dark"
              }`}
            >
              {t(link.key)} {/* ✅ translated */}
            </Link>
          );
        })}
      </div>

      {/* Divider */}
      <div className="w-full h-px bg-border dark:bg-border-dark mb-2" />

      {/* Footer Text */}
      <p className="text-[11px] opacity-80">
        {t("copyright", { year: new Date().getFullYear() })}
      </p>
    </div>
  );
};

export default SidebarFooter;