import UploadManager from "../core/UploadManager.js";

export const uploadService = {
  createManager: (options) => new UploadManager(options),
  async withRetry(task, options) {
    return new UploadManager(options).runWithRetry(task, options);
  },
};

export default uploadService;
