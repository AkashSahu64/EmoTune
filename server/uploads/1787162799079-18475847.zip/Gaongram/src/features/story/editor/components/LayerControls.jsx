import React, { useMemo, useRef, useState } from "react";
import {
  ChevronDown,
  ChevronUp,
  Copy,
  Eye,
  EyeOff,
  GripVertical,
  Lock,
  Trash2,
} from "lucide-react";
import { getLayerName, isLayerSelectable, sortLayers } from "../engine/helpers/layerUtils.js";
import { selectActiveLayer, useCanvasStore } from "../useCanvasStore.js";

const typeLabel = {
  base: "Base",
  text: "Text",
  media: "Media",
  emoji: "Sticker",
  gif: "GIF",
  music: "Music",
  frame: "Frame",
};

const LayerControls = ({ engine }) => {
  const layers = useCanvasStore((state) => state.layers);
  const activeLayer = useCanvasStore(selectActiveLayer);
  const activeLayerId = useCanvasStore((state) => state.activeLayerId);
  const setActiveLayerId = useCanvasStore((state) => state.setActiveLayerId);
  const updateLayer = useCanvasStore((state) => state.updateLayer);
  const reorderLayer = useCanvasStore((state) => state.reorderLayer);
  const reorderLayersByIds = useCanvasStore((state) => state.reorderLayersByIds);
  const duplicateLayer = useCanvasStore((state) => state.duplicateLayer);
  const [draggingId, setDraggingId] = useState(null);
  const dragStateRef = useRef(null);

  const orderedLayers = useMemo(
    () => sortLayers(layers).reverse(),
    [layers],
  );

  const handleSelect = (layer) => {
    if (!isLayerSelectable(layer)) return;
    setActiveLayerId(layer.id);
    engine?.selectLayer(layer.id);
  };

  const canMoveLayer = (layer) => layer.type !== "base" && !layer.locked;

  const commitOrder = (dragId, targetId) => {
    if (!dragId || !targetId || dragId === targetId) return;

    const dragLayer = orderedLayers.find((layer) => layer.id === dragId);
    const targetLayer = orderedLayers.find((layer) => layer.id === targetId);
    if (!canMoveLayer(dragLayer) || !canMoveLayer(targetLayer)) return;

    const nextIds = orderedLayers.map((layer) => layer.id);
    const from = nextIds.indexOf(dragId);
    const to = nextIds.indexOf(targetId);
    if (from === -1 || to === -1) return;

    const [moved] = nextIds.splice(from, 1);
    nextIds.splice(to, 0, moved);
    reorderLayersByIds(nextIds, { topToBottom: true, recordHistory: true });
  };

  const handlePointerDown = (event, layer) => {
    if (!canMoveLayer(layer)) return;
    dragStateRef.current = {
      id: layer.id,
      pointerId: event.pointerId,
    };
    setDraggingId(layer.id);
    event.currentTarget.setPointerCapture?.(event.pointerId);
    event.preventDefault();
  };

  const handlePointerMove = (event) => {
    if (!dragStateRef.current) return;
    const target = document
      .elementFromPoint(event.clientX, event.clientY)
      ?.closest("[data-layer-id]");
    const targetId = target?.getAttribute("data-layer-id");
    if (targetId && targetId !== dragStateRef.current.overId) {
      dragStateRef.current.overId = targetId;
    }
  };

  const handlePointerUp = (event) => {
    const dragState = dragStateRef.current;
    if (!dragState) return;
    event.currentTarget.releasePointerCapture?.(dragState.pointerId);
    commitOrder(dragState.id, dragState.overId);
    dragStateRef.current = null;
    setDraggingId(null);
  };

  const handleNativeDragStart = (event, layer) => {
    if (!canMoveLayer(layer)) {
      event.preventDefault();
      return;
    }
    event.dataTransfer.effectAllowed = "move";
    event.dataTransfer.setData("text/layer-id", layer.id);
    setDraggingId(layer.id);
  };

  const handleNativeDrop = (event, targetLayer) => {
    event.preventDefault();
    const dragId = event.dataTransfer.getData("text/layer-id");
    commitOrder(dragId, targetLayer.id);
    setDraggingId(null);
  };

  return (
    <div className="space-y-2">
      <div className="rounded-lg border-border dark:border-border-dark bg-card dark:bg-card-dark px-3 py-2">
        <div className="flex items-center justify-between">
          <p className="text-sm font-semibold">Stack</p>
          <span className="rounded-full bg-foreground-dark dark:bg-foreground px-2 py-1 text-xs text-muted-dark dark:text-muted font-semibold">
            {layers.length}
          </span>
        </div>

        <div className="mt-3 space-y-2">
          {orderedLayers.map((layer) => {
            const isActive = activeLayerId === layer.id;
            const isDragging = draggingId === layer.id;
            const selectable = isLayerSelectable(layer);

            return (
              <div
                key={layer.id}
                data-layer-id={layer.id}
                draggable={canMoveLayer(layer)}
                onDragStart={(event) => handleNativeDragStart(event, layer)}
                onDragOver={(event) => event.preventDefault()}
                onDrop={(event) => handleNativeDrop(event, layer)}
                onDragEnd={() => setDraggingId(null)}
                className={`flex items-center gap-2 rounded-lg border px-2 py-1 transition ${
                  isActive
                    ? "border-border dark:border-border-dark bg-muted dark:bg-muted-dark"
                    : "border-border dark:border-border-dark bg-muted/80 dark:bg-mutedForeground-dark hover:bg-muted dark:hover:bg-mutedForeground-dark"
                } ${isDragging ? "scale-[0.99] opacity-60" : ""}`}
              >
                <button
                  type="button"
                  onPointerDown={(event) => handlePointerDown(event, layer)}
                  onPointerMove={handlePointerMove}
                  onPointerUp={handlePointerUp}
                  onPointerCancel={handlePointerUp}
                  className="flex h-9 w-7 shrink-0 touch-none items-center justify-center rounded-md text-foreground dark:text-foreground-dark transition disabled:opacity-25"
                  disabled={!canMoveLayer(layer)}
                  aria-label={`Drag ${getLayerName(layer)}`}
                  title={canMoveLayer(layer) ? "Drag to reorder" : "Locked layer"}
                >
                  <GripVertical size={20} className="font-semibold"/>
                </button>

                <button
                  type="button"
                  className="flex min-w-0 flex-1 items-center gap-2 text-left disabled:cursor-not-allowed disabled:opacity-55"
                  onClick={() => handleSelect(layer)}
                  disabled={!selectable}
                >
                  <div className="min-w-0 flex-1 leading-tight">
                    <p className="truncate text-sm font-medium">
                      {getLayerName(layer)}
                    </p>
                    <p className="text-xs text-foreground/70 dark:text-foreground-dark/70">
                      {typeLabel[layer.type] || layer.type}
                    </p>
                  </div>
                  {layer.locked && <Lock size={14} className="text-foreground/45 dark:text-foreground-dark/45" />}
                </button>

                <button
                  type="button"
                  onClick={() =>
                    updateLayer(layer.id, { visible: layer.visible === false })
                  }
                  disabled={layer.type === "base"}
                  className="rounded-full p-2 text-foreground/60 transition hover:bg-foreground/10 hover:text-foreground disabled:opacity-35"
                  aria-label={layer.visible === false ? "Show layer" : "Hide layer"}
                  title={layer.visible === false ? "Show" : "Hide"}
                >
                  {layer.visible === false ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {activeLayer && (
        <div className="rounded-lg border-border dark:border-border-dark bg-muted dark:bg-muted-dark px-3 py-2">
          <p className="text-sm font-semibold">Selected Layer</p>
          <div className="mt-3 grid grid-cols-4 gap-2">
            <button
              type="button"
              onClick={() => reorderLayer(activeLayer.id, "up")}
              disabled={!canMoveLayer(activeLayer)}
              className="flex h-10 items-center justify-center rounded-md bg-foreground/10 dark:bg-foreground-dark/10 text-foreground dark:text-foreground-dark transition hover:bg-foreground/15 dark:hover:bg-foreground-dark/15 disabled:opacity-35"
              aria-label="Move layer up"
              title="Move up"
            >
              <ChevronUp size={18} />
            </button>
            <button
              type="button"
              onClick={() => reorderLayer(activeLayer.id, "down")}
              disabled={!canMoveLayer(activeLayer)}
              className="flex h-10 items-center justify-center rounded-md bg-foreground/10 dark:bg-foreground-dark/10 text-foreground dark:text-foreground-dark transition hover:bg-foreground/15 dark:hover:bg-foreground-dark/15 disabled:opacity-35"
              aria-label="Move layer down"
              title="Move down"
            >
              <ChevronDown size={18} />
            </button>
            <button
              type="button"
              onClick={() => duplicateLayer(activeLayer.id)}
              disabled={activeLayer.locked || activeLayer.type === "base"}
              className="flex h-10 items-center justify-center rounded-md bg-foreground/10 dark:bg-foreground-dark/10 text-foreground dark:text-foreground-dark transition hover:bg-foreground/15 dark:hover:bg-foreground-dark/15 disabled:opacity-35"
              aria-label="Duplicate layer"
              title="Duplicate"
            >
              <Copy size={17} />
            </button>
            <button
              type="button"
              onClick={() => engine?.layerManager?.removeLayer(activeLayer.id)}
              disabled={activeLayer.locked || activeLayer.type === "base"}
              className="flex h-10 items-center justify-center rounded-md bg-red-500/20 text-red-700 transition hover:bg-red-500/30 disabled:opacity-35"
              aria-label="Delete layer"
              title="Delete"
            >
              <Trash2 size={17} />
            </button>
          </div>

          <div className="mt-4 space-y-3">
            <label className="block">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-foreground dark:text-foreground-dark">Opacity</span>
                <span className="text-xs font-semibold text-foreground dark:text-foreground-dark">
                  {Math.round((activeLayer.opacity ?? 1) * 100)}%
                </span>
              </div>

              <input
                type="range"
                min="0.1"
                max="1"
                step="0.01"
                value={activeLayer.opacity ?? 1}
                onChange={(event) =>
                  updateLayer(
                    activeLayer.id,
                    { opacity: Number(event.target.value) },
                    { recordHistory: false },
                  )
                }
                onPointerUp={() =>
                  updateLayer(
                    activeLayer.id,
                    { opacity: activeLayer.opacity ?? 1 },
                    { recordHistory: true },
                  )
                }
                style={{
                  background: `linear-gradient(to right, #22c55e ${
                    (activeLayer.opacity ?? 1) * 100
                  }%, #d1d5db ${(activeLayer.opacity ?? 1) * 100}%)`,
                }}
                className="custom-range w-full"
              />
            </label>
          </div>
        </div>
      )}
    </div>
  );
};

export default React.memo(LayerControls);
