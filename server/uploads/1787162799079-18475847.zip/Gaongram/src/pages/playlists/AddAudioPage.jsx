import React from 'react';
import AddAudioList from '../../components/playlist/AddAudioList.jsx';

const AddAudioPage = () => {
  return <AddAudioList />;
};

export default AddAudioPage;