import React, { useState } from "react";
import { motion } from "framer-motion";
import { useSearchParams, useNavigate, Link } from "react-router-dom";
import { Lock, Eye, EyeOff } from "lucide-react";
import Button from "../../../components/common/Button.jsx";
import Seo from "../../../components/seo/Seo.jsx";
import { buildStaticPageSeo } from "../../../seo/seoBuilders.js";
import { authService } from "../../../services/auth.service.js";
import { showSuccess } from "../../../utils/toast.js";

const ResetPassword = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const token = searchParams.get("token");

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [errors, setErrors] = useState({});

  const [showPass, setShowPass] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const validate = () => {
    const newErrors = {};

    if (!password) {
      newErrors.password = "Password is required";
    } else if (password.length < 6) {
      newErrors.password = "Minimum 6 characters required";
    }

    if (!confirmPassword) {
      newErrors.confirmPassword = "Confirm your password";
    } else if (password !== confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!token) {
      setErrors({ general: "Invalid or expired reset link" });
      return;
    }

    if (!validate()) return;

    setLoading(true);
    setErrors({});

    try {
      const res = await authService.resetPassword({
        token,
        new_password: password,
        confirm_password: confirmPassword,
      });

      showSuccess(res.message || "Password reset successful 🎉");
      setSuccess(true);

      setTimeout(() => navigate("/login"), 2000);
    } catch (err) {
      setErrors({
        general:
          err.response?.data?.message ||
          "Reset failed. Link may be expired.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Seo {...buildStaticPageSeo("resetPassword")} />

      <div className="min-h-screen bg-login-hero flex items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-sm"
        >
          <div className="backdrop-blur-md bg-light-card/10 shadow-premium border border-gray-100/30 rounded-xl3 px-6 py-8">

            <h2 className="text-2xl font-bold text-white mb-2">
              Set New Password 🔐
            </h2>

            <p className="text-light-subtext text-sm mb-6">
              Enter your new password below
            </p>

            {/* 🔴 General Error */}
            {errors.general && (
              <p className="text-red-400 text-sm mb-3 text-center">
                {errors.general}
              </p>
            )}

            {!success ? (
              <form onSubmit={handleSubmit} className="space-y-5">

                {/* Password */}
                <div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 h-5 w-5 text-light-subtext" />
                    <input
                      type={showPass ? "text" : "password"}
                      value={password}
                      onChange={(e) => {
                        setPassword(e.target.value);
                        setErrors((prev) => ({ ...prev, password: "" }));
                      }}
                      placeholder="New password"
                      className={`w-full pl-10 pr-10 py-2 border rounded-lg bg-light-card/20 text-white outline-none ${
                        errors.password
                          ? "border-red-400"
                          : "border-light-border/50"
                      }`}
                    />
                    <span
                      onClick={() => setShowPass(!showPass)}
                      className="absolute right-3 top-2.5 cursor-pointer"
                    >
                      {showPass ? <EyeOff size={18} /> : <Eye size={18} />}
                    </span>
                  </div>

                  {/* Error */}
                  {errors.password && (
                    <p className="text-red-400 text-xs mt-1 ml-1">
                      {errors.password}
                    </p>
                  )}
                </div>

                {/* Confirm Password */}
                <div>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 h-5 w-5 text-light-subtext" />
                    <input
                      type={showConfirm ? "text" : "password"}
                      value={confirmPassword}
                      onChange={(e) => {
                        setConfirmPassword(e.target.value);
                        setErrors((prev) => ({ ...prev, confirmPassword: "" }));
                      }}
                      placeholder="Confirm password"
                      className={`w-full pl-10 pr-10 py-2 border rounded-lg bg-light-card/20 text-white outline-none ${
                        errors.confirmPassword
                          ? "border-red-400"
                          : "border-light-border/50"
                      }`}
                    />
                    <span
                      onClick={() => setShowConfirm(!showConfirm)}
                      className="absolute right-3 top-2.5 cursor-pointer"
                    >
                      {showConfirm ? <EyeOff size={18} /> : <Eye size={18} />}
                    </span>
                  </div>

                  {/* Error */}
                  {errors.confirmPassword && (
                    <p className="text-red-400 text-xs mt-1 ml-1">
                      {errors.confirmPassword}
                    </p>
                  )}
                </div>

                <Button
                  type="submit"
                  loading={loading}
                  fullWidth
                  className="py-2.5 bg-green-950/80 hover:bg-green-950 text-white outline-none"
                >
                  Reset Password
                </Button>

                <div className="text-center">
                  <Link to="/forgot-password" className="text-sm text-viral-blue">
                    Request new link
                  </Link>
                </div>
              </form>
            ) : (
              <div className="text-center">
                <h3 className="text-lg text-white mb-2">
                  Password Updated ✅
                </h3>
                <p className="text-light-subtext text-sm">
                  Redirecting to login...
                </p>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default ResetPassword;
