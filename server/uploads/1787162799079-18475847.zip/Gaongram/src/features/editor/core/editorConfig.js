export const EDITOR_MODES = {
  story: "story",
  post: "post",
  profile: "profile",
};

export const EDITOR_FEATURES = {
  crop: "crop",
  aspectRatio: "aspectRatio",
  filters: "filters",
  zoom: "zoom",
  rotate: "rotate",
  text: "text",
  music: "music",
  stickers: "stickers",
  drawing: "drawing",
  gifs: "gifs",
  video: "video",
  animations: "animations",
  effects: "effects",
  timeline: "timeline",
  layers: "layers",
  carousel: "carousel",
  export: "export",
};

export const SHARED_CREATIVE_FEATURES = [
  EDITOR_FEATURES.text,
  EDITOR_FEATURES.music,
  EDITOR_FEATURES.stickers,
  EDITOR_FEATURES.drawing,
  EDITOR_FEATURES.gifs,
  EDITOR_FEATURES.video,
  EDITOR_FEATURES.animations,
  EDITOR_FEATURES.effects,
  EDITOR_FEATURES.filters,
  EDITOR_FEATURES.crop,
  EDITOR_FEATURES.timeline,
  EDITOR_FEATURES.layers,
  EDITOR_FEATURES.export,
];

export const EDITOR_CONFIGS = {
  [EDITOR_MODES.story]: {
    mode: EDITOR_MODES.story,
    title: "Create story",
    aspectRatio: "9:16",
    outputType: "story",
    maxImageSize: 20 * 1024 * 1024,
    maxVideoSize: 100 * 1024 * 1024,
    features: SHARED_CREATIVE_FEATURES,
    defaultTool: "text",
    exportQuality: 0.94,
  },
  [EDITOR_MODES.post]: {
    mode: EDITOR_MODES.post,
    title: "Edit post media",
    aspectRatio: "1:1",
    outputType: "post",
    maxImageSize: 20 * 1024 * 1024,
    maxVideoSize: 100 * 1024 * 1024,
    features: [...SHARED_CREATIVE_FEATURES, EDITOR_FEATURES.carousel],
    defaultTool: "filters",
    exportQuality: 0.94,
  },
  [EDITOR_MODES.profile]: {
    mode: EDITOR_MODES.profile,
    title: "Edit profile photo",
    aspectRatio: "1:1",
    outputType: "profile",
    maxImageSize: 8 * 1024 * 1024,
    maxVideoSize: 0,
    features: [
      EDITOR_FEATURES.crop,
      EDITOR_FEATURES.aspectRatio,
      EDITOR_FEATURES.filters,
      EDITOR_FEATURES.zoom,
      EDITOR_FEATURES.rotate,
      EDITOR_FEATURES.export,
    ],
    defaultTool: "crop",
    exportQuality: 0.92,
  },
};

export const getEditorConfig = (modeOrConfig = EDITOR_MODES.story) => {
  if (typeof modeOrConfig === "object" && modeOrConfig) {
    const base = EDITOR_CONFIGS[modeOrConfig.mode] || EDITOR_CONFIGS.story;
    return {
      ...base,
      ...modeOrConfig,
      features: modeOrConfig.features || base.features,
    };
  }

  return EDITOR_CONFIGS[modeOrConfig] || EDITOR_CONFIGS.story;
};

export const editorSupports = (config, feature) =>
  Boolean(getEditorConfig(config).features?.includes(feature));
