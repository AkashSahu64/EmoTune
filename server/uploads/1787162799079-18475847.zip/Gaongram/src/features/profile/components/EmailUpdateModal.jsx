// components/EmailUpdateModal.jsx
import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { motion } from 'framer-motion';
import Button from '../../../components/common/Button';
import { showToast } from '../../../utils/toast';

const EmailUpdateModal = ({ isOpen, onClose, profile, onUpdate, isUpdating }) => {
  const [email, setEmail] = useState('');

  useEffect(() => {
    if (profile) {
      setEmail(profile.email || '');
    }
  }, [profile]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email) {
      showToast('Email is required', 'error');
      return;
    }
    try {
      await onUpdate({ data: { email } });
      onClose();
    } catch {
      // Error handled in parent
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-6">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm"
          onClick={onClose}
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative bg-white dark:bg-card-dark rounded-xl shadow-xl w-full max-w-md overflow-hidden"
        >
          {/* Header */}
          <div className="px-6 py-2 border-b border-border dark:border-border-dark bg-gradient-to-r from-gaon-cream to-white dark:from-gray-800 dark:to-card-dark">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-foreground dark:text-foreground-dark">
                Update Email
              </h3>
              <button
                onClick={onClose}
                className="p-1.5 text-gray-400 hover:text-foreground dark:hover:text-foreground-dark hover:bg-gray-100 dark:hover:bg-muted-dark rounded-lg transition-colors"
              >
                <X size={20} />
              </button>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="px-6 py-3">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-mutedForeground-dark mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  className="w-full px-2 py-2 border border-gray-200 dark:border-border-dark rounded-md focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all bg-white dark:bg-card-dark text-foreground dark:text-foreground-dark outline-none"
                  required
                />
              </div>
            </div>

            {/* Footer */}
            <div className="mt-6 flex justify-end gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isUpdating}
                className="border-gray-300 dark:border-border-dark text-foreground dark:text-foreground-dark hover:bg-gray-50 dark:hover:bg-muted-dark rounded-lg px-4"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                loading={isUpdating}
                disabled={isUpdating}
                className="bg-primary hover:bg-primary-light rounded-lg px-4 shadow-md text-white"
              >
                {isUpdating ? 'Updating...' : 'Update Email'}
              </Button>
            </div>
          </form>
        </motion.div>
      </div>
    </div>
  );
};

export default EmailUpdateModal;