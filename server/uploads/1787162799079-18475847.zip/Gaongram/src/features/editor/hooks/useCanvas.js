import { useEffect, useRef, useState } from "react";
import CanvasManager from "../core/CanvasManager.js";

export const useCanvas = ({ file, store, config, aspectRatio, onPreviewChange, onError }) => {
  const canvasRef = useRef(null);
  const managerRef = useRef(null);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    if (!canvasRef.current || !file) return undefined;

    setIsReady(false);
    managerRef.current?.dispose();
    store.getState().resetEditor?.();

    const manager = new CanvasManager({
      canvasEl: canvasRef.current,
      store,
      config,
      onReady: () => setIsReady(true),
      onError,
      onPreviewChange,
    });

    managerRef.current = manager;
    manager.init(file, aspectRatio || config.aspectRatio);

    return () => {
      manager.dispose();
      managerRef.current = null;
      store.getState().resetEditor?.();
    };
  }, [aspectRatio, config, file, onError, onPreviewChange, store]);

  return {
    canvasRef,
    engine: managerRef.current?.engine || null,
    manager: managerRef.current,
    isReady,
  };
};

export default useCanvas;
