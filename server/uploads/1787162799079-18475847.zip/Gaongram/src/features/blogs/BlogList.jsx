import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { Grid, List, Filter, Search, TrendingUp } from 'lucide-react';
import { feedService } from '../../services/feed.service.js';
import { useInfiniteScroll } from '../../hooks/useInfiniteScroll.js';
import BlogCard from './BlogCard.jsx';
import Loader from '../../components/common/Loader.jsx';
import EmptyState from '../../components/common/EmptyState.jsx';
import Button from '../../components/common/Button.jsx';

const BlogList = () => {
  const [viewMode, setViewMode] = useState('grid'); // 'grid' or 'list'
  const [sortBy, setSortBy] = useState('latest'); // 'latest', 'popular', 'trending'
  const [searchQuery, setSearchQuery] = useState('');
  const [category, setCategory] = useState('all');

  const {
    data: blogs,
    loading,
    error,
    hasMore,
    ref,
    refresh,
    loadMore,
  } = useInfiniteScroll(
    async ({ page, limit }) => {
      const params = {
        page,
        limit,
        sort: sortBy,
        search: searchQuery,
        category: category !== 'all' ? category : undefined,
      };
      
      const response = await feedService.getBlogs(params);
      return response;
    },
    {
      limit: 12,
    }
  );

  const categories = [
    { id: 'all', name: 'All', count: 125 },
    { id: 'technology', name: 'Technology', count: 42 },
    { id: 'lifestyle', name: 'Lifestyle', count: 36 },
    { id: 'travel', name: 'Travel', count: 28 },
    { id: 'food', name: 'Food', count: 19 },
    { id: 'fashion', name: 'Fashion', count: 15 },
  ];

  const sortOptions = [
    { id: 'latest', name: 'Latest', icon: 'clock' },
    { id: 'popular', name: 'Most Popular', icon: 'trending-up' },
    { id: 'trending', name: 'Trending', icon: 'fire' },
  ];

  const handleSearch = (e) => {
    e.preventDefault();
    refresh();
  };

  if (loading && !blogs?.length) {
    return (
      <div className="min-h-screen bg-gray-50 pt-20">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white rounded-xl shadow-sm p-6">
                <div className="animate-pulse">
                  <div className="h-48 bg-gray-200 rounded-lg mb-4" />
                  <div className="space-y-3">
                    <div className="h-4 bg-gray-200 rounded w-3/4" />
                    <div className="h-4 bg-gray-200 rounded w-1/2" />
                    <div className="h-4 bg-gray-200 rounded w-2/3" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 pt-20">
        <div className="max-w-7xl mx-auto px-4">
          <EmptyState
            icon="document"
            title="Error loading blogs"
            description="Unable to load blogs at this time. Please try again."
            action={
              <Button variant="primary" onClick={refresh}>
                Try Again
              </Button>
            }
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Blogs</h1>
          <p className="text-gray-600">
            Discover stories, thinking, and expertise from writers on any topic.
          </p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
          {/* Search Bar */}
          <form onSubmit={handleSearch} className="mb-6">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search blogs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-instagram-pink focus:border-transparent"
              />
              <Button
                type="submit"
                variant="primary"
                className="absolute right-2 top-1/2 transform -translate-y-1/2"
              >
                Search
              </Button>
            </div>
          </form>

          {/* View Controls */}
          <div className="flex flex-col md:flex-row md:items-center justify-between space-y-4 md:space-y-0">
            {/* Categories */}
            <div className="flex overflow-x-auto space-x-2 no-scrollbar">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setCategory(cat.id);
                    refresh();
                  }}
                  className={`px-4 py-2 rounded-full whitespace-nowrap ${
                    category === cat.id
                      ? 'bg-instagram-pink text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {cat.name}
                  <span className="ml-2 text-xs opacity-75">
                    ({cat.count})
                  </span>
                </button>
              ))}
            </div>

            {/* Sort and View Controls */}
            <div className="flex items-center space-x-4">
              {/* Sort Dropdown */}
              <div className="relative">
                <select
                  value={sortBy}
                  onChange={(e) => {
                    setSortBy(e.target.value);
                    refresh();
                  }}
                  className="appearance-none bg-gray-100 border border-gray-300 rounded-lg px-4 py-2 pr-10 focus:ring-2 focus:ring-instagram-pink focus:border-transparent"
                >
                  {sortOptions.map((option) => (
                    <option key={option.id} value={option.id}>
                      {option.name}
                    </option>
                  ))}
                </select>
                <Filter className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4 pointer-events-none" />
              </div>

              {/* View Toggle */}
              <div className="flex items-center bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded ${
                    viewMode === 'grid'
                      ? 'bg-white shadow-sm'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                  aria-label="Grid view"
                >
                  <Grid className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded ${
                    viewMode === 'list'
                      ? 'bg-white shadow-sm'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                  aria-label="List view"
                >
                  <List className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Blog List */}
        {blogs?.length === 0 ? (
          <EmptyState
            icon="document"
            title="No blogs found"
            description={
              searchQuery
                ? `No results found for "${searchQuery}". Try a different search.`
                : "No blogs available in this category yet."
            }
            action={
              searchQuery ? (
                <Button variant="outline" onClick={() => setSearchQuery('')}>
                  Clear Search
                </Button>
              ) : null
            }
          />
        ) : (
          <>
            {/* Grid View */}
            {viewMode === 'grid' ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {blogs.map((blog) => (
                  <motion.div
                    key={blog.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                  >
                    <BlogCard blog={blog} variant="grid" />
                  </motion.div>
                ))}
              </div>
            ) : (
              // List View
              <div className="space-y-6">
                {blogs.map((blog) => (
                  <motion.div
                    key={blog.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                  >
                    <BlogCard blog={blog} variant="list" />
                  </motion.div>
                ))}
              </div>
            )}

            {/* Load More Trigger */}
            {hasMore && (
              <div ref={ref} className="py-10">
                <div className="flex justify-center">
                  <Button
                    variant="outline"
                    onClick={loadMore}
                    loading={loading}
                  >
                    Load More
                  </Button>
                </div>
              </div>
            )}
          </>
        )}

        {/* No More Content */}
        {!hasMore && blogs?.length > 0 && (
          <div className="py-12 text-center">
            <div className="inline-block p-4 bg-gray-100 rounded-full mb-4">
              <TrendingUp className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              You're all caught up!
            </h3>
            <p className="text-gray-600">
              You've seen all the latest blogs. Check back later for more.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default BlogList;