import { useCallback, useMemo, useState } from "react";
import ExportManager from "../core/ExportManager.js";

export const useExport = ({ engine, store, config }) => {
  const [isExporting, setIsExporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [message, setMessage] = useState("");

  const manager = useMemo(() => new ExportManager({ engine, store, config }), [config, engine, store]);

  const exportMedia = useCallback(
    async (options = {}) => {
      setIsExporting(true);
      setProgress(4);
      setMessage("Preparing media...");
      try {
        return await manager.export({
          ...options,
          onProgress: ({ progress: nextProgress, message: nextMessage }) => {
            setProgress(nextProgress);
            if (nextMessage) setMessage(nextMessage);
            options.onProgress?.({ progress: nextProgress, message: nextMessage });
          },
        });
      } finally {
        setIsExporting(false);
        setProgress(0);
        setMessage("");
      }
    },
    [manager],
  );

  return { exportMedia, isExporting, progress, message };
};

export default useExport;
