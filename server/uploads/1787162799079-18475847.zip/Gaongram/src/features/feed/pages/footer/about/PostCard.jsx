// src/components/common/PostCard.jsx
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Heart, MessageCircle, Share2, Bookmark, MoreHorizontal } from 'lucide-react';
import Avatar from '../../../../../components/common/Avatar.jsx'; // adjust path as needed
import { formatNumber, formatTime } from '../../../../../utils/formatTime.js';

const PostCard = ({
  avatar,
  username,
  timestamp,
  imageUrl,
  caption,
  likes = 0,
  comments = 0,
  saved = false,
  onLike,
  onComment,
  onShare,
  onSave,
  aspectRatio = 'aspect-square', // or 'aspect-[4/5]'
  className = '',
}) => {
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(likes);
  const [isSaved, setIsSaved] = useState(saved);

  const handleLike = () => {
    setIsLiked(!isLiked);
    setLikesCount(prev => isLiked ? prev - 1 : prev + 1);
    onLike?.();
  };

  const handleSave = () => {
    setIsSaved(!isSaved);
    onSave?.();
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={`bg-card dark:bg-card-dark rounded-xl border border-border dark:border-border-dark overflow-hidden ${className}`}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 pt-3 pb-1">
        <div className="flex items-center gap-3">
          <Avatar src={avatar} alt={username} size="small" />
          <div>
            <p className="text-sm font-semibold text-foreground dark:text-foreground-dark">
              {username}
            </p>
            <p className="text-xs text-mutedForeground dark:text-mutedForeground-dark">
              {formatTime(timestamp)}
            </p>
          </div>
        </div>
        <button className="text-mutedForeground hover:text-foreground">
          <MoreHorizontal className="w-5 h-5" />
        </button>
      </div>

      {/* Image */}
      <div className={`relative w-full ${aspectRatio} bg-muted dark:bg-muted-dark`}>
        <img
          src={imageUrl}
          alt={caption}
          className="absolute inset-0 w-full h-full object-cover"
        />
      </div>

      {/* Action Buttons */}
      <div className="px-4 pt-2 pb-1">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={handleLike} className="focus:outline-none">
              <Heart
                className={`w-6 h-6 transition-colors ${
                  isLiked ? 'fill-red-500 text-red-500' : 'text-foreground dark:text-foreground-dark'
                }`}
              />
            </button>
            <button onClick={onComment} className="focus:outline-none">
              <MessageCircle className="w-6 h-6 text-foreground dark:text-foreground-dark" />
            </button>
            <button onClick={onShare} className="focus:outline-none">
              <Share2 className="w-6 h-6 text-foreground dark:text-foreground-dark" />
            </button>
          </div>
          <button onClick={handleSave} className="focus:outline-none">
            <Bookmark
              className={`w-6 h-6 transition-colors ${
                isSaved ? 'fill-foreground text-foreground' : 'text-foreground dark:text-foreground-dark'
              }`}
            />
          </button>
        </div>

        {/* Likes count */}
        {likesCount > 0 && (
          <p className="text-sm font-semibold text-foreground dark:text-foreground-dark mt-2">
            {formatNumber(likesCount)} likes
          </p>
        )}

        {/* Caption */}
        {caption && (
          <p className="text-sm text-foreground dark:text-foreground-dark mt-1">
            <span className="font-semibold mr-2">{username}</span>
            {caption}
          </p>
        )}

        {/* Comments count */}
        {comments > 0 && (
          <button
            onClick={onComment}
            className="text-xs text-mutedForeground dark:text-mutedForeground-dark mt-1"
          >
            View all {formatNumber(comments)} comments
          </button>
        )}
      </div>
    </motion.div>
  );
};

export default PostCard;