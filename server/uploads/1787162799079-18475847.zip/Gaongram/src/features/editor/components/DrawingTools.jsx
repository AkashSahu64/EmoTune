export { default } from "../../feed/createPost/editor/components/PaintControls.jsx";
