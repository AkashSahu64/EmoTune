import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Image as ImageIcon,
  Music,
  Pencil,
  Trash2,
  Video,
  X,
} from "lucide-react";
import { useAuthStore } from "../../../../store/authStore.js";
import { useUIStore } from "../../../../store/uiStore.js";
import {
  parseApiError,
  postEditService,
} from "../../../../services/postEdit.service.js";
import { showSuccess, showError } from "../../../../utils/toast.js";
import { FEED_EVENTS, publishFeedEvent } from "../../../../utils/feedEvents.js";
import { parsePollOptions } from "../../../../utils/normalizeVibePost.js";
import Button from "../../../../components/common/Button.jsx";
import Avatar from "../../../../components/common/Avatar.jsx";
import PostCaptionEditor from "../../createPost/PostCaptionEditor.jsx";
import UploadZone from "../../createPost/UploadZone.jsx";
import MediaEditorModal from "../../createPost/MediaEditorModal.jsx";
import PollBuilder from "../../createPost/PollBuilder.jsx";
import SensitiveContentCheckbox from "../../createPost/SensitiveContentCheckbox.jsx";

const MAX_IMAGES = 10;

const createClientId = () =>
  typeof crypto !== "undefined" && crypto.randomUUID
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(16).slice(2)}`;

const useObjectUrls = (files) => {
  const [urls, setUrls] = useState([]);

  useEffect(() => {
    const nextUrls = files.map((file) => URL.createObjectURL(file));
    setUrls(nextUrls);

    return () => {
      nextUrls.forEach((url) => URL.revokeObjectURL(url));
    };
  }, [files]);

  return urls;
};

const validateFiles = (files, expectedType, maxSizeMB) => {
  const list = Array.isArray(files) ? files : [files].filter(Boolean);
  const maxBytes = maxSizeMB * 1024 * 1024;

  return list.filter((file) => {
    if (!file?.type?.startsWith(expectedType)) {
      showError(`Unsupported ${expectedType.replace("/", "")} file`);
      return false;
    }

    if (file.size > maxBytes) {
      showError(`File size must be less than ${maxSizeMB}MB`);
      return false;
    }

    return true;
  });
};

const resolvePrivacy = (post) => {
  if (post?.privacy) return post.privacy;
  if (post?.is_private) return "private";
  return "public";
};

const EditPostModal = ({ post }) => {
  const { user } = useAuthStore();
  const { closeModal } = useUIStore();
  const submitAbortRef = useRef(null);

  const isImage = post?.media_type === "image" || post?.images?.length > 0;
  const isVideo = post?.media_type === "video" || post?.videos?.length > 0;
  const isAudio = post?.media_type === "audio" || Boolean(post?.audio);
  const isPoll =
    post?.media_type === "poll" ||
    Boolean(post?.poll_question || post?.poll?.poll_question);

  const [caption, setCaption] = useState(post?.caption ?? post?.content ?? "");
  const [privacy, setPrivacy] = useState(resolvePrivacy(post));
  const [location, setLocation] = useState(post?.location || "");
  const [imageItems, setImageItems] = useState(() =>
    (post?.images || []).map((image) => ({
      kind: "existing",
      id: image.id,
      url: image.image || image.url,
    })),
  );
  const [removedImageIds, setRemovedImageIds] = useState([]);
  const [editingImageClientId, setEditingImageClientId] = useState(null);
  const [newVideo, setNewVideo] = useState(null);
  const [newThumbnail, setNewThumbnail] = useState(null);
  const [audioTitle, setAudioTitle] = useState(post?.audio?.title || "");
  const [newAudio, setNewAudio] = useState(null);
  const [newCover, setNewCover] = useState(null);
  const [pollQuestion, setPollQuestion] = useState(
    post?.poll_question || post?.poll?.poll_question || post?.poll?.question || "",
  );
  const [pollOptions, setPollOptions] = useState(() => {
    const options = parsePollOptions(post?.poll_options || post?.poll?.poll_options);
    return options.length >= 2 ? options : ["", ""];
  });
  const [pollDuration, setPollDuration] = useState(post?.poll?.duration || 24);
  const [isSubmitting, setIsSubmitting] = useState(false);
const [isSensitive, setIsSensitive] = useState(
  Boolean(post?.is_sensitive),
);

  const newImageFiles = useMemo(
    () => imageItems.filter((item) => item.kind === "new").map((item) => item.file),
    [imageItems],
  );
  const newVideoFiles = useMemo(() => (newVideo ? [newVideo] : []), [newVideo]);
  const newThumbnailFiles = useMemo(
    () => (newThumbnail ? [newThumbnail] : []),
    [newThumbnail],
  );
  const newAudioFiles = useMemo(() => (newAudio ? [newAudio] : []), [newAudio]);
  const newCoverFiles = useMemo(() => (newCover ? [newCover] : []), [newCover]);
  const newImagePreviews = useObjectUrls(newImageFiles);
  const newVideoPreview = useObjectUrls(newVideoFiles)[0];
  const newThumbnailPreview = useObjectUrls(newThumbnailFiles)[0];
  const newAudioPreview = useObjectUrls(newAudioFiles)[0];
  const newCoverPreview = useObjectUrls(newCoverFiles)[0];

  const newImagePreviewByClientId = useMemo(() => {
    const map = new Map();
    let previewIndex = 0;

    imageItems.forEach((item) => {
      if (item.kind === "new") {
        map.set(item.clientId, newImagePreviews[previewIndex]);
        previewIndex += 1;
      }
    });

    return map;
  }, [imageItems, newImagePreviews]);

  const newImageEditorFiles = useMemo(
    () => imageItems.filter((item) => item.kind === "new").map((item) => item.file),
    [imageItems],
  );
  const newImageItems = useMemo(
    () => imageItems.filter((item) => item.kind === "new"),
    [imageItems],
  );
  const editingNewImageIndex = useMemo(
    () =>
      imageItems
        .filter((item) => item.kind === "new")
        .findIndex((item) => item.clientId === editingImageClientId),
    [editingImageClientId, imageItems],
  );

  useEffect(() => {
    return () => {
      submitAbortRef.current?.abort();
    };
  }, []);

  const canClose = !isSubmitting;
  const handleClose = () => {
    if (!canClose) {
      showError("Please wait for the update to finish");
      return;
    }

    closeModal();
  };

  const addImages = useCallback(
    (files) => {
      const validFiles = validateFiles(files, "image/", 10);
      if (!validFiles.length) return;

      if (imageItems.length + validFiles.length > MAX_IMAGES) {
        showError("Maximum 10 images allowed");
        return;
      }

      setImageItems((prev) => [
        ...prev,
        ...validFiles.map((file) => ({
          kind: "new",
          clientId: createClientId(),
          file,
        })),
      ]);
    },
    [imageItems.length],
  );

  const removeImage = (index) => {
    setImageItems((prev) => {
      const target = prev[index];
      if (target?.kind === "existing" && target.id) {
        setRemovedImageIds((ids) => [...new Set([...ids, target.id])]);
      }

      return prev.filter((_, itemIndex) => itemIndex !== index);
    });
  };

  const moveImage = (index, direction) => {
    setImageItems((prev) => {
      const nextIndex = index + direction;
      if (nextIndex < 0 || nextIndex >= prev.length) return prev;

      const next = [...prev];
      const [item] = next.splice(index, 1);
      next.splice(nextIndex, 0, item);
      return next;
    });
  };

  const saveEditedImages = (updatedFiles) => {
    let fileIndex = 0;

    setImageItems((prev) =>
      prev.map((item) => {
        if (item.kind !== "new") return item;

        const file = updatedFiles[fileIndex] || item.file;
        fileIndex += 1;
        return { ...item, file };
      }),
    );
    setEditingImageClientId(null);
  };

  const handleVideoSelect = (file) => {
    const [validFile] = validateFiles(file, "video/", 100);
    if (validFile) setNewVideo(validFile);
  };

  const handleThumbnailSelect = (file) => {
    const [validFile] = validateFiles(file, "image/", 10);
    if (validFile) setNewThumbnail(validFile);
  };

  const handleAudioSelect = (file) => {
    const [validFile] = validateFiles(file, "audio/", 100);
    if (validFile) setNewAudio(validFile);
  };

  const handleCoverSelect = (file) => {
    const [validFile] = validateFiles(file, "image/", 10);
    if (validFile) setNewCover(validFile);
  };

  const validate = () => {
    if (isImage && imageItems.length === 0) {
      showError("At least one image is required");
      return false;
    }

    if (isPoll) {
      const validOptions = pollOptions.filter((option) => option.trim());
      if (!pollQuestion.trim() || validOptions.length < 2) {
        showError("Please provide a question and at least two options");
        return false;
      }
    }

    if (isAudio && !audioTitle.trim()) {
      showError("Please enter an audio title");
      return false;
    }

    return true;
  };

  const handleSubmit = async () => {
    if (isSubmitting || !validate()) {
      return;
    }

    submitAbortRef.current?.abort();
    submitAbortRef.current = new AbortController();
    setIsSubmitting(true);

    try {
      const response = await postEditService.updatePost(
        post.id,
        {
          content: caption,
          privacy,
          location,
          removedImageIds,
          imageOrder: imageItems.map((item, index) =>
            item.kind === "existing" ? item.id : `new:${index}`,
          ),
          newImages: imageItems
            .filter((item) => item.kind === "new")
            .map((item) => item.file),
          video: newVideo,
          thumbnail: newThumbnail,
          audioTitle,
          audioFile: newAudio,
          coverImage: newCover,
          pollQuestion,
          pollOptions: pollOptions.filter((option) => option.trim()),
isSensitive,
        },
        { signal: submitAbortRef.current.signal },
      );

      showSuccess("Post updated successfully");
      publishFeedEvent({
        type: FEED_EVENTS.UPDATED,
        post: response?.data || response,
      });
      closeModal();
    } catch (error) {
      if (error.name !== "CanceledError" && error.name !== "AbortError") {
        showError(parseApiError(error, "Failed to update post. Please try again."));
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!post) {
    return null;
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.22 }}
      className="w-full max-w-lg mx-auto bg-white dark:bg-gray-900 rounded-xl shadow-[0_25px_60px_rgba(0,0,0,0.15)] overflow-hidden"
    >
      <div className="sticky top-0 z-20 bg-white/95 dark:bg-gray-900/95 backdrop-blur border-b border-gray-200 dark:border-gray-700 px-4 py-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold text-gray-900 dark:text-white">
            Edit Post
          </h2>
          <button
            onClick={handleClose}
            disabled={!canClose}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition disabled:opacity-50"
            aria-label="Close edit post"
          >
            <X className="w-4 h-4 text-gray-500 dark:text-gray-400" />
          </button>
        </div>
      </div>

      <div className="max-h-[72vh] overflow-y-auto px-4 py-4 space-y-5">
        <div className="flex items-center gap-3">
          <Avatar
            src={user?.avatar || post.user?.avatar}
            alt={user?.username || post.user?.username}
            size="medium"
          />
          <div className="min-w-0">
            <p className="text-sm font-semibold text-gray-900 dark:text-white truncate">
              {user?.username || post.user?.username}
            </p>
            {/* <select
              value={privacy}
              onChange={(event) => setPrivacy(event.target.value)}
              disabled={isSubmitting}
              className="text-xs text-gray-600 dark:text-gray-300 bg-transparent outline-none"
            >
              <option value="public">Public</option>
              <option value="friends">Friends</option>
              <option value="private">Private</option>
            </select> */}
          </div>
        </div>

        <PostCaptionEditor caption={caption} setCaption={setCaption} />

        {isImage && (
          <section className="space-y-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-gray-900 dark:text-white">
              <ImageIcon className="w-4 h-4" />
              <span>Images</span>
              <span className="text-xs font-normal text-gray-500">
                {imageItems.length}/{MAX_IMAGES}
              </span>
            </div>

            {/* {imageItems.length > 0 && (
              <div className="grid grid-cols-3 gap-2">
                {imageItems.map((item, index) => {
                  const preview =
                    item.kind === "existing"
                      ? item.url
                      : newImagePreviewByClientId.get(item.clientId);

                  return (
                    <div key={item.id || item.clientId} className="relative aspect-square">
                      <img
                        src={preview}
                        alt=""
                        className="w-full h-full object-cover rounded-lg bg-gray-100 dark:bg-gray-800"
                      />
                      <div className="absolute inset-x-1 top-1 flex justify-between">
                        <button
                          onClick={() => moveImage(index, -1)}
                          disabled={index === 0 || isSubmitting}
                          className="p-1 bg-black/55 text-white rounded-full disabled:opacity-30"
                          aria-label="Move image left"
                        >
                          <ArrowLeft className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => removeImage(index)}
                          disabled={isSubmitting}
                          className="p-1 bg-black/55 text-white rounded-full disabled:opacity-50"
                          aria-label="Remove image"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                      <div className="absolute inset-x-1 bottom-1 flex justify-between">
                        <button
                          onClick={() => moveImage(index, 1)}
                          disabled={index === imageItems.length - 1 || isSubmitting}
                          className="p-1 bg-black/55 text-white rounded-full disabled:opacity-30"
                          aria-label="Move image right"
                        >
                          <ArrowRight className="w-3 h-3" />
                        </button>
                        {item.kind === "new" && (
                          <button
                            onClick={() => setEditingImageClientId(item.clientId)}
                            disabled={isSubmitting}
                            className="p-1 bg-black/55 text-white rounded-full disabled:opacity-50"
                            aria-label="Edit image"
                          >
                            <Pencil className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            <UploadZone
              onFileSelect={addImages}
              accept="image/*"
              maxSizeMB={10}
              multiple
            /> */}
          </section>
        )}

        {isVideo && (
          <section className="space-y-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-gray-900 dark:text-white">
              <Video className="w-4 h-4" />
              <span>Video</span>
            </div>

            <video
              src={newVideoPreview || post.videos?.[0]?.video || post.videos?.[0]?.hls_playlist}
              poster={newThumbnailPreview || post.videos?.[0]?.thumbnail}
              controls
              playsInline
              className="w-full max-h-64 rounded-lg object-contain bg-black"
            />

            {/* <div className="grid sm:grid-cols-2 gap-3">
              <div>
                <p className="text-xs font-medium text-gray-600 dark:text-gray-300 mb-2">
                  Replace video
                </p>
                <UploadZone
                  onFileSelect={handleVideoSelect}
                  accept="video/*"
                  maxSizeMB={100}
                  multiple={false}
                />
              </div>
              <div>
                <p className="text-xs font-medium text-gray-600 dark:text-gray-300 mb-2">
                  Replace thumbnail
                </p>
                <UploadZone
                  onFileSelect={handleThumbnailSelect}
                  accept="image/*"
                  maxSizeMB={10}
                  multiple={false}
                />
              </div>
            </div> */}
          </section>
        )}

        {isAudio && (
          <section className="space-y-3">
            {/* <div className="flex items-center gap-2 text-sm font-semibold text-gray-900 dark:text-white">
              <Music className="w-4 h-4" />
              <span>Audio</span>
            </div> */}

            {/* <input
              type="text"
              value={audioTitle}
              onChange={(event) => setAudioTitle(event.target.value)}
              placeholder="Audio title"
              disabled={isSubmitting}
              className="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-lg text-sm bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
            />

            <audio
              controls
              src={newAudioPreview || post.audio?.audio}
              className="w-full"
            />

            {(newCoverPreview || post.audio?.cover_image) && (
              <img
                src={newCoverPreview || post.audio?.cover_image}
                alt=""
                className="w-28 h-28 object-cover rounded-lg bg-gray-100 dark:bg-gray-800"
              />
            )}

            <div className="grid sm:grid-cols-2 gap-3">
              <div>
                <p className="text-xs font-medium text-gray-600 dark:text-gray-300 mb-2">
                  Replace audio
                </p>
                <UploadZone
                  onFileSelect={handleAudioSelect}
                  accept="audio/*"
                  maxSizeMB={100}
                  multiple={false}
                />
              </div>
              <div>
                <p className="text-xs font-medium text-gray-600 dark:text-gray-300 mb-2">
                  Replace cover
                </p>
                <UploadZone
                  onFileSelect={handleCoverSelect}
                  accept="image/*"
                  maxSizeMB={10}
                  multiple={false}
                />
              </div>
            </div> */}
          </section>
        )}

        {isPoll && (
          <section className="space-y-3">
            <input
              type="text"
              value={pollQuestion}
              onChange={(event) => setPollQuestion(event.target.value)}
              placeholder="Poll question"
              disabled={isSubmitting}
              className="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-lg text-sm bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
            />
            <div className="bg-gray-50 dark:bg-gray-800/70 rounded-xl p-3">
              <PollBuilder
                options={pollOptions}
                setOptions={setPollOptions}
                duration={pollDuration}
                setDuration={setPollDuration}
              />
            </div>
          </section>
        )}

        {/* <input
          type="text"
          placeholder="Add location (optional)"
          value={location}
          onChange={(event) => setLocation(event.target.value)}
          disabled={isSubmitting}
          className="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-lg text-sm bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
        /> */}

        {(isImage || isVideo) && (
  <div className="mt-2">
    <SensitiveContentCheckbox
      checked={isSensitive}
      onChange={setIsSensitive}
    />
  </div>
)}
      </div>

      <div className="sticky bottom-0 z-20 bg-white/95 dark:bg-gray-900/95 backdrop-blur border-t border-gray-200 dark:border-gray-700 px-4 py-3">
        <div className="flex gap-3">
          <Button
            variant="outline"
            fullWidth
            onClick={handleClose}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            variant="primary"
            fullWidth
            onClick={handleSubmit}
            loading={isSubmitting}
          >
            Save Changes
          </Button>
        </div>
      </div>

      {editingImageClientId && editingNewImageIndex >= 0 && (
        <MediaEditorModal
          isOpen
          onClose={() => setEditingImageClientId(null)}
          mediaFile={newImageEditorFiles}
          activeIndex={editingNewImageIndex}
          setActiveIndex={(updater) => {
            const nextIndex =
              typeof updater === "function" ? updater(editingNewImageIndex) : updater;
            const nextItem = newImageItems[nextIndex];
            if (nextItem) {
              setEditingImageClientId(nextItem.clientId);
            }
          }}
          onSave={saveEditedImages}
          mediaType="image"
        />
      )}
    </motion.div>
  );
};

export default EditPostModal;