import { fabric } from "fabric";
import { DEFAULT_FILTERS } from "../../utils/filterPresets.js";
import { isFilterableObject } from "../helpers/layerUtils.js";
import { clamp } from "../helpers/math.js";

const FILTER_KEYS = [
  "brightness",
  "contrast",
  "saturation",
  "blur",
  "sepia",
  "grayscale",
  "warm",
  "cool",
  "vintage",
  "cinematic",
];

const normalizeFilterValues = (filterValues = DEFAULT_FILTERS) =>
  FILTER_KEYS.reduce(
    (acc, key) => {
      const value = Number(filterValues?.[key] || 0);
      acc[key] = Number.isFinite(value) ? value : 0;
      return acc;
    },
    {},
  );

const getFilterSignature = (filterValues) =>
  FILTER_KEYS.map((key) => `${key}:${Number(filterValues[key] || 0).toFixed(4)}`).join("|");

export class FilterManager {
  constructor(engine) {
    this.engine = engine;
    this.ensure2dFilterBackend();
  }

  ensure2dFilterBackend() {
    if (fabric.Canvas2dFilterBackend && !(fabric.filterBackend instanceof fabric.Canvas2dFilterBackend)) {
      fabric.filterBackend = new fabric.Canvas2dFilterBackend();
    }
  }

  hasActiveFilters(filterValues = DEFAULT_FILTERS) {
    const values = normalizeFilterValues(filterValues);
    return FILTER_KEYS.some((key) => Math.abs(values[key]) > 0.0001);
  }

  buildFabricFilters(filterValues = DEFAULT_FILTERS) {
    const values = normalizeFilterValues(filterValues);
    const {
      Brightness,
      Contrast,
      Saturation,
      Blur,
      Sepia,
      Grayscale,
      BlendColor,
    } = fabric.Image.filters;
    const filters = [];

    if (values.brightness) {
      filters.push(new Brightness({ brightness: clamp(values.brightness, -1, 1) }));
    }
    if (values.contrast) {
      filters.push(new Contrast({ contrast: clamp(values.contrast, -1, 1) }));
    }
    if (values.saturation) {
      filters.push(new Saturation({ saturation: clamp(values.saturation, -1, 1) }));
    }
    if (values.blur) {
      filters.push(new Blur({ blur: clamp(values.blur, 0, 1) }));
    }
    if (values.sepia) {
      filters.push(new Sepia());
    }
    if (values.grayscale) {
      filters.push(new Grayscale());
    }
    if (values.warm) {
      filters.push(
        new BlendColor({
          color: "#F77737",
          mode: "overlay",
          alpha: clamp(values.warm, 0, 1) * 0.22,
        }),
      );
    }
    if (values.cool) {
      filters.push(
        new BlendColor({
          color: "#3B82F6",
          mode: "overlay",
          alpha: clamp(values.cool, 0, 1) * 0.22,
        }),
      );
    }
    if (values.vintage) {
      filters.push(
        new BlendColor({
          color: "#C6A75E",
          mode: "multiply",
          alpha: clamp(values.vintage, 0, 1) * 0.18,
        }),
      );
    }
    if (values.cinematic) {
      filters.push(
        new BlendColor({
          color: "#0B0F14",
          mode: "multiply",
          alpha: clamp(values.cinematic, 0, 1) * 0.2,
        }),
      );
    }

    return filters;
  }

  buildCssFilter(filterValues = DEFAULT_FILTERS) {
    const values = normalizeFilterValues(filterValues);
    const brightness = 1 + clamp(values.brightness, -1, 1);
    const contrast = 1 + clamp(values.contrast, -1, 1);
    const saturation = 1 + clamp(values.saturation, -1, 1);
    const blur = clamp(values.blur, 0, 1) * 14;
    const sepia = clamp(values.sepia + values.vintage * 0.45 + values.warm * 0.18, 0, 1);
    const grayscale = clamp(values.grayscale, 0, 1);
    const hue = clamp(values.cool, 0, 1) * -8 + clamp(values.warm, 0, 1) * 8;

    return [
      `brightness(${brightness.toFixed(3)})`,
      `contrast(${contrast.toFixed(3)})`,
      `saturate(${saturation.toFixed(3)})`,
      sepia ? `sepia(${sepia.toFixed(3)})` : "",
      grayscale ? `grayscale(${grayscale.toFixed(3)})` : "",
      blur ? `blur(${blur.toFixed(2)}px)` : "",
      hue ? `hue-rotate(${hue.toFixed(2)}deg)` : "",
    ].filter(Boolean).join(" ") || "none";
  }

  applyFiltersToObject(object, filterValues = DEFAULT_FILTERS, options = {}) {
    if (!isFilterableObject(object) || typeof object.applyFilters !== "function") {
      return false;
    }

    const values = normalizeFilterValues(filterValues);
    const signature = getFilterSignature(values);
    const shouldRebuildFilters = options.rebuild || object.__storyFilterSignature !== signature;

    object.objectCaching = false;
    object.noScaleCache = true;
    object.dirty = true;
    object.__storyFilterValues = values;

    if (shouldRebuildFilters) {
      object.filters = this.buildFabricFilters(values);
      object.__storyFilterSignature = signature;
    }

    try {
      this.ensure2dFilterBackend();
      object.applyFilters();
      object.dirty = true;
      object.setCoords?.();
      return true;
    } catch (error) {
      object.filters = [];
      object.__storyFilterSignature = "filter-error";
      object.dirty = true;
      this.engine.requestRender?.({ preview: false, immediate: true });
      this.engine.onError?.(
        new Error("This media was too large for realtime filters. It has been optimized; please try the filter again."),
      );
      return false;
    }
  }

  applyFiltersForLayer(layer) {
    if (!layer?.id) return false;
    const object = this.engine.objectMap.get(layer.id);
    if (!object) return false;
    return this.applyFiltersToObject(object, layer.__mergedFilters || layer.filters);
  }
}
