// src/features/feed/createPost/EmojiPickerInput.jsx
import React, { useState, useRef, useEffect } from "react";
import { Smile } from "lucide-react";
import Picker from "emoji-picker-react"; 

const EmojiPickerInput = ({ value, onChange, placeholder, rows = 5 }) => {
  const [showPicker, setShowPicker] = useState(false);
  const pickerRef = useRef();

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (pickerRef.current && !pickerRef.current.contains(e.target)) {
        setShowPicker(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const onEmojiClick = (emojiData) => {
    onChange(value + emojiData.emoji);
  };

  return (
    <div className="relative">
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={rows}
        className="w-full h-24 px-2 py-1 border border-border dark:border-border-dark bg-card dark:bg-card-dark rounded-xl focus:ring-2 focus:ring-primary/80 focus:border-transparent resize-none outline-none"
      />
      <button
        type="button"
        onClick={() => setShowPicker(!showPicker)}
        className="absolute bottom-3 right-3 text-foreground dark:text-foreground-dark hover:text-primary"
      >
        <Smile className="w-5 h-5" />
      </button>
      {/* PICKER */}

      {showPicker && (
        <div
          ref={pickerRef}
          className=" absolute right-0 top-[90%] z-50 shadow-md rounded-md overflow-hidden"
        >
          <Picker
            onEmojiClick={onEmojiClick}
            width={320}
            height={400}
            previewConfig={{
              showPreview: false,
            }}
            skinTonesDisabled
          />
        </div>
      )}
    </div>
  );
};

export default EmojiPickerInput;