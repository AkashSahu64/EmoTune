import React from 'react';
import { X } from 'lucide-react';

const EditorHeader = ({ mode, onClose, config }) => {
  const getTitle = () => {
    switch(mode) {
      case 'select': return config.type === 'profile' ? 'Profile Picture' : 'Cover Photo';
      case 'camera': return `Take ${config.type === 'profile' ? 'Photo' : 'Cover Photo'}`;
      case 'edit': return `Edit ${config.type === 'profile' ? 'Image' : 'Cover Photo'}`;
      case 'filters': return 'Apply Filters';
      default: return '';
    }
  };

  return (
    <div className="px-6 py-2 border-b bg-gradient-to-r from-gaon-cream to-white flex items-center justify-between">
      <h3 className="text-lg font-semibold text-gaon-black">
        {getTitle()}
      </h3>
      <button
        onClick={onClose}
        className="p-1.5 text-gray-400 hover:text-gaon-black hover:bg-gray-100 rounded-lg transition-colors"
      >
        <X size={20} />
      </button>
    </div>
  );
};

export default EditorHeader;