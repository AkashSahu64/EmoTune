// src/components/layout/AppFooter.jsx
import React, { useState, useRef, useEffect } from "react";
import { ChevronDown, Globe, Check } from "lucide-react";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { LANGUAGES } from "../../../../constants/languages";
import { motion, AnimatePresence } from "framer-motion";

const AppFooter = () => {
  const { t, i18n } = useTranslation();
  const [isLangDropdownOpen, setIsLangDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);
  
  const currentLanguage = LANGUAGES.find(lang => lang.code === i18n.language) || LANGUAGES.find(l => l.code === 'en');

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsLangDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleLanguageSelect = (code) => {
    i18n.changeLanguage(code);
    setIsLangDropdownOpen(false);
  };

  const companyLinks = [
    { name: "About", path: "/about" },
    { name: "Blog", path: "/blogs" },
    { name: "Careers", external: "https://careers.gaongram.in" },
  ];

  const resourceLinks = [
    { name: "Help Center", path: "/help-center" },
    { name: "Safety", path: "/safety" },
    { name: "Community Guidelines", path: "/community-guidelines" },
  ];

  const legalLinks = [
    { name: "Privacy", path: "/privacy" },
    { name: "Terms", path: "/terms" },
    { name: "Contact", path: "/locations" },
  ];

  const renderLinks = (links) =>
    links.map((item, i) => {
      if (item.external) {
        return (
          <li key={i}>
            <a
              href={item.external}
              target="_blank"
              rel="noopener noreferrer"
              className="group text-mutedForeground dark:text-mutedForeground-dark transition"
            >
              <span className="relative">
                {item.name}
                <span className="absolute left-0 -bottom-1 w-0 h-[1px] bg-primary transition-all duration-300 group-hover:w-full" />
              </span>
            </a>
          </li>
        );
      }

      return (
        <li key={i}>
          <Link
            to={item.path}
            className="group text-mutedForeground dark:text-mutedForeground-dark transition"
          >
            <span className="relative">
              {item.name}
              <span className="absolute left-0 -bottom-1 w-0 h-[1px] bg-primary transition-all duration-300 group-hover:w-full" />
            </span>
          </Link>
        </li>
      );
    });

  return (
    <footer className="border-t border-border dark:border-border-dark bg-background dark:bg-background-dark">
      <div className="max-w-7xl mx-auto px-6 py-16">
        
        {/* 🔥 TOP SECTION */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-12 mb-12">
          
          {/* 🟢 BRAND */}
          <div className="md:col-span-2 space-y-4">
            <h2 className="text-2xl font-bold text-foreground dark:text-foreground-dark">
              {t("app_name")}
            </h2>
            <p className="text-mutedForeground dark:text-mutedForeground-dark max-w-sm">
              {t("tagline")}
            </p>

            {/* Language Selector Dropdown */}
            <div className="relative inline-block" ref={dropdownRef}>
              <button
                onClick={() => setIsLangDropdownOpen(!isLangDropdownOpen)}
                className="inline-flex items-center gap-2 px-4 py-2 border border-border dark:border-border-dark rounded-full text-sm text-mutedForeground dark:text-mutedForeground-dark hover:bg-muted dark:hover:bg-muted-dark transition"
              >
                <Globe className="w-4 h-4" />
                <span>{currentLanguage?.englishName || 'English'}</span>
                <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${isLangDropdownOpen ? 'rotate-180' : ''}`} />
              </button>

              <AnimatePresence>
                {isLangDropdownOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.15 }}
                    className="absolute bottom-full left-0 mb-2 w-56 bg-white dark:bg-card-dark rounded-lg shadow-lg border border-border dark:border-border-dark overflow-hidden z-50"
                  >
                    <div className="max-h-64 overflow-y-auto py-1">
                      {LANGUAGES.map((lang) => (
                        <button
                          key={lang.code}
                          onClick={() => handleLanguageSelect(lang.code)}
                          className={`w-full flex items-center justify-between px-4 py-2 text-sm hover:bg-muted dark:hover:bg-muted-dark transition ${
                            i18n.language === lang.code
                              ? 'bg-primary/10 dark:bg-primary/20 text-primary'
                              : 'text-foreground dark:text-foreground-dark'
                          }`}
                        >
                          <span className="flex items-center gap-2">
                            <span>{lang.flag}</span>
                            <span>{lang.englishName}</span>
                            <span className="text-xs text-mutedForeground dark:text-mutedForeground-dark">
                              {lang.nativeName}
                            </span>
                          </span>
                          {i18n.language === lang.code && (
                            <Check className="w-4 h-4 text-primary" />
                          )}
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* 📂 COMPANY */}
          <div>
            <h3 className="text-sm font-semibold text-foreground dark:text-foreground-dark mb-4">
              {t("company")}
            </h3>
            <ul className="space-y-3 text-sm">
              {renderLinks(companyLinks)}
            </ul>
          </div>

          {/* 📂 RESOURCES */}
          <div>
            <h3 className="text-sm font-semibold text-foreground dark:text-foreground-dark mb-4">
              {t("resources")}
            </h3>
            <ul className="space-y-3 text-sm">
              {renderLinks(resourceLinks)}
            </ul>
          </div>

          {/* 📂 LEGAL */}
          <div>
            <h3 className="text-sm font-semibold text-foreground dark:text-foreground-dark mb-4">
              {t("legal")}
            </h3>
            <ul className="space-y-3 text-sm">
              {renderLinks(legalLinks)}
            </ul>
          </div>
        </div>

        {/* 🔥 BOTTOM BAR */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-mutedForeground dark:text-mutedForeground-dark border-t border-border dark:border-border-dark pt-6">
          <p>{t("copyright")}</p>

          <div className="flex gap-4">
            <Link to="/privacy" className="hover:text-foreground transition">
              {t("privacy")}
            </Link>
            <Link to="/terms" className="hover:text-foreground transition">
              {t("terms")}
            </Link>
            <Link to="/safety" className="hover:text-foreground transition">
              {t("safety")}
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default AppFooter;