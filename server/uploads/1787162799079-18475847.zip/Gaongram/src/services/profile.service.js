import api from "../config/axios.js";

export const profileService = {
  /**
   * Toggle follow/unfollow for a user profile
   * @param {string|number} profileId - The ID of the profile to follow/unfollow
   * @returns {Promise<Object>} Response data
   */
  toggleFollow: async (profileId) => {
    try {
      const response = await api.post(`/profiles/${profileId}/follow/`);
      return response.data;
    } catch (error) {
      console.error("Error toggling follow:", error);
      throw error;
    }
  },

  /**
   * Get user profile by ID
   * @param {string|number} profileId - The ID of the profile
   * @returns {Promise<Object>} Profile data
   */
  getProfile: async (profileId) => {
    try {
      const response = await api.get(`/profiles/${profileId}/`);
      return response.data;
    } catch (error) {
      console.error("Error fetching profile:", error);
      throw error;
    }
  },
  getProfiles: async (params = {}) => {
    try {
      const res = await api.get("/profiles/", { params });

      const apiData = res.data?.data;

      if (!apiData || !Array.isArray(apiData.results)) {
        return {
          users: [],
          next: undefined,
        };
      }

      const users = apiData.results.map((item) => ({
        // profile table id
        profile_id: item.id,

        // actual user id
        user_id: Number(item.user_id),

        username: item.username,

        name: item.full_name || item.username,

        avatar: item.photo || item.profile_image,

        is_following: item.is_following,

        is_private: item.is_private,
      }));

      // ✅ extract only page number
      let nextPage = undefined;

      if (apiData.next) {
        const url = new URL(apiData.next);

        nextPage = url.searchParams.get("page");
      }

      return {
        users,

        next: nextPage,
      };
    } catch (error) {
      console.error("Error fetching profiles:", error);

      throw error;
    }
  },
};