import React from "react";
import { motion } from "framer-motion";
import { Flag, Trash2, Edit } from "lucide-react";
import { useUIStore } from "../../store/uiStore.js";
import { useReport } from "../../hooks/useReport.js";
import { useTranslation } from "react-i18next";

const CommentOptionsModal = ({
  isOwner,
  onDelete,
  onEdit,
  commentId,
  commentData,
}) => {
  const { closeModal } = useUIStore();
  const { openReport } = useReport();
  const { t } = useTranslation(); 

  const handleReportComment = () => {
    closeModal();
    setTimeout(() => {
      openReport({
        modelType: "comment",
        objectId: commentId,
        objectData: commentData,
      });
    }, 150);
  };

  return (
    <div className="flex items-center justify-center w-full h-full">
      <motion.div
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        transition={{ duration: 0.2 }}
        className="w-full max-w-sm bg-white dark:bg-card-dark rounded-2xl shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-border dark:border-border-dark text-center">
          <h3 className="text-lg font-semibold text-foreground dark:text-foreground-dark">
            {t("comment_options")}
          </h3>
        </div>

        {/* Actions */}
        <div className="py-2">

          {isOwner && onEdit && (
            <button
              onClick={() => {
                onEdit();
                closeModal();
              }}
              className="w-full flex items-center gap-3 px-6 py-3 hover:bg-gray-50 dark:hover:bg-muted-dark transition"
            >
              <Edit className="w-5 h-5 text-mutedForeground dark:text-mutedForeground-dark" />
              <span className="text-foreground dark:text-foreground-dark">
                {t("edit")}
              </span>
            </button>
          )}

          {isOwner && onDelete && (
            <button
              onClick={() => {
                onDelete();
                closeModal();
              }}
              className="w-full flex items-center gap-3 px-6 py-3 hover:bg-red-50 dark:hover:bg-red-950/30 transition"
            >
              <Trash2 className="w-5 h-5 text-red-600" />
              <span className="text-red-600 font-medium">
                {t("delete")}
              </span>
            </button>
          )}

          {!isOwner && (
            <button
              onClick={handleReportComment}
              className="w-full flex items-center gap-3 px-6 py-3 hover:bg-red-50 dark:hover:bg-red-950/30 transition"
            >
              <Flag className="w-5 h-5 text-red-600" />
              <span className="text-red-600 font-medium">
                {t("report")}
              </span>
            </button>
          )}
        </div>

        {/* Cancel */}
        <div className="border-t border-border dark:border-border-dark">
          <button
            onClick={closeModal}
            className="w-full py-3 text-mutedForeground dark:text-mutedForeground-dark hover:bg-gray-50 dark:hover:bg-muted-dark transition"
          >
            {t("cancel")}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default CommentOptionsModal;