const MIN_OBJECT_SIZE = 32;

export function constrainObjectSize(object) {
  if (!object) return;
  const w = object.getScaledWidth();
  const h = object.getScaledHeight();
  if (w < MIN_OBJECT_SIZE || h < MIN_OBJECT_SIZE) {
    const minScale = Math.max(
      MIN_OBJECT_SIZE / (object.width || 1),
      MIN_OBJECT_SIZE / (object.height || 1)
    );
    object.set({
      scaleX: Math.max(object.scaleX || 1, minScale),
      scaleY: Math.max(object.scaleY || 1, minScale),
    });
  }
}