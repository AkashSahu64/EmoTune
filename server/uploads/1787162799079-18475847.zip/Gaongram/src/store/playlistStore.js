import { create } from 'zustand';

export const usePlaylistStore = create((set) => ({
  playlists: [],
  isLoading: false,
  error: null,

  setPlaylists: (playlists) => set({ playlists }),
  addPlaylist: (playlist) =>
    set((state) => ({ playlists: [playlist, ...state.playlists] })),
  updatePlaylistInStore: (id, updated) =>
    set((state) => ({
      playlists: state.playlists.map((p) => (p.id === id ? { ...p, ...updated } : p)),
    })),
  addPlaylistItem: (playlistId, item) =>
    set((state) => ({
      playlists: state.playlists.map((p) =>
        p.id === playlistId
          ? {
              ...p,
              items: [...(p.items || []), item],
            }
          : p,
      ),
    })),
  removePlaylistItem: (playlistId, audioId) =>
    set((state) => ({
      playlists: state.playlists.map((p) =>
        p.id === playlistId
          ? {
              ...p,
              items: (p.items || []).filter((item) => String(item.audio?.id) !== String(audioId)),
            }
          : p,
      ),
    })),
  removePlaylistFromStore: (id) =>
    set((state) => ({
      playlists: state.playlists.filter((p) => p.id !== id),
    })),
}));
