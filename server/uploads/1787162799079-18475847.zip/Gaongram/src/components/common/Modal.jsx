// components/common/Modal.jsx
import React, { useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useUIStore } from "../../store/uiStore.js";

const Modal = ({
  isOpen,
  onClose,
  children,
  closeOnOverlayClick = true,
  closeOnEscape = true,
}) => {
  const { closeModal, modal } = useUIStore();

  useEffect(() => {
  const handleEscape = (e) => {
    if (e.key === "Escape" && isOpen && closeOnEscape) {
      onClose?.() || closeModal();
    }
  };

  if (isOpen) {
    const scrollbarWidth =
      window.innerWidth -
      document.documentElement.clientWidth;

    document.body.style.overflow = "hidden";
    document.body.style.paddingRight = `${scrollbarWidth}px`;

    document.addEventListener("keydown", handleEscape);
  }

  return () => {
    document.body.style.overflow = "";
    document.body.style.paddingRight = "";

    document.removeEventListener("keydown", handleEscape);
  };
}, [isOpen, onClose, closeModal, closeOnEscape]);

  const isMobile =
    typeof window !== "undefined" ? window.innerWidth <= 768 : false;
  const isCommentsModal = modal?.type === "comments";
  const isShareModal = modal?.type === "share";

  const isBottomSheetModal = (isCommentsModal || isShareModal) && isMobile;
  const isRightDrawerModal = isCommentsModal && !isMobile;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          key="modal-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm"
          onClick={closeOnOverlayClick ? onClose || closeModal : undefined}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className={`w-full h-full flex ${
              isBottomSheetModal
                ? "items-end justify-center"
                : isRightDrawerModal
                ? "justify-end items-stretch"
                : "items-center justify-center p-4"
            }`}
          >
            {isCommentsModal ? (
              isMobile ? (
                // 📱 MOBILE → BOTTOM SHEET for comments
                <motion.div
                  key="comments-bottom-sheet"
                  initial={{ y: "100%" }}
                  animate={{ y: 0 }}
                  exit={{ y: "100%" }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                  className="absolute bottom-0 left-0 right-0 h-[60vh] bg-white rounded-t-2xl shadow-lg flex flex-col"
                >
                  {children}
                </motion.div>
              ) : (
                // 💻 DESKTOP → RIGHT DRAWER for comments
                <motion.div
                  key="comments-drawer"
                  initial={{ x: "100%" }}
                  animate={{ x: 0 }}
                  exit={{ x: "100%" }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                  className="w-full max-w-md h-screen bg-white shadow-lg flex flex-col"
                >
                  {children}
                </motion.div>
              )
            ) : isShareModal && isMobile ? (
              // 📱 SHARE MODAL → BOTTOM SHEET on mobile
              <motion.div
                key="share-bottom-sheet"
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "100%" }}
                transition={{ duration: 0.3, ease: "easeOut" }}
                className="absolute bottom-0 left-0 right-0 rounded-t-2xl shadow-lg"
              >
                {children}
              </motion.div>
            ) : (
              // 🖥️ DEFAULT CENTER MODAL (share on desktop, other modals)
              <motion.div
                key="center-modal"
                initial={{ scale: 0.92, y: 20, opacity: 0 }}
                animate={{ scale: 1, y: 0, opacity: 1 }}
                exit={{ scale: 0.95, y: 10, opacity: 0 }}
                transition={{ duration: 0.25, ease: "easeOut" }}
                className="w-full max-w-md overflow-hidden rounded-xl bg-card dark:bg-card-dark text-foreground dark:text-foreground-dark shadow-lg"
              >
                {children}
              </motion.div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default Modal;
