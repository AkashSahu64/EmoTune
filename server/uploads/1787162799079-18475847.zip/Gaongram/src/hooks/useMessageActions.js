// src/hooks/useMessageActions.js
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { messageService } from "../services/message.service";
import { useChatStore } from "../store/chatStore";
import { showToast } from "../utils/toast";

export const useMessageActions = (receiverId) => {
  const queryClient = useQueryClient();
  const { updateMessage, deleteMessage, clearChat, setSelectedChat } =
    useChatStore();

  const editMessage = useMutation({
    mutationFn: async ({ messageId, newMessage }) => {
      const response = await messageService.patchMessage(messageId, {
        message: newMessage,
        receiver: receiverId,
      });
      if (response.success) {
        updateMessage(receiverId, messageId, {
          message: newMessage,
          edited: true,
          updated_at: new Date().toISOString(),
        });
      }
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["messages", receiverId]);
    },
  });

  const deleteMessageAction = useMutation({
    mutationFn: async ({ messageId, forEveryone = false }) => {
      if (!messageId || String(messageId).startsWith("temp_")) {
        return;
      }

      const response = await messageService.deleteMessage(
        messageId,
        forEveryone,
      );
      if (response.success) {
        deleteMessage(receiverId, messageId, forEveryone);
        showToast(
          forEveryone ? "Message deleted for everyone" : "Message deleted",
          "success",
        );
      }
      return response;
    },
  });

  const clearChatAction = useMutation({
    mutationFn: async () => {
      const response = await messageService.clearChat(receiverId);
      if (response.success) {
        clearChat(receiverId);
        showToast("Chat cleared successfully", "success");
      }
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["chatList"]);
    },
  });

  const blockUserAction = useMutation({
    mutationFn: async (userId) => {
      const response = await messageService.toggleBlockUser(userId);
      if (response.success) {
        showToast(response.message || "User blocked", "success");
        // Clear selected chat
        setSelectedChat(null);
      }
      return response;
    },
  });

  return {
    editMessage: editMessage.mutate,
    isEditing: editMessage.isPending,
    deleteMessage: deleteMessageAction.mutate,
    isDeleting: deleteMessageAction.isPending,
    clearChat: clearChatAction.mutate,
    isClearing: clearChatAction.isPending,
    blockUser: blockUserAction.mutate,
    isBlocking: blockUserAction.isPending,
  };
};
