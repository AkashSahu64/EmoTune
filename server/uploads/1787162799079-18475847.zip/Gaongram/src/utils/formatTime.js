import dayjs from "dayjs";
import relativeTime from "dayjs/plugin/relativeTime";
import updateLocale from "dayjs/plugin/updateLocale";
import i18n from "../i18n/i18n";

dayjs.extend(relativeTime);
dayjs.extend(updateLocale);

/*
Locale (fallback only - i18n UI handle karega)
*/
dayjs.updateLocale("en", {
  relativeTime: {
    future: "in %s",
    past: "%s ago",
    s: "just now",
    m: "a minute",
    mm: "%d minutes",
    h: "an hour",
    hh: "%d hours",
    d: "a day",
    dd: "%d days",
    M: "a month",
    MM: "%d months",
    y: "a year",
    yy: "%d years",
  },
});

/*
Main formatter (i18n enabled)
*/
export const formatTime = (timestamp, format = "relative") => {
  if (!timestamp) return "";

  const t = i18n.t.bind(i18n);

  const now = dayjs();
  const date = dayjs(timestamp);

  if (!date.isValid()) return "";

  if (format === "relative") {
    const seconds = now.diff(date, "second");
    const minutes = now.diff(date, "minute");
    const hours = now.diff(date, "hour");
    const days = now.diff(date, "day");
    const weeks = now.diff(date, "week");
    const months = now.diff(date, "month");
    const years = now.diff(date, "year");

    // Just now
    if (seconds < 60) {
      return t("time.just_now");
    }

    // Minutes
    if (minutes < 60) {
      return t("time.minutes_ago", {
        count: minutes,
      });
    }

    // Hours
    if (hours < 24) {
      return t("time.hours_ago", {
        count: hours,
      });
    }

    // Days
    if (days < 7) {
      const remainingHours = now.diff(
        date.add(days, "day"),
        "hour",
      );

      if (remainingHours > 0) {
        return t("time.days_hours_ago", {
          days,
          hours: remainingHours,
        });
      }

      return t("time.days_ago", {
        count: days,
      });
    }

    // Weeks (up to 30 days)
    if (days < 30) {
      return t("time.weeks_ago", {
        count: Math.max(1, weeks),
      });
    }

    // Months
    if (months < 12) {
      return t("time.months_ago", {
        count: Math.max(1, months),
      });
    }

    // Years
    return t("time.years_ago", {
      count: Math.max(1, years),
    });
  }

  return date.format(format);
};

/*
Number formatter
*/
export const formatNumber = (num) => {
  if (!num && num !== 0) return "0";

  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + "M";
  }

  if (num >= 1000) {
    return (num / 1000).toFixed(1) + "K";
  }

  return num.toString();
};

/*
Compact version (Instagram style)
*/
export const getTimeAgo = (timestamp) => {
  if (!timestamp) return "";

  const t = i18n.t.bind(i18n);

  const now = dayjs();
  const date = dayjs(timestamp);

  if (!date.isValid()) return "";

  const diffSeconds = now.diff(date, "second");

  // now
  if (diffSeconds < 60) {
    return t("time.now_short");
  }

  // minutes
  if (diffSeconds < 3600) {
    const m = Math.floor(diffSeconds / 60);

    return t("time.minutes_short", {
      count: m,
    });
  }

  // hours
  if (diffSeconds < 86400) {
    const h = Math.floor(diffSeconds / 3600);

    return t("time.hours_short", {
      count: h,
    });
  }

  // days
  if (diffSeconds < 604800) {
    const d = Math.floor(diffSeconds / 86400);

    return t("time.days_short", {
      count: d,
    });
  }

  const days = now.diff(date, "day");
  const months = now.diff(date, "month");
  const years = now.diff(date, "year");

  // weeks
  if (days < 30) {
    const weeks = Math.max(1, Math.floor(days / 7));

    return t("time.weeks_short", {
      count: weeks,
    });
  }

  // months
  if (months < 12) {
    return t("time.months_short", {
      count: Math.max(1, months),
    });
  }

  // years
  return t("time.years_short", {
    count: Math.max(1, years),
  });
};

/*
Media player time
*/
export const formatPlayerTime = (seconds) => {
  if (!seconds || isNaN(seconds)) {
    return "0:00";
  }

  const minutes = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);

  return `${minutes}:${secs.toString().padStart(2, "0")}`;
};