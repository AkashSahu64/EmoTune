import React, { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Pencil, PencilLine } from "lucide-react";

const buildVersionedImageUrl = (src, revision) => {
  if (!src) return "";
  if (!revision) return src;

  const separator = src.includes("?") ? "&" : "?";
  return `${src}${separator}v=${revision}`;
};

const FloatingActionButton = ({ onClick, children, label, className = "" }) => (
  <motion.button
    type="button"
    whileTap={{ scale: 0.94 }}
    onClick={onClick}
    aria-label={label}
    className={`flex items-center justify-center rounded-full border border-border dark:border-border-dark bg-transparent text-foreground dark:text-foreground-dark shadow-soft backdrop-blur ${className}`}
  >
    {children}
  </motion.button>
);

const ProfileCover = ({
  displayName,
  username,
  coverImage,
  coverPreviewImage,
  coverImageRevision,
  avatarImage,
  avatarPreviewImage,
  avatarImageRevision,
  isOwnProfile,
  isCoverUpdating,
  isAvatarUpdating,
  onEditCover,
  onEditAvatar,
  onCoverPreviewReady,
  onAvatarPreviewReady,
  onPreviewCover,
  onPreviewAvatar,
}) => {
  const resolvedCoverImage = useMemo(
    () => buildVersionedImageUrl(coverImage, coverImageRevision),
    [coverImage, coverImageRevision],
  );
  const resolvedAvatarImage = useMemo(
    () => buildVersionedImageUrl(avatarImage, avatarImageRevision),
    [avatarImage, avatarImageRevision],
  );
  const visibleCoverImage = coverPreviewImage || resolvedCoverImage;
  const visibleAvatarImage = avatarPreviewImage || resolvedAvatarImage;

  const [coverLoaded, setCoverLoaded] = useState(!visibleCoverImage);
  const [avatarLoaded, setAvatarLoaded] = useState(!visibleAvatarImage);

  useEffect(() => {
    setCoverLoaded(!visibleCoverImage);
  }, [visibleCoverImage]);

  useEffect(() => {
    setAvatarLoaded(!visibleAvatarImage);
  }, [visibleAvatarImage]);

  useEffect(() => {
    if (!coverPreviewImage || !resolvedCoverImage) return undefined;

    const image = new window.Image();
    image.src = resolvedCoverImage;
    image.onload = () => {
      onCoverPreviewReady?.();
    };

    return () => {
      image.onload = null;
    };
  }, [coverPreviewImage, onCoverPreviewReady, resolvedCoverImage]);

  useEffect(() => {
    if (!avatarPreviewImage || !resolvedAvatarImage) return undefined;

    const image = new window.Image();
    image.src = resolvedAvatarImage;
    image.onload = () => {
      onAvatarPreviewReady?.();
    };

    return () => {
      image.onload = null;
    };
  }, [avatarPreviewImage, onAvatarPreviewReady, resolvedAvatarImage]);

  return (
    <section className="relative">
      <div className="relative h-[120px] overflow-hidden bg-muted dark:bg-muted-dark lg:h-[180px]">
        {visibleCoverImage ? (
          <>
            {!coverLoaded ? (
              <div className="absolute inset-0 bg-primary" />
            ) : null}

            <img
              src={visibleCoverImage}
              alt={`${displayName}'s cover`}
              onClick={() => onPreviewCover?.(visibleCoverImage)}
              className={`h-full w-full object-cover transition duration-500 cursor-pointer ${
                coverLoaded ? "opacity-100" : "opacity-0"
              }`}
              onLoad={() => setCoverLoaded(true)}
            />
          </>
        ) : (
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,_rgba(198,167,94,0.28),_transparent_28%),linear-gradient(135deg,_rgba(14,77,56,0.92),_rgba(17,97,73,0.7)_55%,_rgba(244,208,136,0.38)_100%)]" />
        )}

        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-muted via-muted/5 to-transparent dark:from-muted-dark dark:via-muted-dark/5 dark:to-transparent" />

        {isOwnProfile ? (
          <FloatingActionButton
            onClick={onEditCover}
            label="Edit cover image"
            className="absolute right-4 top-4 z-10 h-7 w-7 bg-white/30 dark:bg-white/20 text-mutedForeground dark:text-mutedForeground-dark"
          >
            <PencilLine size={16} />
          </FloatingActionButton>
        ) : null}

        {isCoverUpdating ? (
          <div className="absolute inset-0 z-0 flex items-center justify-center bg-black/20 backdrop-blur-[2px]">
            <div className="h-10 w-10 animate-spin rounded-full border-2 border-white border-t-transparent" />
          </div>
        ) : null}
      </div>

      <div className="pointer-events-none absolute inset-x-0 bottom-0 flex translate-y-1/2 justify-center">
        <div className="pointer-events-auto relative">
          <div className="relative h-32 w-32 overflow-hidden rounded-full border-2 border-border dark:border-border-dark bg-muted dark:bg-muted-dark shadow-soft lg:h-36 lg:w-36">
            {visibleAvatarImage ? (
              <>
                {!avatarLoaded ? (
                  <div className="absolute inset-0 animate-pulse bg-gradient-to-br from-[#ecebe7] via-[#e3e7ef] to-[#d8ddd8]" />
                ) : null}
                <img
                  src={visibleAvatarImage}
                  alt={username}
                  onClick={() => onPreviewAvatar?.(visibleAvatarImage)}
                  className={`h-full w-full object-cover transition duration-500 cursor-pointer ${
                    avatarLoaded ? "opacity-100" : "opacity-0"
                  }`}
                  onLoad={() => setAvatarLoaded(true)}
                />
              </>
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-[#183b2f] via-[#2b5d48] to-[#c6a75e] text-3xl font-semibold uppercase text-white">
                {(displayName || username || "G").charAt(0)}
              </div>
            )}

            {isAvatarUpdating ? (
              <div className="absolute inset-0 flex items-center justify-center bg-white/70">
                <div className="h-8 w-8 animate-spin rounded-full border-2 border-foreground border-t-transparent" />
              </div>
            ) : null}
          </div>

          {isOwnProfile ? (
            <FloatingActionButton
              onClick={onEditAvatar}
              label="Edit profile image"
              className="absolute bottom-2 right-4 z-10 h-6 w-6 border-border-dark bg-transparent text-black"
            >
              <Pencil size={14} />
            </FloatingActionButton>
          ) : null}
        </div>
      </div>
    </section>
  );
};

export default React.memo(ProfileCover);
