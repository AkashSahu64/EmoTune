// src/features/messages/components/ChatHeader.jsx
import React, { useState } from 'react';
import { ArrowLeft, MoreVertical, UserMinus, Trash2, Palette } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Avatar from '../../../components/common/Avatar';


const ChatHeader = ({ user, isOnline, onClearChat, onBlockUser, onOpenThemePicker }) => {
  const navigate = useNavigate();
  const [showMenu, setShowMenu] = useState(false);

  return (
    <div className="sticky top-0 z-10 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 px-4 py-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/messages')} className="p-2">
            <ArrowLeft className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate(`/profile/${user?.username}`)}>
            <Avatar src={user?.profile_image} alt={user?.full_name || "User"} size="md" />
            <div>
              <h2 className="font-semibold">
                {user?.full_name || "Loading..."}
              </h2>
              <p className="text-xs text-gray-500">
                {isOnline ? 'Online' : 'Offline'}
              </p>
            </div>
          </div>
        </div>

        <div className="relative">
          <button onClick={() => setShowMenu(!showMenu)} className="p-2">
            <MoreVertical className="w-5 h-5" />
          </button>

          {showMenu && (
            <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 z-20">
              <button
                onClick={() => {
                  onClearChat();
                  setShowMenu(false);
                }}
                className="w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                Clear Chat
              </button>
              <button
                onClick={() => {
                  onBlockUser();
                  setShowMenu(false);
                }}
                className="w-full px-4 py-2 text-left text-red-500 hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2"
              >
                <UserMinus className="w-4 h-4" />
                Block User
              </button>
              <button
                onClick={() => {
                  onOpenThemePicker();
                  setShowMenu(false);
                }}
                className="w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700 flex items-center gap-2"
              >
                <Palette className="w-4 h-4" />
                Theme
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatHeader;