import React from "react";
import { Loader2 } from "lucide-react";

const SharedCanvas = React.forwardRef(function SharedCanvas(
  { isReady, className = "", canvasClassName = "", children },
  ref,
) {
  return (
    <section className={`relative flex min-h-0 items-center justify-center overflow-hidden rounded-xl border border-border bg-muted p-1 dark:border-border-dark dark:bg-muted-dark sm:p-2 ${className}`}>
      <div className={`relative max-h-full max-w-full ${canvasClassName}`}>
        {!isReady && (
          <div className="absolute inset-0 z-10 flex items-center justify-center rounded-xl bg-background/75 backdrop-blur-sm dark:bg-background-dark/75">
            <Loader2 className="h-8 w-8 animate-spin text-foreground dark:text-foreground-dark" />
          </div>
        )}
        <canvas ref={ref} className="block max-h-full max-w-full" />
        {children}
      </div>
    </section>
  );
});

export default SharedCanvas;
