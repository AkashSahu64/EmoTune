import { create } from "zustand";
import { ensureAudioElement } from "../utils/audioManager";
import { mediaController } from "../media/MediaController";

const sameId = (a, b) => String(a ?? "") === String(b ?? "");

export const usePlayerStore = create((set, get) => ({
  currentTrack: null,
  queue: [],
  currentIndex: -1,
  isPlaying: false,
  isVisible: false,
  mode: "bar",
  position: { x: 20, y: 100 },
  isDragging: false,

  setTrack: (track, options = {}) => {
    if (track?.id && track?.src) {
      ensureAudioElement(track.id, track.src, "audio");
    }
    const instance = track?.id ? mediaController.getMediaInstance(track.id) : null;
    set({
      currentTrack: track,
      isVisible: true,
      isPlaying: options.isPlaying ?? instance?.playing ?? get().isPlaying,
      queue: track ? [track] : [],
      currentIndex: 0,
    });
  },

  setQueue: (tracks, startIndex = 0, options = {}) => {
    const safeTracks = Array.isArray(tracks) ? tracks.filter(Boolean) : [];
    if (!safeTracks.length) return;
    const boundedIndex = Math.max(0, Math.min(startIndex, safeTracks.length - 1));
    const selected = safeTracks[boundedIndex];

    if (selected?.id && selected?.src) {
      ensureAudioElement(
        selected.id,
        selected.src,
        "audio",
      );
    }

    const current = get().currentTrack;
    const instance = selected?.id ? mediaController.getMediaInstance(selected.id) : null;
    const shouldReplace =
      options.force ||
      !current ||
      !sameId(current.id, selected?.id) ||
      get().queue.length !== safeTracks.length ||
      get().queue.some((track, index) => !sameId(track.id, safeTracks[index]?.id));

    if (!shouldReplace) return;

    set({
      queue: safeTracks,
      currentIndex: boundedIndex,
      currentTrack: selected,
      isVisible: true,
      isPlaying: options.isPlaying ?? instance?.playing ?? get().isPlaying,
    });
  },

  nextTrack: () => {
    const { queue, currentIndex } = get();
    if (!queue.length) return;
    const nextIdx = (currentIndex + 1) % queue.length;
    const nextTrack = queue[nextIdx];
    if (nextTrack?.id && nextTrack?.src) {
      ensureAudioElement(nextTrack.id, nextTrack.src, "audio");
    }
    set({
      currentIndex: nextIdx,
      currentTrack: nextTrack,
    });
    if (get().isPlaying) {
      mediaController.play(nextTrack.id, { manual: true }).catch(console.warn);
    }
  },

  prevTrack: () => {
    const { queue, currentIndex } = get();
    if (!queue.length) return;
    const prevIdx = currentIndex === 0 ? queue.length - 1 : currentIndex - 1;
    const prevTrack = queue[prevIdx];
    if (prevTrack?.id && prevTrack?.src) {
      ensureAudioElement(prevTrack.id, prevTrack.src, "audio");
    }
    set({
      currentIndex: prevIdx,
      currentTrack: prevTrack,
    });
    if (get().isPlaying) {
      mediaController.play(prevTrack.id, { manual: true }).catch(console.warn);
    }
  },

  play: () => set({ isPlaying: true }),
  pause: () => set({ isPlaying: false }),
  hide: () => set({ isVisible: false }),
  setPlaying: (playing) => set({ isPlaying: playing }),

  toggleMode: () =>
    set((state) => {
      const newMode = state.mode === "bar" ? "card" : "bar";

      return {
        mode: newMode,
        isVisible: true,
        position:
          newMode === "card"
            ? { x: 20, y: 100 }
            : {
                x: 20,
                y:
                  typeof window !== "undefined"
                    ? window.innerHeight - 100
                    : 100,
              },
      };
    }),
  setPosition: (pos) => set({ position: pos }),
  setDragging: (dragging) => set({ isDragging: dragging }),
}));
