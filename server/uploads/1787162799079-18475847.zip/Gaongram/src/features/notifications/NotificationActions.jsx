import React from "react";

const NotificationActions = ({
  type,
  is_followed_by,
  loading,
  requestId,
  onAccept,
  onReject,
}) => {
  if (type === "follow_request") {
    // If the sender already follows you, show "Following" badge (no actions)
    if (is_followed_by) {
      return (
        <span className="text-sm font-medium bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-lg px-3 py-1.5">
          Following
        </span>
      );
    }

    // Otherwise show Accept / Reject buttons
    return (
      <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
        <button
          onClick={() => onAccept(requestId)}
          disabled={loading}
          className="px-3 py-1.5 text-sm font-medium text-white bg-primary hover:bg-primary-light rounded-lg transition disabled:opacity-50"
        >
          Accept
        </button>
        <button
          onClick={() => onReject(requestId)}
          disabled={loading}
          className="px-3 py-1.5 text-sm font-medium text-gray-800 dark:text-gray-200 bg-gray-200 dark:bg-gray-700 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition disabled:opacity-50"
        >
          Reject
        </button>
      </div>
    );
  }

  // For any other notification type, no actions
  return null;
};

export default React.memo(NotificationActions);