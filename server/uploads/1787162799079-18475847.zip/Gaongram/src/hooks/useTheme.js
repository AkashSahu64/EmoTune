import { useCallback, useEffect, useState } from "react";
import { applyTheme, getInitialTheme, initializeTheme } from "../utils/theme.js";

export const useTheme = () => {
  const [theme, setThemeState] = useState(getInitialTheme);

  useEffect(() => {
    setThemeState(initializeTheme());

    const handleThemeChange = (event) => {
      if (event.detail?.theme) {
        setThemeState(event.detail.theme);
      }
    };

    window.addEventListener("gaongram:theme-change", handleThemeChange);
    return () => {
      window.removeEventListener("gaongram:theme-change", handleThemeChange);
    };
  }, []);

  const setTheme = useCallback((nextTheme) => {
    setThemeState(applyTheme(nextTheme));
  }, []);

  const toggleTheme = useCallback(() => {
    setThemeState((currentTheme) =>
      applyTheme(currentTheme === "light" ? "dark" : "light"),
    );
  }, []);

  return { theme, setTheme, toggleTheme };
};