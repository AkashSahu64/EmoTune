import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { blogsAPI } from './api.js';
import { showSuccess, showError } from '../../../utils/toast.js';

export const useBlogs = (params = {}) => {
  return useQuery({
    queryKey: ['blogs', params],
    queryFn: () => blogsAPI.getBlogs(params),
    staleTime: 3 * 60 * 1000, // 3 minutes
  });
};

export const useBlog = (blogId) => {
  return useQuery({
    queryKey: ['blog', blogId],
    queryFn: () => blogsAPI.getBlog(blogId),
    enabled: !!blogId,
    staleTime: 5 * 60 * 1000,
  });
};

export const useCreateBlog = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: blogsAPI.createBlog,
    onSuccess: () => {
      showSuccess('Blog created successfully!');
      queryClient.invalidateQueries(['blogs']);
    },
    onError: (error) => {
      showError(error.response?.data?.message || 'Failed to create blog');
    },
  });
};

export const useUpdateBlog = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, ...data }) => blogsAPI.updateBlog(id, data),
    onSuccess: (data, variables) => {
      showSuccess('Blog updated successfully!');
      queryClient.invalidateQueries(['blog', variables.id]);
      queryClient.invalidateQueries(['blogs']);
    },
    onError: (error) => {
      showError(error.response?.data?.message || 'Failed to update blog');
    },
  });
};

export const useDeleteBlog = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: blogsAPI.deleteBlog,
    onSuccess: () => {
      showSuccess('Blog deleted successfully!');
      queryClient.invalidateQueries(['blogs']);
    },
    onError: (error) => {
      showError(error.response?.data?.message || 'Failed to delete blog');
    },
  });
};

export const useLikeBlog = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: blogsAPI.likeBlog,
    onMutate: async (blogId) => {
      await queryClient.cancelQueries(['blog', blogId]);
      
      const previousBlog = queryClient.getQueryData(['blog', blogId]);
      
      if (previousBlog) {
        queryClient.setQueryData(['blog', blogId], {
          ...previousBlog,
          is_liked: true,
          likes_count: (previousBlog.likes_count || 0) + 1,
        });
      }
      
      return { previousBlog };
    },
    onError: (error, blogId, context) => {
      if (context?.previousBlog) {
        queryClient.setQueryData(['blog', blogId], context.previousBlog);
      }
      showError('Failed to like blog');
    },
    onSettled: (data, error, blogId) => {
      queryClient.invalidateQueries(['blog', blogId]);
    },
  });
};

export const useUnlikeBlog = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: blogsAPI.unlikeBlog,
    onMutate: async (blogId) => {
      await queryClient.cancelQueries(['blog', blogId]);
      
      const previousBlog = queryClient.getQueryData(['blog', blogId]);
      
      if (previousBlog) {
        queryClient.setQueryData(['blog', blogId], {
          ...previousBlog,
          is_liked: false,
          likes_count: Math.max(0, (previousBlog.likes_count || 1) - 1),
        });
      }
      
      return { previousBlog };
    },
    onError: (error, blogId, context) => {
      if (context?.previousBlog) {
        queryClient.setQueryData(['blog', blogId], context.previousBlog);
      }
      showError('Failed to unlike blog');
    },
    onSettled: (data, error, blogId) => {
      queryClient.invalidateQueries(['blog', blogId]);
    },
  });
};

export const useSaveBlog = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: blogsAPI.saveBlog,
    onMutate: async (blogId) => {
      await queryClient.cancelQueries(['blog', blogId]);
      
      const previousBlog = queryClient.getQueryData(['blog', blogId]);
      
      if (previousBlog) {
        queryClient.setQueryData(['blog', blogId], {
          ...previousBlog,
          is_saved: true,
        });
      }
      
      return { previousBlog };
    },
    onSuccess: () => {
      showSuccess('Blog saved');
    },
    onError: (error, blogId, context) => {
      if (context?.previousBlog) {
        queryClient.setQueryData(['blog', blogId], context.previousBlog);
      }
      showError('Failed to save blog');
    },
    onSettled: (data, error, blogId) => {
      queryClient.invalidateQueries(['blog', blogId]);
    },
  });
};

export const useUnsaveBlog = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: blogsAPI.unsaveBlog,
    onMutate: async (blogId) => {
      await queryClient.cancelQueries(['blog', blogId]);
      
      const previousBlog = queryClient.getQueryData(['blog', blogId]);
      
      if (previousBlog) {
        queryClient.setQueryData(['blog', blogId], {
          ...previousBlog,
          is_saved: false,
        });
      }
      
      return { previousBlog };
    },
    onSuccess: () => {
      showSuccess('Blog removed from saved');
    },
    onError: (error, blogId, context) => {
      if (context?.previousBlog) {
        queryClient.setQueryData(['blog', blogId], context.previousBlog);
      }
      showError('Failed to unsave blog');
    },
    onSettled: (data, error, blogId) => {
      queryClient.invalidateQueries(['blog', blogId]);
    },
  });
};

export const useBlogCategories = () => {
  return useQuery({
    queryKey: ['blog-categories'],
    queryFn: blogsAPI.getCategories,
    staleTime: 10 * 60 * 1000, // 10 minutes
  });
};

export const useBlogTags = () => {
  return useQuery({
    queryKey: ['blog-tags'],
    queryFn: blogsAPI.getTags,
    staleTime: 10 * 60 * 1000,
  });
};

export const useTrendingBlogs = (params = {}) => {
  return useQuery({
    queryKey: ['trending-blogs', params],
    queryFn: () => blogsAPI.getTrendingBlogs(params),
    staleTime: 5 * 60 * 1000,
  });
};