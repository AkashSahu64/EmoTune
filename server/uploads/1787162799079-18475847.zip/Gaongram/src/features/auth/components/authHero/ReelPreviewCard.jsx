import { motion } from "framer-motion";

const ReelPreviewCard = () => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 0.25, scale: 1 }}
      transition={{ duration: 0.6, delay: 0.3 }}
      className="
        hidden lg:flex
        absolute
        left-[38%]
        top-[50%]
        -translate-x-1/2
        -translate-y-1/2
        w-[210px]
        h-[360px]
        rounded-[28px]
        bg-black/20
        backdrop-blur-md
        border border-white/5
        items-center
        justify-center
        z-[15]
      "
    >
      {/* Play Icon */}
      <div className="text-white/70 text-4xl">▶</div>

      {/* Progress bar */}
      <div className="absolute bottom-3 left-4 right-4 h-[2px] bg-white/20 rounded-full overflow-hidden">
        <div className="w-1/2 h-full bg-white/50 rounded-full" />
      </div>

      <span className="absolute bottom-6 left-4 text-[11px] text-white/60">
        🎵 trending
      </span>
    </motion.div>
  );
};

export default ReelPreviewCard;