import { fabric } from "fabric";

const MAX_FILTER_SOURCE_SIZE = 2048;
const EXPORT_SAFE_PROTOCOLS = new Set(["http:", "https:", "blob:", "data:"]);

export const isLocalObjectUrl = (url) =>
  typeof url === "string" && url.startsWith("blob:");

export const isCanvasExportSafeUrl = (url) => {
  if (typeof url !== "string" || !url.trim()) return false;

  try {
    const parsed = new URL(url, window.location.href);
    if (!EXPORT_SAFE_PROTOCOLS.has(parsed.protocol)) return false;
    if (parsed.protocol === "data:" && !parsed.href.startsWith("data:image/")) {
      return false;
    }
    return true;
  } catch {
    return false;
  }
};

export const revokeObjectUrl = (url) => {
  if (isLocalObjectUrl(url)) URL.revokeObjectURL(url);
};

export const createObjectUrl = (file) => URL.createObjectURL(file);

const downscaleImageForFilters = (element) => {
  const width = element.naturalWidth || element.width || 0;
  const height = element.naturalHeight || element.height || 0;
  const maxSide = Math.max(width, height);

  if (!width || !height || maxSide <= MAX_FILTER_SOURCE_SIZE) return element;

  const scale = MAX_FILTER_SOURCE_SIZE / maxSide;
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(width * scale));
  canvas.height = Math.max(1, Math.round(height * scale));
  const context = canvas.getContext("2d", { alpha: true });
  context.imageSmoothingEnabled = true;
  context.imageSmoothingQuality = "high";
  context.drawImage(element, 0, 0, canvas.width, canvas.height);
  return canvas;
};

const getImageSourceDimensions = (element) => ({
  width: Math.max(
    1,
    element?.naturalWidth || element?.videoWidth || element?.width || 320,
  ),
  height: Math.max(
    1,
    element?.naturalHeight || element?.videoHeight || element?.height || 320,
  ),
});

export const canReadImagePixels = (element) => {
  if (!element) return false;

  try {
    const { width, height } = getImageSourceDimensions(element);
    const canvas = document.createElement("canvas");
    canvas.width = Math.min(width, 2);
    canvas.height = Math.min(height, 2);
    const context = canvas.getContext("2d", { alpha: true });
    context.drawImage(element, 0, 0, canvas.width, canvas.height);
    context.getImageData(0, 0, 1, 1);
    canvas.width = 0;
    canvas.height = 0;
    return true;
  } catch {
    return false;
  }
};

export const createExportSafePlaceholderCanvas = ({
  width = 320,
  height = 320,
  label = "Media unavailable",
} = {}) => {
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(width));
  canvas.height = Math.max(1, Math.round(height));
  const context = canvas.getContext("2d", { alpha: true });
  const radius = Math.min(canvas.width, canvas.height) * 0.12;

  context.fillStyle = "rgba(18,18,22,0.92)";
  context.fillRect(0, 0, canvas.width, canvas.height);
  context.strokeStyle = "rgba(255,255,255,0.24)";
  context.lineWidth = Math.max(
    2,
    Math.min(canvas.width, canvas.height) * 0.015,
  );
  context.beginPath();
  context.roundRect?.(4, 4, canvas.width - 8, canvas.height - 8, radius);
  if (!context.roundRect) {
    context.rect(4, 4, canvas.width - 8, canvas.height - 8);
  }
  context.stroke();

  const iconSize = Math.min(canvas.width, canvas.height) * 0.24;
  const cx = canvas.width / 2;
  const cy = canvas.height / 2 - iconSize * 0.15;
  context.fillStyle = "rgba(255,255,255,0.16)";
  context.beginPath();
  context.arc(cx, cy, iconSize * 0.5, 0, Math.PI * 2);
  context.fill();
  context.fillStyle = "rgba(255,255,255,0.78)";
  context.font = `700 ${Math.max(16, iconSize * 0.45)}px Inter, Arial, sans-serif`;
  context.textAlign = "center";
  context.textBaseline = "middle";
  context.fillText("♪", cx, cy);

  context.font = `600 ${Math.max(12, Math.min(18, canvas.width * 0.055))}px Inter, Arial, sans-serif`;
  context.fillStyle = "rgba(255,255,255,0.72)";
  context.fillText(
    label,
    cx,
    Math.min(canvas.height - 20, cy + iconSize * 0.9),
  );
  return canvas;
};

export const createPlaceholderFabricImage = ({
  width = 320,
  height = 320,
  label,
  layerId,
} = {}) => {
  const placeholder = new fabric.Image(
    createExportSafePlaceholderCanvas({ width, height, label }),
    {
      layerId,
      originX: "center",
      originY: "center",
      centeredScaling: true,
      centeredRotation: true,
      objectCaching: false,
      lockUniScaling: true,
      selectable: true,
      evented: true,
      hasControls: true,
    },
  );
  placeholder.__storyExportSafe = true;
  placeholder.__storyFallbackPlaceholder = true;
  return placeholder;
};

const loadHtmlImageElement = (
  url,
  { crossOrigin = "anonymous", referrerPolicy = "no-referrer" } = {},
) =>
  new Promise((resolve, reject) => {
    const img = new Image();
    const parsed = new URL(url, window.location.href);
    if (parsed.protocol === "http:" || parsed.protocol === "https:") {
      if (crossOrigin) img.crossOrigin = crossOrigin;
      if (referrerPolicy) img.referrerPolicy = referrerPolicy;
    }
    img.decoding = "async";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Unable to load image"));
    img.src = url;
  });

const resolveMusicCoverLoadUrl = (url) => {
  try {
    const parsed = new URL(url, window.location.href);
    if (
      parsed.hostname === "gaongram.com" &&
      parsed.pathname.startsWith("/media/vibe_post_audios/covers/")
    ) {
      return `${parsed.pathname}${parsed.search}${parsed.hash}`;
    }
  } catch {
    // Keep the original validation error path below.
  }
  return url;
};

// Load and validate an image before Fabric can draw it into the export canvas.
export const loadImageElement = (url, options = {}) => {
  return new Promise((resolve, reject) => {
    if (!url) return reject(new Error("Missing image source"));
    const { downscale = true, requireExportSafe = true } = options;

    if (!isCanvasExportSafeUrl(url)) {
      reject(new Error("Image source is not export-safe"));
      return;
    }

    loadHtmlImageElement(url)
      .then((element) => {
        if (requireExportSafe && !canReadImagePixels(element)) {
          reject(new Error("Image source failed export-safety validation"));
          return;
        }
        const sourceElement = downscale
          ? downscaleImageForFilters(element)
          : element;
        const image = new fabric.Image(sourceElement);
        image.__storyExportSafe = true;
        image.__storySourceUrl = url;
        resolve(image);
      })
      .catch((error) => {
        console.error("Image failed:", url, error);
        reject(error);
      });
  });
};

export const loadMusicCoverImage = async (url) => {
  if (!url) throw new Error("Missing music cover source");
  if (!isCanvasExportSafeUrl(url)) {
    throw new Error("Music cover source is not export-safe");
  }

  const loadUrl = resolveMusicCoverLoadUrl(url);

  try {
    const element = await loadHtmlImageElement(loadUrl);
    if (!canReadImagePixels(element)) {
      throw new Error("Music cover failed export-safety validation");
    }
    const image = new fabric.Image(element);
    image.__storyExportSafe = true;
    image.__storySourceUrl = url;
    return image;
  } catch {
    const element = await loadHtmlImageElement(loadUrl, {
      crossOrigin: null,
      referrerPolicy: null,
    });
    const image = new fabric.Image(element);
    image.__storyExportSafe = false;
    image.__storySourceUrl = url;
    image.__storyCorsFallback = true;
    return image;
  }
};

const walkFabricObjects = (objects, callback) => {
  objects.forEach((object) => {
    callback(object);
    if (Array.isArray(object?._objects)) {
      walkFabricObjects(object._objects, callback);
    }
  });
};

const replaceImageWithPlaceholder = (object) => {
  const element = object?._element || object?.getElement?.();
  const { width, height } = getImageSourceDimensions(element || object);
  const placeholder = createExportSafePlaceholderCanvas({
    width,
    height,
    label: "Preview unavailable",
  });

  if (typeof object.setElement === "function") {
    object.setElement(placeholder);
  } else {
    object._element = placeholder;
  }
  object.__storyExportSafe = true;
  object.__storyFallbackPlaceholder = true;
  object.dirty = true;
};

const resetFabricBackstore = (canvas) => {
  const width = canvas.getWidth();
  const height = canvas.getHeight();
  canvas.setDimensions({ width, height }, { backstoreOnly: true });
  canvas.calcOffset?.();
};

export const validateCanvasExportSafety = (canvas) => {
  if (!canvas) return { safe: false, replaced: 0 };
  let replaced = 0;

  walkFabricObjects(canvas.getObjects(), (object) => {
    const element = object?._element || object?.getElement?.();
    const isHtmlImage =
      typeof HTMLImageElement !== "undefined" &&
      element instanceof HTMLImageElement;
    const isImageObject = object?.type === "image" || isHtmlImage;
    if (!isImageObject || object.__storyExportSafe === true) return;
    if (canReadImagePixels(element)) {
      object.__storyExportSafe = true;
      return;
    }
    replaceImageWithPlaceholder(object);
    replaced += 1;
  });

  if (replaced > 0) resetFabricBackstore(canvas);
  canvas.renderAll();

  try {
    canvas.getElement().toDataURL("image/png");
    return { safe: true, replaced };
  } catch (error) {
    resetFabricBackstore(canvas);
    canvas.renderAll();
    try {
      canvas.getElement().toDataURL("image/png");
      return { safe: true, replaced };
    } catch {
      // Continue to the stronger fallback below.
    }

    walkFabricObjects(canvas.getObjects(), (object) => {
      const element = object?._element || object?.getElement?.();
      const isHtmlImage =
        typeof HTMLImageElement !== "undefined" &&
        element instanceof HTMLImageElement;
      if (object?.type !== "image" && !isHtmlImage) return;
      replaceImageWithPlaceholder(object);
      replaced += 1;
    });
    resetFabricBackstore(canvas);
    canvas.renderAll();

    try {
      canvas.getElement().toDataURL("image/png");
      return { safe: true, replaced };
    } catch (retryError) {
      return {
        safe: false,
        replaced,
        error: retryError || error,
      };
    }
  }
};

export const createPreviewUnavailableDataUrl = (width = 320, height = 568) =>
  createExportSafePlaceholderCanvas({
    width,
    height,
    label: "Preview unavailable",
  }).toDataURL("image/jpeg", 0.82);
