import { useCallback, useEffect, useRef, useState } from "react";

const DEFAULT_IMAGE_DURATION = 7000;

export const useTimeline = ({ isActive, mediaType, videoRef, durationMs = DEFAULT_IMAGE_DURATION, onComplete }) => {
  const [progress, setProgress] = useState(0);
  const rafRef = useRef(null);
  const startRef = useRef(0);
  const elapsedRef = useRef(0);
  const pausedRef = useRef(false);
  const completeRef = useRef(false);

  const complete = useCallback(() => {
    if (completeRef.current) return;
    completeRef.current = true;
    onComplete?.();
  }, [onComplete]);

  const animate = useCallback(
    (now) => {
      if (!isActive || pausedRef.current) return;
      const elapsed = elapsedRef.current + now - startRef.current;
      const next = Math.min(100, (elapsed / durationMs) * 100);
      setProgress(next);
      if (next >= 100) complete();
      else rafRef.current = requestAnimationFrame(animate);
    },
    [complete, durationMs, isActive],
  );

  const reset = useCallback(() => {
    cancelAnimationFrame(rafRef.current);
    completeRef.current = false;
    pausedRef.current = false;
    elapsedRef.current = 0;
    startRef.current = performance.now();
    setProgress(0);
    if (videoRef?.current) videoRef.current.currentTime = 0;
  }, [videoRef]);

  const pause = useCallback(() => {
    pausedRef.current = true;
    elapsedRef.current = (progress / 100) * durationMs;
    cancelAnimationFrame(rafRef.current);
    videoRef?.current?.pause?.();
  }, [durationMs, progress, videoRef]);

  const resume = useCallback(() => {
    pausedRef.current = false;
    startRef.current = performance.now();
    if (mediaType === "video") videoRef?.current?.play?.().catch(() => undefined);
    else rafRef.current = requestAnimationFrame(animate);
  }, [animate, mediaType, videoRef]);

  const seek = useCallback(
    (percent) => {
      const next = Math.min(100, Math.max(0, percent));
      setProgress(next);
      elapsedRef.current = (next / 100) * durationMs;
      startRef.current = performance.now();
      const video = videoRef?.current;
      if (video?.duration) video.currentTime = (next / 100) * video.duration;
    },
    [durationMs, videoRef],
  );

  useEffect(() => {
    reset();
    if (!isActive) return undefined;

    if (mediaType === "video" && videoRef?.current) {
      const video = videoRef.current;
      const update = () => {
        if (!video.duration) return;
        const next = Math.min(100, (video.currentTime / video.duration) * 100);
        setProgress(next);
        if (next >= 99.9 || video.ended) complete();
      };
      video.addEventListener("timeupdate", update);
      video.addEventListener("ended", complete);
      video.addEventListener("seeking", update);
      video.addEventListener("seeked", update);
      return () => {
        video.removeEventListener("timeupdate", update);
        video.removeEventListener("ended", complete);
        video.removeEventListener("seeking", update);
        video.removeEventListener("seeked", update);
      };
    }

    rafRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(rafRef.current);
  }, [animate, complete, isActive, mediaType, reset, videoRef]);

  return { progress, pause, resume, reset, seek };
};

export default useTimeline;
