import { EDITOR_CONFIGS, EDITOR_MODES } from "../core/editorConfig.js";

export const postEditorConfig = {
  ...EDITOR_CONFIGS[EDITOR_MODES.post],
  aspectRatios: ["free", "1:1", "4:5", "16:9", "9:16"],
  video: {
    allowCanvasFilters: false,
    allowFullImageEditor: false,
    allowTrim: true,
    allowMute: true,
    allowVolume: true,
    allowCover: true,
  },
};

export default postEditorConfig;
