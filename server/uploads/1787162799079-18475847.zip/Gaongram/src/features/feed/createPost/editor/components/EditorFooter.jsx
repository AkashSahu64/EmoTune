// src/features/feed/createPost/components/editor/components/EditorFooter.jsx

import Button from "../../../../../components/common/Button.jsx";

const EditorFooter = ({
  onReset,
  onSave,
  processing,
}) => {

  return (

    <div className="flex items-center justify-between px-3 py-2 border-t">

      <button
        onClick={onReset}
        className="text-[11px] font-medium text-gray-700"
      >
        Reset
      </button>

      <Button
        onClick={onSave}
        loading={processing}
        className="h-8 px-4 rounded-full text-[11px]"
      >
        Apply
      </Button>

    </div>

  );

};

export default EditorFooter;