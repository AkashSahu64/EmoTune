import { optimizeImageFile } from "./imageOptimization.js";

export const compressMediaFile = async (file, options = {}) => {
  if (!file) return file;
  if (file.type?.startsWith("image/")) {
    return optimizeImageFile(file, options.image);
  }
  return file;
};

export const formatBytes = (bytes = 0) => {
  if (!bytes) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / 1024 ** index).toFixed(index ? 1 : 0)} ${units[index]}`;
};
