import React from "react";

const ExportLoader = ({ visible, progress = 0, message = "Preparing media..." }) => {
  if (!visible) return null;

  return (
    <div className="mx-3 mt-3 space-y-2 sm:mx-5">
      <div className="overflow-hidden rounded-full bg-muted dark:bg-muted-dark">
        <div
          className="h-1.5 rounded-full bg-gradient-to-r from-viral-pink via-viral-purple to-viral-orange transition-all"
          style={{ width: `${Math.max(progress, 8)}%` }}
        />
      </div>
      <p className="text-xs font-medium text-mutedForeground dark:text-mutedForeground-dark">
        {message}
      </p>
    </div>
  );
};

export default React.memo(ExportLoader);
