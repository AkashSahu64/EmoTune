// src/features/feed/createPost/components/editor/components/CropControls.jsx

import {
  FlipHorizontal,
  FlipVertical,
  RotateCw,
  ZoomIn,
} from "lucide-react";

import ToolButton from "./ToolButton";

const CropControls = ({
  aspect,
  setAspect,
  setCrop,
  flipX,
  setFlipX,
  flipY,
  setFlipY,
  rotation,
  setRotation,
  zoom,
  setZoom,
  showCropOverlay,
  setShowCropOverlay = () => {},
}) => {

  return (

    <div className="space-y-3">

      <div className="flex gap-1.5 flex-wrap">

        {[
          {
            label: "Free",
            value: undefined,
          },
          {
            label: "1:1",
            value: 1,
          },
          {
            label: "4:5",
            value: 4 / 5,
          },
          {
            label: "16:9",
            value: 16 / 9,
          },
          {
            label: "9:16",
            value: 9 / 16,
          },
        ].map((item) => (

          <button
            key={item.label}
            onClick={() => {

              setAspect(item.value);
              setShowCropOverlay?.(true);

              if (
                item.value ===
                undefined
              ) {

                setCrop({
                  x: 10,
                  y: 10,
                  width: 80,
                  height: 80,
                  unit: "%",
                });

              }

            }}
            className={`
              h-7
              px-2.5
              rounded-lg
              text-[10px]
              font-medium
              transition-all duration-200

              ${
                aspect === item.value
                  ? "bg-primary text-white"
                  : "bg-gray-100 text-gray-700"
              }
            `}
          >

            {item.label}

          </button>

        ))}

      </div>

      <div className="grid grid-cols-3 gap-2">
        <ToolButton
          active={flipX}
          onClick={() =>
            setFlipX(!flipX)
          }
          icon={FlipHorizontal}
          label="Flip X"
        />

        <ToolButton
          active={flipY}
          onClick={() =>
            setFlipY(!flipY)
          }
          icon={FlipVertical}
          label="Flip Y"
        />

        <ToolButton
          active={false}
          onClick={() =>
            setRotation(
              rotation + 90
            )
          }
          icon={RotateCw}
          label="Rotate"
        />

      </div>

      <div className="bg-gray-200 rounded-xl px-3 py-2 space-y-2">

        <div className="flex items-center justify-between">

          <div className="flex items-center gap-1.5">

            <ZoomIn className="w-3.5 h-3.5 text-gray-600" />

            <span className="text-[11px] font-medium text-gray-700">
              Zoom
            </span>

          </div>

          <span className="text-[10px] font-medium text-gray-500">
            {zoom.toFixed(1)}x
          </span>

        </div>

        <input
          type="range"
          min={1}
          max={3}
          step={0.1}
          value={zoom}
          onChange={(e) =>
            setZoom(
              parseFloat(
                e.target.value
              )
            )
          }
          className="
            w-full
            accent-primary
            cursor-pointer
          "
        />

      </div>

    </div>

  );

};

export default CropControls;