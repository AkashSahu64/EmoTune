import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  Heart,
  MessageCircle,
  Bookmark,
  Share2,
  Eye,
  Calendar,
  User,
  Tag,
  ChevronLeft,
  MoreVertical,
  Edit,
  Trash2,
  Clock,
} from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuthStore } from '../../store/authStore.js';
import { useUIStore } from '../../store/uiStore.js';
import { feedService } from '../../services/feed.service.js';
import { sanitizeHtml } from '../../utils/sanitizeHtml.js';
import { formatTime } from '../../utils/formatTime.js';
import { showSuccess, showError } from '../../utils/toast.js';
import Avatar from '../../components/common/Avatar.jsx';
import Button from '../../components/common/Button.jsx';
import Loader from '../../components/common/Loader.jsx';
import EmptyState from '../../components/common/EmptyState.jsx';
import Seo from '../../components/seo/Seo.jsx';
import CommentBox from '../comments/CommentBox.jsx';
import CommentItem from '../comments/CommentItem.jsx';

const BlogDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { user, isAuthenticated } = useAuthStore();
  const { openModal } = useUIStore();
  
  const [isLiked, setIsLiked] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  const [showComments, setShowComments] = useState(false);

  // Fetch blog details
  const {
    data: blog,
    isLoading,
    isError,
    error,
  } = useQuery({
    queryKey: ['blog', id],
    queryFn: () => feedService.getBlog(id),
    enabled: !!id,
  });

  // Fetch comments
  const {
    data: commentsData,
    isLoading: commentsLoading,
  } = useQuery({
    queryKey: ['blog-comments', id],
    queryFn: () => commentService.getComments({ blog_id: id }),
    enabled: !!id && showComments,
  });

  // Like mutation
  const likeMutation = useMutation({
    mutationFn: () => feedService.likeBlog(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['blog', id]);
    },
    onError: (error) => {
      showError('Failed to like blog');
      setIsLiked(!isLiked);
      setLikeCount(prev => isLiked ? prev + 1 : prev - 1);
    },
  });

  // Save mutation
  const saveMutation = useMutation({
    mutationFn: () => feedService.saveBlog(id),
    onSuccess: () => {
      showSuccess(isSaved ? 'Blog removed from saved' : 'Blog saved');
    },
    onError: (error) => {
      showError('Failed to save blog');
      setIsSaved(!isSaved);
    },
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: () => feedService.deleteBlog(id),
    onSuccess: () => {
      showSuccess('Blog deleted successfully');
      navigate('/blogs');
    },
    onError: (error) => {
      showError('Failed to delete blog');
    },
  });

  useEffect(() => {
    if (blog) {
      setIsLiked(blog.is_liked || false);
      setIsSaved(blog.is_saved || false);
      setLikeCount(blog.likes_count || 0);
    }
  }, [blog]);

  const handleLike = () => {
    if (!isAuthenticated) {
      openModal('login');
      return;
    }

    setIsLiked(!isLiked);
    setLikeCount(prev => isLiked ? prev - 1 : prev + 1);
    likeMutation.mutate();
  };

  const handleSave = () => {
    if (!isAuthenticated) {
      openModal('login');
      return;
    }

    setIsSaved(!isSaved);
    saveMutation.mutate();
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: blog?.title,
          text: blog?.excerpt,
          url: window.location.href,
        });
      } catch (error) {
        if (error.name !== 'AbortError') {
          await copyToClipboard();
        }
      }
    } else {
      await copyToClipboard();
    }
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      showSuccess('Link copied to clipboard!');
    } catch (error) {
      showError('Failed to copy link');
    }
  };

  const handleDelete = () => {
    openModal('confirm', {
      title: 'Delete Blog',
      message: 'Are you sure you want to delete this blog? This action cannot be undone.',
      onConfirm: () => deleteMutation.mutate(),
    });
  };

  const handleEdit = () => {
    navigate(`/blogs/${id}/edit`);
  };

  const isOwner = user?.id === blog?.author?.id;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 pt-20">
        <div className="max-w-4xl mx-auto px-4">
          <div className="bg-white rounded-xl shadow-sm p-8">
            <Loader fullScreen={false} text="Loading blog..." />
          </div>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="min-h-screen bg-gray-50 pt-20">
        <div className="max-w-4xl mx-auto px-4">
          <EmptyState
            icon="document"
            title="Blog not found"
            description="The blog you're looking for doesn't exist or has been removed."
            action={
              <Button
                variant="primary"
                onClick={() => navigate('/blogs')}
              >
                Browse Blogs
              </Button>
            }
          />
        </div>
      </div>
    );
  }

  if (!blog) {
    return null;
  }

  const readingTime = Math.ceil((blog.content?.length || 0) / 1000);

  return (
    <>
      <Seo
        title={blog.title}
        description={blog.excerpt}
        ogImage={blog.cover_image}
        ogType="article"
      />
      
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b sticky top-0 z-10">
          <div className="max-w-4xl mx-auto px-4">
            <div className="flex items-center justify-between h-16">
              <button
                onClick={() => navigate(-1)}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900"
              >
                <ChevronLeft className="w-5 h-5" />
                <span>Back</span>
              </button>
              
              <div className="flex items-center space-x-4">
                <button
                  onClick={handleSave}
                  className={`p-2 rounded-full ${
                    isSaved
                      ? 'text-yellow-500 bg-yellow-50'
                      : 'text-gray-500 hover:text-yellow-500 hover:bg-gray-100'
                  }`}
                  aria-label={isSaved ? 'Unsave' : 'Save'}
                >
                  <Bookmark className={`w-5 h-5 ${isSaved ? 'fill-current' : ''}`} />
                </button>
                
                <button
                  onClick={handleShare}
                  className="p-2 rounded-full text-gray-500 hover:text-gray-900 hover:bg-gray-100"
                  aria-label="Share"
                >
                  <Share2 className="w-5 h-5" />
                </button>
                
                {isOwner && (
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={handleEdit}
                      className="p-2 rounded-full text-gray-500 hover:text-blue-600 hover:bg-blue-50"
                      aria-label="Edit"
                    >
                      <Edit className="w-5 h-5" />
                    </button>
                    <button
                      onClick={handleDelete}
                      className="p-2 rounded-full text-gray-500 hover:text-red-600 hover:bg-red-50"
                      aria-label="Delete"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-4xl mx-auto px-4 py-8">
          <motion.article
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-2xl shadow-lg overflow-hidden"
          >
            {/* Cover Image */}
            {blog.cover_image && (
              <div className="h-96 overflow-hidden">
                <img
                  src={blog.cover_image}
                  alt={blog.title}
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            <div className="p-8">
              {/* Blog Title */}
              <h1 className="text-4xl font-bold text-gray-900 mb-4">
                {blog.title}
              </h1>

              {/* Author Info */}
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center space-x-4">
                  <Link to={`/profile/${blog.author?.username}`}>
                    <Avatar
                      src={blog.author?.avatar}
                      alt={blog.author?.username}
                      size="large"
                    />
                  </Link>
                  <div>
                    <Link
                      to={`/profile/${blog.author?.username}`}
                      className="font-semibold text-gray-900 hover:text-instagram-pink"
                    >
                      {blog.author?.username}
                    </Link>
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <div className="flex items-center space-x-1">
                        <Calendar className="w-4 h-4" />
                        <span>{formatTime(blog.created_at, 'full')}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>{readingTime} min read</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Eye className="w-4 h-4" />
                        <span>{blog.views_count || 0} views</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <button
                    onClick={handleLike}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-lg ${
                      isLiked
                        ? 'bg-red-50 text-red-600'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
                    <span className="font-medium">{likeCount}</span>
                  </button>
                </div>
              </div>

              {/* Tags */}
              {blog.tags && blog.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-8">
                  {blog.tags.map((tag) => (
                    <Link
                      key={tag.id || tag}
                      to={`/tag/${tag.slug || tag}`}
                      className="inline-flex items-center px-3 py-1 bg-gray-100 text-gray-700 rounded-full hover:bg-gray-200"
                    >
                      <Tag className="w-3 h-3 mr-1" />
                      {tag.name || tag}
                    </Link>
                  ))}
                </div>
              )}

              {/* Blog Content */}
              <div className="prose prose-lg max-w-none mb-12">
                <div
                  dangerouslySetInnerHTML={{
                    __html: sanitizeHtml(blog.content),
                  }}
                />
              </div>

              {/* Stats */}
              <div className="flex items-center justify-between py-6 border-t border-b">
                <div className="flex items-center space-x-6">
                  <button
                    onClick={handleLike}
                    className={`flex items-center space-x-2 ${
                      isLiked ? 'text-red-600' : 'text-gray-600 hover:text-red-600'
                    }`}
                  >
                    <Heart className={`w-6 h-6 ${isLiked ? 'fill-current' : ''}`} />
                    <span className="font-medium">{likeCount} Likes</span>
                  </button>

                  <button
                    onClick={() => setShowComments(!showComments)}
                    className="flex items-center space-x-2 text-gray-600 hover:text-gray-900"
                  >
                    <MessageCircle className="w-6 h-6" />
                    <span className="font-medium">
                      {blog.comments_count || 0} Comments
                    </span>
                  </button>
                </div>

                <div className="flex items-center space-x-4">
                  <button
                    onClick={handleSave}
                    className={`flex items-center space-x-2 ${
                      isSaved
                        ? 'text-yellow-600'
                        : 'text-gray-600 hover:text-yellow-600'
                    }`}
                  >
                    <Bookmark className={`w-6 h-6 ${isSaved ? 'fill-current' : ''}`} />
                    <span className="font-medium">{isSaved ? 'Saved' : 'Save'}</span>
                  </button>
                </div>
              </div>

              {/* Comments Section */}
              {showComments && (
                <div className="mt-8">
                  <h3 className="text-xl font-bold text-gray-900 mb-6">
                    Comments ({blog.comments_count || 0})
                  </h3>
                  
                  {/* Add Comment */}
                  <div className="mb-8">
                    <CommentBox
                      blogId={blog.id}
                      onCommentAdded={() => {
                        queryClient.invalidateQueries(['blog-comments', id]);
                        queryClient.invalidateQueries(['blog', id]);
                      }}
                    />
                  </div>

                  {/* Comments List */}
                  <div className="space-y-6">
                    {commentsLoading ? (
                      <Loader text="Loading comments..." />
                    ) : commentsData?.data?.length > 0 ? (
                      commentsData.data.map((comment) => (
                        <CommentItem
                          key={comment.id}
                          comment={comment}
                          blogId={blog.id}
                        />
                      ))
                    ) : (
                      <EmptyState
                        icon="users"
                        title="No comments yet"
                        description="Be the first to comment on this blog."
                      />
                    )}
                  </div>
                </div>
              )}
            </div>
          </motion.article>
        </div>
      </div>
    </>
  );
};

export default BlogDetail;