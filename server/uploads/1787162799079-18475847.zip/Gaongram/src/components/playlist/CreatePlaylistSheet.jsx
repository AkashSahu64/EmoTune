import React, { useState, useRef } from "react";
import { motion } from "framer-motion";
import { ChevronLeft, Camera, Check } from "lucide-react";
import { playlistService } from "../../services/playlist.service.js";
import { usePlaylistStore } from "../../store/playlistStore.js";
import Avatar from "../common/Avatar.jsx";

const CreatePlaylistSheet = ({ onBack, onCreated }) => {
  const [title, setTitle] = useState("");
  const [isPublic, setIsPublic] = useState(true);
  const [coverFile, setCoverFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const fileInputRef = useRef(null);
  const { addPlaylist, updatePlaylistInStore, removePlaylistFromStore } =
    usePlaylistStore();

  const handleImageSelect = (e) => {
    const file = e.target.files[0];

    if (file) {
      setCoverFile(file);

      const url = URL.createObjectURL(file);
      setPreviewUrl(url);

      setErrors((prev) => ({
        ...prev,
        cover_image: "",
      }));
    }
  };

  const handleSubmit = async () => {
    const newErrors = {};

    if (!title.trim()) {
      newErrors.title = "Playlist name is required";
    }

    if (!coverFile) {
      newErrors.cover_image = "Cover image is required";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setLoading(true);

    const tempId = `temp-${Date.now()}`;

    const optimisticPlaylist = {
      id: tempId,
      title: title.trim(),
      is_public: isPublic,
      cover_image: previewUrl,
      items: [],
      isOptimistic: true,
    };

    addPlaylist(optimisticPlaylist);

    try {
      const res = await playlistService.createPlaylist({
        title: title.trim(),
        is_public: isPublic,
        cover_image: coverFile,
      });

      updatePlaylistInStore(tempId, res.data);

      onCreated(res.data);
    } catch (error) {
      removePlaylistFromStore(tempId);

      const apiErrors = error?.response?.data;

      setErrors({
        title: apiErrors?.title?.[0] || apiErrors?.detail || "",

        cover_image:
          apiErrors?.cover_image?.[0] ||
          apiErrors?.image?.[0] ||
          apiErrors?.detail ||
          "Failed to create playlist",
      });

      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      className="flex flex-col h-full"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
    >
      {/* Header */}
      <div className="flex items-center p-2 border-b border-border dark:border-border-dark">
        <button
          onClick={onBack}
          className="p-1 hover:bg-foreground/10 rounded-full transition"
        >
          <ChevronLeft className="w-5 h-5 text-foreground dark:text-foreground-dark" />
        </button>
        <h2 className="flex-1 text-center text-lg font-semibold text-foreground dark:text-foreground-dark">
          New playlist
        </h2>
        <div className="w-8" />
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-2 space-y-4">
        {/* Cover upload */}
        <div className="flex flex-col items-center">
          <div className="relative">
            <Avatar
              src={previewUrl}
              alt="Playlist cover"
              size="2xl"
              className="rounded-full"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="absolute bottom-2 right-2 p-1 bg-black/50 border border-border dark:border-border-dark rounded-full text-white shadow-lg"
            >
              <Camera size={16} />
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageSelect}
              className="hidden"
            />
          </div>
          <p className="text-xs text-mutedForeground dark:text-mutedForeground-dark mt-2">
            Tap to change cover
          </p>
          {errors.cover_image && (
            <p className="text-sm text-red-500 mt-2 text-center">
              {errors.cover_image}
            </p>
          )}
        </div>

        {/* Playlist name */}
        <div>
          <label className="block text-sm font-medium text-foreground dark:text-foreground-dark mb-1">
            Playlist name
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. My favorites"
            className="w-full px-3 py-2 bg-muted dark:bg-muted-dark border border-border dark:border-border-dark rounded-lg text-foreground dark:text-foreground-dark placeholder:text-foreground/50 focus:outline-none focus:ring-2 focus:ring-gaon-green"
            autoFocus
          />
          {errors.title && (
            <p className="text-sm text-red-500 mt-1">{errors.title}</p>
          )}
        </div>

        {/* Privacy toggle */}
        <div>
          <label className="block text-sm font-medium text-foreground dark:text-foreground-dark mb-1">
            Privacy
          </label>
          <select
            value={isPublic ? "public" : "private"}
            onChange={(e) => setIsPublic(e.target.value === "public")}
            className="w-full px-3 py-2 bg-muted dark:bg-muted-dark border border-border dark:border-border-dark rounded-lg text-foreground dark:text-foreground-dark focus:outline-none focus:ring-2 focus:ring-gaon-green"
          >
            <option value="public">Public – Anyone can see</option>
            <option value="private">Private – Only you</option>
          </select>
        </div>
      </div>

      {/* Create button */}
      <div className="px-4 py-3 border-t border-border dark:border-border-dark">
        <button
          onClick={handleSubmit}
          disabled={!title.trim() || loading}
          className="w-full py-2.5 px-3 bg-primary text-white font-medium rounded-lg flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? (
            <>
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Creating...
            </>
          ) : (
            <>
              <Check className="w-5 h-5" />
              Create playlist
            </>
          )}
        </button>
      </div>
    </motion.div>
  );
};

export default React.memo(CreatePlaylistSheet);
