/* global process, URL */
export const SITE_NAME = "GaonGram";
export const DEFAULT_SITE_URL = "https://gaongram.com";
export const DEFAULT_DESCRIPTION =
  "GaonGram is a social platform for posts, reels, audio, blogs, playlists, stories, and real-time conversations across Bharat.";
export const DEFAULT_KEYWORDS =
  "GaonGram, social media, Indian social network, reels, audio, blogs, chat, creators, Bharat";

const runtimeEnv = () => {
  const viteEnv = import.meta.env || {};
  const nodeEnv = typeof process !== "undefined" ? process.env || {} : {};
  return { ...nodeEnv, ...viteEnv };
};

export const normalizeBaseUrl = (value, fallback = DEFAULT_SITE_URL) =>
  String(value || fallback).replace(/\/+$/, "");

export const getSiteUrl = () => {
  const env = runtimeEnv();
  return normalizeBaseUrl(env.VITE_SITE_URL || env.SITE_URL);
};

export const getApiBaseUrl = () => {
  const env = runtimeEnv();
  const configured =
    env.SEO_API_BASE_URL || env.VITE_API_BASE_URL || env.API_BASE_URL;
  const siteUrl = getSiteUrl();

  if (configured && /^https?:\/\//i.test(configured)) {
    return normalizeBaseUrl(configured);
  }

  if (configured && String(configured).startsWith("/")) {
    return normalizeBaseUrl(new URL(configured, siteUrl).href);
  }

  return `${siteUrl}/api/v1`;
};

export const SEO_CONFIG = {
  siteName: SITE_NAME,
  get siteUrl() {
    return getSiteUrl();
  },
  defaultTitle: "GaonGram - Connect, Share, Chat, and Discover Bharat",
  defaultDescription: DEFAULT_DESCRIPTION,
  defaultKeywords: DEFAULT_KEYWORDS,
  defaultImage: "/preview.png",
  defaultImageAlt: "GaonGram social sharing preview",
  defaultImageWidth: 1200,
  defaultImageHeight: 630,
  locale: "en_IN",
  themeColor: "#0f172a",
  twitterSite: "@gaongram",
  organizationName: "GaonGram Technologies Pvt. Ltd.",
  contactEmail: "support@gaongram.com",
  socialProfiles: [
    "https://www.facebook.com/gaongram",
    "https://www.instagram.com/gaongram",
    "https://www.linkedin.com/company/gaongram",
    "https://twitter.com/gaongram",
  ],
};

export const INDEX_ROBOTS =
  "index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1";
export const NOINDEX_ROBOTS = "noindex, nofollow, noarchive";

export const INDEXABLE_ROUTE_PATTERNS = [
  /^\/profile\/[^/]+\/?$/i,
  /^\/profile\/[^/]+\/post\/[^/]+\/?$/i,
  /^\/blogs(?:\/[^/]+)?\/?$/i,
  /^\/reels(?:\/[^/]+)?\/?$/i,
  /^\/audio(?:\/[^/]+)?\/?$/i,
  /^\/playlists(?:\/[^/]+)?\/?$/i,
  /^\/posts(?:\/[^/]+)?\/?$/i,
  /^\/hashtags\/[^/]+\/?$/i,
  /^\/search\/hashtags\/[^/]+\/?$/i,
];

export const NOINDEX_ROUTE_PATTERNS = [
  /^\/login\/?$/i,
  /^\/register\/?$/i,
  /^\/messages(?:\/.*)?$/i,
  /^\/settings(?:\/.*)?$/i,
  /^\/notifications(?:\/.*)?$/i,
  /^\/change-password\/?$/i,
  /^\/reset-password\/?$/i,
  /^\/verify-otp\/?$/i,
  /^\/auth\/google\/?$/i,
  /^\/blogs\/(?:create|edit)(?:\/.*)?$/i,
];
