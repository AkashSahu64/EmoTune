import { useMemo } from "react";
import UploadManager from "../core/UploadManager.js";

export const useUpload = (options) => useMemo(() => new UploadManager(options), [options]);

export default useUpload;
