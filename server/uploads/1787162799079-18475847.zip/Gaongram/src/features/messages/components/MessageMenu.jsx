// src/features/messages/components/MessageMenu.jsx
import React, { useState } from 'react';

const MessageMenu = ({ message, onClose, onEdit, onDelete }) => {
  const [showDeleteOptions, setShowDeleteOptions] = useState(false);
  
  if (showDeleteOptions) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={onClose}>
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 max-w-sm w-full mx-4" onClick={e => e.stopPropagation()}>
          <h3 className="text-lg font-semibold mb-4">Delete Message</h3>
          <div className="space-y-2">
            <button
              onClick={() => onDelete(false)}
              className="w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
            >
              Delete for me
            </button>
            <button
              onClick={() => onDelete(true)}
              className="w-full px-4 py-2 text-left text-red-500 hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
            >
              Delete for everyone
            </button>
            <button onClick={onClose} className="w-full px-4 py-2 text-center text-gray-500">
              Cancel
            </button>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={onClose}>
      <div className="bg-white dark:bg-gray-800 rounded-xl p-6 max-w-sm w-full mx-4" onClick={e => e.stopPropagation()}>
        <div className="space-y-2">
          {message.message && (
            <button
              onClick={onEdit}
              className="w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
            >
              Edit Message
            </button>
          )}
          <button
            onClick={() => setShowDeleteOptions(true)}
            className="w-full px-4 py-2 text-left text-red-500 hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
          >
            Delete
          </button>
          <button onClick={onClose} className="w-full px-4 py-2 text-center text-gray-500">
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default MessageMenu;