// hooks/useMediaAutoplay.js
import { useEffect, useRef, useState, useCallback } from 'react';
import { useMediaStore } from '../store/mediaStore.js';
import { mediaController } from '../media/MediaController.js';

export const useMediaAutoplay = (mediaId, options = {}) => {
  const { threshold = 0.6, rootMargin = '50px', root = null } = options;
  const elementRef = useRef(null);
  const [isVisible, setIsVisible] = useState(false);
  const isVisibleRef = useRef(false);
  
  const { 
    activePostId, 
    userInteracted, 
    setActivePost, 
    clearActivePost,
    canAutoplayPost,
  } = useMediaStore();
  
  const handleIntersect = useCallback((entries) => {
    entries.forEach((entry) => {
      const isCurrentlyVisible = entry.intersectionRatio >= threshold;
      const wasVisible = isVisibleRef.current;
      
      if (isCurrentlyVisible && !wasVisible) {
        setIsVisible(true);
        isVisibleRef.current = true;
        
        if (mediaId && canAutoplayPost(mediaId)) {
          setActivePost(mediaId);

          const mediaInstance = mediaController.getMediaInstance(mediaId);
          if (mediaInstance && mediaInstance.element) {
            mediaController.play(mediaId, {
              autoplay: true,
              manual: false,
              muted: !userInteracted,
            }).catch(() => {});
          }
        }
      } else if (!isCurrentlyVisible && wasVisible) {
        setIsVisible(false);
        isVisibleRef.current = false;
        
        // Pause if playing
        const mediaInstance = mediaController.getMediaInstance(mediaId);
        if (mediaInstance && mediaInstance.playing && String(mediaController.activeMedia) === String(mediaId)) {
          mediaController.pause(mediaId);
        }
        
        // Clear active post
        if (activePostId === mediaId) {
          clearActivePost();
        }
      }
    });
  }, [mediaId, threshold, userInteracted, activePostId, setActivePost, clearActivePost, canAutoplayPost]);
  
  useEffect(() => {
    if (!elementRef.current || !mediaId) return;
    const observedElement = elementRef.current;
    
    const observer = new IntersectionObserver(handleIntersect, {
      threshold: [0, threshold, 1],
      root,
      rootMargin
    });
    
    observer.observe(observedElement);
    
    return () => {
      observer.unobserve(observedElement);
    };
  }, [mediaId, threshold, root, rootMargin, handleIntersect]);
  
  return {
    elementRef,
    isVisible
  };
};
