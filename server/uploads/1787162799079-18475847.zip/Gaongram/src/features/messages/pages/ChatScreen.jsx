// src/features/messages/pages/ChatScreen.jsx
import React, {
  useState,
  useEffect,
  useMemo,
  useCallback,
  useRef,
} from "react";
import { useNavigate } from "react-router-dom";
import { Virtuoso } from "react-virtuoso";
import { MessageCircle } from "lucide-react";
import { useMessages } from "../../../hooks/useMessages";
import { useSendMessage } from "../../../hooks/useSendMessage";
import { useMessageActions } from "../../../hooks/useMessageActions";
import { useTyping } from "../../../hooks/useTyping";
import { useChatStore } from "../../../store/chatStore";
import { useAuthStore } from "../../../store/authStore";
import { useSocket } from "../../../context/SocketProvider";
import ChatHeader from "../components/ChatHeader";
import ChatMessage from "../components/ChatMessage";
import ChatInput from "../components/ChatInput";
import { showToast } from "../../../utils/toast";
import { messageService } from "../../../services/message.service";
import ThemePicker from "../components/ThemePicker";
import { CHAT_THEMES } from "../../../utils/chatThemes";
import { useParams } from "react-router-dom";

import { useChatThemeStore } from "../../../store/chatThemeStore";
const ChatScreen = ({ userId, userData }) => {
  const navigate = useNavigate();
  const { connect, disconnect, isConnected } = useSocket();
  const { user } = useAuthStore();
  const { selectedChat, blockedUsers, failedMessages, onlineUsers } =
    useChatStore();
  const [editingMessage, setEditingMessage] = useState(null);
  const virtuosoRef = useRef(null);
  const isAtBottomRef = useRef(true);
  const isMountedRef = useRef(true);
  const [replyingTo, setReplyingTo] = useState(null);
  const { chatList, setChatList } = useChatStore();
  const inputRef = useRef(null);
  const { userId: routeUserId } = useParams();

  const receiverId = parseInt(userId || routeUserId);

  const [inputHeight, setInputHeight] = useState(50);
  const { currentTheme } = useChatThemeStore();
  const theme = CHAT_THEMES[currentTheme];

  const hearts = useMemo(
    () =>
      Array.from({ length: 60 }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 12,
        duration: 15 + Math.random() * 15,
      })),
    [],
  );
  const renderPatternWallpaper = () => {
    if (theme.pattern !== "doodle") return null;

    const icons = [
      "❤️",
      "⭐",
      "🎵",
      "☕",
      "🎁",
      "🌸",
      "✈️",
      "📷",
      "⚽",
      "🎮",
      "🐱",
      "🎈",
      "🎧",
      "🍕",
      "🚀",
      "💬",
    ];

    return (
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-[0.08]">
        {[...Array(300)].map((_, i) => (
          <span
            key={i}
            className="absolute text-2xl"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              transform: `rotate(${Math.random() * 360}deg)`,
            }}
          >
            {icons[Math.floor(Math.random() * icons.length)]}
          </span>
        ))}
      </div>
    );
  };

  const renderThemeAnimation = () => {
    switch (theme.animation) {
      case "hearts":
        return (
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {hearts.map((heart) => (
              <span
                key={heart.id}
                className="heart-animation absolute"
                style={{
                  left: `${heart.left}%`,
                  animationDelay: `${heart.delay}s`,
                  animationDuration: `${heart.duration}s`,
                }}
              >
                <div className="w-8 h-8 rounded-full backdrop-blur-xl bg-pink-300/20 border border-pink-300/30 flex items-center justify-center shadow-[0_0_25px_rgba(255,105,180,.4)]">
                  ❤️
                </div>
              </span>
            ))}
          </div>
        );

      case "stars":
        return (
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {[...Array(50)].map((_, i) => (
              <span
                key={i}
                className="star-animation absolute text-xs"
                style={{
                  top: `${Math.random() * 100}%`,
                  left: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 5}s`,
                }}
              >
                ✨
              </span>
            ))}
          </div>
        );

      case "clouds":
        return (
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {[...Array(10)].map((_, i) => (
              <span
                key={i}
                className="cloud-animation absolute text-5xl"
                style={{
                  top: `${Math.random() * 90}%`,
                  animationDelay: `${i * 2}s`,
                }}
              >
                ☁️
              </span>
            ))}
          </div>
        );

      case "fire":
        return (
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {[...Array(25)].map((_, i) => (
              <span
                key={i}
                className="fire-animation absolute text-xl"
                style={{
                  left: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 5}s`,
                }}
              >
                🔥
              </span>
            ))}
          </div>
        );

      default:
        return null;
    }
  };

  const isBlocked = blockedUsers.has(receiverId);
  const isReceiverOnline = onlineUsers.get(receiverId)?.online || false;
  const [showThemePage, setShowThemePage] = useState(false);

  // Try to get user from chatList or selectedChat, but only if it has full_name
  const chatUser = chatList.find((c) => c.user_id === receiverId);
  const fullUser =
    (chatUser?.full_name ? chatUser : null) ||
    (selectedChat?.full_name ? selectedChat : null);

  const { messages, isLoading, loadMore, hasNextPage, markAllAsRead } =
    useMessages(receiverId);
  const { sendMessage, isSending } = useSendMessage(receiverId);
  const { editMessage, deleteMessage, clearChat, blockUser } =
    useMessageActions(receiverId);
  const { startTyping, isTyping } = useTyping(receiverId, user?.id);

  useEffect(() => {
    if (inputRef.current) {
      setInputHeight(inputRef.current.offsetHeight);
    }
  }, []);

  // Connect WebSocket when chat opens, disconnect when leaving
  useEffect(() => {
    if (!receiverId) return;
    const timer = setTimeout(() => {
      if (isMountedRef.current) connect(receiverId);
    }, 0);
    return () => {
      clearTimeout(timer);
      disconnect();
    };
  }, [receiverId, connect, disconnect]);

  // Mark messages as read when chat is opened and not loading
  useEffect(() => {
    if (receiverId && !isLoading && isConnected) {
      markAllAsRead();
    }
  }, [receiverId, isLoading, markAllAsRead, isConnected]);

  const handleSaveEdit = async ({ messageId, newMessage }) => {
    await editMessage({ messageId, newMessage });
    setEditingMessage(null);
  };

  const handleCancelEdit = () => {
    setEditingMessage(null);
  };

  const handleSend = async ({ message, files }) => {
    if (isBlocked) return;

    if (files?.length) {
      for (const file of files) {
        const fileType = file.type.startsWith("image/")
          ? "image"
          : file.type.startsWith("audio/")
            ? "audio"
            : file.type.startsWith("video/")
              ? "video"
              : "others";

        sendMessage({
          message: "",
          file,
          file_type: fileType,
          reply_to: replyingTo?.id, // 🔥 ADD THIS
        });
      }
    } else if (message?.trim()) {
      sendMessage({
        message,
        file: null,
        file_type: "others",
        reply_to: replyingTo?.id, // 🔥 ADD THIS
      });
    }

    setReplyingTo(null); // ✅ reset
  };

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await messageService.getChatUsers();

        const users = res?.data?.results || res?.data?.data?.results || [];

        // ✅ MAIN FIX
        setChatList(users);
      } catch (err) {
        console.error("User fetch failed", err);
      }
    };

    fetchUsers();
  }, []);

  const userMap = useMemo(() => {
    const map = new Map();

    chatList.forEach((u) => {
      map.set(Number(u.id), u.profile_image);
    });

    return map;
  }, [chatList]);

  // console.log("chatList", chatList);
  // console.log("userMap", userMap);

  const handleLoadMore = useCallback(() => {
    if (!hasNextPage || isLoading) return;
    loadMore();
  }, [hasNextPage, isLoading, loadMore]);

  const handleRetry = (tempId) => {
    const failedMsg = failedMessages.get(tempId);
    if (failedMsg?.retryFn) failedMsg.retryFn();
  };

  const groupedMessages = useMemo(() => {
    const groups = {};
    messages.forEach((msg) => {
      if (msg.deleted_for_me && !msg.isTemp) return;
      const date = new Date(msg.created_at).toLocaleDateString();
      if (!groups[date]) groups[date] = [];
      groups[date].push(msg);
    });

    return groups;
  }, [messages]);

  const flatMessages = useMemo(() => {
    return Object.entries(groupedMessages).flatMap(([date, msgs]) => [
      { isDateHeader: true, date },
      ...msgs,
    ]);
  }, [groupedMessages]);

  const scrollToBottom = useCallback(() => {
    virtuosoRef.current?.scrollToIndex({
      index: flatMessages.length - 1,
      align: "end",
      behavior: "smooth",
    });
  }, [flatMessages.length]);

  // Initial scroll to bottom when messages first load
  const isFirstLoad = useRef(true);
  useEffect(() => {
    if (messages.length > 0 && isFirstLoad.current) {
      scrollToBottom();
      isFirstLoad.current = false;
    }
  }, [messages, scrollToBottom]);

  // Auto-scroll when new message arrives and user is at bottom
  useEffect(() => {
    if (isAtBottomRef.current && flatMessages.length > 0) {
      scrollToBottom();
    }
  }, [flatMessages.length, scrollToBottom]);

  // Set mounted flag
  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  if (isLoading && messages.length === 0) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }
  if (showThemePage) {
    return <ThemePicker onClose={() => setShowThemePage(false)} />;
  }

  return (
    <div
      className="w-full min-h-screen flex flex-col relative overflow-hidden bg-background dark:bg-background-dark"
      style={{ background: theme.wallpaper }}
    >
      {renderPatternWallpaper()}
      {renderThemeAnimation()}

      <ChatHeader
        user={userData || fullUser}
        isOnline={isReceiverOnline}
        onClearChat={clearChat}
        onBlockUser={() => blockUser(receiverId)}
        onOpenThemePicker={() => setShowThemePage(true)}
      />

      {/* rest of the component unchanged */}
      <div className="flex-1 relative">
        {flatMessages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-8">
            <MessageCircle className="w-16 h-16 text-gray-300 mb-4" />
            <h3 className="text-lg font-semibold mb-2">No messages yet</h3>
            <p className="text-gray-500">
              Send a message to start the conversation
            </p>
          </div>
        ) : (
          <Virtuoso
            ref={virtuosoRef}
            data={flatMessages}
            style={{ height: "100%" }}
            components={{
              Footer: () => <div style={{ height: inputHeight + 10 }} />,
            }}
            followOutput={(isAtBottom) => (isAtBottom ? "smooth" : false)}
            startReached={handleLoadMore}
            atBottomStateChange={(atBottom) => {
              isAtBottomRef.current = atBottom;
            }}
            computeItemKey={(index, item) =>
              item.isDateHeader ? `date-${item.date}` : item.id || item.tempId
            }
            itemContent={(index, item) => {
              if (item.isDateHeader) {
                return (
                  <div className="text-center my-2">
                    <span className="text-xs text-gray-400 bg-gray-100 dark:bg-gray-800 px-2 py-0.5 rounded-full">
                      {item.date}
                    </span>
                  </div>
                );
              }
              const prevItem = index > 0 ? flatMessages[index - 1] : null;
              const nextItem =
                index < flatMessages.length - 1
                  ? flatMessages[index + 1]
                  : null;

              const isSameSender = (a, b) =>
                a &&
                b &&
                !a.isDateHeader &&
                !b.isDateHeader &&
                a.sender === b.sender;

              const isWithinTime = (a, b) =>
                Math.abs(new Date(a.created_at) - new Date(b.created_at)) <
                5 * 60 * 1000;

              // 👉 grouping flags
              const isFirstInGroup =
                !isSameSender(prevItem, item) || !isWithinTime(prevItem, item);

              const isLastInGroup =
                !isSameSender(item, nextItem) || !isWithinTime(item, nextItem);

              // optional (for avatar)
              const isGrouped = !isFirstInGroup;
              return (
                <ChatMessage
                  message={item}
                  showAvatar={isFirstInGroup}
                  // isGrouped={isGrouped}
                  isFirstInGroup={isFirstInGroup}
                  isLastInGroup={isLastInGroup}
                  avatarUrl={
                    userMap.get(Number(item.sender)) ||
                    chatList.find((u) => u.user_id === Number(item.sender))
                      ?.profile_image ||
                    null
                  }
                  onReply={(msg) => setReplyingTo(msg)}
                  // replyingToMessage={replyingTo}
                  onEdit={setEditingMessage}
                  onDelete={deleteMessage}
                  onRetry={
                    item.tempId ? () => handleRetry(item.tempId) : undefined
                  }
                  isGrouped={isGrouped}
                />
              );
            }}
          />
        )}
        {isTyping && (
          <div className="absolute bottom-0 left-4 mb-2">
            <div className="bg-gray-100 dark:bg-gray-800 rounded-full px-3 py-1 text-xs text-gray-500">
              Typing...
            </div>
          </div>
        )}
      </div>
      <div className="sticky bottom-0 z-10 bg-white dark:bg-gray-900">
        <ChatInput
          onSend={(data) => {
            handleSend(data);
            setReplyingTo(null);
          }}
          replyingTo={replyingTo}
          onCancelReply={() => setReplyingTo(null)}
          isBlocked={isBlocked}
          onTyping={startTyping}
          isSending={isSending}
          editingMessage={editingMessage}
          onCancelEdit={handleCancelEdit}
          onSaveEdit={handleSaveEdit}
        />
      </div>
    </div>
  );
};

export default ChatScreen;
