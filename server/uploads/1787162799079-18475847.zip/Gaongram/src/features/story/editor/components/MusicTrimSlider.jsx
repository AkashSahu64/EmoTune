// import React, { useEffect, useMemo, useRef, useState } from "react";
// import { useCanvasStore } from "../useCanvasStore.js";
// import { normalizeStoryMediaUrl } from "../../audio/storyAudioManager.js";

// const MAX_CLIP_DURATION = 15;

// const clamp = (value, min, max) => Math.min(Math.max(value, min), max);

// const formatTime = (sec) => {
//   const safe = Math.max(0, Number(sec) || 0);
//   const m = Math.floor(safe / 60);
//   const s = Math.floor(safe % 60);
//   return `${m}:${s.toString().padStart(2, "0")}`;
// };

// const MusicTrimSlider = () => {
//   const music = useCanvasStore((state) => state.music);
//   const setMusic = useCanvasStore((state) => state.setMusic);
//   const fallbackDuration = music?.sourceDuration || music?.duration || MAX_CLIP_DURATION;
//   const [totalDuration, setTotalDuration] = useState(fallbackDuration);
//   const [isDragging, setIsDragging] = useState(false);
//   const audioRef = useRef(null);
//   const safeAudioUrl = useMemo(() => normalizeStoryMediaUrl(music?.audio), [music?.audio]);

//   useEffect(() => {
//     if (!safeAudioUrl) {
//       setTotalDuration(0);
//       return;
//     }
//     const audio = new Audio();
//     let cancelled = false;
//     audio.preload = "metadata";
//     audio.src = safeAudioUrl;
//     audioRef.current = audio;
//     const onMeta = () => {
//       if (!cancelled) {
//         setTotalDuration(Number.isFinite(audio.duration) ? audio.duration : fallbackDuration);
//       }
//     };
//     const onError = () => {
//       if (!cancelled) setTotalDuration(fallbackDuration);
//     };
//     setTotalDuration(fallbackDuration);
//     audio.addEventListener("loadedmetadata", onMeta);
//     audio.addEventListener("durationchange", onMeta);
//     audio.addEventListener("error", onError);
//     audio.load();
//     return () => {
//       cancelled = true;
//       audio.removeEventListener("loadedmetadata", onMeta);
//       audio.removeEventListener("durationchange", onMeta);
//       audio.removeEventListener("error", onError);
//       audio.removeAttribute("src");
//       audio.load();
//       audioRef.current = null;
//     };
//   }, [fallbackDuration, safeAudioUrl]);

//   const clipDuration = Math.max(1, Math.min(music?.duration || MAX_CLIP_DURATION, totalDuration || fallbackDuration));
//   const maxStart = Math.max(0, (totalDuration || fallbackDuration) - clipDuration);
//   const currentStart = clamp(music?.startTime ?? 0, 0, maxStart);
//   const progressPercent = useMemo(
//     () => (maxStart > 0 ? (currentStart / maxStart) * 100 : 0),
//     [currentStart, maxStart],
//   );

//   if (!music) return null;

//   const handleChange = (e) => {
//     const val = clamp(Number(e.target.value), 0, maxStart);
//     setMusic(
//       {
//         ...music,
//         startTime: val,
//         duration: clipDuration,
//         sourceDuration: totalDuration || fallbackDuration,
//       },
//       { recordHistory: !isDragging },
//     );
//   };

//   return (
//     <div className="mt-2 flex w-full min-w-0 flex-col gap-2 overflow-hidden rounded-lg border border-border bg-card p-3 dark:border-border-dark dark:bg-card-dark">
//       <div className="flex min-w-0 items-center justify-between gap-3">
//         <span className="min-w-0 truncate text-xs font-medium text-mutedForeground dark:text-mutedForeground-dark">
//           Start at {formatTime(currentStart)}
//         </span>
//         <span className="shrink-0 text-[10px] text-mutedForeground/70 dark:text-mutedForeground-dark/70">
//           {formatTime(currentStart + clipDuration)}
//         </span>
//       </div>
//       <div className="relative w-full min-w-0">
//         <input
//           type="range"
//           min={0}
//           max={maxStart || 0}
//           step={0.1}
//           value={currentStart}
//           onChange={handleChange}
//           onPointerDown={() => setIsDragging(true)}
//           onPointerUp={() => setIsDragging(false)}
//           onPointerCancel={() => setIsDragging(false)}
//           onTouchStart={() => setIsDragging(true)}
//           onTouchEnd={() => setIsDragging(false)}
//           disabled={!maxStart}
//           className="custom-range block h-8 w-full min-w-0 touch-pan-x appearance-none rounded-full bg-transparent disabled:opacity-45"
//           style={{
//             background: `linear-gradient(to right, rgb(225 48 108) 0%, rgb(225 48 108) ${progressPercent}%, rgba(148,163,184,0.32) ${progressPercent}%, rgba(148,163,184,0.32) 100%)`,
//           }}
//           aria-label="Music trim start"
//         />
//       </div>
//       <div className="flex min-w-0 justify-between gap-2 text-[10px] text-mutedForeground/60 dark:text-mutedForeground-dark/60">
//         <span>{formatTime(0)}</span>
//         <span>{formatTime(maxStart)}</span>
//       </div>
//     </div>
//   );
// };

// export default React.memo(MusicTrimSlider);
