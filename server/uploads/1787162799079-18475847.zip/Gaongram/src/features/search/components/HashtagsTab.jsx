import React from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import {
  HiFire,
  HiHeart,
  HiChatBubbleLeft,
  HiEye,
  HiPlay,
} from "react-icons/hi2";

import { hashtagService } from "../../../services/hashtag.service";
import EmptyState from "../../../components/common/EmptyState";
import { useTranslation } from "react-i18next";
import { Hash, MessageCircle } from "lucide-react";

const HashtagsTab = ({ searchTerm = "" }) => {
  const { t } = useTranslation();
  const navigate = useNavigate();

  const trimmedSearch = searchTerm?.trim().toLowerCase() || "";

  // HASHTAGS API
  const { data, isLoading, error } = useQuery({
    queryKey: ["hashtags"],
    queryFn: hashtagService.getTrendingHashtags,
  });

  // TRENDING POSTS API
  const { data: trendingPostsData, isLoading: trendingPostsLoading } = useQuery(
    {
      queryKey: ["trending-posts"],
      queryFn: hashtagService.getTrendingPosts,
    },
  );

  console.log("TRENDING POSTS DATA =>", trendingPostsData);

  // HASHTAGS
  const hashtags =
    data?.data?.data?.results?.filter((item) =>
      item.tag.toLowerCase().includes(trimmedSearch),
    ) || [];

  // TRENDING POSTS
  const trendingPosts = trendingPostsData?.data?.results || [];

  // HASHTAG CLICK
  const handleHashtagClick = (tag) => {
    navigate(`/hashtag/${tag}`);
  };

  const handleTrendingPostClick = (post) => {
    console.log("Clicked Post =>", post);

    // EXTRACT HASHTAG
    const hashtagMatch = post.content?.match(/#(\w+)/);

    // FIRST HASHTAG
    const hashtag = hashtagMatch?.[1];

    if (hashtag) {
      navigate(`/hashtag/${hashtag}`);
    }
  };

  // LOADING
  if (isLoading) {
    return (
      <div className="space-y-3">
        {Array(8)
          .fill(0)
          .map((_, idx) => (
            <div key={idx} className="h-12 shimmer rounded-lg bg-muted" />
          ))}
      </div>
    );
  }

  // ERROR
  if (error) {
    return (
      <EmptyState
        icon="alert"
        title={t("failed_load_hashtags")}
        description={error.message}
      />
    );
  }

  const showEmptyHashtags = !hashtags.length;

  return (
    <div className="space-y-2">
      {/* HASHTAGS */}
      <div>
        <h2 className="text-base font-semibold mb-2">Trending Hashtags</h2>

        {showEmptyHashtags ? (
          <EmptyState
            icon="hash"
            title="No hashtags found"
            description={
              trimmedSearch
                ? `No hashtag found for "${trimmedSearch}"`
                : "No hashtags available"
            }
          />
        ) : (
          <ul className="divide-y divide-border dark:divide-border-dark">
            {hashtags.map((hashtag) => (
              <li key={hashtag.id}>
                <button
                  onClick={() => handleHashtagClick(hashtag.slug)}
                  className="w-full flex items-center justify-between py-1.5 px-2 hover:bg-muted dark:hover:bg-muted-dark transition-colors rounded-lg"
                >
                  <div className="flex flex-col items-start leading-tight">
                    <span className="text-md font-medium text-primary">
                      # {hashtag.tag}
                    </span>

                    <span className="text-xs text-mutedForeground">
                      {hashtag.global_count} posts
                    </span>
                  </div>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* TRENDING POSTS */}
      <div>
        <div className="flex items-center justify-between mb-4 px-1">
          <h2 className="text-base font-semibold">Trending Posts</h2>

          <span className="text-xs text-mutedForeground">
            {trendingPosts.length} posts
          </span>
        </div>

        {trendingPostsLoading ? (
          <div className="grid grid-cols-2 gap-3">
            {Array(4)
              .fill(0)
              .map((_, idx) => (
                <div key={idx} className="h-52 shimmer rounded-xl bg-muted" />
              ))}
          </div>
        ) : trendingPosts.length === 0 ? (
          <EmptyState
            icon="post"
            title="No trending posts found"
            description="Trending posts are not available right now"
          />
        ) : (
          <div className=" grid lg:grid-cols-2 justify-items-center lg:px-4 pb-4 gap-2 lg:gap-5">
            {trendingPosts.map((post) => {
              const previewImage =
                post.images?.[0]?.image ||
                post.videos?.[0]?.thumbnail ||
                post.audio?.cover_image;
              const hashtag = post.content?.match(/#(\w+)/)?.[1] || "trending";

              return (
                <button
                  key={post.id}
                  onClick={() => handleTrendingPostClick(post)}
                  className=" group relative w-full h-[340px] overflow-hidden rounded-2xl"
                >
                  {/* IMAGE */}
                  {previewImage ? (
                    <img
                      src={previewImage}
                      alt={post.content || "Trending Post"}
                      className=" absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                  ) : (
                    <div className=" absolute inset-0 flex items-center justify-center bg-gradient-to-br from-zinc-800 to-black p-6">
                      <p className=" text-white/90 text-center text-base font-medium line-clamp-5">
                        {post.content || "No Content"}
                      </p>
                    </div>
                  )}

                  {/* OVERLAY */}
                  <div className=" absolute inset-0 bg-gradient-to-t from-black via-black/20 to-black/5" />

                  {/* TOP SECTION */}
                  <div className=" absolute top-4 right-4 flex items-start justify-between z-20">
                    {/* TRENDING BADGE */}
                    <div className=" flex items-center gap-1 px-2 py-1 rounded-full bg-black/10 text-white text-sm font-semibold">
                      <Hash className="w-3 h-3" />
                      <span>{hashtag}</span>
                    </div>
                  </div>

                  {/* BOTTOM CONTENT */}
                  <div className=" absolute bottom-0 left-0 right-0 z-20 p-2">
                    {/* USER */}
                    <div className="flex items-center gap-2 mt-3">
                      <img
                        src={post.profile_image || "/default-avatar.png"}
                        alt={post.user_name}
                        className=" w-10 h-10 rounded-full object-cover border-2 border-white/20 shadow-md flex-shrink-0"
                        onError={(e) => {
                          e.currentTarget.src = "/default-avatar.png";
                        }}
                      />

                      <div className="min-w-0 leading-tight">
                        <p
                          className=" text-sm font-semibold text-white truncate leading-none"
                        >
                          @{post.user_name || "gaongram"}
                        </p>
                      </div>
                    </div>

                    {/* STATS */}
                    <div className=" flex items-center gap-2 mt-4">
                      {/* LIKES */}
                      <div className=" flex items-center gap-1.5 px-2 py-1 rounded-full bg-white/10 backdrop-blur-xl border border-white/10 text-white text-xs font-medium">
                        <HiHeart className="w-4 h-4" />

                        <span>{post.total_likes || 0}</span>
                      </div>

                      {/* COMMENTS */}
                      <div className=" flex items-center gap-1.5 px-2 py-1 rounded-full bg-white/10 backdrop-blur-xl border border-white/10 text-white text-xs font-medium">
                        <MessageCircle className="w-4 h-4" />

                        <span>{post.comments_count || 0}</span>
                      </div>

                      {/* VIEWS */}
                      <div className=" flex items-center gap-1.5 px-2 py-1 rounded-full bg-white/10 backdrop-blur-xl border border-white/10 text-white text-xs font-medium">
                        <HiEye className="w-4 h-4" />

                        <span>{post.views_count || 0}</span>
                      </div>
                    </div>
                  </div>

                  {/* HOVER SHINE */}
                  <div className=" absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 bg-gradient-to-tr from-transparent via-white/5 to-transparent" />
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default React.memo(HashtagsTab);
