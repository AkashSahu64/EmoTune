import { fabric } from "fabric";
import {
  canReadImagePixels,
  createExportSafePlaceholderCanvas,
  createPlaceholderFabricImage,
  isCanvasExportSafeUrl,
  loadImageElement,
  loadMusicCoverImage,
} from "../helpers/dom.js";

export class ObjectFactory {
  constructor(engine) {
    this.engine = engine;
  }

  async createImageObject(src, layerId) {
    const image = await loadImageElement(src).catch((error) => {
      console.error("[StoryEditor] Image layer fallback", { src, error });
      return createPlaceholderFabricImage({
        layerId,
        width: this.engine.canvas?.getWidth?.() || 320,
        height: this.engine.canvas?.getHeight?.() || 568,
        label: "Media unavailable",
      });
    });
    if (this.engine.isDisposed) return null;
    image.set({
      layerId,
      originX: "center",
      originY: "center",
      centeredScaling: true,
      centeredRotation: true,
      cropX: 0,
      cropY: 0,
      width: image._element?.naturalWidth || image.width,
      height: image._element?.naturalHeight || image.height,
      objectCaching: false,
      lockUniScaling: true,
      selectable: true,
      evented: true,
      hasControls: true,
    });
    image.setCoords();
    return image;
  }

  createSVGObject(svgString, layerId) {
    return new Promise((resolve, reject) => {
      fabric.loadSVGFromString(svgString, (objects, options) => {
        if (!objects || !objects.length) {
          reject(new Error("SVG load failed"));
          return;
        }
        const obj = fabric.util.groupSVGElements(objects, options);
        obj.set({
          layerId,
          originX: "center",
          originY: "center",
          centeredScaling: true,
          centeredRotation: true,
          selectable: true,
          evented: true,
          objectCaching: false, // prevent clipping
        });
        // Ensure proper bounding box
        obj.setCoords();
        resolve(obj);
      });
    });
  }

  createVideoObject(src, layerId) {
    const loadPromise = new Promise((resolve, reject) => {
      const video = document.createElement("video");
      video.crossOrigin = "anonymous";
      video.src = src;
      video.muted = true;
      video.loop = true;
      video.playsInline = true;
      video.preload = "auto";

      const onReady = () => {
        cleanup();
        if (this.engine.isDisposed) {
          video.pause();
          video.removeAttribute("src");
          video.load();
          resolve(null);
          return;
        }
        const intrinsicWidth = Math.max(1, video.videoWidth || 720);
        const intrinsicHeight = Math.max(1, video.videoHeight || 1280);
        const canvasWidth = Math.max(
          1,
          this.engine.canvas?.getWidth?.() || intrinsicWidth,
        );
        const canvasHeight = Math.max(
          1,
          this.engine.canvas?.getHeight?.() || intrinsicHeight,
        );
        const fitScale = Math.min(
          canvasWidth / intrinsicWidth,
          canvasHeight / intrinsicHeight,
        );
        const fitWidth = Math.max(1, intrinsicWidth * fitScale);
        const fitHeight = Math.max(1, intrinsicHeight * fitScale);

        const object = new fabric.Rect({
          width: fitWidth,
          height: fitHeight,
          fill: "rgba(0,0,0,0)",
          stroke: "rgba(255,255,255,0)",
          layerId,
          originX: "center",
          originY: "center",
          objectCaching: false,
          lockUniScaling: true,
          selectable: true,
          evented: true,
          hasControls: true,
        });
        object.type = "rect";
        object.mediaType = "video";
        object.__storyVideoElement = video;
        object.__storyIntrinsicWidth = intrinsicWidth;
        object.__storyIntrinsicHeight = intrinsicHeight;
        object.__storyMediaAspect = intrinsicWidth / intrinsicHeight;
        object.__storyFitWidth = fitWidth;
        object.__storyFitHeight = fitHeight;
        this.engine.registerVideoElement?.(layerId, video, object);
        video.play().catch(() => undefined);
        resolve(object);
      };

      const onError = () => {
        cleanup();
        reject(new Error("Unable to load video"));
      };
      const cleanup = () => {
        video.removeEventListener("loadedmetadata", onReady);
        video.removeEventListener("loadeddata", onReady);
        video.removeEventListener("error", onError);
      };
      video.addEventListener("loadedmetadata", onReady, { once: true });
      video.addEventListener("loadeddata", onReady, { once: true });
      video.addEventListener("error", onError, { once: true });
      video.load();
    });

    return this.engine.trackSourceUrlLoad(src, loadPromise);
  }

  async createMusicGroup(musicData, layerId) {
    const safeCoverUrl = isCanvasExportSafeUrl(musicData.cover_image)
      ? musicData.cover_image
      : "";
    const coverPromise = safeCoverUrl
      ? loadMusicCoverImage(safeCoverUrl).catch((error) => {
          console.error(
            "[StoryEditor] Music cover fallback:",
            musicData.cover_image,
            error,
          );
          return null;
        })
      : Promise.resolve(null);

    const loadedCover = await coverPromise;
    const cardWidth = 200;
    const cardHeight = 48;
    const padding = 4;
    const coverSize = 40;
    const textLeft = padding + coverSize + 8;
    const textWidth = cardWidth - textLeft - 3;
    const truncate = (value = "", max = 24) =>
      String(value).length > max ? `${String(value).slice(0, max - 3)}...` : String(value);

    const bg = new fabric.Rect({
      width: cardWidth,
      height: cardHeight,
      rx: 12,
      ry: 12,
      fill: "rgba(18,18,22,0.58)",
      stroke: "rgba(255,255,255,0.28)",
      strokeWidth: 1,
      shadow: new fabric.Shadow("rgba(0,0,0,0.38) 0 12px 28px"),
      selectable: false,
      evented: false,
    });

    const coverCanvas = document.createElement("canvas");
    coverCanvas.width = coverSize;
    coverCanvas.height = coverSize;
    const coverContext = coverCanvas.getContext("2d", { alpha: true });
    coverContext.save();
    coverContext.beginPath();
    coverContext.arc(coverSize / 2, coverSize / 2, coverSize / 2, 0, Math.PI * 2);
    coverContext.clip();
    if (loadedCover?._element) {
      const element = loadedCover._element;
      const sourceWidth = element.naturalWidth || element.width || coverSize;
      const sourceHeight = element.naturalHeight || element.height || coverSize;
      const sourceSize = Math.min(sourceWidth, sourceHeight);
      coverContext.drawImage(
        element,
        (sourceWidth - sourceSize) / 2,
        (sourceHeight - sourceSize) / 2,
        sourceSize,
        sourceSize,
        0,
        0,
        coverSize,
        coverSize,
      );
    } else {
      const placeholder = createExportSafePlaceholderCanvas({
        width: coverSize,
        height: coverSize,
        label: "",
      });
      coverContext.drawImage(placeholder, 0, 0, coverSize, coverSize);
    }
    coverContext.restore();
    const coverImg = new fabric.Image(coverCanvas, {
      left: padding,
      top: (cardHeight - coverSize) / 2,
      width: coverSize,
      height: coverSize,
      originX: "left",
      originY: "top",
      selectable: false,
      evented: false,
      objectCaching: false,
    });
    coverImg.__storyExportSafe = loadedCover
      ? loadedCover.__storyExportSafe === true
      : true;
    coverImg.__storySourceUrl = musicData.cover_image;

    const titleText = new fabric.Textbox(truncate(musicData.title || "Music", 20), {
      left: textLeft,
      top: 7,
      width: textWidth,
      fontSize: 16,
      fontFamily: "Inter, Arial, sans-serif",
      fontWeight: "700",
      fill: "#ffffff",
      textAlign: "left",
      selectable: false,
      evented: false,
      objectCaching: false,
    });
    const artistText = new fabric.Textbox(truncate(musicData.artist || "", 25), {
      left: titleText.left,
      top: 28,
      width: titleText.width,
      fontSize: 12,
      fontFamily: "Inter, Arial, sans-serif",
      fontWeight: "500",
      fill: "rgba(255,255,255,0.76)",
      textAlign: "left",
      selectable: false,
      evented: false,
      objectCaching: false,
    });

    const group = new fabric.Group(
      [bg, coverImg, titleText, artistText],
      {
        layerId,
        originX: "center",
        originY: "center",
        objectCaching: false,
        lockUniScaling: true,
        musicData: {
          id: musicData.id,
          title: musicData.title,
          artist: musicData.artist,
          cover_image: musicData.cover_image,
          audio: musicData.audio,
          startTime: musicData.startTime,
          duration: musicData.duration,
          sourceDuration: musicData.sourceDuration,
        },
      },
    );
    return group;
  }

  async createGifObject(url, layerId) {
    if (!isCanvasExportSafeUrl(url)) {
      return createPlaceholderFabricImage({
        layerId,
        width: 260,
        height: 260,
        label: "Sticker unavailable",
      });
    }

    return new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.referrerPolicy = "no-referrer";
      img.onload = () => {
        if (!canReadImagePixels(img)) {
          resolve(createPlaceholderFabricImage({
            layerId,
            width: 260,
            height: 260,
            label: "Sticker unavailable",
          }));
          return;
        }
        const gifObject = new fabric.Image(img, {
          layerId,
          originX: "center",
          originY: "center",
          centeredScaling: true,
          centeredRotation: true,
          objectCaching: false,
          selectable: true,
          evented: true,
          hasControls: true,
        });
        gifObject.set({ width: img.width, height: img.height });
        // Initial sizing
        const maxWidth = this.engine.canvas.getWidth() * 0.4;
        gifObject.scaleToWidth(maxWidth);
        gifObject.setCoords();
        gifObject.__storyExportSafe = true;
        resolve(gifObject);
      };
      img.onerror = () =>
        resolve(createPlaceholderFabricImage({
          layerId,
          width: 260,
          height: 260,
          label: "Sticker unavailable",
        }));
      img.src = url;
    });
  }
}
