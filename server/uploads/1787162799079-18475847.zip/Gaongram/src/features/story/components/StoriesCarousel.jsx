import React, { useRef, useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Plus, Play } from "lucide-react";
import { motion as Motion } from "framer-motion";
import { useAuthStore } from "../../../store/authStore.js";
import { useUIStore } from "../../../store/uiStore.js";
import { useStoriesFeed } from "../../../hooks/useStoriesFeed.js";
import Avatar from "../../../components/common/Avatar.jsx";

const StoriesCarousel = () => {
  const { user } = useAuthStore();
  const { openModal } = useUIStore();
  const { data: stories = [], isLoading, error, refetch } = useStoriesFeed();
  const navigate = useNavigate();
  const carouselRef = useRef(null);
  const didDragRef = useRef(false);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);

  // Drag scroll handlers
  const handleMouseDown = (e) => {
    didDragRef.current = false;
    setIsDragging(true);
    setStartX(e.pageX - carouselRef.current.offsetLeft);
    setScrollLeft(carouselRef.current.scrollLeft);
  };
  const handleMouseLeave = () => setIsDragging(false);
  const handleMouseUp = () => setIsDragging(false);
  const handleMouseMove = (e) => {
    if (!isDragging) return;
    e.preventDefault();
    const x = e.pageX - carouselRef.current.offsetLeft;
    const walk = (x - startX) * 2;
    if (Math.abs(walk) > 6) didDragRef.current = true;
    carouselRef.current.scrollLeft = scrollLeft - walk;
  };

  const handleCreateStory = () => openModal("create-story");

  // Separate my story and others
  const myStory = stories.find((s) => s.type === "story" && s.isOwn);
  const otherStories = stories.filter((s) => s.type === "story" && !s.isOwn);

  const myProfileImage =
  myStory?.stories?.[0]?.profile_image ||
  user?.avatar ||
  user?.profile_image ||   
  user?.photo ||           
  `https://ui-avatars.com/api/?name=${user?.username || "User"}`;

  // Preload next stories (simple intersection observer)
  useEffect(() => {
    if (!carouselRef.current) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const img = entry.target.querySelector("img");
            if (img && img.dataset.src) img.src = img.dataset.src;
          }
        });
      },
      { root: carouselRef.current, threshold: 0.1 },
    );
    const items = carouselRef.current.querySelectorAll("[data-preload]");
    items.forEach((item) => observer.observe(item));
    return () => observer.disconnect();
  }, [stories]);

  if (isLoading) {
    return (
      <div className="flex gap-3 pb-2 overflow-x-auto">
        {[...Array(5)].map((_, i) => (
          <div
            key={i}
            className="flex-shrink-0 w-24 h-40 bg-gray-200 dark:bg-gray-800 rounded-xl animate-pulse"
          />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl text-center">
        <p className="text-sm text-red-600 dark:text-red-400 mb-2">
          Failed to load stories
        </p>
        <button
          onClick={() => refetch()}
          className="text-sm text-blue-600 hover:underline"
        >
          Try again
        </button>
      </div>
    );
  }

  const handleStoryClick = (storyGroup, index) => {
    if (didDragRef.current) {
      didDragRef.current = false;
      return;
    }
    // Pass the entire user's stories and the clicked index via location state
    navigate(`/story/${storyGroup.storyId}`, {
      state: { stories: storyGroup.stories, initialIndex: index },
    });
  };

  return (
    <div
      ref={carouselRef}
      className="no-scrollbar flex touch-pan-x gap-3 overflow-x-auto overscroll-x-contain pb-2 scroll-smooth [-webkit-overflow-scrolling:touch] sm:gap-4"
      onMouseDown={handleMouseDown}
      onMouseLeave={handleMouseLeave}
      onMouseUp={handleMouseUp}
      onMouseMove={handleMouseMove}
    >
      {/* Create Story Card */}
      {/* My Story Card (Create + View) */}
      <Motion.div
        className="relative h-40 w-24 flex-shrink-0 max-[380px]:h-36 max-[380px]:w-20"
      >
        <div
          className="relative w-full h-full rounded-xl overflow-hidden cursor-pointer bg-gradient-to-br from-gray-200 to-gray-300 dark:from-gray-800 dark:to-gray-900"
          onClick={() => {
            if (myStory) {
              handleStoryClick(myStory, 0);
            }
          }}
        >
          {/* Story Preview */}
          {myStory?.stories?.[0] && (
            <>
              {myStory.stories[0].story_type === "video" ? (
                <video
                  src={myStory.stories[0].story}
                  className="w-full h-full object-cover"
                  muted
                  preload="metadata"
                />
              ) : (
                <img
                  src={myStory.stories[0].story}
                  alt="My Story"
                  className="w-full h-full object-cover"
                />
              )}
            </>
          )}

          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

          {/* Avatar */}
          <div className="absolute top-2 left-2">
            <div className="w-8 h-8 rounded-full ring-2 ring-white overflow-hidden">
              <Avatar src={myProfileImage} alt={user?.username} size="sm" />
            </div>
          </div>

          {/* Create Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleCreateStory();
            }}
            className="absolute bottom-8 left-1/2 z-20 flex h-7 w-7 -translate-x-1/2 items-center justify-center rounded-full bg-primary shadow-lg"
            aria-label="Create story"
          >
            <Plus className="w-4 h-4 text-white" />
          </button>

          <p className="absolute bottom-2 left-0 right-0 text-xs font-medium text-white text-center">
            Your Story
          </p>
        </div>
      </Motion.div>

      {/* Other Users' Stories */}
      {otherStories.map((group) => {
        const firstStory = group.stories[0];
        return (
          <Motion.div
            key={group.id}
            className="relative h-40 w-24 flex-shrink-0 max-[380px]:h-36 max-[380px]:w-20"
            whileHover={{ scale: 1.01 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <div
              className="relative w-full h-full rounded-xl overflow-hidden cursor-pointer"
              onClick={() => handleStoryClick(group, 0)}
            >
              {/* Preview Image or Video Thumbnail */}
              {firstStory.story_type === "video" ? (
                <>
                  <video
                    src={firstStory.story}
                    className="w-full h-full object-cover"
                    preload="metadata"
                    muted
                    data-preload
                  />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                    <Play className="w-6 h-6 text-white fill-white" />
                  </div>
                </>
              ) : (
                <img
                  src={firstStory.story}
                  alt=""
                  className="w-full h-full object-cover"
                  loading="lazy"
                  data-preload
                />
              )}

              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

              {/* Avatar with Seen/Unseen Ring */}
              <div className="absolute top-2 left-2">
                <div
                  className={`w-8 h-8 rounded-full p-[2px] ${
                    group.hasNew
                      ? "bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-600"
                      : "bg-gray-400"
                  }`}
                >
                  <div className="w-full h-full rounded-full overflow-hidden bg-white">
                    <img
                      src={
                        group.user.avatar ||
                        `https://ui-avatars.com/api/?name=${group.user.username}`
                      }
                      alt=""
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              </div>

              {/* Username */}
              <div className="absolute bottom-2 left-2 right-2">
                <p className="text-xs font-medium text-white truncate text-center">
                  {group.user.username}
                </p>
              </div>

              {/* New Indicator Dot */}
              {group.hasNew && (
                <div className="absolute top-3 right-3 w-2 h-2 bg-blue-500 rounded-full border border-white" />
              )}
            </div>
          </Motion.div>
        );
      })}
    </div>
  );
};

export default StoriesCarousel;
