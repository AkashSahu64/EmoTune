import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { 
  TrendingUp, Hash, Flame, Clock, Globe, TrendingDown, 
  ArrowUpRight, Search, Filter 
} from 'lucide-react';
import { useInfiniteScroll } from '../../hooks/useInfiniteScroll.js';
import { formatNumber } from '../../utils/formatTime.js';
import Loader from '../../components/common/Loader.jsx';
import EmptyState from '../../components/common/EmptyState.jsx';
import Button from '../../components/common/Button.jsx';
import Seo from '../../components/seo/Seo.jsx';
import { buildStaticPageSeo } from '../../seo/seoBuilders.js';

const TrendingHashtags = () => {
  const [timeRange, setTimeRange] = useState('today'); // 'today', 'week', 'month'
  const [category, setCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Fetch trending hashtags
  const {
    data: hashtags,
    loading,
    error,
    hasMore,
    ref,
    refresh,
    loadMore,
  } = useInfiniteScroll(
    async ({ page, limit }) => {
      const params = {
        page,
        limit,
        time_range: timeRange,
        category: category !== 'all' ? category : undefined,
        search: searchQuery || undefined,
      };
      
      // TODO: Replace with actual API call
      return {
        data: Array(limit).fill(null).map((_, i) => ({
          id: i + 1,
          name: `hashtag${i + 1}`,
          display_name: `#Hashtag${i + 1}`,
          posts_count: Math.floor(Math.random() * 10000) + 1000,
          growth: Math.floor(Math.random() * 100) - 50, // -50 to +50
          trend: ['up', 'down', 'stable'][Math.floor(Math.random() * 3)],
          category: ['entertainment', 'technology', 'sports', 'fashion'][Math.floor(Math.random() * 4)],
          top_post: {
            id: i + 100,
            media_url: `https://picsum.photos/400/300?random=${i + 1}`,
            likes_count: Math.floor(Math.random() * 5000) + 1000,
            comments_count: Math.floor(Math.random() * 500) + 100,
          },
        })),
      };
    },
    {
      limit: 10,
    }
  );

  const timeRanges = [
    { id: 'today', label: 'Today', icon: Clock },
    { id: 'week', label: 'This Week', icon: TrendingUp },
    { id: 'month', label: 'This Month', icon: Flame },
  ];

  const categories = [
    { id: 'all', label: 'All Categories' },
    { id: 'entertainment', label: 'Entertainment' },
    { id: 'technology', label: 'Technology' },
    { id: 'sports', label: 'Sports' },
    { id: 'fashion', label: 'Fashion' },
    { id: 'food', label: 'Food' },
    { id: 'travel', label: 'Travel' },
  ];

  const getTrendIcon = (trend) => {
    switch (trend) {
      case 'up':
        return <TrendingUp className="w-4 h-4 text-green-500" />;
      case 'down':
        return <TrendingDown className="w-4 h-4 text-red-500" />;
      default:
        return <Globe className="w-4 h-4 text-gray-500" />;
    }
  };

  const getTrendColor = (trend) => {
    switch (trend) {
      case 'up':
        return 'text-green-600 bg-green-50';
      case 'down':
        return 'text-red-600 bg-red-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  if (loading && !hashtags?.length) {
    return (
      <div className="min-h-screen bg-gray-50 pt-20">
        <div className="max-w-6xl mx-auto px-4">
          <Loader fullScreen={false} text="Loading trending hashtags..." />
        </div>
      </div>
    );
  }

  return (
    <>
      <Seo {...buildStaticPageSeo('trending')} />
      
      <div className="min-h-screen bg-gray-50">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-instagram-purple to-instagram-pink text-white">
          <div className="max-w-6xl mx-auto px-4 py-16">
            <div className="text-center">
              <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Flame className="w-10 h-10" />
              </div>
              <h1 className="text-4xl font-bold mb-4">Trending Now</h1>
              <p className="text-xl opacity-90">
                Discover what's trending across GaonGram
              </p>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-6xl mx-auto px-4 -mt-8">
          {/* Filters */}
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
            {/* Search */}
            <div className="mb-6">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search hashtags..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-instagram-pink focus:border-transparent"
                />
                <Button
                  variant="primary"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2"
                  onClick={refresh}
                >
                  Search
                </Button>
              </div>
            </div>

            <div className="flex flex-col md:flex-row md:items-center justify-between space-y-4 md:space-y-0">
              {/* Time Range */}
              <div className="flex overflow-x-auto space-x-2 no-scrollbar">
                {timeRanges.map((range) => {
                  const Icon = range.icon;
                  const isActive = timeRange === range.id;
                  
                  return (
                    <button
                      key={range.id}
                      onClick={() => {
                        setTimeRange(range.id);
                        refresh();
                      }}
                      className={`flex items-center space-x-2 px-4 py-2 rounded-full whitespace-nowrap ${
                        isActive
                          ? 'bg-instagram-pink text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="text-sm font-medium">{range.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Categories */}
              <div className="flex items-center space-x-2">
                <Filter className="w-4 h-4 text-gray-400" />
                <select
                  value={category}
                  onChange={(e) => {
                    setCategory(e.target.value);
                    refresh();
                  }}
                  className="border-none bg-transparent text-sm font-medium text-gray-700 focus:outline-none focus:ring-0"
                >
                  {categories.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Hashtags Grid */}
          {hashtags?.length === 0 ? (
            <EmptyState
              icon="trending-up"
              title="No trending hashtags"
              description={
                searchQuery
                  ? `No hashtags found for "${searchQuery}". Try a different search.`
                  : "No trending hashtags at the moment."
              }
              action={
                searchQuery && (
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSearchQuery('');
                      refresh();
                    }}
                  >
                    Clear Search
                  </Button>
                )
              }
            />
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {hashtags?.map((hashtag, index) => (
                  <motion.div
                    key={hashtag.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="bg-white rounded-2xl shadow-sm overflow-hidden hover:shadow-lg transition-shadow"
                  >
                    {/* Hashtag Header */}
                    <div className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-12 h-12 bg-gradient-to-r from-instagram-purple to-instagram-pink rounded-xl flex items-center justify-center">
                            <Hash className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h3 className="font-bold text-gray-900 text-lg">
                              {hashtag.display_name}
                            </h3>
                            <div className={`inline-flex items-center space-x-1 px-2 py-1 rounded-full text-xs ${getTrendColor(hashtag.trend)}`}>
                              {getTrendIcon(hashtag.trend)}
                              <span>{hashtag.growth > 0 ? '+' : ''}{hashtag.growth}%</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Stats */}
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div className="bg-gray-50 p-3 rounded-lg">
                          <div className="text-2xl font-bold text-gray-900">
                            {formatNumber(hashtag.posts_count)}
                          </div>
                          <div className="text-sm text-gray-500">Posts</div>
                        </div>
                        <div className="bg-gray-50 p-3 rounded-lg">
                          <div className="text-2xl font-bold text-gray-900">
                            {formatNumber(hashtag.top_post.likes_count)}
                          </div>
                          <div className="text-sm text-gray-500">Top Likes</div>
                        </div>
                      </div>

                      {/* Category */}
                      <div className="inline-block px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                        {hashtag.category}
                      </div>
                    </div>

                    {/* Top Post Preview */}
                    <div className="relative group">
                      <img
                        src={hashtag.top_post.media_url}
                        alt={`Top post for ${hashtag.display_name}`}
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                        <div className="text-white">
                          <div className="flex items-center space-x-4 text-sm">
                            <span>❤️ {formatNumber(hashtag.top_post.likes_count)}</span>
                            <span>💬 {formatNumber(hashtag.top_post.comments_count)}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="p-4 border-t">
                      <div className="flex items-center justify-between">
                        <button className="text-instagram-pink hover:text-pink-600 font-medium">
                          View Posts
                        </button>
                        <button className="flex items-center space-x-1 text-gray-600 hover:text-gray-900">
                          <ArrowUpRight className="w-4 h-4" />
                          <span className="text-sm">Follow</span>
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Load More */}
              {hasMore && (
                <div ref={ref} className="py-10">
                  <div className="flex justify-center">
                    <Button
                      variant="outline"
                      onClick={loadMore}
                      loading={loading}
                    >
                      Load More Hashtags
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default TrendingHashtags;
