import { constrainToBounds } from "../constraints/boundary.js";
import { constrainObjectSize } from "../constraints/minSize.js";
import { snapObject } from "../constraints/snapping.js";
import { transformFromObject, readTextStyle } from "./TransformUtils.js";

export class EventManager {
  constructor(engine) {
    this.engine = engine;
    this.gestureState = null;
    this.handleSelection = this.handleSelection.bind(this);
    this.handleSelectionCleared = this.handleSelectionCleared.bind(this);
    this.handleObjectMoving = this.handleObjectMoving.bind(this);
    this.handleObjectScaling = this.handleObjectScaling.bind(this);
    this.handleObjectModified = this.handleObjectModified.bind(this);
    this.handleTextChanged = this.handleTextChanged.bind(this);
    this.touchStart = this.touchStart.bind(this);
    this.touchMove = this.touchMove.bind(this);
    this.touchEnd = this.touchEnd.bind(this);
    this.handleWindowResize = this.handleWindowResize.bind(this);
  }

  bind() {
    const { canvas } = this.engine;
    if (!canvas) return;
    canvas.on("selection:created", this.handleSelection);
    canvas.on("selection:updated", this.handleSelection);
    canvas.on("selection:cleared", this.handleSelectionCleared);
    canvas.on("object:moving", this.handleObjectMoving);
    canvas.on("object:scaling", this.handleObjectScaling);
    canvas.on("object:rotating", this.handleObjectScaling);
    canvas.on("object:modified", this.handleObjectModified);
    canvas.on("text:changed", this.handleTextChanged);

    canvas.upperCanvasEl.addEventListener("touchstart", this.touchStart, { passive: false });
    canvas.upperCanvasEl.addEventListener("touchmove", this.touchMove, { passive: false });
    canvas.upperCanvasEl.addEventListener("touchend", this.touchEnd, { passive: true });
    window.addEventListener("resize", this.handleWindowResize);
  }

  unbind() {
    const { canvas } = this.engine;
    if (!canvas) return;
    canvas.off("selection:created", this.handleSelection);
    canvas.off("selection:updated", this.handleSelection);
    canvas.off("selection:cleared", this.handleSelectionCleared);
    canvas.off("object:moving", this.handleObjectMoving);
    canvas.off("object:scaling", this.handleObjectScaling);
    canvas.off("object:rotating", this.handleObjectScaling);
    canvas.off("object:modified", this.handleObjectModified);
    canvas.off("text:changed", this.handleTextChanged);

    canvas.upperCanvasEl.removeEventListener("touchstart", this.touchStart);
    canvas.upperCanvasEl.removeEventListener("touchmove", this.touchMove);
    canvas.upperCanvasEl.removeEventListener("touchend", this.touchEnd);
    window.removeEventListener("resize", this.handleWindowResize);
  }

  handleSelection(event) {
    const object = event.selected?.[0] || event.target;
    const layer = this.engine.store.getState().layers.find((item) => item.id === object?.layerId);
    if (!layer || layer.locked || layer.visible === false) {
      this.engine.store.getState().setActiveLayerId(null);
      return;
    }
    this.engine.store.getState().setActiveLayerId(object.layerId);
  }

  handleSelectionCleared() {
    this.engine.store.getState().setActiveLayerId(null);
  }

  handleObjectMoving(event) {
    const target = event?.target || event;
    if (!target || !this.engine.canvas || !target.layerId) return;

    const { canvas, store } = this.engine;
    snapObject(target, canvas.getWidth(), canvas.getHeight());
    constrainObjectSize(target);
    constrainToBounds(target, canvas.getWidth(), canvas.getHeight());

    store.getState().updateLayer(
      target.layerId,
      transformFromObject(target),
      { recordHistory: false }
    );
    this.engine.requestRender({ preview: false });
  }

  handleObjectScaling(event) {
    const obj = event.target;
    if (!obj) return;

    obj.set({ originX: "center", originY: "center" });
    constrainObjectSize(obj);
    constrainToBounds(obj, this.engine.canvas.getWidth(), this.engine.canvas.getHeight());
    obj.setCoords();
  }

  handleObjectModified(event, recordHistory = true) {
    const obj = event.target;
    if (!obj || !obj.layerId) return;
    this.engine.store.getState().updateLayer(
      obj.layerId,
      transformFromObject(obj),
      { recordHistory }
    );
    this.engine.requestRender({ preview: true });
  }

  handleTextChanged(event) {
    const target = event?.target || event;
    if (!target || !target.layerId) return;

    const bounds = this.engine.getBaseBounds();
    const maxWidth = bounds
      ? bounds.width * 0.9
      : this.engine.canvas.getWidth() * 0.8;

    target.set({ width: maxWidth });
    target.initDimensions();
    target.setCoords();

    this.engine.store.getState().updateLayer(
      target.layerId,
      {
        text: target.text,
        style: readTextStyle(target),
      },
      { recordHistory: false }
    );
    this.engine.requestRender({ preview: false });
  }

  touchStart(event) {
    if (event.touches.length !== 2 || !this.engine.canvas) return;
    const object = this.engine.canvas.getActiveObject();
    if (!object || !object.selectable) return;
    event.preventDefault();

    const [first, second] = event.touches;
    this.gestureState = {
      object,
      distance: Math.hypot(second.clientX - first.clientX, second.clientY - first.clientY),
      angle: Math.atan2(second.clientY - first.clientY, second.clientX - first.clientX),
      scaleX: object.scaleX || 1,
      scaleY: object.scaleY || 1,
      rotation: object.angle || 0,
    };
  }

  touchMove(event) {
    if (!this.gestureState || event.touches.length !== 2) return;
    event.preventDefault();

    const [first, second] = event.touches;
    const distance = Math.hypot(second.clientX - first.clientX, second.clientY - first.clientY);
    const angle = Math.atan2(second.clientY - first.clientY, second.clientX - first.clientX);
    const scale = Math.max(0.25, Math.min(4, distance / this.gestureState.distance));
    const rotation = this.gestureState.rotation + ((angle - this.gestureState.angle) * 180) / Math.PI;

    this.gestureState.object.set({
      scaleX: this.gestureState.scaleX * scale,
      scaleY: this.gestureState.scaleY * scale,
      angle: rotation,
    });
    this.gestureState.object.setCoords();
    this.engine.requestRender({ preview: false });
    this.engine.store.getState().updateLayer(
      this.gestureState.object.layerId,
      transformFromObject(this.gestureState.object),
      { recordHistory: false }
    );
  }

  touchEnd() {
    if (this.gestureState?.object) {
      this.handleObjectModified({ target: this.gestureState.object }, true);
    }
    this.gestureState = null;
  }

  handleWindowResize() {
    if (!this.engine.canvas) return;
    this.engine.resizeToAspectRatio(this.engine.canvas.storyAspectRatio || "9:16");
  }
}
