const trimTrailingSlash = (value) => String(value || "").replace(/\/+$/, "");

export const API_BASE_URL = trimTrailingSlash(
  import.meta.env.VITE_API_BASE_URL || "/api/v1",
);
export const APP_NAME = 'GaonGram';
export const APP_DESCRIPTION = 'Instagram-like social media platform';

// Development mode check
export const IS_DEVELOPMENT = import.meta.env.DEV;
export const IS_PRODUCTION = import.meta.env.PROD;

// Token keys for localStorage
export const TOKEN_KEYS = {
  ACCESS_TOKEN: 'gaongram_access_token',
  REFRESH_TOKEN: 'gaongram_refresh_token',
  USER_DATA: 'gaongram_user_data',
};
