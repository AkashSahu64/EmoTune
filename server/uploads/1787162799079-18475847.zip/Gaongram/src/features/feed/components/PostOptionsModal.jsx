import React, { useMemo, useRef, useState } from "react";
import {
  Trash2,
  Edit,
  Flag,
  Link as LinkIcon,
  Download,
  UserMinus,
} from "lucide-react";
import { useUIStore } from "../../../store/uiStore.js";
import { useReport } from "../../../hooks/useReport.js";
import { useBlock } from "../../../hooks/useBlock.js";
import { showSuccess, showError } from "../../../utils/toast.js";
import { copyTextToClipboard } from "../../../utils/clipboard.js";
import { downloadUrl, getPostMediaDownloads } from "../../../utils/postMedia.js";
import Button from "../../../components/common/Button.jsx";
import { useTranslation } from "react-i18next";

const PostOptionsModal = ({ postId, authorId, isOwner = false, post }) => {
  const { closeModal, openModal } = useUIStore();
  const { openReport } = useReport();
  const { toggleBlock, isToggling } = useBlock();
  const { t } = useTranslation();
  const [isDownloading, setIsDownloading] = useState(false);
  const downloadAbortRef = useRef(null);

  const resolvedAuthorId = authorId || post?.user?.id || post?.author;
  const postUrl = `${window.location.origin}/post/${postId}`;
  const downloads = useMemo(
    () => getPostMediaDownloads(post, postId),
    [post, postId],
  );

  const handleCopyLink = async () => {
    const copied = await copyTextToClipboard(postUrl);

    if (copied) {
      showSuccess(t("link_copied") || "Link copied");
      closeModal();
      return;
    }

    showError(t("copy_failed") || "Failed to copy link");
  };

  const handleReport = () => {
    openReport({
      modelType: "post",
      objectId: postId,
      objectData: { postId, authorId: resolvedAuthorId },
    });
  };

  const handleBlockUser = async () => {
    if (!resolvedAuthorId) {
      showError("User data not found");
      return;
    }

    const confirmed = window.confirm(
      t("confirm_block_user") || "Are you sure you want to block this user?",
    );

    if (!confirmed) {
      return;
    }

    try {
      await toggleBlock(resolvedAuthorId);
      closeModal();
    } catch {
      // useBlock owns the toast and rollback path.
    }
  };

  const handleDelete = () => {
    openModal("delete-confirm", {
      postId,
    });
  };

  const handleEdit = () => {
    if (!post) {
      showError("Post data not found");
      return;
    }

    openModal("edit-post", {
      post,
    });
  };

  const handleDownload = async () => {
    if (!downloads.length) {
      showError("No downloadable media found");
      return;
    }

    downloadAbortRef.current?.abort();
    downloadAbortRef.current = new AbortController();
    setIsDownloading(true);

    try {
      for (const asset of downloads) {
        await downloadUrl({
          ...asset,
          signal: downloadAbortRef.current.signal,
        });
      }

      showSuccess(t("download_started") || "Download started");
      closeModal();
    } catch (error) {
      if (error.name !== "AbortError") {
        showError("Failed to download media");
      }
    } finally {
      setIsDownloading(false);
    }
  };

  const ownerOptions = [
    {
      icon: Edit,
      label: t("edit_post"),
      onClick: handleEdit,
      color: "text-blue-600 dark:text-blue-400",
    },
    {
      icon: LinkIcon,
      label: t("copy_link"),
      onClick: handleCopyLink,
      color: "text-gray-700 dark:text-gray-400",
    },
    {
      icon: Download,
      label: isDownloading ? "Downloading..." : t("download"),
      onClick: handleDownload,
      color: "text-gray-700 dark:text-gray-400",
      disabled: isDownloading,
    },
    {
      icon: Trash2,
      label: t("delete_post"),
      onClick: handleDelete,
      color: "text-red-600 dark:text-red-400",
      destructive: true,
    },
  ];

  const viewerOptions = [
    {
      icon: Flag,
      label: t("report"),
      onClick: handleReport,
      color: "text-red-600 dark:text-red-400",
      destructive: true,
    },
    {
      icon: UserMinus,
      label: isToggling ? "Updating..." : t("block_user"),
      onClick: handleBlockUser,
      color: "text-red-600 dark:text-red-400",
      destructive: true,
      disabled: isToggling,
    },
    {
      icon: LinkIcon,
      label: t("copy_link"),
      onClick: handleCopyLink,
      color: "text-gray-700 dark:text-gray-400",
    },
    {
      icon: Download,
      label: isDownloading ? "Downloading..." : t("download"),
      onClick: handleDownload,
      color: "text-gray-700 dark:text-gray-400",
      disabled: isDownloading,
    },
  ];

  const options = isOwner ? ownerOptions : viewerOptions;

  return (
    <div className="p-4 max-w-xs mx-auto bg-white dark:bg-card-dark rounded-lg">
      <div className="space-y-0.5">
        {options.map((option) => (
          <button
            key={option.label}
            onClick={option.onClick}
            disabled={option.disabled}
            className={`
              w-full flex items-center space-x-3 p-3
              rounded-lg transition-colors duration-200
              hover:bg-gray-50 dark:hover:bg-muted-dark active:bg-gray-100 dark:active:bg-muted-dark
              disabled:opacity-50 disabled:cursor-not-allowed
              ${
                option.destructive
                  ? "hover:bg-red-50 dark:hover:bg-red-950/30 active:bg-red-100 dark:active:bg-red-950/50"
                  : ""
              }
            `}
          >
            <option.icon className={`w-5 h-5 ${option.color}`} />
            <span
              className={`font-medium ${
                option.destructive
                  ? "text-red-600 dark:text-red-400"
                  : "text-foreground dark:text-foreground-dark"
              }`}
            >
              {option.label}
            </span>
          </button>
        ))}
      </div>

      <div className="mt-4 pt-3 border-t border-border dark:border-border-dark">
        <Button
          variant="ghost"
          fullWidth
          onClick={closeModal}
          disabled={isDownloading || isToggling}
          className="text-mutedForeground dark:text-mutedForeground-dark hover:text-foreground dark:hover:text-foreground-dark hover:bg-gray-50 dark:hover:bg-muted-dark"
        >
          {t("cancel")}
        </Button>
      </div>
    </div>
  );
};

export default PostOptionsModal;
