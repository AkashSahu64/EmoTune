// pages/audio/components/AudioControls.jsx
import React from "react";
import {
  Play,
  Music,
  Pause,
  RotateCcw,
  RotateCw,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { RiSkipLeftFill, RiSkipRightFill } from "react-icons/ri";
import { FaPlay, FaPause } from "react-icons/fa6";

const AudioControls = React.memo(
  ({
    isActuallyPlaying,
    audioError,
    hasError,
    isLoading,
    isFirst,
    isLast,
    onTap,
    onSkipBackward,
    onSkipForward,
    onPreviousCard,
    onNextCard,
  }) => {
    return (
      <div className="flex items-center justify-between mb-6">
        {/* Previous Card Button */}
        <button
          onClick={onPreviousCard}
          disabled={isFirst || audioError || hasError}
          className="p-2 text-white hover:bg-white/10 rounded-full transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
          aria-label="Previous audio"
        >
          <RiSkipLeftFill className="w-8 h-8" />
        </button>

        {/* Skip 5s Backward */}
        <button
          onClick={onSkipBackward}
          disabled={audioError || hasError}
          className="relative p-2 text-white hover:bg-white/10 rounded-full transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
          aria-label="Skip back 5 seconds"
        >
          <RotateCcw className="w-7 h-7" />

          {/* Number Overlay */}
          <span className="absolute inset-0 flex items-center justify-center text-[10px] font-bold">
            5
          </span>
        </button>

        {/* Play/Pause Button */}
        <button
          onClick={onTap}
          disabled={audioError || hasError || isLoading}
          className={`w-14 h-14 rounded-full flex items-center justify-center shadow-xl transition-all ${audioError || hasError ? "bg-gray-500 cursor-not-allowed" : "bg-white hover:bg-gray-100 hover:shadow-2xl"}`}
          aria-label={isActuallyPlaying ? "Pause" : "Play"}
        >
          {audioError || hasError ? (
            <Music className="w-7 h-7 text-gray-700" />
          ) : isActuallyPlaying ? (
            <FaPause className="w-6 h-6 text-black" />
          ) : (
            <FaPlay className="w-6 h-6 text-black ml-1" />
          )}
        </button>

        {/* Skip 5s Forward */}
        <button
          onClick={onSkipForward}
          disabled={audioError || hasError}
          className="relative p-2 text-white hover:bg-white/10 rounded-full transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
          aria-label="Skip forward 5 seconds"
        >
          <RotateCw className="w-7 h-7" />

          {/* Number Overlay */}
          <span className="absolute inset-0 flex items-center justify-center text-[10px] font-bold">
            5
          </span>
        </button>

        {/* Next Card Button */}
        <button
          onClick={onNextCard}
          disabled={isLast || audioError || hasError}
          className="p-2 text-white hover:bg-white/10 rounded-full transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
          aria-label="Next audio"
        >
          <RiSkipRightFill className="w-8 h-8" />
        </button>
      </div>
    );
  },
);

AudioControls.displayName = "AudioControls";

export default AudioControls;
