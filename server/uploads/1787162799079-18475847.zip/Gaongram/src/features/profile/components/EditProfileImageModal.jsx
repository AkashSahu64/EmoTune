// components/EditProfileImageModal.jsx - REFACTORED WITH SHARED ARCHITECTURE
import React from 'react';
import BaseImageEditor from '../components/image-editor/BaseImageEditor';
import ImageSourceSelector from '../components/image-editor/ImageSourceSelector';
import CameraView from '../components/image-editor/CameraView';
import CropperView from '../components/image-editor/CropperView';
import FiltersPanel from '../components/image-editor/FiltersPanel';
import EditorFooter from '../components/image-editor/EditorFooter';
import EditorHeader from '../components/image-editor/EditorHeader';

// Profile-specific configuration
const PROFILE_CONFIG = {
  type: "profile",
  defaultAspect: 1,
  cropShape: "round",
  outputKey: "photo",
  maxWidth: 1024,
  maxHeight: 1024,
  aspectRatios: [
    { label: 'Square (1:1)', value: 1/1 },
    { label: 'Portrait (4:5)', value: 4/5 },
    { label: 'Classic (3:4)', value: 3/4 },
    { label: 'Free', value: null },
  ]
};

const EditProfileImageModal = ({ 
  isOpen, 
  onClose, 
  profile, 
  onUpdate, 
  isUpdating 
}) => {
  return (
    <BaseImageEditor
      isOpen={isOpen}
      onClose={onClose}
      profile={profile}
      onUpdate={onUpdate}
      isUpdating={isUpdating}
      config={PROFILE_CONFIG}
      
      // UI Components
      renderHeader={({ mode, onClose, config }) => (
        <EditorHeader mode={mode} onClose={onClose} config={config} />
      )}
      
      renderSourceSelector={({ imagePreview, fileInputRef, onFileSelect, onCameraSelect, config }) => (
        <ImageSourceSelector
          imagePreview={imagePreview}
          fileInputRef={fileInputRef}
          onFileSelect={onFileSelect}
          onCameraSelect={onCameraSelect}
          config={config}
        />
      )}
      
      renderCameraView={({ showCamera, webcamRef, onCapture, onToggleCamera, onBack, config }) => (
        <CameraView
          showCamera={showCamera}
          webcamRef={webcamRef}
          onCapture={onCapture}
          onToggleCamera={onToggleCamera}
          onBack={onBack}
          config={config}
        />
      )}
      
      renderCropperView={({ 
        selectedImage, 
        crop, 
        zoom, 
        rotation, 
        aspect, 
        onCropChange, 
        onZoomChange, 
        onRotationChange, 
        onAspectChange, 
        onCropComplete,
        onNext,
        onReset,
        config 
      }) => (
        <CropperView
          selectedImage={selectedImage}
          crop={crop}
          zoom={zoom}
          rotation={rotation}
          aspect={aspect}
          onCropChange={onCropChange}
          onZoomChange={onZoomChange}
          onRotationChange={onRotationChange}
          onAspectChange={onAspectChange}
          onCropComplete={onCropComplete}
          onNext={onNext}
          onReset={onReset}
          config={config}
        />
      )}
      
      renderFiltersPanel={({ imagePreview, filters, onFilterChange, onBack, onResetFilters, config }) => (
        <FiltersPanel
          imagePreview={imagePreview}
          filters={filters}
          onFilterChange={onFilterChange}
          onBack={onBack}
          onResetFilters={onResetFilters}
          config={config}
        />
      )}
      
      renderFooter={({ onCancel, onSubmit, isUpdating, isDisabled, config }) => (
        <EditorFooter
          onCancel={onCancel}
          onSubmit={onSubmit}
          isUpdating={isUpdating}
          isDisabled={isDisabled}
          config={config}
        />
      )}
    />
  );
};

export default EditProfileImageModal;