const getArtistName = (artist) => {
  if (!artist) return "";
  if (typeof artist === "string") return artist;
  return artist.displayName || artist.full_name || artist.username || artist.name || "";
};

export const getMusicMetadata = (source) => {
  const audio = source?.audio || source?.music || source?.track || source;
  if (!audio || typeof audio !== "object") return null;

  const title =
    audio.title ||
    audio.audio_title ||
    audio.music_title ||
    audio.name ||
    source?.audio_title ||
    source?.music_title ||
    "";
  const artist =
    getArtistName(audio.artist) ||
    audio.audio_artist ||
    audio.music_artist ||
    audio.artist_name ||
    source?.audio_artist ||
    source?.music_artist ||
    "";
  const coverImage =
    audio.cover_image ||
    audio.coverImage ||
    audio.audio_cover_image ||
    audio.music_cover_image ||
    audio.thumbnail ||
    source?.cover_image ||
    "";

  if (!title && !artist) return null;
  return {
    title: title || "Original audio",
    artist,
    coverImage,
  };
};
