import React from "react";
import { motion as Motion } from "framer-motion";
import {
  Image,
  Layers,
  Music,
  Palette,
  Square,
  Type,
} from "lucide-react";
import { LuSticker } from "react-icons/lu";

const TOOLS = [
  { id: "text", label: "Text", icon: Type },
  { id: "media", label: "Media", icon: Image },
  { id: "emoji", label: "Stickers", icon: LuSticker },
  { id: "filters", label: "Filters", icon: Palette },
  { id: "frame", label: "Frame", icon: Square },
  { id: "music", label: "Music", icon: Music },
  { id: "layers", label: "Layers", icon: Layers },
];

const EditorToolbar = ({ activeTool, onToolChange }) => {
  return (
    <nav className="flex items-center gap-2 overflow-x-auto rounded-xl border border-border dark:border-border-dark bg-white/80 dark:bg-gray-900/80 p-2 md:flex-col md:gap-3 md:py-3 md:px-0">
      {TOOLS.map(({ id, label, icon }) => {
        const isActive = activeTool === id;

        return (
          <button
            key={id}
            type="button"
            onClick={() => onToolChange(id)}
            className="relative flex flex-col items-center justify-center gap-1 rounded-xl px-4 py-2"
          >
            {/* ✅ Smooth moving active background */}
            {isActive && (
              <Motion.div
                layoutId="active-pill"
                transition={{
                  type: "spring",
                  stiffness: 380,
                  damping: 28,
                }}
                className="absolute inset-0 rounded-lg bg-primary shadow-md"
              />
            )}

            {/* ✅ Content */}
            <Motion.div
              className={`relative z-10 flex flex-col items-center gap-1.5 ${
                isActive
                  ? "text-white"
                  : "text-mutedForeground dark:text-mutedForeground-dark"
              }`}
            >
              {React.createElement(icon, { size: 20, strokeWidth: 2.2 })}

              <span className="text-xs font-medium leading-none">
                {label}
              </span>
            </Motion.div>
          </button>
        );
      })}
    </nav>
  );
};

export default React.memo(EditorToolbar);
