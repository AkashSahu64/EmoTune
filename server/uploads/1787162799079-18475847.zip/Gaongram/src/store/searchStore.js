import { create } from 'zustand';

const useSearchStore = create((set) => ({
  allFetchedPosts: [],

  /**
   * Merge new posts into the existing list.
   * Duplicates are removed by post.id (latest post wins).
   */
  addPosts: (newPosts) => {
    set((state) => {
      const mergedMap = new Map(
        state.allFetchedPosts.map((p) => [p.id, p])
      );
      newPosts.forEach((p) => {
        if (p?.id) mergedMap.set(p.id, p);
      });
      return { allFetchedPosts: Array.from(mergedMap.values()) };
    });
  },
}));

export default useSearchStore;