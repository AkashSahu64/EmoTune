import { useState, useCallback } from 'react';
import { useUIStore } from '../store/uiStore.js';
import { reportService } from '../services/report.service.js';
import { showSuccess, showError } from '../utils/toast.js';

/**
 * Global hook for reporting users, posts, and comments
 * Single source of truth for all reporting functionality
 */
export const useReport = () => {
  const { openModal, closeModal } = useUIStore();
  const [isReporting, setIsReporting] = useState(false);
  const [reportReasons, setReportReasons] = useState([]);

  /**
   * Fetch report reasons (cached for performance)
   */
  const fetchReportReasons = useCallback(async () => {
    if (reportReasons.length > 0) return reportReasons;
    
    try {
      const reasons = await reportService.getReportReasons();
      setReportReasons(reasons);
      return reasons;
    } catch (error) {
      console.error('Failed to fetch report reasons:', error);
      // Return default reasons as fallback
      const defaultReasons = [
        { key: 'spam', label: 'Spam or misleading' },
        { key: 'nudity', label: 'Nudity or sexual content' },
        { key: 'violence', label: 'Violence' },
        { key: 'hate', label: 'Hate speech' },
        { key: 'harassment', label: 'Harassment or bullying' },
        { key: 'false_info', label: 'False information' },
        { key: 'illegal', label: 'Illegal activities' },
        { key: 'other', label: 'Other' }
      ];
      return defaultReasons;
    }
  }, [reportReasons]);

  /**
   * Open report modal with proper model type
   */
  const openReport = useCallback(async ({ modelType, objectId, objectData = null }) => {
    // Validate model type
    const validTypes = ['user', 'post', 'comment'];
    if (!validTypes.includes(modelType)) {
      console.error(`Invalid model type: ${modelType}. Must be one of: ${validTypes.join(', ')}`);
      return;
    }

    if (!objectId) {
      console.error('Report object ID is required');
      return;
    }

    // Fetch reasons and open modal
    const reasons = await fetchReportReasons();
    
    openModal('report', {
      modelType,
      objectId,
      objectData,
      reasons,
      onSubmit: async (reason, description) => {
        return await submitReport({ modelType, objectId, reason, description });
      }
    });
  }, [fetchReportReasons, openModal]);

  /**
   * Submit report to backend
   */
  const submitReport = useCallback(async ({ modelType, objectId, reason, description = null }) => {
    setIsReporting(true);
    
    try {
      await reportService.submitReport({
        modelType,
        objectId,
        reason,
        description
      });
      
      showSuccess('Report submitted successfully. We will review it shortly.');
    //   closeModal();
      return { success: true };
    } catch (error) {
      console.error('Failed to submit report:', error);
      showError('Failed to submit report. Please try again.');
      return { success: false, error };
    } finally {
      setIsReporting(false);
    }
  }, [closeModal]);

  /**
   * Quick report without modal (for simple cases)
   */
  const quickReport = useCallback(async (modelType, objectId, reason) => {
    return submitReport({ modelType, objectId, reason });
  }, [submitReport]);

  return {
    openReport,
    submitReport,
    quickReport,
    isReporting,
    reportReasons,
    fetchReportReasons
  };
};