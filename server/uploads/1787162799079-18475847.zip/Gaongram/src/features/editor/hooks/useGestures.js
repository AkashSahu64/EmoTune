import { useMemo } from "react";
import { GestureManager } from "../core/GestureManager.js";

export const useGestures = (handlers) => useMemo(() => new GestureManager(handlers), [handlers]);

export default useGestures;
