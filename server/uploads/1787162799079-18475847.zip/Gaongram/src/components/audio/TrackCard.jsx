import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Play, 
  Pause, 
  Heart, 
  MoreVertical, 
  Music, 
  User, 
  Clock, 
  BarChart,
  Share2,
  Plus,
  Download,
  Volume2
} from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  likeTrack, 
  unlikeTrack, 
  addToQueue,
  downloadTrack,
  addToPlaylist
} from '../../features/tracks/api';
import { useAuth } from '../../hooks/useAuth';
import { useNotifications } from '../../hooks/useNotifications';
import { useAudioPlayer } from '../../hooks/useAudioPlayer';
import { formatDistanceToNow } from 'date-fns';

export const TrackCard = ({ track, variant = 'default', showStats = true }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLiked, setIsLiked] = useState(track.isLiked || false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [likeCount, setLikeCount] = useState(track._count?.likes || track.likeCount || 0);
  const [playCount, setPlayCount] = useState(track.playCount || 0);
  
  const { user } = useAuth();
  const { showNotification } = useNotifications();
  const { playTrack, pauseTrack, currentTrack, addTrackToQueue } = useAudioPlayer();
  const queryClient = useQueryClient();
  
  const isOwner = user?.id === track.artist?.id || user?.id === track.user?.id;
  
  // Like mutation
  const likeMutation = useMutation({
    mutationFn: () => likeTrack(track.id),
    onSuccess: () => {
      setIsLiked(true);
      setLikeCount(prev => prev + 1);
      queryClient.invalidateQueries(['tracks']);
    },
    onError: (error) => {
      showNotification(error.response?.data?.message || 'Failed to like track', 'error');
    }
  });
  
  const unlikeMutation = useMutation({
    mutationFn: () => unlikeTrack(track.id),
    onSuccess: () => {
      setIsLiked(false);
      setLikeCount(prev => Math.max(0, prev - 1));
      queryClient.invalidateQueries(['tracks']);
    },
    onError: (error) => {
      showNotification(error.response?.data?.message || 'Failed to unlike track', 'error');
    }
  });
  
  // Add to queue mutation
  const addToQueueMutation = useMutation({
    mutationFn: () => addToQueue(track.id),
    onSuccess: () => {
      showNotification('Added to queue', 'success');
      addTrackToQueue(track);
    },
    onError: (error) => {
      showNotification(error.response?.data?.message || 'Failed to add to queue', 'error');
    }
  });
  
  // Download mutation
  const downloadMutation = useMutation({
    mutationFn: () => downloadTrack(track.id),
    onSuccess: (url) => {
      // Trigger download
      const link = document.createElement('a');
      link.href = url;
      link.download = `${track.title}.mp3`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      showNotification('Download started', 'success');
    },
    onError: (error) => {
      showNotification(error.response?.data?.message || 'Failed to download track', 'error');
    }
  });
  
  const handleLikeToggle = () => {
    if (isLiked) {
      unlikeMutation.mutate();
    } else {
      likeMutation.mutate();
    }
  };
  
  const handlePlayToggle = () => {
    if (currentTrack?.id === track.id && isPlaying) {
      pauseTrack();
      setIsPlaying(false);
    } else {
      playTrack(track);
      setIsPlaying(true);
      setPlayCount(prev => prev + 1);
    }
  };
  
  const handleAddToQueue = () => {
    addToQueueMutation.mutate();
  };
  
  const handleDownload = () => {
    if (track.isDownloadable) {
      downloadMutation.mutate();
    } else {
      showNotification('This track is not available for download', 'info');
    }
  };
  
  const formatDuration = (seconds) => {
    if (!seconds) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };
  
  const formatDate = (dateString) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true });
    } catch {
      return 'Some time ago';
    }
  };
  
  if (variant === 'compact') {
    return (
      <div className="group flex items-center gap-3 p-3 hover:bg-gray-50 rounded-xl transition-colors">
        {/* Play Button */}
        <button
          onClick={handlePlayToggle}
          className="flex-shrink-0 w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white hover:shadow-lg transition-shadow"
        >
          {isPlaying && currentTrack?.id === track.id ? (
            <Pause size={16} fill="white" />
          ) : (
            <Play size={16} fill="white" />
          )}
        </button>
        
        {/* Track Info */}
        <div className="flex-1 min-w-0">
          <Link to={`/track/${track.id}`}>
            <p className="font-medium text-gray-900 truncate hover:text-blue-600">
              {track.title}
            </p>
          </Link>
          <Link to={`/profile/${track.artist?.username || track.user?.username}`}>
            <p className="text-sm text-gray-600 truncate hover:text-gray-800">
              {track.artist?.displayName || track.artist?.username || track.user?.displayName || track.user?.username}
            </p>
          </Link>
        </div>
        
        {/* Duration */}
        <div className="flex-shrink-0 text-sm text-gray-500">
          {formatDuration(track.duration)}
        </div>
        
        {/* Actions */}
        <div className="flex-shrink-0 flex items-center gap-1">
          <button
            onClick={handleLikeToggle}
            className={`p-1.5 rounded-full ${isLiked ? 'text-red-500' : 'text-gray-400 hover:text-red-500'}`}
          >
            <Heart size={16} className={isLiked ? 'fill-red-500' : ''} />
          </button>
          <button
            onClick={() => setShowMoreMenu(!showMoreMenu)}
            className="p-1.5 text-gray-400 hover:text-gray-600 rounded-full"
          >
            <MoreVertical size={16} />
          </button>
        </div>
        
        {/* More Menu */}
        {showMoreMenu && (
          <div className="absolute right-0 top-12 z-10 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-1">
            <button
              onClick={handleAddToQueue}
              className="flex items-center gap-2 w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50"
            >
              <Plus size={14} />
              Add to Queue
            </button>
            <button
              onClick={() => console.log('Add to playlist')}
              className="flex items-center gap-2 w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50"
            >
              <Plus size={14} />
              Add to Playlist
            </button>
            <button
              onClick={handleDownload}
              className="flex items-center gap-2 w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50"
            >
              <Download size={14} />
              Download
            </button>
            <button
              onClick={() => console.log('Share')}
              className="flex items-center gap-2 w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50"
            >
              <Share2 size={14} />
              Share
            </button>
          </div>
        )}
      </div>
    );
  }
  
  if (variant === 'grid') {
    return (
      <div className="group bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
        {/* Thumbnail with Play Button */}
        <div className="relative aspect-square overflow-hidden bg-gradient-to-br from-purple-100 to-blue-100">
          {track.coverArt ? (
            <img
              src={track.coverArt}
              alt={track.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <div className="flex items-center justify-center w-full h-full">
              <Music size={48} className="text-purple-300" />
            </div>
          )}
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors" />
          <button
            onClick={handlePlayToggle}
            className="absolute bottom-4 right-4 p-3 bg-green-500 rounded-full text-white opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 transition-all hover:scale-105 hover:bg-green-600"
          >
            {isPlaying && currentTrack?.id === track.id ? (
              <Pause size={20} fill="white" />
            ) : (
              <Play size={20} fill="white" />
            )}
          </button>
        </div>
        
        {/* Content */}
        <div className="p-4">
          <Link to={`/track/${track.id}`}>
            <h3 className="font-semibold text-gray-900 truncate hover:text-blue-600 mb-1">
              {track.title}
            </h3>
          </Link>
          
          <Link to={`/profile/${track.artist?.username || track.user?.username}`}>
            <p className="text-sm text-gray-600 truncate hover:text-gray-800 mb-3">
              {track.artist?.displayName || track.artist?.username || track.user?.displayName || track.user?.username}
            </p>
          </Link>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4 text-sm text-gray-500">
              <div className="flex items-center gap-1">
                <Clock size={12} />
                <span>{formatDuration(track.duration)}</span>
              </div>
              <div className="flex items-center gap-1">
                <Heart size={12} />
                <span>{likeCount}</span>
              </div>
            </div>
            
            <button
              onClick={handleLikeToggle}
              className={`p-1.5 rounded-full ${isLiked ? 'text-red-500' : 'text-gray-400 hover:text-red-500'}`}
            >
              <Heart size={16} className={isLiked ? 'fill-red-500' : ''} />
            </button>
          </div>
        </div>
      </div>
    );
  }
  
  // Default variant (list)
  return (
    <div className="group flex items-center gap-4 p-4 bg-white rounded-xl border border-gray-200 hover:border-gray-300 transition-colors">
      {/* Track Number (optional) */}
      {track.trackNumber && (
        <div className="flex-shrink-0 w-8 text-center text-gray-500 font-medium">
          {track.trackNumber}
        </div>
      )}
      
      {/* Play Button */}
      <button
        onClick={handlePlayToggle}
        className="flex-shrink-0 w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white hover:shadow-lg transition-shadow group-hover:scale-105"
      >
        {isPlaying && currentTrack?.id === track.id ? (
          <Pause size={20} fill="white" />
        ) : (
          <Play size={20} fill="white" />
        )}
      </button>
      
      {/* Track Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between">
          <div className="flex-1 min-w-0">
            <Link to={`/track/${track.id}`}>
              <h3 className="font-semibold text-gray-900 truncate hover:text-blue-600">
                {track.title}
              </h3>
            </Link>
            <div className="flex items-center gap-2 mt-1">
              <Link to={`/profile/${track.artist?.username || track.user?.username}`}>
                <p className="text-sm text-gray-600 hover:text-gray-800 truncate">
                  {track.artist?.displayName || track.artist?.username || track.user?.displayName || track.user?.username}
                </p>
              </Link>
              {track.featuredArtists && track.featuredArtists.length > 0 && (
                <>
                  <span className="text-gray-400">•</span>
                  <span className="text-sm text-gray-500">
                    feat. {track.featuredArtists.map(a => a.displayName || a.username).join(', ')}
                  </span>
                </>
              )}
            </div>
          </div>
          
          {/* Duration */}
          <div className="flex-shrink-0 ml-4 text-sm text-gray-500">
            {formatDuration(track.duration)}
          </div>
        </div>
        
        {/* Stats and Metadata */}
        {showStats && (
          <div className="flex items-center gap-4 mt-3 text-xs text-gray-500">
            {track.genre && (
              <span className="px-2 py-1 bg-gray-100 rounded-full">{track.genre}</span>
            )}
            {track.releaseDate && (
              <span>{formatDate(track.releaseDate)}</span>
            )}
            <div className="flex items-center gap-2">
              <Heart size={10} />
              <span>{likeCount}</span>
            </div>
            <div className="flex items-center gap-2">
              <BarChart size={10} />
              <span>{playCount.toLocaleString()} plays</span>
            </div>
          </div>
        )}
      </div>
      
      {/* Actions */}
      <div className="flex-shrink-0 flex items-center gap-2">
        <button
          onClick={handleLikeToggle}
          className={`p-2 rounded-lg ${isLiked ? 'bg-red-50 text-red-600' : 'hover:bg-gray-100 text-gray-600'}`}
        >
          <Heart size={18} className={isLiked ? 'fill-red-500' : ''} />
        </button>
        
        <button
          onClick={handleAddToQueue}
          className="p-2 hover:bg-gray-100 text-gray-600 rounded-lg"
        >
          <Plus size={18} />
        </button>
        
        <button
          onClick={() => setShowMoreMenu(!showMoreMenu)}
          className="p-2 hover:bg-gray-100 text-gray-600 rounded-lg"
        >
          <MoreVertical size={18} />
        </button>
        
        {/* More Menu */}
        {showMoreMenu && (
          <div className="absolute right-4 top-16 z-10 w-56 bg-white rounded-xl shadow-lg border border-gray-200 py-2">
            <div className="px-4 py-2 border-b border-gray-100">
              <p className="font-medium text-gray-900 truncate">{track.title}</p>
              <p className="text-sm text-gray-600 truncate">
                {track.artist?.displayName || track.artist?.username}
              </p>
            </div>
            
            <button
              onClick={handlePlayToggle}
              className="flex items-center gap-2 w-full px-4 py-3 text-left text-gray-700 hover:bg-gray-50"
            >
              {isPlaying && currentTrack?.id === track.id ? (
                <>
                  <Pause size={16} />
                  Pause
                </>
              ) : (
                <>
                  <Play size={16} />
                  Play Now
                </>
              )}
            </button>
            
            <button
              onClick={handleAddToQueue}
              className="flex items-center gap-2 w-full px-4 py-3 text-left text-gray-700 hover:bg-gray-50"
            >
              <Plus size={16} />
              Add to Queue
            </button>
            
            <button
              onClick={() => console.log('Add to playlist')}
              className="flex items-center gap-2 w-full px-4 py-3 text-left text-gray-700 hover:bg-gray-50"
            >
              <Plus size={16} />
              Add to Playlist
            </button>
            
            {track.isDownloadable && (
              <button
                onClick={handleDownload}
                className="flex items-center gap-2 w-full px-4 py-3 text-left text-gray-700 hover:bg-gray-50"
              >
                <Download size={16} />
                Download
              </button>
            )}
            
            <button
              onClick={() => console.log('Share track')}
              className="flex items-center gap-2 w-full px-4 py-3 text-left text-gray-700 hover:bg-gray-50"
            >
              <Share2 size={16} />
              Share
            </button>
            
            {isOwner && (
              <>
                <div className="border-t border-gray-100 my-1" />
                <button
                  onClick={() => console.log('Edit track')}
                  className="flex items-center gap-2 w-full px-4 py-3 text-left text-gray-700 hover:bg-gray-50"
                >
                  Edit Track
                </button>
                <button
                  onClick={() => console.log('View analytics')}
                  className="flex items-center gap-2 w-full px-4 py-3 text-left text-gray-700 hover:bg-gray-50"
                >
                  <BarChart size={16} />
                  View Analytics
                </button>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

// Audio Player Progress Component
export const TrackProgress = ({ currentTime, duration, onChange }) => {
  const progress = (currentTime / duration) * 100 || 0;
  
  return (
    <div className="w-full">
      <div className="relative h-1 bg-gray-200 rounded-full overflow-hidden">
        <div
          className="absolute left-0 top-0 h-full bg-gradient-to-r from-blue-500 to-purple-600 rounded-full"
          style={{ width: `${progress}%` }}
        />
        <input
          type="range"
          min="0"
          max={duration}
          value={currentTime}
          onChange={(e) => onChange(parseFloat(e.target.value))}
          className="absolute inset-0 w-full opacity-0 cursor-pointer"
        />
      </div>
      <div className="flex justify-between text-xs text-gray-500 mt-1">
        <span>{formatTime(currentTime)}</span>
        <span>{formatTime(duration)}</span>
      </div>
    </div>
  );
};

const formatTime = (seconds) => {
  if (!seconds) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
};

// Volume Control Component
export const VolumeControl = ({ volume, onChange }) => {
  return (
    <div className="flex items-center gap-2">
      <Volume2 size={16} className="text-gray-500" />
      <div className="relative w-24 h-1 bg-gray-200 rounded-full">
        <div
          className="absolute left-0 top-0 h-full bg-gray-500 rounded-full"
          style={{ width: `${volume * 100}%` }}
        />
        <input
          type="range"
          min="0"
          max="1"
          step="0.01"
          value={volume}
          onChange={(e) => onChange(parseFloat(e.target.value))}
          className="absolute inset-0 w-full opacity-0 cursor-pointer"
        />
      </div>
    </div>
  );
};