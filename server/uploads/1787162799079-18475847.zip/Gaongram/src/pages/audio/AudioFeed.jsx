import React, { useMemo } from "react";
import AudioCard from "./AudioCard.jsx";
import Loader from "../../components/common/Loader.jsx";

const AudioFeed = React.memo(
  ({
    audioPosts,
    playingStates,
    playbackRates,
    audioErrors,
    user,
    hasMore,
    loadingMore,
    lastAudioCardRef,
    scrollContainerRef,
    onAudioEnded,
    onAudioError,
    onPreviousCard,
    onNextCard,
    onSpeedChange,
    onShare,
    onLike,
    onAudioTap,
    onComments,
    onOptions,
    sleepTimer,
    remainingTime,
    onSetSleepTimer,
    onCancelSleepTimer,
    isPlaylistMode,
  }) => {
    const feedTracks = useMemo(() => {
      return audioPosts.map(post => ({
        id: post.id,
        postId: post.id,
        audioId: post.audio?.id,
        title: post.audio?.title,
        artist: post.user?.username || post.user_name,
        cover: post.audio?.cover_image,
        src: post.audio?.audio,
      }));
    }, [audioPosts]);

    return (
      <div className="relative w-full min-h-screen bg-background dark:bg-black">
        <div ref={scrollContainerRef} className="h-[calc(100vh-4rem)] md:h-screen overflow-y-auto snap-y snap-mandatory scrollbar-hide pb-2">
          {audioPosts.map((audioPost, index) => {
            const isLast = index === audioPosts.length - 1;
            return (
              <AudioCard
                key={`audio-${audioPost.id}-${audioPost.audio?.id || "track"}`}
                audioPost={audioPost}
                isPlaying={playingStates[audioPost.id] || false}
                playbackRate={playbackRates[audioPost.id] || 1}
                audioError={audioErrors[audioPost.id]}
                user={user}
                isFirst={index === 0}
                isLast={isLast}
                onEnded={() => onAudioEnded(audioPost.id)}
                onError={() => onAudioError(audioPost.id)}
                onPreviousCard={() => onPreviousCard(audioPost.id)}
                onNextCard={() => onNextCard(audioPost.id)}
                onSpeedChange={() => onSpeedChange(audioPost.id)}
                onShare={() => onShare(audioPost.id, audioPost.audio?.title)}
                onLike={() => onLike(audioPost.id, audioPost.is_liked)}
                onTap={() => onAudioTap(audioPost.id)}
                onComments={() => onComments(audioPost.id)}
                onOptions={() => onOptions(audioPost.id, audioPost.author === user?.id)}
                sleepTimer={sleepTimer}
                remainingTime={remainingTime}
                onSetSleepTimer={onSetSleepTimer}
                onCancelSleepTimer={onCancelSleepTimer}
                feedTracks={feedTracks}
                currentIndex={index}
                isPlaylistMode={isPlaylistMode}
              />
            );
          })}
          {hasMore && (
            <div ref={lastAudioCardRef} data-last-audio-card="true" className="h-32 flex items-center justify-center">
              {loadingMore ? (
                <Loader />
              ) : (
                <span className="text-mutedForeground dark:text-gray-400 text-sm">Scroll for more...</span>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }
);

AudioFeed.displayName = "AudioFeed";
export default AudioFeed;
