import React, { useState } from "react";
import {
  Heart,
  MoreVertical,
} from "lucide-react";

import { BiMessageRounded } from "react-icons/bi";
import { MdOutlineSpeed } from "react-icons/md";
import { FaShare } from "react-icons/fa6";
import { MdHourglassBottom } from "react-icons/md";
import SleepTimerSheet from "./SleepTimerSheet.jsx";
import { useTranslation } from "react-i18next";

const AudioActions = React.memo(
  ({
    audioPost,
    playbackRate,
    audioError,
    hasError,
    onLike,
    onComments,
    onSpeedChange,
    onShare,
    onOptions,
    formatNumber,
    sleepTimer,
    remainingTime,
    onSetSleepTimer,
    onCancelSleepTimer,
  }) => {
    const [showTimerSheet, setShowTimerSheet] = useState(false);
    const { t } = useTranslation();  

    return (
      <div className="flex items-center justify-between border-t border-gray-700 pt-7">
        
        {/* Sleep Timer */}
        <button
          onClick={() => setShowTimerSheet(true)}
          className="flex flex-col items-center text-gray-400 hover:text-white transition-colors"
          aria-label={t("sleep_timer")}
        >
          <div className="p-2 rounded-full hover:bg-white/10">
            <MdHourglassBottom className="w-7 h-7" />
          </div>

          <span className="text-xs mt-0">
            {sleepTimer
              ? `${Math.floor(remainingTime / 60000)}:${Math.floor(
                  (remainingTime % 60000) / 1000
                )
                  .toString()
                  .padStart(2, "0")}`
              : t("timer")} 
          </span>
        </button>

        {/* Like */}
        <button
          onClick={onLike}
          disabled={audioError || hasError}
          className="flex flex-col items-center text-gray-400 hover:text-white transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
          aria-label={
            audioPost.is_liked ? t("unlike") : t("like") 
          }
        >
          <div className="p-2 rounded-full hover:bg-white/10">
            <Heart
              className={`w-7 h-7 transition-colors duration-200 ${
                audioPost.is_liked
                  ? "text-red-500 fill-red-500"
                  : "text-gray-400"
              }`}
            />
          </div>

          <span className="text-xs mt-0">
            {formatNumber(audioPost.likes_count || 0)}
          </span>
        </button>

        {/* Comments */}
        <button
          onClick={onComments}
          disabled={audioError || hasError}
          className="flex flex-col items-center text-gray-400 hover:text-white transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
          aria-label={t("comments")} 
        >
          <div className="p-2 rounded-full hover:bg-white/10">
            <BiMessageRounded className="w-7 h-7" />
          </div>

          <span className="text-xs mt-0">
            {formatNumber(audioPost.comments_count || 0)}
          </span>
        </button>

        {/* Sleep Timer Sheet */}
        {showTimerSheet && (
          <SleepTimerSheet
            isOpen={showTimerSheet}
            onClose={() => setShowTimerSheet(false)}
            onSet={onSetSleepTimer}
            onCancel={onCancelSleepTimer}
            isActive={!!sleepTimer}
          />
        )}

        {/* Playback Speed */}
        <button
          onClick={onSpeedChange}
          disabled={audioError || hasError}
          className="flex flex-col items-center text-gray-400 hover:text-white transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
          aria-label={t("playback_speed", { rate: playbackRate })} 
        >
          <div className="p-2 rounded-full hover:bg-white/10">
            <MdOutlineSpeed className="w-7 h-7" />
          </div>

          <span className="text-xs mt-0">{playbackRate}x</span>
        </button>

        {/* Share */}
        <button
          onClick={onShare}
          disabled={audioError || hasError}
          className="flex flex-col items-center text-gray-400 hover:text-white transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
          aria-label={t("share")} 
        >
          <div className="p-2 rounded-full hover:bg-white/10">
            <FaShare className="w-6 h-6" />
          </div>

          <span className="text-xs mt-0">{t("share")}</span> 
        </button>

        {/* More Options */}
        <button
          onClick={onOptions}
          className="flex flex-col items-center text-gray-400 hover:text-white transition-colors"
          aria-label={t("more_options")} 
        >
          <div className="p-2 rounded-full hover:bg-white/10">
            <MoreVertical className="w-7 h-7" />
          </div>

          <span className="text-xs mt-0">{t("more")}</span> 
        </button>
      </div>
    );
  }
);

AudioActions.displayName = "AudioActions";

export default AudioActions;
