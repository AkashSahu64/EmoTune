import React from "react";
import { useNavigate } from "react-router-dom";
import { X } from "lucide-react";
import { motion } from "framer-motion";

import { useUIStore } from "../../../store/uiStore.js";
import { useFollow } from "../../../hooks/useFollow.js";

import Avatar from "../../../components/common/Avatar.jsx";
import Button from "../../../components/common/Button.jsx";
import { useTranslation } from "react-i18next"; // ✅ added
import { useQuery } from "@tanstack/react-query";
import { profileService } from "../../../services/profile.service.js";

// ✅ Individual Row (FIXED + i18n)
const SuggestedUserRow = ({ user, onClose }) => {
  const navigate = useNavigate();
  const { t } = useTranslation(); // ✅ added

  const { toggleFollow, isFollowing, isFollowingRequested, isLoading } =
    useFollow(user.user_id || user.id, user.is_private);

  const goProfile = () => navigate(`/profile/${user.username || user.user_id || user.id}`);

  const followClick = (e) => {
    e.stopPropagation();
    toggleFollow();
  };

  // ✅ FIX: use translation keys instead of hardcoded text
  let labelKey = "follow";
  let variant = "primary";
  let disabled = isLoading;

  if (isFollowingRequested) {
    labelKey = "requested";
    variant = "outline";
    disabled = true;
  } else if (isFollowing) {
    labelKey = "following";
    variant = "outline";
  }

  return (
    <div
      onClick={goProfile}
      className="flex items-center gap-3 px-3 py-1 rounded-lg cursor-pointer hover:bg-muted dark:hover:bg-muted-dark transition"
    >
      {/* Avatar */}
      <div className="flex-shrink-0">
        <Avatar src={user.avatar} alt={user.username} size="medium" />
      </div>

      {/* Text */}
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium truncate" title={user.username}>
          {user.username}
        </p>
        <p className="text-xs text-mutedForeground truncate">
          {user.full_name || user.name}
        </p>
      </div>

      {/* Button */}
      <div className="flex-shrink-0">
        <Button
          size="small"
          variant={variant}
          onClick={followClick}
          disabled={disabled}
          className="w-[80px] justify-center"
        >
          {t(labelKey)} {/* ✅ translated */}
        </Button>
      </div>
    </div>
  );
};

// ✅ MAIN MODAL (FIXED)
const SuggestedUsersModal = () => {
  const { modal, closeModal } = useUIStore();
  const { t } = useTranslation(); // ✅ added

  const normalizeToArray = (res) => {
    if (Array.isArray(res)) return res;
    if (Array.isArray(res?.users)) return res.users;
    if (Array.isArray(res?.data)) return res.data;
    if (Array.isArray(res?.data?.results)) return res.data.results;
    if (Array.isArray(res?.results)) return res.results;
    return [];
  };

  const { data: allSuggestedUsers = [] } = useQuery({
    queryKey: ["all-suggested-users-modal"],
    queryFn: async () => {
      let page = 1;
      let allUsers = [];
      let next = true;

      while (next) {
        const res = await profileService.getProfiles({
          page,
          page_size: 100,
        });

        const batch = normalizeToArray(res);

        allUsers = [...allUsers, ...batch];

        if (!res?.next) {
          next = false;
        } else {
          page += 1;
        }
      }

      return allUsers;
    },
    enabled: modal?.type === "suggested-users-modal",
  });

  const users = allSuggestedUsers;

  if (!modal || modal.type !== "suggested-users-modal") return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-6">
        {/* 🔥 Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm"
          onClick={closeModal}
        />

        {/* 🔥 Modal */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-md bg-white dark:bg-card-dark rounded-xl shadow-xl overflow-hidden"
        >
          {/* HEADER */}
          <div className="px-5 py-3 border-b border-border dark:border-border-dark bg-gradient-to-r from-gaon-cream to-white dark:from-gray-800 dark:to-card-dark">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">
                {t("suggested_users")} {/* ✅ translated */}
              </h2>

              <button
                onClick={closeModal}
                className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-muted-dark transition"
              >
                <X size={20} />
              </button>
            </div>
          </div>

          {/* BODY */}
          <div className="max-h-[65vh] overflow-y-auto p-3 space-y-1 hide-scrollbar">
            {allSuggestedUsers.length === 0 ? (
              <div className="py-10 flex justify-center">
                <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              </div>
            ) : (
              users.map((user) => (
                <SuggestedUserRow
                  key={user.id}
                  user={user}
                  onClose={closeModal}
                />
              ))
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default SuggestedUsersModal;
