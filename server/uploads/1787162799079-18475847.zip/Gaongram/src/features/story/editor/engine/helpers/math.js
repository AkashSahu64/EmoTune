export const clamp = (value, min, max) => Math.min(Math.max(value, min), max);

export const getSliderBackground = (value, min, max, isDark) => {
  const percent = ((value - min) / (max - min)) * 100;

  const filled = isDark ? "#4ade80" : "#118239"; // green
  const empty = isDark ? "#374151" : "#d1d5db"; // gray

  return `linear-gradient(
    to right,
    ${filled} 0%,
    ${filled} ${percent}%,
    ${empty} ${percent}%,
    ${empty} 100%
  )`;
};