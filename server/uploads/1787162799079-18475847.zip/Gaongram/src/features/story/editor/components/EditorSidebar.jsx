// EditorSidebar.jsx
import React from "react";
import { motion as Motion } from "framer-motion";
import TextTool from "../tools/TextTool.jsx";
import MediaTool from "../tools/MediaTool.jsx";
import EmojiTool from "../tools/EmojiTool.jsx";
import FilterTool from "../tools/FilterTool.jsx";
import MusicTool from "../tools/MusicTool.jsx";
import FrameTool from "../tools/FrameTool.jsx";
import LayerControls from "./LayerControls.jsx";
import { CropPanel, PaintPanel } from "../../../editor/shared/SharedPanels.jsx";

const TOOL_TITLES = {
  text: "Text",
  media: "Media",
  emoji: "Stickers",
  filters: "Filters",
  crop: "Crop",
  paint: "Paint",
  frame: "Frame",
  music: "Music",
  layers: "Layers",
};

const EditorSidebar = ({ activeTool, engine }) => {
  const canDragSheet =
    typeof window !== "undefined" &&
    window.matchMedia?.("(max-width: 767px)")?.matches;

  const renderTool = () => {
    switch (activeTool) {
      case "text":
        return <TextTool engine={engine} />;
      case "media":
        return <MediaTool engine={engine} />;
      case "emoji":
        return <EmojiTool engine={engine} />;
      case "filters":
        return <FilterTool engine={engine} />;
      case "crop":
        return <CropPanel engine={engine} />;
      case "paint":
        return <PaintPanel engine={engine} />;
      case "frame":
        return <FrameTool />;
      case "music":
        return <MusicTool engine={engine}/>;
      case "layers":
      default:
        return <LayerControls engine={engine} />;
    }
  };

  return (
    <Motion.aside
      drag={canDragSheet ? "y" : false}
      dragConstraints={{ top: 0, bottom: 0 }}
      dragElastic={0.05}
      className="flex h-full max-h-[38dvh] min-h-0 w-full touch-pan-y flex-col overflow-hidden rounded-t-2xl border border-border bg-white/95 text-foreground shadow-premium backdrop-blur-xl dark:border-border-dark dark:bg-gray-900/95 dark:text-foreground-dark md:max-h-none md:w-full md:rounded-xl"
    >
      <div className="flex justify-center pt-2 md:hidden" aria-hidden="true">
        <div className="h-1 w-10 rounded-full bg-gray-300 dark:bg-gray-700" />
      </div>
      <div className="shrink-0 border-b border-border px-4 py-2 dark:border-border-dark sm:px-5">
        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-mutedForeground dark:text-mutedForeground-dark">
          Editor Panel
        </p>
        <h2 className="mt-1 text-lg font-semibold">{TOOL_TITLES[activeTool]}</h2>
      </div>
      <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 py-3 [-webkit-overflow-scrolling:touch] sm:px-5 sm:py-4">
        {renderTool()}
      </div>
    </Motion.aside>
  );
};

export default React.memo(EditorSidebar);
