import React, { useState, useEffect } from "react";
import { Plus, ChevronLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { playlistService } from "../../services/playlist.service.js";
import { vibeService } from "../../services/vibe.service.js";
import { usePlaylistStore } from "../../store/playlistStore.js";
import PlaylistCard from "../../components/playlist/PlaylistCard.jsx";
import PlaylistBottomSheet from "../../components/playlist/PlaylistBottomSheet.jsx";
import Loader from "../../components/common/Loader.jsx";
import Seo from "../../components/seo/Seo.jsx";
import { buildStaticPageSeo } from "../../seo/seoBuilders.js";
import { shouldSkipLiveSeoFetch } from "../../seo/seoUtils.js";
import Avatar from "../../components/common/Avatar.jsx";
import { usePlayerStore } from "../../store/playerStore.js";

const PlaylistsPage = () => {
  const navigate = useNavigate();
  const skipLiveFetch = shouldSkipLiveSeoFetch();

  const [loading, setLoading] = useState(true);
  const [isBottomSheetOpen, setIsBottomSheetOpen] = useState(false);
  const [randomSongs, setRandomSongs] = useState([]);

  const { playlists, setPlaylists } = usePlaylistStore();
  const { setQueue } = usePlayerStore();

  useEffect(() => {
    if (skipLiveFetch) {
      setLoading(false);
      return;
    }

    Promise.all([fetchPlaylists(), fetchRandomSongs()]);
  }, [skipLiveFetch]);

  const fetchPlaylists = async () => {
    setLoading(true);

    const res = await playlistService.getPlaylists();

    if (res.success) {
      setPlaylists(res.data.results || []);
    }

    setLoading(false);

    return res;
  };

  const fetchRandomSongs = async () => {
    try {
      const res = await vibeService.getVibePosts({
        audio: true,
        limit: 10,
      });

      let songs = Array.isArray(res.data) ? res.data : [];

      // shuffle
      songs = songs.sort(() => Math.random() - 0.5);

      setRandomSongs(songs.slice(0, 10));
    } catch (error) {
      console.error("Failed to fetch random songs:", error);
    }
  };

  const handleSongClick = (clickedAudioId) => {
  const formattedTracks = randomSongs.map((item) => ({
    id: item.audio?.id,
    audio: item.audio,
    user: item.user,
    created_at: item.created_at,
    views_count: item.views_count || 0,
    comments_count: item.comments_count || 0,
    likes_count: item.likes_count || 0,
  }));

  const selectedIndex = formattedTracks.findIndex(
    (track) => Number(track.id) === Number(clickedAudioId)
  );

  if (selectedIndex === -1) return;

  // set global queue
  setQueue(formattedTracks, selectedIndex, {
    isPlaying: true,
    force: true,
  });

  // open AUDIO PLAYER
  navigate(`/audio?start=${clickedAudioId}`);
};

  // ================= LOADING =================
  if (loading) {
    return (
      <>
        <Seo {...buildStaticPageSeo("playlists")} />
        <div className="h-screen flex items-center justify-center bg-white dark:bg-black">
          <Loader />
        </div>
      </>
    );
  }

  // ================= UI =================
  return (
    <>
      <Seo {...buildStaticPageSeo("playlists")} />
      <div className="min-h-screen bg-white dark:bg-black">
        {/* HEADER */}
        <div className="flex items-center justify-between px-4 lg:pt-2 pb-3">
          <button onClick={() => navigate(-1)}>
            <ChevronLeft className="w-6 h-6 text-black dark:text-white" />
          </button>

          <h1 className="text-lg font-semibold text-black dark:text-white">
            My Playlists
          </h1>

          {/* ✅ FIXED PLUS BUTTON */}
          <button className="p-1" onClick={() => setIsBottomSheetOpen(true)}>
            <Plus className="w-6 h-6 text-black dark:text-white" />
          </button>
        </div>

        {/* SECTION TITLE */}
        <div className="px-4 pt-2 pb-2">
          <h2 className="text-base font-medium text-black dark:text-white">
            Playlists
          </h2>
        </div>

        {/* DIVIDER */}
        <div className="h-px bg-gray-300 dark:bg-gray-800 mx-4 mb-2" />

        {/* PLAYLIST LIST */}
        <div>
          {playlists.map((playlist) => (
            <PlaylistCard key={playlist.id} playlist={playlist} />
          ))}
        </div>

        {/* RANDOM SONGS */}
        <div className="px-4 pt-6 pb-24">
          <h2 className="text-base font-semibold text-black dark:text-white mb-3">
            Random Songs
          </h2>

          <div className="space-y-1">
            {randomSongs.map((item) => {
              const audio = item.audio;

              if (!audio?.id) return null;

              return (
                <div
  key={audio.id}
  onClick={() => handleSongClick(audio.id)}
  className="
    flex items-center gap-3
    p-2 rounded-xl
    bg-gray-100 dark:bg-gray-900
    active:scale-[0.98]
    transition-transform
    cursor-pointer
  "
>
                  <Avatar
                    src={audio.cover_image}
                    alt={audio.title}
                    size="medium"
                    className="rounded-lg"
                  />

                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-black dark:text-white truncate">
                      {audio.title}
                    </div>

                    <div className="text-sm text-gray-500 truncate">
                      @{item.user?.username || "Unknown"}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* ✅ PLAYLIST BOTTOM SHEET */}
        {isBottomSheetOpen && (
          <PlaylistBottomSheet
            isOpen={isBottomSheetOpen}
            onClose={() => setIsBottomSheetOpen(false)}
          />
        )}
      </div>
    </>
  );
};

export default PlaylistsPage;
