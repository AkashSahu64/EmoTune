// src/components/layout/Sidebar.jsx
import React, { useState } from "react";
import { useEffect } from "react";
import { notificationService } from "../../services/notification.service.js";
import { motion } from "framer-motion";
import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  Search,
  MessageCircle,
  PlusSquare,
  Settings,
  Music,
} from "lucide-react";
import { FaBell } from "react-icons/fa";
import { IoMdHome } from "react-icons/io";
import { FaRegUser } from "react-icons/fa6";
import { ImFire } from "react-icons/im";

import { useAuthStore } from "../../store/authStore.js";
import { useUIStore } from "../../store/uiStore.js";
import { useRequireAuth } from "../../hooks/useRequireAuth.js";

import Avatar from "../common/Avatar.jsx";
import gaonGramLogo from "../../assets/logo.png";
import SettingsPopup from "../common/SettingsPopup.jsx";
import { useTranslation } from "react-i18next";

const Sidebar = () => {
  const location = useLocation();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuthStore();
  const { openModal } = useUIStore();
  const requireAuth = useRequireAuth();
  const [unreadCount, setUnreadCount] = useState(0);

  const [showSettings, setShowSettings] = useState(false);

  const handleProtectedNavigation = (path) => {
    requireAuth(() => navigate(path));
  };

  const handleCreateClick = () => {
    requireAuth(() => openModal("create-post-selector"));
  };

  // ✅ FIX: use keys instead of static labels
  const mainLinks = [
    { icon: IoMdHome, key: "feed", path: "/", public: true },
    { icon: Search, key: "search", path: "/search", public: true },
    { icon: ImFire, key: "vibes", path: "/reels", public: true },
    { icon: Music, key: "audio", path: "/audio", public: true },
    {
      icon: MessageCircle,
      key: "messages",
      path: "/messages",
      protected: true,
    },
    {
      icon: FaBell,
      key: "notifications",
      path: "/notifications",
      protected: true,
    },
    {
      icon: PlusSquare,
      key: "create",
      protected: true,
      onClick: handleCreateClick,
    },
    {
      icon: FaRegUser,
      key: "profile",
      path: isAuthenticated ? `/profile/${user?.id}` : "/login",
      protected: !isAuthenticated,
    },
  ];
  useEffect(() => {
    const fetchUnreadCount = async () => {
      try {
        const count = await notificationService.getUnreadCount();

        setUnreadCount(count);
      } catch (error) {
        console.error("Failed to fetch unread count:", error);
      }
    };

    // initial fetch
    fetchUnreadCount();

    // sync when notifications become read
    const handleNotificationsRead = () => {
      setUnreadCount(0);
    };

    window.addEventListener("notifications-read", handleNotificationsRead);

    return () => {
      window.removeEventListener("notifications-read", handleNotificationsRead);
    };
  }, []);

  return (
    <>
      <motion.aside
        initial={{ x: -300 }}
        animate={{ x: 0 }}
        className="hidden lg:block fixed left-0 top-0 h-full w-64 border-r border-border dark:border-border-dark bg-card dark:bg-card-dark shadow-soft z-10"
      >
        <div className="py-2 flex flex-col h-full">
          {/* LOGO */}
          <div>
            <Link
              to="/"
              className="flex items-center space-x-3 mb-8 border-b border-border dark:border-border-dark w-full"
            >
              <img
                src={gaonGramLogo}
                alt="GaonGram"
                className="w-12 h-12 object-contain ml-4"
              />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-primary via-accent to-viral-pink bg-clip-text text-transparent">
                {t("app_name")}
              </h1>
            </Link>
          </div>

          {/* MAIN LINKS */}
          <div className="space-y-1 px-4">
            {mainLinks.map((link) => {
              const Icon = link.icon;
              const isActive = location.pathname === link.path;

              // Create / custom click
              if (link.onClick) {
                return (
                  <button
                    key={link.key}
                    onClick={link.onClick}
                    className="flex items-center space-x-3 px-4 py-3 rounded-lg text-foreground dark:text-foreground-dark hover:bg-muted dark:hover:bg-muted-dark w-full text-left"
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{t(link.key)}</span>
                  </button>
                );
              }

              // Protected links
              if (link.protected) {
                return (
                  <button
                    key={link.key}
                    onClick={() => handleProtectedNavigation(link.path)}
                    className={`flex items-center space-x-3 px-4 py-2 rounded-lg transition-colors ${
                      isActive
                        ? "bg-primary/10 dark:bg-primary/20 text-primary"
                        : "hover:bg-muted dark:hover:bg-muted-dark text-foreground dark:text-foreground-dark"
                    } w-full text-left`}
                  >
                    <div className="relative">
                      <Icon className="w-5 h-5" />

                      {link.key === "notifications" && unreadCount > 0 && (
                        <span
                          className="
                          absolute -top-2 -right-2
                          min-w-[18px] h-[18px]
                          px-1
                          flex items-center justify-center
                          rounded-full
                          bg-red-500 text-white
                          text-[10px] font-semibold
                        "
                        >
                          {unreadCount > 99 ? "99+" : unreadCount}
                        </span>
                      )}
                    </div>
                    <span className="font-medium">{t(link.key)}</span>
                  </button>
                );
              }

              // Public links
              return (
                <Link
                  key={link.key}
                  to={link.path}
                  className={`flex items-center space-x-3 px-4 py-2 rounded-lg transition-colors ${
                    isActive
                      ? "bg-primary/10 dark:bg-primary/20 text-primary"
                      : "hover:bg-muted dark:hover:bg-muted-dark text-foreground dark:text-foreground-dark"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{t(link.key)}</span>
                </Link>
              );
            })}
          </div>

          {/* Divider */}
          <div className="mt-2 pt-2 border-t border-border dark:border-border-dark px-4"></div>

          {/* SETTINGS */}
          <div className="mt-auto border-t border-border dark:border-border-dark px-4 pt-2">
            <button
              onClick={() => requireAuth(() => setShowSettings(true))}
              className="flex items-center space-x-3 px-4 py-2 rounded-lg text-foreground dark:text-foreground-dark hover:bg-muted dark:hover:bg-muted-dark w-full"
            >
              <Settings className="w-5 h-5" />
              <span className="font-medium">{t("settings")}</span>
            </button>
          </div>
        </div>
      </motion.aside>

      {showSettings && <SettingsPopup onClose={() => setShowSettings(false)} />}
    </>
  );
};

export default Sidebar;
