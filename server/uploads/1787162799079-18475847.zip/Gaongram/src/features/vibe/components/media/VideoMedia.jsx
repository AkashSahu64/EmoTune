// components/vibe/media/VideoMedia.jsx

import React, { useState, useRef, useEffect } from "react";
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  VolumeX,
  Maximize2,
  Minimize2,
} from "lucide-react";
import Hls from "hls.js";
import SensitiveContentOverlay from "../../../../components/vibe/SensitiveContentOverlay.jsx";

const VideoMedia = ({
  videoUrl,
  videoSources,
  videoThumbnail,
  videoRef,
  videoProgressBarRef,
  videoCurrentTime,
  videoDuration,
  videoLoading,
  isMuted,
  onVideoProgressClick,
  onVideoSkipForward,
  onVideoSkipBackward,
  toggleVideoPlay,
  handleGlobalMuteToggle,
  onVideoEnded,
  onVideoLoadStart,
  onVideoCanPlay,
  onVideoMetadataLoad,
  renderViewCount,
  formatPlayerTime,
  isSensitiveBlocked = false,
  onSensitiveClick,
}) => {
  const [orientation, setOrientation] = useState("landscape");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [volume, setVolume] = useState(1);
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);
  const [hoverProgress, setHoverProgress] = useState(null);

  const [currentVideoUrl, setCurrentVideoUrl] = useState(
    videoSources?.hls || videoSources?.mp4 || null,
  );

  const containerRef = useRef(null);
  const volumeSliderRef = useRef(null);

  const handleMetadata = (e) => {
    if (videoRef.current) {
      const video = videoRef.current;
      const aspect = video.videoWidth / video.videoHeight;

      setOrientation(aspect < 1 ? "portrait" : "landscape");
    }

    if (onVideoMetadataLoad) onVideoMetadataLoad(e);
  };

  const toggleFullscreen = async () => {
    if (isSensitiveBlocked) {
      onSensitiveClick?.();
      return;
    }

    if (!containerRef.current) return;

    if (!isFullscreen) {
      await containerRef.current.requestFullscreen();
      setIsFullscreen(true);
    } else {
      await document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener("fullscreenchange", handleFullscreenChange);

    return () =>
      document.removeEventListener("fullscreenchange", handleFullscreenChange);
  }, []);

  const handleVolumeChange = (e) => {
    if (isSensitiveBlocked) return;

    const newVolume = parseFloat(e.target.value);

    setVolume(newVolume);

    if (videoRef.current) {
      videoRef.current.volume = newVolume;

      if (newVolume === 0) {
        videoRef.current.muted = true;
      } else {
        videoRef.current.muted = false;
      }
    }
  };

  useEffect(() => {
    if (videoRef.current) {
      if (isMuted) {
        videoRef.current.muted = true;
        setVolume(0);
      } else {
        videoRef.current.muted = false;
        setVolume(videoRef.current.volume || 1);
      }
    }
  }, [isMuted, videoRef]);

  useEffect(() => {
    const video = videoRef.current;

    if (!video || !currentVideoUrl) return;

    let hls;
    let fallbackTimeout;

    if (isSensitiveBlocked) {
      video.pause();
      video.removeAttribute("src");
      video.load();
      return undefined;
    }

    const isHls = currentVideoUrl.includes(".m3u8");

    // ============================================
    // HLS VIDEO
    // ============================================

    if (isHls) {
      // -----------------------------
      // SAFARI NATIVE HLS
      // -----------------------------

      if (video.canPlayType("application/vnd.apple.mpegurl")) {
        video.src = currentVideoUrl;

        video.load();

        fallbackTimeout = setTimeout(() => {
          if (
            video.readyState < 2 &&
            videoSources?.mp4 &&
            currentVideoUrl !== videoSources.mp4
          ) {
            setCurrentVideoUrl(videoSources.mp4);
          }
        }, 1000);
      }

      // -----------------------------
      // HLS.JS SUPPORT
      // -----------------------------
      else if (Hls.isSupported()) {
        console.log("[HLS.js MODE]");

        hls = new Hls({
          enableWorker: true,
          lowLatencyMode: true,
        });

        hls.loadSource(currentVideoUrl);

        hls.attachMedia(video);

        // fallback timer
        fallbackTimeout = setTimeout(() => {
          if (
            video.readyState < 2 &&
            videoSources?.mp4 &&
            currentVideoUrl !== videoSources.mp4
          ) {
            console.log("[TIMEOUT FALLBACK TO MP4]");

            hls.destroy();

            setCurrentVideoUrl(videoSources.mp4);
          }
        }, 1000);

        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          console.log("[HLS SUCCESS]");

          clearTimeout(fallbackTimeout);
        });

        hls.on(Hls.Events.ERROR, (event, data) => {
          console.error("[HLS ERROR]", data);

          if (videoSources?.mp4 && currentVideoUrl !== videoSources.mp4) {
            console.log("[ERROR FALLBACK TO MP4]");

            clearTimeout(fallbackTimeout);

            hls.destroy();

            setCurrentVideoUrl(videoSources.mp4);
          }
        });
      }
    }

    // ============================================
    // MP4 VIDEO
    // ============================================
    else {
      video.src = currentVideoUrl;

      video.load();
    }

    // ============================================
    // CLEANUP
    // ============================================

    return () => {
      clearTimeout(fallbackTimeout);

      video.pause();

      video.removeAttribute("src");

      video.load();

      if (hls) {
        hls.destroy();
      }
    };
  }, [currentVideoUrl, isSensitiveBlocked]);

  useEffect(() => {
    if (!isSensitiveBlocked || !videoRef.current) return;

    videoRef.current.pause();
    videoRef.current.muted = true;
  }, [isSensitiveBlocked, videoRef]);

  const handleProgressHover = (e) => {
    if (isSensitiveBlocked) return;

    const rect = e.currentTarget.getBoundingClientRect();

    const percent = (e.clientX - rect.left) / rect.width;

    setHoverProgress(Math.min(Math.max(percent * 100, 0), 100));
  };

  // Close slider when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        volumeSliderRef.current &&
        !volumeSliderRef.current.contains(event.target) &&
        showVolumeSlider
      ) {
        setShowVolumeSlider(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [showVolumeSlider]);

  const videoProgressPercentage = videoDuration
    ? (videoCurrentTime / videoDuration) * 100
    : 0;

  // ✅ SAME HEIGHT KE SAATH FIX
  const containerClasses = `relative w-full ${
    !isFullscreen
      ? orientation === "portrait"
        ? "aspect-[10.02/17.8]"
        : "aspect-video"
      : "h-screen"
  } min-h-[580px] bg-gradient-to-br from-gray-900 to-black group shadow-2xl`;

  // ✅ VIDEO CROP NAHI HOGA
  const videoObjectFit = "object-contain";

  const LoadingSpinner = () => (
    <div className="absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm z-20">
      <div className="relative">
        <div className="w-10 h-10 rounded-full border-2 border-white/20 border-t-primary animate-spin" />

        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-1.5 h-1.5 bg-primary rounded-full animate-pulse" />
        </div>
      </div>
    </div>
  );

  return (
    <div ref={containerRef} className={containerClasses}>
      {videoThumbnail && (
        <img
          src={videoThumbnail}
          alt="Video thumbnail"
          className={`absolute inset-0 w-full h-full object-cover transition-all duration-700 ${
            !videoLoading ? "opacity-0 scale-105" : "opacity-100 scale-100"
          } ${isSensitiveBlocked ? "opacity-100 blur-xl scale-105 brightness-75" : ""}`}
        />
      )}

      <video
        ref={videoRef}
        className={`w-full h-full ${videoObjectFit} transition-all duration-500 ${
          isSensitiveBlocked ? "pointer-events-none blur-xl scale-105 brightness-75" : ""
        }`}
        playsInline
        preload="metadata"
        onEnded={onVideoEnded}
        onLoadedMetadata={handleMetadata}
        onLoadStart={onVideoLoadStart}
        onCanPlay={onVideoCanPlay}
        poster={videoThumbnail}
        controls={false}
        disablePictureInPicture={isSensitiveBlocked}
        controlsList="nodownload noplaybackrate noremoteplayback nofullscreen"
        onClick={(e) => {
          e.stopPropagation();
          if (isSensitiveBlocked) onSensitiveClick?.();
        }}
      />

      {videoLoading && !isSensitiveBlocked && <LoadingSpinner />}
      {renderViewCount("video")}
      {isSensitiveBlocked && (
        <SensitiveContentOverlay onClick={onSensitiveClick} />
      )}

      {!isSensitiveBlocked && (
        <div
          className="absolute inset-0 flex items-center justify-center
          opacity-0 group-hover:opacity-100
          transition-all duration-500
          pointer-events-none"
        >
          <div className="flex items-center space-x-8 pointer-events-auto">
            <button
              type="button"
              aria-label="Skip video back 5 seconds"
              onClick={onVideoSkipBackward}
              className="relative p-2 bg-black/20 rounded-full border border-white/20 transition-all duration-200 hover:scale-110"
            >
              <RotateCcw className="w-5 h-5 text-white" />

              <span className="absolute inset-0 flex items-center justify-center text-[10px] font-bold text-white pointer-events-none">
                5s
              </span>
            </button>

            <button
              type="button"
              aria-label="Play or pause video"
              onClick={toggleVideoPlay}
              className="relative p-3 bg-black/20 rounded-full border border-white/30 shadow-2xl transition-all duration-300 hover:scale-110"
            >
              {videoRef.current && !videoRef.current.paused ? (
                <Pause className="w-7 h-7 text-white fill-white" />
              ) : (
                <Play className="w-7 h-7 text-white fill-white ml-0.5" />
              )}
            </button>

            <button
              type="button"
              aria-label="Skip video forward 5 seconds"
              onClick={onVideoSkipForward}
              className="relative p-2 bg-black/20 rounded-full border border-white/20 transition-all duration-200 hover:scale-110"
            >
              <RotateCw className="w-5 h-5 text-white" />

              <span className="absolute inset-0 flex items-center justify-center text-[10px] font-bold text-white pointer-events-none">
                5s
              </span>
            </button>
          </div>
        </div>
      )}

      {!isSensitiveBlocked && (
        <div
          className="absolute bottom-0 left-0 right-0
          opacity-0 group-hover:opacity-100
          transition-all duration-500
          translate-y-1 group-hover:translate-y-0
          pt-6 pb-2 px-3
          z-30"
        >
        <div
          ref={videoProgressBarRef}
          className="relative h-1 bg-white/80 rounded-full cursor-pointer group/progress overflow-visible mb-2"
          onClick={onVideoProgressClick}
          onMouseMove={handleProgressHover}
          onMouseLeave={() => setHoverProgress(null)}
        >
          <div
            className="absolute left-0 top-0 h-full bg-gradient-to-r from-primary to-primary/80 rounded-full transition-all duration-150"
            style={{
              width: `${videoProgressPercentage}%`,
            }}
          />

          <div
            className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-lg
            opacity-0 group-hover/progress:opacity-100 transition-all duration-200 hover:scale-125"
            style={{
              left: `${videoProgressPercentage}%`,
            }}
          />

          {hoverProgress !== null && (
            <div
              className="absolute -top-8 -translate-x-1/2 bg-black/80 backdrop-blur-sm text-white text-xs px-2 py-1 rounded-md pointer-events-none whitespace-nowrap"
              style={{
                left: `${hoverProgress}%`,
              }}
            >
              {formatPlayerTime((hoverProgress / 100) * videoDuration)}
            </div>
          )}
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center space-x-1 text-white/80 text-sm font-mono px-2 py-1 rounded-md">
              <span>{formatPlayerTime(videoCurrentTime)}</span>

              <span className="text-white/40">/</span>

              <span className="text-white/60">
                {formatPlayerTime(videoDuration)}
              </span>
            </div>

            <div className="relative" ref={volumeSliderRef}>
              <button
                onClick={() => {
                  handleGlobalMuteToggle();
                  setShowVolumeSlider(true);
                }}
                className="p-2 bg-white/10 hover:bg-white/20 rounded-full backdrop-blur-sm transition-all duration-200"
                aria-label="Volume control"
              >
                {isMuted || volume === 0 ? (
                  <VolumeX className="w-4 h-4 text-white" />
                ) : (
                  <Volume2 className="w-4 h-4 text-white" />
                )}
              </button>

              {showVolumeSlider && (
                <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 flex items-center p-2 bg-black/80 backdrop-blur-xl rounded-xl border border-white/20 shadow-xl z-50">
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.01"
                    value={volume}
                    onChange={handleVolumeChange}
                    className="w-24 h-1.5 bg-white/20 rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-primary [&::-webkit-slider-thumb]:shadow-lg"
                  />
                </div>
              )}
            </div>
          </div>

          <button
            onClick={toggleFullscreen}
            className="p-2 bg-white/10 hover:bg-white/20 rounded-full backdrop-blur-sm transition-all duration-200"
            aria-label={isFullscreen ? "Exit fullscreen" : "Fullscreen"}
          >
            {isFullscreen ? (
              <Minimize2 className="w-4 h-4 text-white" />
            ) : (
              <Maximize2 className="w-4 h-4 text-white" />
            )}
          </button>
        </div>
        </div>
      )}
    </div>
  );
};

export default VideoMedia;
