import StoryEditor from "../../editor/editors/StoryEditor.jsx";

export default StoryEditor;
