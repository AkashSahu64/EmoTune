// PollVote.jsx
import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { CheckCircle, BarChart3, Users, Clock, Check } from "lucide-react";
import { useAuthStore } from "../../../store/authStore.js";
import { useUIStore } from "../../../store/uiStore.js";
import { vibeService } from "../../../services/vibe.service.js";
// import { showError, showSuccess } from "../../../utils/toast.js";
import { formatTime } from "../../../utils/formatTime.js";
import { useTranslation } from "react-i18next";

const PollVote = ({ poll, postId, onVote }) => {
  const { isAuthenticated, user } = useAuthStore();
  const { openModal } = useUIStore();
  const { t } = useTranslation();

  const [selectedOption, setSelectedOption] = useState(null);
  const [hasVoted, setHasVoted] = useState(false);
  const [totalVotes, setTotalVotes] = useState(0);
  const [options, setOptions] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [pollEnded, setPollEnded] = useState(false);

  useEffect(() => {
    if (!poll) return;

    const normalizedUserVote =
      poll.user_vote !== null && poll.user_vote !== undefined
        ? String(poll.user_vote).trim()
        : null;

    const userVoted = normalizedUserVote !== null;
    setHasVoted(userVoted);
    if (userVoted) {
      const votedIndex = (poll.poll_options || []).findIndex((option) => {
        const optionText =
          typeof option === "object" ? option.text || option.option : option;

        return String(optionText).trim() === normalizedUserVote;
      });

      setSelectedOption(votedIndex);
    }

    let votesTotal = 0;
    const votesArray = poll.poll_votes || {};
    if (typeof votesArray === "object") {
      votesTotal = Object.values(votesArray).reduce(
        (sum, count) => sum + (Number(count) || 0),
        0,
      );
    }
    setTotalVotes(votesTotal);

    const pollOptions = (poll.poll_options || []).map((option, index) => {
      const optionText =
        typeof option === "object" ? option.text || option.option : option;

      const voteCount = Number(votesArray?.[optionText]) || 0;
      const percentage =
        votesTotal > 0 ? Math.round((voteCount / votesTotal) * 100) : 0;
      return {
        id: index,
        text:
          typeof option === "object" ? option.text || option.option : option,
        votes: Number(voteCount) || 0,
        percentage,
        isSelected:
          userVoted && String(optionText).trim() === normalizedUserVote,
      };
    });
    setOptions(pollOptions);

    if (poll.expires_at) {
      const now = new Date();
      const expiresAt = new Date(poll.expires_at);
      setPollEnded(now > expiresAt);
    }
  }, [poll]);

  const handleVote = async (optionIndex) => {
    if (!isAuthenticated) {
      openModal("login");
      return;
    }

    // Same option clicked again
    if (selectedOption === optionIndex && hasVoted) {
      return;
    }

    setIsSubmitting(true);

    try {
      await vibeService.votePoll(postId, poll.poll_options[optionIndex]);
      setSelectedOption(optionIndex);

      const previousSelected = selectedOption;

      let updatedOptions = [...options];

      // Remove previous vote
      if (previousSelected !== null && previousSelected !== undefined) {
        updatedOptions = updatedOptions.map((option, idx) => {
          if (idx === previousSelected) {
            return {
              ...option,
              votes: Math.max(0, option.votes - 1),
            };
          }
          return option;
        });
      }

      // Add new vote
      updatedOptions = updatedOptions.map((option, idx) => {
        if (idx === optionIndex) {
          return {
            ...option,
            votes: option.votes + 1,
            isSelected: true,
          };
        }

        return {
          ...option,
          isSelected: false,
        };
      });

      // Recalculate percentages
      const total = updatedOptions.reduce(
        (sum, option) => sum + option.votes,
        0,
      );

      updatedOptions = updatedOptions.map((option) => ({
        ...option,
        percentage: total > 0 ? Math.round((option.votes / total) * 100) : 0,
      }));

      setOptions(updatedOptions);

      setTotalVotes(total);

      setHasVoted(true);

      if (onVote) onVote();
    } catch (error) {
      showError(error.response?.data?.message || "Failed to submit vote");
    } finally {
      setIsSubmitting(false);
    }
  };

  const calculatePercentage = (votes) => {
    if (totalVotes === 0) return 0;
    return Math.round((votes / totalVotes) * 100);
  };

  const getWinningOption = () => {
    if (!hasVoted || options.length === 0) return null;
    let maxVotes = -1;
    let winningOption = null;
    options.forEach((option) => {
      if (option.votes > maxVotes) {
        maxVotes = option.votes;
        winningOption = option;
      }
    });
    return winningOption;
  };

  const winningOption = getWinningOption();

  if (!poll || !poll.poll_question) {
    return (
      <div className="bg-card dark:bg-card-dark rounded-xl p-8 text-center border border-border dark:border-border-dark">
        <p className="text-mutedForeground dark:text-mutedForeground-dark">
          {t("no_poll_available")}
        </p>
      </div>
    );
  }

  return (
    <div className="w-full max-w-md mx-auto bg-card border-t border-border dark:border-border-dark dark:bg-card-dark px-2 py-1 shadow-soft">
      {/* Header */}
      <div className="flex items-start gap-3 pb-0 mb-2 border-b border-border dark:border-border-dark">
        {/* Poll Icon */}
        <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 dark:bg-primary/15 flex items-center justify-center">
          <BarChart3 className="w-6 h-6 text-primary" />
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          {/* Poll Question */}
          <h3 className="text-[17px] font-semibold leading-[1.25] text-foreground dark:text-foreground-dark line-clamp-2 break-words">
            {poll.poll_question}
          </h3>

          {/* Votes */}
          <div className="flex items-center">
            <div className="flex items-center gap-1 py-1 text-xs text-mutedForeground dark:text-mutedForeground-dark">
              <Users className="w-3.5 h-3.5 flex-shrink-0" />
              <span className="font-medium">
                {totalVotes} {t("votes")}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Options */}
      <div className="space-y-1">
        {options.map((option, index) => {
          const percentage = hasVoted ? calculatePercentage(option.votes) : 0;

          const isSelected = hasVoted && selectedOption === index;

          const isWinner = hasVoted && winningOption?.id === index;

          return (
            <div key={index} className="relative">
              <button
                onClick={() => handleVote(index)}
                disabled={isSubmitting}
                className={`relative overflow-hidden w-full rounded-lg border border-border dark:border-border-dark transition-all duration-200 p-2 text-left ${
                  isSelected
                    ? "border-primary bg-primary/10 dark:bg-primary/15 shadow-sm"
                    : "border-border dark:border-border-dark bg-background dark:bg-background-dark hover:bg-muted/70 dark:hover:bg-muted-dark/60"
                }`}
              >
                {/* Animated background progress */}
                {hasVoted && (
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${percentage}%` }}
                    transition={{ duration: 0.7, ease: "easeOut" }}
                    className="absolute inset-y-0 left-0 bg-primary/10 dark:bg-primary/20"
                  />
                )}

                {/* Content */}
                <div className="relative z-10 flex items-center justify-between gap-3">
                  {/* Left Side */}
                  <div className="flex items-center gap-2 min-w-0">
                    {isWinner && (
                      <CheckCircle className="w-4 h-4 text-primary flex-shrink-0" />
                    )}

                    <span className="text-sm font-medium text-foreground leading-tight dark:text-foreground-dark break-words">
                      {option.text}
                    </span>
                  </div>

                  {/* Right Side */}
                  {hasVoted && (
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <span className="text-sm font-semibold text-foreground dark:text-foreground-dark">
                        {percentage}%
                      </span>

                      <span className="text-xs text-mutedForeground dark:text-mutedForeground-dark">
                        ({option.votes})
                      </span>
                    </div>
                  )}
                </div>
              </button>

              {/* Selected Badge */}
              {isSelected && (
                <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-primary text-white flex items-center justify-center shadow-md">
                  <Check className="w-3 h-3" />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Footer */}
      <div className="mt-3 pt-3 border-t border-border dark:border-border-dark">
        <div className="flex items-center">
          {hasVoted ? (
            <div className="bg-primary/10 w-full dark:bg-primary/10 text-primary rounded-lg p-2 text-sm flex items-center space-x-2">
              <CheckCircle className="w-4 h-4 text-primary flex-shrink-0" />
              <span className="font-medium">{t("vote_recorded")}</span>
            </div>
          ) : (
            <div className="text-sm text-mutedForeground dark:text-mutedForeground-dark">
              {isAuthenticated ? t("select_option_vote") : t("login_to_vote")}
            </div>
          )}
        </div>
      </div>

      {/* Winning result */}
      {hasVoted && winningOption && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-2 px-2 rounded-lg bg-muted dark:bg-muted-dark border border-border dark:border-border-dark"
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between space-y-1 sm:space-y-0">
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold text-foreground dark:text-foreground-dark">
                {t("winning_option")}
              </h4>

              <p className="text-mutedForeground dark:text-mutedForeground-dark truncate">
                {winningOption.text}
              </p>
            </div>

            <div className="text-right flex-shrink-0">
              <div className="text-xl font-bold text-primary">
                {calculatePercentage(winningOption.votes)}%
              </div>

              <div className="text-sm text-mutedForeground dark:text-mutedForeground-dark">
                {t("votes_count", {
                  count: winningOption.votes,
                })}
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default PollVote;
