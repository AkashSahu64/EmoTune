export const exportStory = async (canvasEngine) => {
  if (!canvasEngine) throw new Error('No canvas engine');
  const blob = await canvasEngine.exportBlob();
  return new File([blob], 'story.png', { type: 'image/png' });
};