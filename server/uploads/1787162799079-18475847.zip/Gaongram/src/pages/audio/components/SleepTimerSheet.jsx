import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";

const SleepTimerSheet = ({
  isOpen,
  onClose,
  onSet,
  onCancel,
  isActive
}) => {

  const options = [
    { label: "30 sec", value: 30000 },
    { label: "5 min", value: 5 * 60 * 1000 },
    { label: "10 min", value: 10 * 60 * 1000 },
    { label: "30 min", value: 30 * 60 * 1000 },
    { label: "1 hour", value: 60 * 60 * 1000 }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="absolute inset-0 z-50 flex items-end">
          
          {/* Overlay */}
          <motion.div
            className="absolute inset-0 bg-black/30 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Bottom Sheet */}
          <motion.div
            className="
              relative w-full 
              bg-white dark:bg-black/80
              rounded-t-3xl py-2 px-6 
              border-t border-border dark:border-gray-700
            "
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", stiffness: 260, damping: 25 }}
          >
            {/* Drag Handle */}
            <div className="w-10 h-1.5 bg-gray-300 dark:bg-gray-600 rounded-full mx-auto mb-4" />

            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-foreground dark:text-white text-lg font-semibold">
                Set Sleep Timer
              </h2>

              <button
                onClick={onClose}
                className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-white/10 transition"
              >
                <X className="w-5 h-5 text-gray-600 dark:text-gray-300" />
              </button>
            </div>

            {/* Options */}
            <div className="space-y-2 text-center">
              {options.map((opt) => (
                <button
                  key={opt.label}
                  onClick={() => {
                    onSet(opt.value);
                    onClose();
                  }}
                  className="
                    w-full text-lg py-2 rounded-lg transition
                    text-foreground dark:text-white
                    hover:bg-gray-100 dark:hover:bg-white/10
                  "
                >
                  {opt.label}
                </button>
              ))}

              {isActive && (
                <button
                  onClick={() => {
                    onCancel();
                    onClose();
                  }}
                  className="w-full py-2 text-red-500 rounded-lg hover:bg-red-100 dark:hover:bg-red-500/10 transition"
                >
                  Cancel Timer
                </button>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default SleepTimerSheet;