// src/pages/CommunityGuidelines.jsx
import React, { useRef } from "react";
import { motion, useInView, useScroll, useTransform } from "framer-motion";
import {
  Shield,
  Users,
  AlertTriangle,
  Ban,
  Flag,
  Eye,
  Scale,
  Clock,
  FileText,
  Heart,
  Lock,
  Globe,
  MessageCircle,
} from "lucide-react";
import PostCard from "../about/PostCard";
import MinimalLayout from "../../../components/layout/MinimalLayout";
import Seo from "../../../../../components/seo/Seo.jsx";
import { buildStaticPageSeo } from "../../../../../seo/seoBuilders.js";

// Reusable animation variants
const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: "easeOut" } },
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.15, delayChildren: 0.1 },
  },
};

const slideFromLeft = {
  hidden: { opacity: 0, x: -50 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.7, ease: "easeOut" } },
};

const slideFromRight = {
  hidden: { opacity: 0, x: 50 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.7, ease: "easeOut" } },
};

const scaleIn = {
  hidden: { opacity: 0, scale: 0.9 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { duration: 0.6, ease: "easeOut" },
  },
};

// ImageTextSection component
const ImageTextSection = ({
  label,
  title,
  content,
  imageUrl,
  reverse,
  bulletPoints,
}) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <motion.section
      ref={ref}
      initial="hidden"
      animate={isInView ? "visible" : "hidden"}
      className="py-16 md:py-24 border-t border-border dark:border-border-dark"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`grid md:grid-cols-2 gap-12 items-center ${reverse ? "md:flex-row-reverse" : ""}`}
        >
          {/* Text side */}
          <motion.div
            variants={staggerContainer}
            className={`space-y-6 ${reverse ? "md:order-2" : ""}`}
          >
            <motion.span
              variants={fadeUp}
              className="text-sm font-semibold uppercase tracking-wider text-primary"
            >
              {label}
            </motion.span>
            <motion.h2
              variants={fadeUp}
              className="text-3xl md:text-4xl font-bold text-foreground dark:text-foreground-dark"
            >
              {title}
            </motion.h2>
            <motion.div
              variants={fadeUp}
              className="prose prose-lg dark:prose-invert text-mutedForeground dark:text-mutedForeground-dark"
            >
              {typeof content === "string"
                ? content
                    .split("\n\n")
                    .map((para, idx) => <p key={idx}>{para}</p>)
                : content}
            </motion.div>
            {bulletPoints && (
              <motion.ul variants={staggerContainer} className="space-y-3 mt-4">
                {bulletPoints.map((point, idx) => (
                  <motion.li
                    key={idx}
                    variants={fadeUp}
                    className="flex items-start gap-3"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0" />
                    <span className="text-mutedForeground dark:text-mutedForeground-dark">
                      {point}
                    </span>
                  </motion.li>
                ))}
              </motion.ul>
            )}
          </motion.div>

          {/* Image side */}
          <motion.div
            variants={reverse ? slideFromLeft : slideFromRight}
            className={`relative ${reverse ? "md:order-1" : ""}`}
          >
            <div className="rounded-2xl overflow-hidden shadow-premium">
              <img
                src={imageUrl}
                alt={title}
                className="w-full h-auto object-cover"
                loading="lazy"
              />
            </div>
            {/* Decorative element */}
            <div className="absolute -z-10 -bottom-6 -right-6 w-48 h-48 bg-primary/5 rounded-full blur-3xl" />
          </motion.div>
        </div>
      </div>
    </motion.section>
  );
};

// Highlight section (black)
const HighlightSection = ({ words }) => {
  const ref = useRef(null);

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });

  // 🎯 Animations
  const leftX = useTransform(scrollYProgress, [0, 1], [-100, 0]);
  const centerY = useTransform(scrollYProgress, [0, 1], [0, 0]);
  const rightX = useTransform(scrollYProgress, [0, 1], [100, 0]);

  const opacity = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0, 1, 1, 0]);

  return (
    <section
      ref={ref}
      className="py-24 text-foreground dark:text-foreground-dark overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-6">
        {/* 🔥 3 COLUMN GRID */}
        <div className="grid grid-cols-1 md:grid-cols-3 items-center text-center">
          {/* LEFT */}
          <motion.div
            style={{ x: leftX, opacity }}
            className="text-4xl md:text-6xl lg:text-7xl font-bold leading-[0.9]"
          >
            {words[0]}
          </motion.div>

          {/* CENTER */}
          <motion.div
            style={{ y: centerY, opacity }}
            className="text-4xl md:text-6xl lg:text-7xl font-bold leading-[0.9]"
          >
            {words[1]}
          </motion.div>

          {/* RIGHT */}
          <motion.div
            style={{ x: rightX, opacity }}
            className="text-4xl md:text-6xl lg:text-7xl font-bold leading-[0.9]"
          >
            {words[2]}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

// Prohibited Content Grid
const ProhibitedGrid = () => {
  const items = [
    {
      icon: Users,
      title: "Hate Speech",
      description: "No incitement against religion, caste, or community.",
    },
    {
      icon: Lock,
      title: "Impersonation",
      description: "Falsely claiming official or public figure status.",
    },
    {
      icon: Eye,
      title: "Harassment",
      description: "Cyber-stalking, bullying, or non‑consensual imagery.",
    },
    {
      icon: AlertTriangle,
      title: "Misinformation",
      description: "Fake news that endangers public health or safety.",
    },
    {
      icon: Ban,
      title: "Obscenity",
      description: "Sexually explicit content or graphic violence.",
    },
    {
      icon: Globe,
      title: "Plagiarism",
      description: "Copyright infringement of local creators.",
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-muted dark:bg-muted-dark">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="text-center mb-12"
        >
          <motion.h2
            variants={fadeUp}
            className="text-3xl md:text-4xl font-bold text-foreground dark:text-foreground-dark"
          >
            Prohibited Content
          </motion.h2>
          <motion.p
            variants={fadeUp}
            className="text-lg text-mutedForeground dark:text-mutedForeground-dark mt-3 max-w-2xl mx-auto"
          >
            Content that violates our core principles will be removed.
          </motion.p>
        </motion.div>
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {items.map((item, idx) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={idx}
                variants={fadeUp}
                whileHover={{
                  y: -8,
                  boxShadow: "0 20px 30px -10px rgba(0,0,0,0.1)",
                }}
                className="bg-card dark:bg-card-dark rounded-xl p-6 border border-border dark:border-border-dark transition-all duration-300"
              >
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-foreground dark:text-foreground-dark">
                  {item.title}
                </h3>
                <p className="text-mutedForeground dark:text-mutedForeground-dark">
                  {item.description}
                </p>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
};

// Enforcement Timeline
const EnforcementTimeline = () => {
  const steps = [
    {
      title: "Strike 1",
      subtitle: "Warning & Education",
      description: "Content removed. Complete Digital Literacy Mini‑Course.",
    },
    {
      title: "Strike 2",
      subtitle: "Temporary Suspension",
      description: "7‑day posting ban. Account under Observation Mode.",
    },
    {
      title: "Strike 3",
      subtitle: "Permanent Termination",
      description: "Account deleted. Data preserved 180 days per IT Rules.",
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-white dark:bg-background-dark">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.h2
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUp}
          className="text-3xl md:text-4xl font-bold text-center mb-16 text-foreground dark:text-foreground-dark"
        >
          Enforcement & Strike System
        </motion.h2>
        <div className="relative">
          {/* Connecting line */}
          <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-border dark:bg-border-dark hidden md:block" />
          <div className="space-y-12 relative">
            {steps.map((step, idx) => (
              <motion.div
                key={idx}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-50px" }}
                variants={fadeUp}
                custom={idx}
                className={`flex flex-col md:flex-row items-center gap-8 ${idx % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"}`}
              >
                <div
                  className={`md:w-1/2 ${idx % 2 === 0 ? "md:text-right md:pr-12" : "md:text-left md:pl-12"}`}
                >
                  <span className="text-6xl font-bold text-primary/20">
                    {idx + 1}
                  </span>
                  <h3 className="text-2xl font-bold mt-2 text-foreground dark:text-foreground-dark">
                    {step.title}
                  </h3>
                  <p className="text-lg font-medium text-primary mt-1">
                    {step.subtitle}
                  </p>
                  <p className="text-mutedForeground dark:text-mutedForeground-dark mt-3">
                    {step.description}
                  </p>
                </div>
                <div className="md:w-1/2 flex justify-center">
                  <div className="w-12 h-12 rounded-full bg-primary text-white flex items-center justify-center font-bold text-xl shadow-soft">
                    {idx + 1}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

// Long content sections (center aligned, max width)
const ContentSection = ({ title, children }) => {
  return (
    <motion.section
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-100px" }}
      variants={staggerContainer}
      className="py-12"
    >
      <div className="max-w-3xl mx-auto px-4">
        <motion.h2
          variants={fadeUp}
          className="text-2xl md:text-3xl font-bold mb-6 text-foreground dark:text-foreground-dark"
        >
          {title}
        </motion.h2>
        <motion.div
          variants={fadeUp}
          className="prose prose-lg dark:prose-invert max-w-none text-mutedForeground dark:text-mutedForeground-dark"
        >
          {children}
        </motion.div>
      </div>
    </motion.section>
  );
};

// Main component
const CommunityGuidelines = () => {
  // Hero PostCard data
  const heroPost = {
    avatar: "https://ui-avatars.com/api/?background=0E4D38&color=fff&name=GG",
    username: "gaongram",
    timestamp: new Date().toISOString(),
    imageUrl:
      "https://img.freepik.com/free-vector/social-media-network_74855-4575.jpg",
    caption: "Our Digital Maryada — respect, safety, dignity. 🌾",
    likes: 15420,
    comments: 342,
  };

  return (
    <MinimalLayout>
      <Seo {...buildStaticPageSeo("guidelines")} />
      <div className="min-h-screen bg-white dark:bg-background-dark">
        {/* Hero Section */}
        <section className="pt-16 pb-12 md:pt-24 md:pb-16 overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial="hidden"
                animate="visible"
                variants={staggerContainer}
                className="space-y-6"
              >
                <motion.h1
                  variants={fadeUp}
                  className="text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight text-foreground dark:text-foreground-dark leading-tight"
                >
                  Community Guidelines
                </motion.h1>
                <motion.p
                  variants={fadeUp}
                  className="text-xl md:text-2xl text-mutedForeground dark:text-mutedForeground-dark"
                >
                  The Digital Maryada of GaonGram
                </motion.p>
                <motion.p
                  variants={fadeUp}
                  className="text-mutedForeground dark:text-mutedForeground-dark max-w-lg"
                >
                  Our commitment to a respectful, safe, and authentic space for
                  every Indian.
                </motion.p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20, rotate: -2 }}
                animate={{ opacity: 1, y: 0, rotate: 0 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="relative"
              >
                <motion.div
                  animate={{ y: [0, -12, 0] }}
                  transition={{
                    duration: 6,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                  className="w-full max-w-sm mx-auto"
                >
                  <PostCard {...heroPost} className="shadow-premium" />
                </motion.div>
                <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-gradient-to-r from-primary/20 to-viral-pink/20 rounded-full blur-3xl" />
              </motion.div>
            </div>
          </div>
        </section>

        {/* Pillar I: Respect */}
        <ImageTextSection
          label="Pillar I"
          title="Universal Respect & Non‑Discrimination"
          content={`India’s strength lies in its diversity. Consequently, GaonGram mandates a policy of Universal Respect (Sarvavyapi Samman).\n\nReligious and Communal Harmony: Users are strictly prohibited from posting, sharing, or promoting content that ridicules, insults, or incites hatred against any religion, sect, or place of worship.\n\nLegal Compliance: This aligns with Section 295A of the IPC (and corresponding sections of the Bhartiya Nyaya Sanhita), which criminalizes deliberate acts intended to outrage religious feelings.\n\nModeration Standard: We distinguish between "Theological Discussion" and "Hate Speech." Content that calls for the economic or social boycott of any religious group is categorized as high‑priority harmful content.`}
          bulletPoints={[
            "Zero‑tolerance for casteist slurs or prejudice.",
            "Enforced under the SC/ST (Prevention of Atrocities) Act.",
          ]}
          imageUrl="https://images.unsplash.com/photo-1531206715517-5c0ba140b2b8?w=800&h=600&fit=crop"
          reverse={false}
        />

        {/* Pillar II: Authenticity */}
        <ImageTextSection
          label="Pillar II"
          title="Authenticity & Identity Integrity"
          content={`In a digital economy, trust is built through Authenticity (Asliyat).\n\nAnti‑Impersonation Protocols: Impersonating a Sarpanch (Village Head), Patwari (Land Record Officer), or any member of the Civil Service is a violation of the IT Act, 2000. Accounts found deceiving the public into believing they are an official government channel will be terminated immediately.\n\nCommercial Fraud: Using the identity of a local business to defraud farmers or artisans is strictly prohibited.\n\nOriginality over Viral Reposts: GaonGram prioritizes original content. We encourage the sharing of indigenous knowledge, such as organic farming techniques (Prakritik Kheti) and regional folk arts.`}
          bulletPoints={[
            "Respect copyrights of local creators.",
            "Plagiarism of folk music/art subject to takedown.",
          ]}
          imageUrl="https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&h=600&fit=crop"
          reverse={true}
        />

        {/* Prohibited Content Grid */}
        <ProhibitedGrid />

        {/* More detailed prohibited content as sections */}
        <ImageTextSection
          label="Red Lines"
          title="Harassment & Protection of Honor"
          content={`The digital safety of women and vulnerable groups is our most critical priority.\n\nNon‑Consensual Intimate Imagery (NCII): The sharing, or threat of sharing, "morphed" or private images is a criminal offense. Our AI proactively scans for "Deepfakes."\n\nCyber‑Stalking: Persistent unwanted engagement, including following a user across groups or leaving repetitive comments after a block, is classified as harassment.`}
          bulletPoints={[
            "AI‑powered detection of abusive slang in 18+ languages.",
            "Screenshot protection for profile pictures.",
          ]}
          imageUrl="https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&h=600&fit=crop"
          reverse={false}
        />

        <ImageTextSection
          label="Red Lines"
          title="Misinformation & Fake News"
          content={`In rural areas, misinformation can lead to physical violence or financial ruin.\n\nAgricultural Sabotage: Spreading false rumors about seed quality, government subsidies, or Mandi prices is prohibited.\n\nHealth and Safety: During medical emergencies, spreading "unverified cures" or anti‑vaccination propaganda is considered a threat to public health.\n\nThe "Forwarded" Label: Content that is "highly forwarded" is automatically subjected to higher AI scrutiny to verify its origin and truthfulness.`}
          bulletPoints={[
            "Fact‑check partnerships with local agencies.",
            "Forward limits to 5 chats at a time.",
          ]}
          imageUrl="https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?w=800&h=600&fit=crop"
          reverse={true}
        />

        {/* Black Highlight */}
        <HighlightSection words={["Respect.", "Safety.", "Dignity."]} />

        {/* Enforcement Tiers */}
        <section className="py-16 md:py-20">
          <div className="max-w-7xl mx-auto px-4">
            <motion.h2
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUp}
              className="text-3xl md:text-4xl font-bold text-center mb-12 text-foreground dark:text-foreground-dark"
            >
              The Enforcement Hierarchy
            </motion.h2>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  icon: Shield,
                  title: "Tier 1: Gram‑Vigil AI",
                  desc: "Regional dialect understanding, real‑time quarantine, 18+ languages.",
                },
                {
                  icon: Flag,
                  title: "Tier 2: Community Vigilance",
                  desc: "Users flag content; high‑volume alerts auto‑hide pending review.",
                },
                {
                  icon: Users,
                  title: "Tier 3: Human Review",
                  desc: "Cultural experts resolve nuanced cases; Grievance Redressal Team.",
                },
              ].map((tier, idx) => {
                const Icon = tier.icon;
                return (
                  <motion.div
                    key={idx}
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true }}
                    variants={fadeUp}
                    whileHover={{ y: -6 }}
                    className="bg-card dark:bg-card-dark p-8 rounded-2xl border border-border dark:border-border-dark shadow-soft transition-all"
                  >
                    <Icon className="w-10 h-10 text-primary mb-4" />
                    <h3 className="text-xl font-bold mb-3 text-foreground dark:text-foreground-dark">
                      {tier.title}
                    </h3>
                    <p className="text-mutedForeground dark:text-mutedForeground-dark">
                      {tier.desc}
                    </p>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Strike System Timeline */}
        <EnforcementTimeline />

        {/* Long Content Sections (exact provided text) */}
        <div className="py-8">
          <ContentSection title="1. Executive Summary: The 'Digital Maryada' Philosophy">
            <p>
              GaonGram is a specialized social intermediary designed for the
              unique socio‑cultural landscape of rural and semi‑urban India. Our
              Community Guidelines represent a "Social Contract" between the
              platform and its users. Unlike global platforms that apply a
              "one‑size‑fits‑all" Western standard, GaonGram integrates Indian
              Constitutional Values with the local ethos of Maryada (Dignity)
              and Bhaichara (Brotherhood).
            </p>
            <p>
              Our objective is to foster a "Digital Town Square" that is
              inclusive, authentic, and free from the toxicity often found in
              unmoderated digital spaces.
            </p>
          </ContentSection>

          <ContentSection title="2. Pillar I: Universal Respect and Non‑Discrimination">
            <p>
              India’s strength lies in its diversity. Consequently, GaonGram
              mandates a policy of Universal Respect (Sarvavyapi Samman).
            </p>
            <h4>2.1. Religious and Communal Harmony</h4>
            <p>
              Prohibited Conduct: Users are strictly prohibited from posting,
              sharing, or promoting content that ridicules, insults, or incites
              hatred against any religion, sect, or place of worship.
            </p>
            <p>
              Legal Compliance: This aligns with Section 295A of the IPC (and
              corresponding sections of the Bhartiya Nyaya Sanhita), which
              criminalizes deliberate acts intended to outrage religious
              feelings.
            </p>
            <p>
              Moderation Standard: We distinguish between "Theological
              Discussion" and "Hate Speech." Content that calls for the economic
              or social boycott of any religious group is categorized as
              high‑priority harmful content.
            </p>
            <h4>2.2. Caste‑Based Discrimination</h4>
            <p>
              Zero‑Tolerance: GaonGram maintains a zero‑tolerance policy for
              casteist slurs or any content that reinforces historical
              prejudices.
            </p>
            <p>
              Statutory Alignment: This policy is enforced in the spirit of the
              Scheduled Castes and the Scheduled Tribes (Prevention of
              Atrocities) Act.
            </p>
          </ContentSection>

          <ContentSection title="3. Pillar II: Authenticity and Identity Integrity">
            <p>
              In a digital economy, trust is built through Authenticity
              (Asliyat).
            </p>
            <h4>3.1. Anti‑Impersonation Protocols</h4>
            <p>
              Public Officials: Impersonating a Sarpanch (Village Head), Patwari
              (Land Record Officer), or any member of the Civil Service is a
              violation of the IT Act, 2000. Accounts found deceiving the public
              into believing they are an official government channel will be
              terminated immediately.
            </p>
            <p>
              Commercial Fraud: Using the identity of a local business to
              defraud farmers or artisans is strictly prohibited.
            </p>
            <h4>3.2. Originality over Viral Reposts</h4>
            <p>
              Creative Promotion: GaonGram prioritizes original content. We
              encourage the sharing of indigenous knowledge, such as organic
              farming techniques (Prakritik Kheti) and regional folk arts.
            </p>
            <p>
              Intellectual Property (IP): Users must respect the copyrights of
              local creators. Plagiarism of folk music or artistic designs is
              subject to our Copyright Takedown Procedure.
            </p>
          </ContentSection>

          <ContentSection title="4. Prohibited Content: The 'Red Lines' of Conduct">
            <h4>4.1. Harassment and the Protection of Honor (Izzat)</h4>
            <p>
              The digital safety of women and vulnerable groups is our most
              critical priority.
            </p>
            <p>
              Non‑Consensual Intimate Imagery (NCII): The sharing, or threat of
              sharing, "morphed" or private images is a criminal offense. Our AI
              proactively scans for "Deepfakes."
            </p>
            <p>
              Cyber‑Stalking: Persistent unwanted engagement, including
              following a user across groups or leaving repetitive comments
              after a block, is classified as harassment.
            </p>
            <h4>4.2. Misinformation and "Fake News"</h4>
            <p>
              In rural areas, misinformation can lead to physical violence or
              financial ruin.
            </p>
            <p>
              Agricultural Sabotage: Spreading false rumors about seed quality,
              government subsidies, or Mandi prices is prohibited.
            </p>
            <p>
              Health and Safety: During medical emergencies, spreading
              "unverified cures" or anti‑vaccination propaganda is considered a
              threat to public health.
            </p>
            <p>
              The "Forwarded" Label: Content that is "highly forwarded" is
              automatically subjected to higher AI scrutiny to verify its origin
              and truthfulness.
            </p>
            <h4>4.3. Nudity, Obscenity, and Graphic Violence</h4>
            <p>
              Family‑Safe Standard: GaonGram is a family‑oriented platform.
              Sexually explicit content, including "soft‑core" pornography or
              suggestive imagery, is forbidden.
            </p>
            <p>
              Graphic Content: Videos depicting animal cruelty, severe
              accidents, or communal violence for the purpose of sensationalism
              will be removed.
            </p>
          </ContentSection>

          <ContentSection title="5. The Enforcement Hierarchy: A Three‑Tier System">
            <p>
              To ensure fair and consistent application of these rules, GaonGram
              utilizes a Hybrid Moderation Framework.
            </p>
            <h4>Tier 1: The "Gram‑Vigil" AI Gatekeeper</h4>
            <p>
              Our AI is trained on Regional Dialect Data. It understands the
              nuances of Hindi, Bhojpuri, Marathi, Tamil, and 18 other
              languages.
            </p>
            <p>
              Contextual Analysis: The AI distinguishes between a cultural
              proverb and a modern insult.
            </p>
            <p>
              Real‑Time Quarantine: Content that scores high on our "Harm Index"
              is quarantined for human review before it becomes visible to the
              public.
            </p>
            <h4>Tier 2: Community‑Led Vigilance</h4>
            <p>
              We empower our users to act as "Digital Chowkidars" (Sentinels).
            </p>
            <p>
              Flagging Mechanism: Users can report content under specific
              categories (e.g., "Hate Speech," "Scam," "Harassment").
            </p>
            <p>
              High‑Volume Alerts: If a post receives a sudden surge of reports,
              it is automatically hidden from the feed pending investigation.
            </p>
            <h4>Tier 3: Human‑in‑the‑Loop (HITL) Review</h4>
            <p>
              Complex cases—such as political satire, local disputes, or
              linguistic nuances—are reviewed by our Grievance Redressal Team.
              These moderators are chosen based on their cultural and linguistic
              expertise in the specific region the report originated from.
            </p>
          </ContentSection>

          <ContentSection title="6. The Strike System and Reformative Justice">
            <p>
              We believe in educating our community. Our penalty system is
              designed to be Reformative rather than just Punitive.
            </p>
            <p>
              Strike 1 (Warning & Education): The content is removed. The user
              must complete a "Digital Literacy Mini‑Course" (a 60‑second video)
              to regain posting privileges.
            </p>
            <p>
              Strike 2 (Temporary Suspension): Posting and commenting are
              disabled for 7 days. The user is placed under "Observation Mode."
            </p>
            <p>
              Strike 3 (Permanent Termination): The account is deleted. In
              accordance with Rule 4 of the IT Rules 2021, we preserve the
              user’s logs for 180 days to assist Law Enforcement if necessary.
            </p>
          </ContentSection>

          <ContentSection title="7. Legal Jurisdiction and GAC">
            <p>
              As a Significant Social Media Intermediary (SSMI), GaonGram
              complies with the Grievance Appellate Committee (GAC).
            </p>
            <p>
              Right to Appeal: If a user believes their content was wrongly
              removed, they may appeal the decision within the app.
            </p>
            <p>
              Final Recourse: If the user is dissatisfied with our Internal
              Grievance Officer’s decision, they have the right to escalate to
              the Government‑appointed GAC.
            </p>
          </ContentSection>

          <ContentSection title="8. Conclusion: A Shared Vision of Progress">
            <p>
              These guidelines are not intended to restrict freedom, but to
              guarantee the Freedom of Safety. By joining GaonGram, every user
              agrees to uphold the dignity of the Indian village in the digital
              world.
            </p>
            <p className="font-semibold text-lg">
              GaonGram: Respecting Roots, Connecting Futures.
            </p>
          </ContentSection>
        </div>

        {/* Footer spacing */}
        <div className="h-16" />
      </div>
    </MinimalLayout>
  );
};

export default CommunityGuidelines;
