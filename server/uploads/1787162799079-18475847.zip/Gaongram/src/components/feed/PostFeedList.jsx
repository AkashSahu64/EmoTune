// src/components/feed/PostFeedList.jsx

import React, {
  useRef,
  useEffect,
  useMemo,
  useCallback,
} from "react";

import VibeCard from "../../features/vibe/components/VibeCard";
import FeedLoader from "./FeedLoader";
import FeedEnd from "./FeedEnd";

const PostFeedList = ({
  items,
  targetPostId,
  isLoading,
  hasNextPage,
  isFetchingNextPage,
  fetchNextPage,
  onPostUpdate,
}) => {
  const loadMoreRef = useRef(null);

  // ---------------- DEDUPLICATE ----------------
  const uniqueItems = useMemo(() => {
    const map = new Map();

    items.forEach((item) => {
      map.set(item.id, item);
    });

    return Array.from(map.values());
  }, [items]);

  // ---------------- LOAD MORE ----------------
  const handleLoadMore = useCallback(
    (entries) => {
      const first = entries[0];

      if (
        first.isIntersecting &&
        hasNextPage &&
        !isFetchingNextPage
      ) {
        fetchNextPage();
      }
    },
    [hasNextPage, isFetchingNextPage, fetchNextPage],
  );

  // ---------------- INTERSECTION OBSERVER ----------------
  useEffect(() => {
    const currentRef = loadMoreRef.current;

    if (!currentRef) return;

    const observer = new IntersectionObserver(handleLoadMore, {
      root: null,

      // smoother preloading
      rootMargin: "1200px",

      threshold: 0,
    });

    observer.observe(currentRef);

    return () => {
      observer.disconnect();
    };
  }, [handleLoadMore]);

  // ---------------- LOADING ----------------
  if (isLoading && !uniqueItems.length) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <div
            key={i}
            className="h-96 animate-pulse rounded-2xl bg-muted"
          />
        ))}
      </div>
    );
  }

  // ---------------- EMPTY ----------------
  if (!isLoading && uniqueItems.length === 0) {
    return (
      <div className="py-20 text-center text-muted-foreground">
        No posts to show.
      </div>
    );
  }

  return (
    <div
      className="
        will-change-transform
        transform-gpu
        backface-hidden
      "
    >
      {/* ---------------- POSTS ---------------- */}
      {uniqueItems.map((item) => (
        <div
          key={item.id}
          data-post-id={item.id}
          className="mb-4"
        >
          <VibeCard
            post={item}
            onUpdate={onPostUpdate}
          />
        </div>
      ))}

      {/* ---------------- SENTINEL ---------------- */}
      <div
        ref={loadMoreRef}
        className="
          flex
          h-20
          items-center
          justify-center
        "
      >
        {isFetchingNextPage && <FeedLoader />}

        {!hasNextPage && uniqueItems.length > 0 && (
          <FeedEnd />
        )}
      </div>
    </div>
  );
};

export default React.memo(PostFeedList);