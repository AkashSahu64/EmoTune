// src/features/profile/components/LanguageSelectorModal.jsx (refactored)
import React from 'react';
import { X, Check } from 'lucide-react';
import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import Button from '../../../components/common/Button';
import { LANGUAGES } from '../../../constants/languages';

const LanguageSelectorModal = ({ isOpen, onClose }) => {
  const { t, i18n } = useTranslation();
  const selectedLang = i18n.language;

  const handleSelect = (code) => {
    i18n.changeLanguage(code);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-6">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm"
          onClick={onClose}
        />
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative bg-white dark:bg-card-dark rounded-xl shadow-xl w-full max-w-md overflow-hidden"
        >
          <div className="px-6 py-3 border-b border-border dark:border-border-dark bg-gradient-to-r from-gaon-cream to-white dark:from-gray-800 dark:to-card-dark">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-foreground dark:text-foreground-dark">
                {t('choose_language')}
              </h3>
              <button
                onClick={onClose}
                className="p-1.5 text-gray-400 hover:text-foreground dark:hover:text-foreground-dark hover:bg-gray-100 dark:hover:bg-muted-dark rounded-lg transition-colors"
              >
                <X size={20} />
              </button>
            </div>
          </div>

          <div className="max-h-[60vh] md:max-h-[70vh] overflow-y-auto hide-scrollbar p-2">
            {LANGUAGES.map((lang) => (
              <button
                key={lang.code}
                onClick={() => handleSelect(lang.code)}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-lg transition-colors ${
                  selectedLang === lang.code
                    ? 'bg-primary/10 dark:bg-primary/20 border border-primary/30'
                    : 'hover:bg-muted dark:hover:bg-muted-dark'
                }`}
              >
                <div className="flex flex-col items-start">
                  <span className="text-foreground dark:text-foreground-dark font-medium">
                    {lang.englishName}
                  </span>
                  <span className="text-xs text-mutedForeground dark:text-mutedForeground-dark">
                    {lang.nativeName}
                  </span>
                </div>
                {selectedLang === lang.code && (
                  <Check className="w-5 h-5 text-primary" />
                )}
              </button>
            ))}
          </div>

          <div className="sticky bottom-0 bg-white dark:bg-card-dark border-t border-border dark:border-border-dark px-6 py-3">
            <div className="flex justify-end gap-3">
              {/* <Button
                variant="outline"
                onClick={onClose}
                className="border-gray-300 dark:border-border-dark text-foreground dark:text-foreground-dark hover:bg-gray-50 dark:hover:bg-muted-dark rounded-lg px-4"
              >
                {t('cancel')}
              </Button> */}
              <Button
                onClick={onClose}
                className="bg-primary hover:bg-primary-light rounded-lg px-4 shadow-md text-white"
              >
                {t('done')}
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default LanguageSelectorModal;