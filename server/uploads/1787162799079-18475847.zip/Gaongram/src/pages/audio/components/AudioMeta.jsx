import React from "react";
import { formatTime } from "../../../utils/formatTime.js";
import Avatar from "../../../components/common/Avatar.jsx";
import FollowButton from "../../../components/common/FollowButton.jsx";
import { useTranslation } from "react-i18next";

const AudioMeta = React.memo(({
  audioTitle,
  user,
  authorId,
  currentUserId,
  timesAgo,
  createdAt
}) => {
  const { t } = useTranslation(); 

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6">
      
      {/* Title */}
      <h1 className="text-2xl md:text-3xl font-bold text-white mb-2 line-clamp-2">
        {audioTitle || t("untitled_audio")} 
      </h1>
      
      {/* User Info */}
      <div className="flex items-center justify-center space-x-2">
        <Avatar
          src={user?.avatar}
          alt={user?.username || t("user")} 
          size="small"
        />

        <span className="text-gray-300">
          @{user?.username || t("user")} 
        </span>

        {authorId && authorId !== currentUserId && (
          <FollowButton
            profileId={authorId}
            size="extra-small"
            className="ml-2"
          />
        )}
      </div>
      
      {/* Time */}
      <p className="text-gray-400 text-sm mt-1">
        {formatTime(createdAt, 'relative')}
      </p>
    </div>
  );
});

AudioMeta.displayName = 'AudioMeta';

export default AudioMeta;