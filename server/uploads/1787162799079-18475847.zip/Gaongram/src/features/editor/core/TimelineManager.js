const clamp = (value, min = 0, max = 100) => Math.min(max, Math.max(min, value));

export class TimelineManager {
  constructor({ durationMs = 7000, onProgress, onComplete } = {}) {
    this.durationMs = durationMs;
    this.onProgress = onProgress;
    this.onComplete = onComplete;
    this.raf = null;
    this.startedAt = 0;
    this.elapsed = 0;
    this.paused = true;
    this.completed = false;
  }

  start(durationMs = this.durationMs) {
    this.stop();
    this.durationMs = durationMs;
    this.startedAt = performance.now();
    this.elapsed = 0;
    this.paused = false;
    this.completed = false;
    this.tick();
  }

  tick = () => {
    if (this.paused) return;
    const elapsed = this.elapsed + performance.now() - this.startedAt;
    const progress = clamp((elapsed / this.durationMs) * 100);
    this.onProgress?.(progress);

    if (progress >= 100) {
      this.completed = true;
      this.paused = true;
      this.onComplete?.();
      return;
    }

    this.raf = requestAnimationFrame(this.tick);
  };

  pause() {
    if (this.paused) return;
    this.elapsed += performance.now() - this.startedAt;
    this.paused = true;
    cancelAnimationFrame(this.raf);
  }

  resume() {
    if (!this.paused || this.completed) return;
    this.startedAt = performance.now();
    this.paused = false;
    this.tick();
  }

  seek(percent) {
    this.elapsed = (clamp(percent) / 100) * this.durationMs;
    this.startedAt = performance.now();
    this.onProgress?.(clamp(percent));
  }

  stop() {
    cancelAnimationFrame(this.raf);
    this.raf = null;
    this.paused = true;
  }
}
