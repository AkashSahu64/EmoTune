// src/pages/Safety.jsx
import React, { useRef } from "react";
import { motion, useInView, useScroll, useTransform } from "framer-motion";
import {
  Shield,
  Lock,
  Eye,
  AlertTriangle,
  Heart,
  Users,
  Scale,
  Smartphone,
  Clock,
  MessageCircle,
  CheckCircle,
  ChevronRight,
  ArrowRight,
  Sparkles,
} from "lucide-react";
import MinimalLayout from "../../../components/layout/MinimalLayout";
import { Link } from "react-router-dom";
import Seo from "../../../../../components/seo/Seo.jsx";
import { buildStaticPageSeo } from "../../../../../seo/seoBuilders.js";

// Animation variants
const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1, delayChildren: 0.1 },
  },
};

const slideFromLeft = {
  hidden: { opacity: 0, x: -40 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.7, ease: "easeOut" } },
};

const slideFromRight = {
  hidden: { opacity: 0, x: 40 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.7, ease: "easeOut" } },
};

// Quick Access Card component (Instagram style)
const QuickAccessCard = ({ icon: Icon, title, description, color }) => {
  return (
    <motion.div
      whileHover={{
        y: -4,
        boxShadow:
          "0 20px 25px -5px rgba(0,0,0,0.05), 0 10px 10px -5px rgba(0,0,0,0.02)",
      }}
      className="bg-white dark:bg-card-dark rounded-2xl p-6 border border-border/50 dark:border-border-dark/50 shadow-soft transition-all duration-300 group cursor-pointer"
    >
      <div
        className={`w-12 h-12 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center mb-4 text-white`}
      >
        <Icon className="w-6 h-6" />
      </div>
      <h3 className="text-lg font-semibold text-foreground dark:text-foreground-dark mb-2 group-hover:text-primary transition-colors">
        {title}
      </h3>
      <p className="text-sm text-mutedForeground dark:text-mutedForeground-dark line-clamp-2">
        {description}
      </p>
      <div className="mt-4 flex items-center text-primary text-sm font-medium">
        Learn more{" "}
        <ChevronRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
      </div>
    </motion.div>
  );
};

// ImageTextSection component (refined)
const ImageTextSection = ({
  label,
  title,
  content,
  imageUrl,
  reverse,
  bulletPoints,
  bgColor = "bg-transparent",
}) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <motion.section
      ref={ref}
      initial="hidden"
      animate={isInView ? "visible" : "hidden"}
      className={`py-16 md:py-24 ${bgColor}`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div
          className={`grid md:grid-cols-2 gap-12 lg:gap-20 items-center ${reverse ? "md:flex-row-reverse" : ""}`}
        >
          <motion.div
            variants={staggerContainer}
            className={`space-y-5 ${reverse ? "md:order-2" : ""}`}
          >
            {label && (
              <motion.span
                variants={fadeUp}
                className="inline-block text-sm font-semibold uppercase tracking-wider text-primary bg-primary/10 px-3 py-1 rounded-full"
              >
                {label}
              </motion.span>
            )}
            <motion.h2
              variants={fadeUp}
              className="text-3xl md:text-4xl font-bold text-foreground dark:text-foreground-dark"
            >
              {title}
            </motion.h2>
            <motion.div
              variants={fadeUp}
              className="prose prose-lg dark:prose-invert text-mutedForeground dark:text-mutedForeground-dark"
            >
              {typeof content === "string"
                ? content
                    .split("\n\n")
                    .map((para, idx) => <p key={idx}>{para}</p>)
                : content}
            </motion.div>
            {bulletPoints && (
              <motion.ul variants={staggerContainer} className="space-y-4 mt-6">
                {bulletPoints.map((point, idx) => (
                  <motion.li
                    key={idx}
                    variants={fadeUp}
                    className="flex items-start gap-3"
                  >
                    <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center mt-0.5 flex-shrink-0">
                      <CheckCircle className="w-3 h-3 text-primary" />
                    </div>
                    <span className="text-mutedForeground dark:text-mutedForeground-dark">
                      {point}
                    </span>
                  </motion.li>
                ))}
              </motion.ul>
            )}
          </motion.div>

          <motion.div
            variants={reverse ? slideFromLeft : slideFromRight}
            className={`relative ${reverse ? "md:order-1" : ""}`}
          >
            <div className="rounded-2xl overflow-hidden shadow-soft border border-border/30 dark:border-border-dark/30">
              <img
                src={imageUrl}
                alt={title}
                className="w-full h-auto object-cover"
                loading="lazy"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </motion.section>
  );
};

// Safety Tools Grid
const SafetyToolsGrid = () => {
  const tools = [
    {
      icon: Lock,
      title: "End‑to‑End Encryption",
      description:
        "Messages are secure and private, only you and the recipient can read them.",
      color: "from-blue-500 to-blue-600",
    },
    {
      icon: Shield,
      title: "Two‑Factor Authentication",
      description:
        "Add an extra layer of security to prevent unauthorized access.",
      color: "from-green-500 to-green-600",
    },
    {
      icon: Eye,
      title: "Profile Picture Guard",
      description:
        "Prevents screenshots and downloads of your profile picture.",
      color: "from-purple-500 to-purple-600",
    },
    {
      icon: AlertTriangle,
      title: "Scam Detection",
      description: "Automatically flags suspicious links and potential fraud.",
      color: "from-orange-500 to-orange-600",
    },
    {
      icon: Users,
      title: "Block & Restrict",
      description: "Control who can interact with you and see your content.",
      color: "from-pink-500 to-pink-600",
    },
    {
      icon: MessageCircle,
      title: "Hidden Words",
      description: "Filter out abusive comments in your local language.",
      color: "from-indigo-500 to-indigo-600",
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-muted/20 to-transparent dark:from-muted-dark/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="text-center mb-12"
        >
          <motion.span
            variants={fadeUp}
            className="text-primary font-semibold text-sm uppercase tracking-wider"
          >
            Tools you can trust
          </motion.span>
          <motion.h2
            variants={fadeUp}
            className="text-3xl md:text-4xl font-bold text-foreground dark:text-foreground-dark mt-2"
          >
            Safety features built for you
          </motion.h2>
          <motion.p
            variants={fadeUp}
            className="text-lg text-mutedForeground dark:text-mutedForeground-dark mt-3 max-w-2xl mx-auto"
          >
            We give you control over your experience with easy‑to‑use tools.
          </motion.p>
        </motion.div>
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {tools.map((item, idx) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={idx}
                variants={fadeUp}
                whileHover={{ y: -6 }}
                className="bg-card dark:bg-card-dark rounded-2xl p-6 border border-border dark:border-border-dark shadow-soft transition-all duration-300"
              >
                <div
                  className={`w-12 h-12 rounded-xl bg-gradient-to-br ${item.color} flex items-center justify-center mb-5 text-white`}
                >
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-foreground dark:text-foreground-dark">
                  {item.title}
                </h3>
                <p className="text-mutedForeground dark:text-mutedForeground-dark">
                  {item.description}
                </p>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
};

// Black Highlight Section (refined)
const HighlightSection = ({ text }) => {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.95, 1, 0.95]);
  const opacity = useTransform(
    scrollYProgress,
    [0, 0.3, 0.7, 1],
    [0.8, 1, 1, 0.8],
  );

  return (
    <section
      ref={ref}
      className="py-24 text-foreground dark:text-foreground-dark overflow-hidden"
    >
      <div className="max-w-4xl mx-auto px-4 text-center">
        <motion.h2
          style={{ scale, opacity }}
          className="text-4xl md:text-6xl lg:text-7xl font-bold leading-tight tracking-tight"
        >
          {text}
        </motion.h2>
      </div>
    </section>
  );
};

// Long Content Section (centered, max-width) - refined
const ContentSection = ({ title, children }) => {
  return (
    <motion.section
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-100px" }}
      variants={staggerContainer}
      className="py-12"
    >
      <div className="max-w-3xl mx-auto px-4">
        <motion.h2
          variants={fadeUp}
          className="text-2xl md:text-3xl font-bold mb-6 text-foreground dark:text-foreground-dark"
        >
          {title}
        </motion.h2>
        <motion.div
          variants={fadeUp}
          className="prose prose-lg dark:prose-invert max-w-none text-mutedForeground dark:text-mutedForeground-dark"
        >
          {children}
        </motion.div>
      </div>
    </motion.section>
  );
};

// Main Safety Page
const Safety = () => {
  return (
    <MinimalLayout>
      <Seo {...buildStaticPageSeo("safety")} />
      <div className="min-h-screen bg-white dark:bg-background-dark">
        {/* Hero Section - Instagram style minimal */}
        <section className="pt-20 pb-12 md:pt-32 md:pb-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial="hidden"
                animate="visible"
                variants={staggerContainer}
                className="space-y-6"
              >
                <motion.h1
                  variants={fadeUp}
                  className="text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight text-foreground dark:text-foreground-dark"
                >
                  Your safety is our priority
                </motion.h1>
                <motion.p
                  variants={fadeUp}
                  className="text-xl text-mutedForeground dark:text-mutedForeground-dark max-w-lg"
                >
                  We build tools and policies that help you connect, create, and
                  share safely.
                </motion.p>
                <motion.div variants={fadeUp} className="flex flex-wrap gap-4">
                  <Link
                    to="/privacy"
                    className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-white rounded-full hover:bg-primary-light transition shadow-soft"
                  >
                    Read guidelines <ArrowRight className="w-4 h-4" />
                  </Link>
                </motion.div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8 }}
                className="relative"
              >
                <img
                  src="https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?w=600&h=600&fit=crop"
                  alt="Safety illustration"
                  className="rounded-3xl shadow-soft"
                />
                <div className="absolute -z-10 -top-10 -right-10 w-64 h-64 bg-gradient-to-br from-primary/20 to-viral-pink/20 rounded-full blur-3xl" />
              </motion.div>
            </div>
          </div>
        </section>

        {/* Intro Philosophy (exact content) */}
        <ImageTextSection
          label="Safety Pillar"
          title='1. Our Philosophy: "Safety First, Social Second"'
          content={`At GaonGram, we believe that a digital platform is only as good as the safety it provides to its weakest user. In the diverse landscape of India, where millions are first-time internet users, safety cannot be a mere feature—it must be the foundation.`}
          bulletPoints={[
            "Protection from cyber-bullying and harassment",
            "Strong safeguards against financial fraud",
            "Strict control over misinformation spread",
            "Safe and respectful Digital Chaupal environment",
          ]}
          imageUrl="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&h=600&fit=crop"
          reverse={true}
        />

        {/* Women’s Digital Security */}
        <ImageTextSection
          label="Safety Pillar"
          title="2. Women’s Digital Security (The Suraksha Shield)"
          content="Women are the backbone of our society, and their safety on GaonGram is our highest priority. We have implemented several 'India-First' safety features:"
          bulletPoints={[
            "Profile Picture Protection: Our 'Digital Shield' ensures that unauthorized users cannot download or take screenshots of profile pictures. This prevents the misuse of images for creating fake profiles or other malicious activities.",
            "Restricted Interaction: Female users have the option to set their accounts so that they only receive messages from people they follow. This eliminates the risk of unsolicited messages and digital stalking.",
            "Abuse Detection in Regional Languages: Our AI is specifically trained to detect and block abusive slang not just in English or Hindi, but in 12+ regional dialects including Bhojpuri, Haryanvi, Punjabi, and Bengali.",
            "Direct Reporting: Every profile has a 'Safety' button that allows women to report harassment directly to our female-led moderation team, which prioritizes these cases for resolution within 2 hours.",
          ]}
          imageUrl="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=800&h=600&fit=crop"
          reverse={false}
          bgColor="bg-muted/20 dark:bg-muted-dark/20"
        />

        {/* Child Safety */}
        <ImageTextSection
          label="Safety Pillar"
          title="3. Child Safety and Minor Protection"
          content="We are committed to providing a wholesome environment for the younger generation."
          bulletPoints={[
            "Age Verification: We strictly enforce a minimum age requirement of 13 years. Accounts suspected of belonging to underage children are flagged for age verification.",
            "Default Privacy for Minors: Accounts for users under 18 are set to 'Private' by default. Their content is not visible in the 'Global' or 'Trending' feeds unless manually approved by them.",
            'Nudity & Exploitation Filters: We employ Google-grade "Computer Vision" technology to instantly detect and delete any content that depicts child exploitation. Such users are not only banned but their details are shared with the National Crime Records Bureau (NCRB).',
          ]}
          imageUrl="https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?w=800&h=600&fit=crop"
          reverse={true}
        />

        {/* Anti-Fraud */}
        <ImageTextSection
          label="Safety Pillar"
          title="4. Anti-Fraud & Financial Security"
          content="In rural India, financial literacy is still evolving, making users vulnerable to scammers."
          bulletPoints={[
            "Verified Official Badges: GaonGram officials will never ask for your Password, OTP, or Bank details. Official accounts are always marked with a specific 'Gold Verified' badge.",
            'Scam Link Detection: Our system automatically scans links shared in DMs. If a link leads to a phishing site or a "Get Rich Quick" scam, the user is warned, and the link is disabled.',
            "UPI Safety Education: We regularly run in-app campaigns to teach users about UPI safety—reminding them that they only need to enter a PIN to send money, not to receive it.",
          ]}
          imageUrl="https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=800&h=600&fit=crop"
          reverse={false}
          bgColor="bg-muted/20 dark:bg-muted-dark/20"
        />

        {/* Combatting Fake News */}
        <ImageTextSection
          label="Safety Pillar"
          title="5. Combatting Fake News & Misinformation (Truth Guard)"
          content="Misinformation can lead to real-world consequences, including communal tension and public panic."
          bulletPoints={[
            'The Fact-Check Label: We partner with local news agencies to verify viral posts. Content that is found to be false is marked with a "Misleading Content" tag, and its reach is restricted by 95%.',
            "Forward Limits: To stop the viral spread of rumors, we have limited the 'Forward' feature to only 5 chats at a time, similar to global standards but with deeper monitoring of the source.",
            "Context Labels: Posts related to sensitive topics like health (vaccines, medicines) or government schemes are provided with official links to ensure users get the correct information.",
          ]}
          imageUrl="https://images.unsplash.com/photo-1586339949916-3e9457bef6d3?w=800&h=600&fit=crop"
          reverse={true}
        />

        {/* Hate Speech */}
        <ImageTextSection
          label="Safety Pillar"
          title="6. Zero Tolerance for Hate Speech & Communal Disharmony"
          content="Bharat is a land of many religions and castes. To maintain harmony:"
          bulletPoints={[
            "Communal Harmony Protocol: Any content that incites violence or promotes hatred against a specific religion, caste, or community is deleted instantly.",
            "Repeat Offender Policy: Users who consistently violate our hate speech guidelines face a 'Three-Strike' rule. The third strike results in a permanent hardware-level ban (meaning they cannot create a new account from the same phone).",
          ]}
          imageUrl="https://images.unsplash.com/photo-1531206715517-5c0ba140b2b8?w=800&h=600&fit=crop"
          reverse={false}
          bgColor="bg-muted/20 dark:bg-muted-dark/20"
        />

        {/* Safety Tools Grid */}
        <SafetyToolsGrid />

        {/* Technical Infrastructure Safety (as content section) */}
        <ContentSection title="7. Technical Infrastructure Safety">
          <ul className="space-y-4 list-disc pl-5">
            <li>
              <strong>End-to-End Encryption (E2EE):</strong> Your private
              messages are yours alone. Not even GaonGram employees can read
              your personal chats.
            </li>
            <li>
              <strong>Secure Servers in India:</strong> By keeping our servers
              within Indian territory, we ensure that your data is protected by
              Indian Cyber Laws and is not subject to foreign surveillance.
            </li>
            <li>
              <strong>Two-Factor Authentication (2FA):</strong> We encourage all
              users to link their accounts to a secondary verification method
              (like an Authenticator App or SMS OTP) to prevent unauthorized
              logins.
            </li>
          </ul>
        </ContentSection>

        {/* Mental Health */}
        <ImageTextSection
          label="Safety Pillar"
          title="8. Mental Health & Well-being"
          content="Social media should make you feel good, not anxious."
          bulletPoints={[
            'Time-Out Reminders: If a user spends more than 2 hours continuously on the app, we send a "Take a Break" reminder.',
            "Comment Filtering: You can 'Mute' certain words or phrases that you find upsetting. This ensures your comment section remains a positive space for you.",
          ]}
          imageUrl="https://images.unsplash.com/photo-1493836512294-502baa1986e2?w=800&h=600&fit=crop"
          reverse={true}
        />

        {/* Law Enforcement */}
        <ImageTextSection
          label="Safety Pillar"
          title="9. Law Enforcement Cooperation"
          content="We work hand-in-hand with the Indian Law Enforcement agencies."
          bulletPoints={[
            "Emergency Response: In cases of kidnapping, missing persons, or threats of self-harm, we provide a 24/7 dedicated portal for police officers to request data (following due legal process) to save lives.",
            "Transparency Reports: Every six months, GaonGram publishes a transparency report detailing how many accounts were banned and how many legal requests were processed.",
          ]}
          imageUrl="https://images.unsplash.com/photo-1589578527966-fdac0f44566c?w=800&h=600&fit=crop"
          reverse={false}
          bgColor="bg-muted/20 dark:bg-muted-dark/20"
        />

        {/* Black Highlight */}
        <HighlightSection text="Safety is not a feature. It is our foundation." />

        {/* Conclusion */}
        <ContentSection title="10. Conclusion: A Shared Responsibility">
          <p>
            Safety is a two-way street. While GaonGram provides the tools and
            the technology, we urge our community to remain vigilant. By
            reporting bad actors and respecting the "Maryada" of our digital
            space, we can ensure that GaonGram remains the safest home for every
            Indian on the internet.
          </p>
        </ContentSection>

        {/* Footer CTA */}
        <section className="py-16 border-t border-border dark:border-border-dark">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={staggerContainer}
            >
              <motion.h2
                variants={fadeUp}
                className="text-2xl md:text-3xl font-bold mb-4 text-foreground dark:text-foreground-dark"
              >
                Have more questions?
              </motion.h2>
              <motion.p
                variants={fadeUp}
                className="text-mutedForeground dark:text-mutedForeground-dark mb-6"
              >
                Visit our Help Center or contact our support team.
              </motion.p>
              <motion.div
                variants={fadeUp}
                className="flex flex-wrap justify-center gap-4"
              >
                <Link to='/help-center' className="px-6 py-3 bg-primary text-white rounded-full hover:bg-primary-light transition shadow-soft">
                  Help Center
                </Link>
                <Link to='/contact' className="px-6 py-3 border border-border dark:border-border-dark rounded-full hover:bg-muted/50 transition">
                  Contact Support
                </Link>
              </motion.div>
            </motion.div>
          </div>
        </section>

        <div className="h-8" />
      </div>
    </MinimalLayout>
  );
};

export default Safety;
