import React, { useState, useRef, useEffect } from "react";
import { motion as Motion, AnimatePresence } from "framer-motion";
import { showToast } from "../../../../utils/toast";
import {
  getCroppedImage,
} from "../../../../utils/image/getCroppedImage";
import { FILTER_PRESETS } from "../../../../utils/image/applyFilters";
import { optimizeImageFile } from "../../../editor/utils/imageOptimization.js";

/**
 * BaseImageEditor - Logic-only component for image editing
 * Handles all state, processing, and business logic
 * No UI rendering - delegates to UI components via props
 */
const BaseImageEditor = ({
  // Required props
  isOpen,
  onClose,
  profile,
  onUpdate,
  isUpdating,

  // Configuration
  config,

  // UI Components
  renderHeader,
  renderSourceSelector,
  renderCameraView,
  renderCropperView,
  renderFiltersPanel,
  renderFooter,
}) => {
  // Editor state
  const [mode, setMode] = useState("select");
  const [selectedImage, setSelectedImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [showCamera, setShowCamera] = useState(false);
  const [uploading, setUploading] = useState(false);

  // Crop state
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [aspect, setAspect] = useState(config.defaultAspect);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState(null);

  // Filter state
  const [filters, setFilters] = useState({
    brightness: 100,
    contrast: 100,
    saturation: 100,
    blur: 0,
  });

  // Store the processed file for immediate UI update
  const [processedFile, setProcessedFile] = useState(null);

  // Refs
  const fileInputRef = useRef(null);
  const webcamRef = useRef(null);

  // Initialize image preview from profile
  useEffect(() => {
    const imageKey =
      config.type === "profile"
        ? profile?.photo || profile?.profile_image
        : profile?.background_image;
    setImagePreview(imageKey);
  }, [profile, config.type]);

  // Handle file selection
  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Validation
    if (file.size > 5 * 1024 * 1024) {
      showToast("Image must be less than 5MB", "error");
      return;
    }

    if (!file.type.startsWith("image/")) {
      showToast("Please select an image file", "error");
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      setSelectedImage(reader.result);
      setMode("edit");
      setImagePreview(reader.result);
    };
    reader.readAsDataURL(file);
  };

  // Handle camera capture
  const handleCapture = async () => {
    if (webcamRef.current) {
      const imageSrc = webcamRef.current.getScreenshot();
      if (imageSrc) {
        setSelectedImage(imageSrc);
        setShowCamera(false);
        setMode("edit");
        setImagePreview(imageSrc);
      }
    }
  };

  // Handle crop completion
  const onCropComplete = (croppedArea, croppedAreaPixels) => {
    setCroppedAreaPixels(croppedAreaPixels);
  };

  // Process image: crop → apply filters → compress
  const processImage = async () => {
    if (!selectedImage || !croppedAreaPixels) {
      showToast("Please select and crop an image first", "error");
      return null;
    }

    try {
      // 1. Crop the image
      const croppedImage = await getCroppedImage(
        selectedImage,
        croppedAreaPixels,
        rotation,
      );

      // 2. Apply filters to cropped image
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      const img = new Image();

      return new Promise((resolve) => {
        img.onload = async () => {
          const scale = Math.min(
            config.maxWidth / img.width,
            config.maxHeight / img.height,
            1,
          );
          canvas.width = Math.max(1, Math.round(img.width * scale));
          canvas.height = Math.max(1, Math.round(img.height * scale));

          if (ctx) {
            ctx.filter = `brightness(${filters.brightness}%) contrast(${filters.contrast}%) saturate(${filters.saturation}%)`;
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = "high";
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

            canvas.toBlob(async (blob) => {
              if (blob) {
                const rawFile = new File([blob], `${config.type}-image.jpg`, {
                  type: "image/jpeg",
                  lastModified: Date.now(),
                });
                const compressedFile = await optimizeImageFile(rawFile, {
                  maxSizeMB: config.type === "profile" ? 1.5 : 3,
                  maxWidthOrHeight: Math.max(config.maxWidth, config.maxHeight),
                  initialQuality: config.type === "profile" ? 0.92 : 0.9,
                });

                const blobUrl = URL.createObjectURL(compressedFile);
                const nextProcessedFile = {
                  file: compressedFile,
                  previewUrl: blobUrl,
                };
                setProcessedFile(nextProcessedFile);

                resolve(nextProcessedFile);
                if (croppedImage.url?.startsWith("blob:")) {
                  window.setTimeout(() => URL.revokeObjectURL(croppedImage.url), 1000);
                }
              }
            }, "image/jpeg");
          }
        };
        img.src = croppedImage.url;
      });
    } catch (error) {
      console.error("Error processing image:", error);
      throw error;
    }
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    if (e) e.preventDefault();

    try {
      setUploading(true);

      const processedImage = await processImage();
      if (!processedImage?.file) {
        setUploading(false);
        return;
      }

      const formData = new FormData();
      formData.append(config.outputKey, processedImage.file);
      formData.append("reset_photo", false);

      // Immediately update local UI with the processed image preview
      if (processedImage.previewUrl) {
        setImagePreview(processedImage.previewUrl);
      }

      // Call the update function from parent
      await onUpdate({
        data: formData,
        previewUrl: processedImage.previewUrl,
        type: config.type,
      });

      // Show success toast
      //   showToast(`${config.type === 'profile' ? 'Profile' : 'Cover'} image updated successfully!`, 'success');

      // Close the modal after a brief delay for UX
      setUploading(false);
      onClose();
    } catch (error) {
      console.error("Error in handleSubmit:", error);
      showToast("Failed to update image", "error");
      setUploading(false);

      // Revert to previous image on error
      const imageKey =
        config.type === "profile"
          ? profile?.photo || profile?.profile_image
          : profile?.background_image;
      setImagePreview(imageKey);
    }
  };

  // Reset to initial state
  const handleReset = () => {
    setMode("select");
    setSelectedImage(null);
    setImagePreview(
      config.type === "profile"
        ? profile?.photo || profile?.profile_image
        : profile?.background_image,
    );
    setShowCamera(false);
    setCrop({ x: 0, y: 0 });
    setZoom(1);
    setRotation(0);
    setAspect(config.defaultAspect);
    setCroppedAreaPixels(null);
    setFilters({
      brightness: 100,
      contrast: 100,
      saturation: 100,
      blur: 0,
    });
    setUploading(false);
    setProcessedFile(null);
  };

  // Toggle camera
  const toggleCamera = () => {
    if (showCamera) {
      setShowCamera(false);
    } else {
      setShowCamera(true);
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (processedFile?.previewUrl) {
        URL.revokeObjectURL(processedFile.previewUrl);
      }
    };
  }, [processedFile]);

  if (!isOpen) return null;

  // Combined loading state
  const isLoading = isUpdating || uploading;

  const editorConfig = {
    ...config,
    filterPresets: FILTER_PRESETS,
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center">
        <Motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm"
          onClick={onClose}
        />

        <Motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative bg-white rounded-2xl shadow-xl w-full max-w-xl overflow-hidden"
        >
          {renderHeader &&
            renderHeader({
              mode,
              onClose,
              config: editorConfig,
            })}

          <div className="p-6">
            <AnimatePresence mode="wait">
              {/* Source Selection Mode */}
              {mode === "select" &&
                renderSourceSelector &&
                renderSourceSelector({
                  imagePreview,
                  fileInputRef,
                  onFileSelect: () => fileInputRef.current?.click(),
                  onCameraSelect: () => setMode("camera"),
                  config: editorConfig,
                })}

              {/* Camera Mode */}
              {mode === "camera" &&
                renderCameraView &&
                renderCameraView({
                  showCamera,
                  webcamRef,
                  onCapture: handleCapture,
                  onToggleCamera: toggleCamera,
                  onBack: () => setMode("select"),
                  config: editorConfig,
                })}

              {/* Edit Mode */}
              {mode === "edit" &&
                selectedImage &&
                renderCropperView &&
                renderCropperView({
                  selectedImage,
                  crop,
                  zoom,
                  rotation,
                  aspect,
                  onCropChange: setCrop,
                  onZoomChange: setZoom,
                  onRotationChange: setRotation,
                  onAspectChange: setAspect,
                  onCropComplete,
                  onNext: () => setMode("filters"),
                  onReset: handleReset,
                  config: editorConfig,
                })}

              {/* Filters Mode */}
              {mode === "filters" &&
                renderFiltersPanel &&
                renderFiltersPanel({
                  imagePreview,
                  filters,
                  onFilterChange: setFilters,
                  onBack: () => setMode("edit"),
                  onResetFilters: () =>
                    setFilters({
                      brightness: 100,
                      contrast: 100,
                      saturation: 100,
                      blur: 0,
                    }),
                  config: editorConfig,
                })}
            </AnimatePresence>

            {/* Footer Actions */}
            {(mode === "edit" || mode === "filters") &&
              renderFooter &&
              renderFooter({
                onCancel: handleReset,
                onSubmit: handleSubmit,
                isUpdating: isLoading,
                isDisabled: !selectedImage || isLoading,
                config: editorConfig,
              })}

            {/* Hidden file input */}
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              capture="environment"
              onChange={handleFileSelect}
              className="hidden"
              disabled={isLoading}
            />

            {/* Loading overlay */}
            {isLoading && (
              <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex items-center justify-center z-10">
                <div className="text-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gaon-green mx-auto mb-4"></div>
                  <p className="text-gray-700 font-medium">
                    Uploading your image...
                  </p>
                  <p className="text-sm text-gray-500 mt-1">Please wait</p>
                </div>
              </div>
            )}
          </div>
        </Motion.div>
      </div>
    </div>
  );
};

export default BaseImageEditor;
