// pages/audio/components/AudioMuteButton.jsx
import React from "react";
import { Volume2, VolumeX } from "lucide-react";

const AudioMuteButton = React.memo(({ isMuted, onToggleMute }) => {
  return (
    <button
      onClick={onToggleMute}
      className="absolute bottom-4 left-4 p-2 bg-black/50 text-white rounded-full backdrop-blur-sm hover:bg-black/70 transition-colors z-10"
      aria-label={isMuted ? "Unmute" : "Mute"}
    >
      {isMuted ? (
        <VolumeX className="w-5 h-5" />
      ) : (
        <Volume2 className="w-5 h-5" />
      )}
    </button>
  );
});

AudioMuteButton.displayName = 'AudioMuteButton';

export default AudioMuteButton;