import axios from "axios";
import { API_BASE_URL, TOKEN_KEYS } from "./env.js";
import { showToast } from "../utils/toast.js";

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 120000,
});

const clearLocalAuth = () => {
  if (typeof localStorage === "undefined") return;
  localStorage.removeItem(TOKEN_KEYS.ACCESS_TOKEN);
  localStorage.removeItem(TOKEN_KEYS.REFRESH_TOKEN);
  localStorage.removeItem(TOKEN_KEYS.USER_DATA);
};

const notifyAuthInvalid = () => {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new Event("gaongram:auth-invalid"));
  }
};

api.interceptors.request.use(
  (config) => {
    const token =
      typeof localStorage !== "undefined"
        ? localStorage.getItem(TOKEN_KEYS.ACCESS_TOKEN)
        : null;
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error),
);

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config || {};

    if (originalRequest.url?.includes("/logout")) {
      return Promise.reject(error);
    }

    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      const refreshToken =
        typeof localStorage !== "undefined"
          ? localStorage.getItem(TOKEN_KEYS.REFRESH_TOKEN)
          : null;

      if (!refreshToken) {
        clearLocalAuth();
        notifyAuthInvalid();
        return Promise.reject(error);
      }

      try {
        const response = await axios.post(`${API_BASE_URL}/token/refresh/`, {
          refresh: refreshToken,
        });
        const { access } = response.data;
        if (typeof localStorage !== "undefined") {
          localStorage.setItem(TOKEN_KEYS.ACCESS_TOKEN, access);
        }
        originalRequest.headers = originalRequest.headers || {};
        originalRequest.headers.Authorization = `Bearer ${access}`;
        return api(originalRequest);
      } catch (refreshError) {
        clearLocalAuth();
        notifyAuthInvalid();
        return Promise.reject(refreshError);
      }
    }

    if (error.response && error.response.status !== 401) {
      const { status, data } = error.response;
      switch (status) {
        case 400:
          showToast(data.message || "Bad request", "error");
          break;
        case 403:
          showToast("You do not have permission", "error");
          break;
        case 404:
          showToast("Resource not found", "error");
          break;
        case 500:
          showToast("Server error. Please try again later.", "error");
          break;
        default:
          showToast(data.message || "An error occurred", "error");
      }
    } else if (error.request) {
      showToast("Network error. Please check your connection.", "error");
    }

    return Promise.reject(error);
  },
);

export default api;