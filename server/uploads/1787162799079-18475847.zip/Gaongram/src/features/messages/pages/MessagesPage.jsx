import React, { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import {
  Search,
  Plus,
  MessageCircle,
  Sparkles,
  Pencil,
  Mail,
  MessageSquare,
  MessageCircleMore,
} from "lucide-react";
import { motion } from "framer-motion";
import { AnimatePresence } from "framer-motion";
import { useChatList } from "../../../hooks/useChatList";
import { useChatStore } from "../../../store/chatStore";
import Avatar from "../../../components/common/Avatar";
import MessageSkeleton from "../components/MessageSkeleton";
import { useTranslation } from "react-i18next";
import Seo from "../../../components/seo/Seo.jsx";
import { buildStaticPageSeo } from "../../../seo/seoBuilders.js";
import ChatScreen from "./ChatScreen";
import { useNavigate } from "react-router-dom";
import { BiSolidMessageRoundedDots } from "react-icons/bi";

// ── Resize Constants ──
const SIDEBAR_MIN_WIDTH = 120;
const SIDEBAR_DEFAULT_WIDTH = 320;
const SIDEBAR_MAX_WIDTH = 580;
const STORAGE_KEY = "messages-sidebar-width";

/** Custom hook: detects if viewport is >= given breakpoint (default 1024) */
function useResponsive(breakpoint = 1024) {
  const [isDesktop, setIsDesktop] = useState(false);

  useEffect(() => {
    const mql = window.matchMedia(`(min-width: ${breakpoint}px)`);
    setIsDesktop(mql.matches);

    const handler = (e) => setIsDesktop(e.matches);
    mql.addEventListener("change", handler);
    return () => mql.removeEventListener("change", handler);
  }, [breakpoint]);

  return isDesktop;
}

const MessagesPage = () => {
  const { chatList, isLoading, markChatAsRead } = useChatList();
  const { unreadCounts } = useChatStore();
  const navigate = useNavigate();
  const { t } = useTranslation();

  // ── Responsive state ──
  const isDesktop = useResponsive(1024);

  // ── Search & Tabs ──
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");
  const [showSearch, setShowSearch] = useState(false);

  // ── Sidebar width state (persisted) ──
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const val = parseFloat(saved);
        if (
          !isNaN(val) &&
          val >= SIDEBAR_MIN_WIDTH &&
          val <= SIDEBAR_MAX_WIDTH
        ) {
          return val;
        }
      }
    } catch (e) {}
    return SIDEBAR_DEFAULT_WIDTH;
  });

  // ── Resize tracking ──
  const [isResizing, setIsResizing] = useState(false);
  const startXRef = useRef(0);
  const startWidthRef = useRef(SIDEBAR_DEFAULT_WIDTH);

  // ── Selected user for desktop split layout ──
  const [selectedUserId, setSelectedUserId] = useState(null);

  // ── Resize event handlers ──
  useEffect(() => {
    if (!isResizing) return;

    const handleMouseMove = (e) => {
      const diff = e.clientX - startXRef.current;
      const newWidth = Math.min(
        Math.max(startWidthRef.current + diff, SIDEBAR_MIN_WIDTH),
        SIDEBAR_MAX_WIDTH,
      );
      setSidebarWidth(newWidth);
    };

    const handleMouseUp = (e) => {
      const diff = e.clientX - startXRef.current;
      const finalWidth = Math.min(
        Math.max(startWidthRef.current + diff, SIDEBAR_MIN_WIDTH),
        SIDEBAR_MAX_WIDTH,
      );
      setSidebarWidth(finalWidth);
      localStorage.setItem(STORAGE_KEY, finalWidth);
      setIsResizing(false);
    };

    document.body.style.cursor = "col-resize";
    document.body.style.userSelect = "none";
    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);

    return () => {
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
    };
  }, [isResizing]);

  // ── Resize start ──
  const startResize = (e) => {
    e.preventDefault(); // prevent text selection / drag ghost
    startXRef.current = e.clientX;
    startWidthRef.current = sidebarWidth;
    setIsResizing(true);
  };

  // ── Double‑click reset ──
  const resetSidebarWidth = () => {
    setSidebarWidth(SIDEBAR_DEFAULT_WIDTH);
    localStorage.setItem(STORAGE_KEY, SIDEBAR_DEFAULT_WIDTH);
  };

  // ── Keyboard adjustment (accessible) ──
  const handleResizeKeyDown = (e) => {
    if (e.key === "ArrowLeft" || e.key === "ArrowRight") {
      e.preventDefault();
      const step = 20;
      const direction = e.key === "ArrowLeft" ? -1 : 1;
      const newWidth = Math.min(
        Math.max(sidebarWidth + direction * step, SIDEBAR_MIN_WIDTH),
        SIDEBAR_MAX_WIDTH,
      );
      setSidebarWidth(newWidth);
      localStorage.setItem(STORAGE_KEY, newWidth);
    }
  };

  // ── Filtered chat list ──
  const filteredChats = chatList.filter((chat) => {
    const matchesSearch = chat.full_name
      ?.toLowerCase()
      .includes(searchQuery.toLowerCase());
    const unreadCount = unreadCounts.get(chat.id) || 0;

    if (activeTab === "unread") return matchesSearch && unreadCount > 0;
    if (activeTab === "requests") return false; // no API yet
    return matchesSearch;
  });

  const unreadChats = chatList.filter(
    (chat) => (unreadCounts.get(chat.id) || 0) > 0,
  ).length;

  const emptyStateData = {
    all: {
      icon: "💬",
      title: "No Messages Yet",
      desc: "Start a conversation and connect with people.",
    },
    unread: {
      icon: "📩",
      title: "No Unread Messages",
      desc: "You're all caught up. No unread chats.",
    },
    requests: {
      icon: "✨",
      title: "No Message Requests",
      desc: "When someone sends you a request, it will appear here.",
    },
  };

  const formatTime = (timeStr) => (timeStr ? timeStr : "");

  if (isLoading) {
    return (
      <>
        <Seo {...buildStaticPageSeo("messages")} />
        <div className="h-full">
          {[1, 2, 3, 4].map((i) => (
            <MessageSkeleton key={i} />
          ))}
        </div>
      </>
    );
  }

  return (
    <>
      <Seo {...buildStaticPageSeo("messages")} />
      <div className="h-screen bg-background dark:bg-background-dark text-foreground dark:text-foreground-dark flex overflow-hidden">
        {/* ── LEFT PANEL (sidebar) ── */}
        <div
          style={{
            width: isDesktop ? `${sidebarWidth}px` : "100%",
            minWidth: isDesktop ? `${sidebarWidth}px` : "100%",
          }}
          className="flex lg:flex bg-background dark:bg-background-dark border-r border-border dark:border-border-dark flex-col relative"
        >
          {/* HEADER (unchanged) */}
          <div className="px-2 pt-2 pb-2 border-b border-border dark:border-border-dark">
            <div className="flex items-center justify-between">
              <div className="flex flex-col leading-tight">
                <h1 className="text-[28px] font-bold text-foreground dark:text-foreground-dark">
                  {t("messages")}
                </h1>
                <p className="text-[13px] text-foreground/60 dark:text-foreground-dark/60">
                  Stay connected with your friends
                </p>
              </div>
              <button
                onClick={() => setShowSearch(!showSearch)}
                className="w-9 h-9 rounded-full border border-border dark:border-border-dark bg-background dark:bg-background-dark flex items-center justify-center hover:bg-muted dark:hover:bg-muted-dark transition-all"
              >
                <Search size={15} />
              </button>
            </div>
            <div className="relative">
              <AnimatePresence>
                {showSearch && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                    className="absolute left-0 right-0 top-2 z-50"
                  >
                    <div className="relative bg-background dark:bg-background-dark rounded-md">
                      <Search
                        size={16}
                        className="absolute left-4 top-1/2 -translate-y-1/2 text-foreground/60 dark:text-foreground-dark/60"
                      />
                      <input
                        type="text"
                        placeholder="Search messages..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full h-10 pl-11 pr-4 rounded-xl border border-border dark:border-border-dark bg-background dark:bg-background-dark text-sm outline-none focus:ring-2 focus:ring-[#00684A]"
                      />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            <div
              className={`flex gap-2 ${showSearch ? "mt-16" : "mt-2"} transition-all`}
            >
              <button
                onClick={() => setActiveTab("all")}
                className={`px-2 h-7 rounded-full text-xs font-medium ${
                  activeTab === "all"
                    ? "bg-primary text-muted"
                    : "border border-border dark:border-border-dark text-foreground dark:text-foreground-dark hover:bg-muted dark:hover:bg-muted-dark"
                }`}
              >
                All
              </button>
              <button
                onClick={() => setActiveTab("unread")}
                className={`px-2 h-7 rounded-full text-xs font-medium ${
                  activeTab === "unread"
                    ? "bg-primary text-muted"
                    : "border border-border dark:border-border-dark text-foreground dark:text-foreground-dark hover:bg-muted dark:hover:bg-muted-dark"
                }`}
              >
                <>
                  Unread
                  {unreadChats > 0 && (
                    <span className="ml-1 text-[10px] bg-white/20 px-1.5 py-0.5 rounded-full">
                      {unreadChats}
                    </span>
                  )}
                </>
              </button>
              <button
                onClick={() => setActiveTab("requests")}
                className={`px-2 h-7 rounded-full text-xs font-medium ${
                  activeTab === "requests"
                    ? "bg-primary text-muted"
                    : "border border-border dark:border-border-dark text-foreground dark:text-foreground-dark hover:bg-muted dark:hover:bg-muted-dark"
                }`}
              >
                Requests
              </button>
            </div>
          </div>

          {/* CHAT LIST (unchanged except for navigation decision) */}
          <div className="flex-1 overflow-y-auto px-2 py-2">
            {filteredChats.length === 0 ? (
              <div className="h-full flex items-center justify-center">
                <div className="text-center px-2">
                  <motion.div className="relative mx-auto w-fit">
                    <Sparkles
                      size={18}
                      className="absolute -top-5 left-1/2 -translate-x-1/2 text-yellow-500"
                    />
                    <Pencil
                      size={18}
                      className="absolute -left-8 top-5 text-emerald-500"
                    />
                    <MessageSquare
                      size={18}
                      className="absolute -right-8 top-5 text-violet-500"
                    />
                    <Mail
                      size={18}
                      className="absolute -bottom-5 left-0 text-pink-500"
                    />
                    <MessageCircle
                      size={18}
                      className="absolute -bottom-5 right-0 text-sky-500"
                    />
                    <div className="relative w-20 h-20 rounded-full bg-gradient-to-br from-[#00A878] to-[#00684A] flex items-center justify-center shadow-xl">
                      <MessageCircle size={42} className="text-white" />
                    </div>
                  </motion.div>

                  <h3 className="mt-8 text-xl font-bold text-foreground dark:text-foreground-dark">
                    {emptyStateData[activeTab].title}
                  </h3>
                  <p className="mt-2 text-sm text-foreground/60 dark:text-foreground-dark/60 max-w-[260px] mx-auto">
                    {emptyStateData[activeTab].desc}
                  </p>
                </div>
              </div>
            ) : (
              filteredChats.map((chat, index) => {
                const unreadCount = unreadCounts.get(chat.id) || 0;
                return (
                  <div
                    key={chat.user_id}
                    onClick={() => {
                      markChatAsRead(chat.user_id);
                      // Preserve existing behaviour: navigate on mobile, select on desktop
                      if (window.innerWidth < 1024) {
                        navigate(`/messages/${chat.user_id}`);
                      } else {
                        setSelectedUserId(chat.user_id);
                      }
                    }}
                  >
                    <motion.div
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.03 }}
                      className={`group flex items-center gap-3 px-2 py-1 rounded-xl cursor-pointer transition-all duration-200 mb-1 ${
                        unreadCount > 0
                          ? "bg-primary/30 dark:bg-primary/20"
                          : "bg-muted dark:bg-muted-dark"
                      } hover:bg-card dark:hover:bg-dark-card hover:shadow-sm`}
                    >
                      <Avatar
                        src={chat.profile_image}
                        alt={chat.full_name}
                        size="medium"
                        isStory={true}
                      />
                      <div className="flex-1 min-w-0 leading-tight">
                        <div className="flex justify-between items-start">
                          <h3 className="font-semibold text-[15px] truncate text-foreground dark:text-foreground-dark">
                            {chat.full_name}
                          </h3>
                          <span className="text-[11px] text-foreground/60 dark:text-foreground-dark/60 ml-2">
                            {formatTime(chat.last_message_time)}
                          </span>
                        </div>
                        <p className="text-[13px] text-foreground/60 dark:text-foreground-dark/60 truncate mt-1">
                          {chat.last_message || "Start conversation"}
                        </p>
                      </div>
                      {unreadCount > 0 && (
                        <div className="min-w-[24px] h-6 px-2 rounded-full bg-primary text-muted text-xs flex items-center justify-center">
                          {unreadCount}
                        </div>
                      )}
                    </motion.div>
                  </div>
                );
              })
            )}
          </div>

          {/* ── RESIZE HANDLE (desktop only) ── */}
          {isDesktop && (
            <div
              onMouseDown={startResize}
              onDoubleClick={resetSidebarWidth}
              onKeyDown={handleResizeKeyDown}
              role="separator"
              aria-valuenow={sidebarWidth}
              aria-valuemin={SIDEBAR_MIN_WIDTH}
              aria-valuemax={SIDEBAR_MAX_WIDTH}
              aria-label="Resize sidebar"
              tabIndex={0}
              className="absolute top-0 right-0 w-3 h-full cursor-col-resize z-50 group outline-none"
            >
              <div
                className={`absolute right-0 top-0 w-[1px] h-full transition-colors ${
                  isResizing
                    ? "bg-primary/80"
                    : "bg-transparent group-hover:bg-primary/80"
                }`}
              />
            </div>
          )}
        </div>

        {/* ── RIGHT PANEL ── */}
        <div className="hidden lg:flex flex-1 relative overflow-hidden bg-background dark:bg-background-dark">
          {selectedUserId ? (
            <ChatScreen
              key={selectedUserId}
              userId={selectedUserId}
              userData={chatList.find(
                (u) => Number(u.user_id) === Number(selectedUserId),
              )}
            />
          ) : (
            <>
              <div className="absolute top-[-80px] right-[-80px] w-[420px] h-[280px] bg-muted dark:bg-muted-dark rounded-bl-[200px] rounded-tl-[120px] rounded-br-[120px]" />
              <div className="absolute bottom-[-160px] left-[60px] w-[700px] h-[320px] rounded-[50%] bg-gradient-to-r from-[#F7EAF5] via-[#FAF4FD] to-transparent dark:bg-gradient-to-r dark:from-muted-dark dark:via-muted-dark/50 dark:to-transparent" />
              <div className="relative z-10 flex flex-col items-center justify-center w-full">
                <div className="relative">
                  <div className="absolute -top-6 -left-8 text-[#D7A94B] text-[28px]">
                    ✦
                  </div>
                  <div className="absolute right-[-50px] top-[60px] text-[#D7A94B] text-[26px]">
                    ✦
                  </div>
                  <div className="absolute left-[-25px] top-[90px] w-3 h-3 rounded-full bg-[#B7DCCB]" />
                  <div className="absolute left-[15px] top-[5px] w-2 h-2 rounded-full bg-[#C8DAD2]" />
                  <div className="absolute right-[20px] top-[10px] w-3 h-3 rounded-full bg-[#D3E6DB]" />
                  <div className="absolute right-[-30px] top-[110px] w-3 h-3 rounded-full bg-[#B884F4]" />
                  <div className="absolute right-[-35px] top-[170px] w-2 h-2 rounded-full bg-[#D7A94B]" />
                  <div className="relative">
                    <MessageCircleMore
                      className="w-[180px] h-[180px] text-muted dark:text-muted-dark flex items-center justify-center"
                      style={{
                        fill: "url(#messageGradient1)",
                      }}
                    />
                    <svg width="0" height="0">
                      <defs>
                        <linearGradient
                          id="messageGradient1"
                          x1="0%"
                          y1="0%"
                          x2="100%"
                          y2="100%"
                        >
                          <stop offset="0%" stopColor="#00A878" />
                          <stop offset="50%" stopColor="#008060" />
                          <stop offset="100%" stopColor="#00684A" />
                        </linearGradient>
                      </defs>
                    </svg>
                  </div>
                  <div className=" absolute right-[-25px] bottom-[-15px] w-[120px] h-[120px] flex items-center justify-center">
                    <MessageCircleMore
                      className="w-full h-full scale-x-[-1] text-muted dark:text-muted-dark"
                      style={{
                        fill: "url(#messageGradient)",
                      }}
                    />

                    <svg width="0" height="0">
                      <defs>
                        <linearGradient
                          id="messageGradient"
                          x1="0%"
                          y1="0%"
                          x2="100%"
                          y2="100%"
                        >
                          <stop offset="0%" stopColor="#F03E91" />
                          <stop offset="50%" stopColor="#FF7C3E" />
                          <stop offset="100%" stopColor="#9D3EFF" />
                        </linearGradient>
                      </defs>
                    </svg>
                  </div>
                </div>
                <h2 className="mt-14 text-[22px] font-bold text-foreground dark:text-foreground-dark">
                  No conversation selected
                </h2>
                <p className="mt-4 text-center text-mutedForeground dark:text-mutedForeground-dark text-[16px] leading-7">
                  Select a chat from the list to start messaging
                  <br />
                  or start a new conversation.
                </p>
                <button className="mt-8 h-[48px] px-8 rounded-xl bg-primary/90 text-white font-medium flex items-center gap-3 hover:bg-primary">
                  <div className="w-7 h-7 rounded-full border-2 border-white flex items-center justify-center">
                    <Plus size={14} strokeWidth={2.5} />
                  </div>
                  <span>Start a new conversation</span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default MessagesPage;
