import { getSiteUrl } from "../metadata/config.mjs";

export const PRIVATE_DISALLOW_PATHS = [
  "/login",
  "/register",
  "/messages",
  "/settings",
  "/notifications",
  "/change-password",
  "/reset-password",
  "/verify-otp",
  "/auth/google",
  "/blogs/create",
  "/blogs/edit",
];

export const renderRobotsTxt = () => {
  const disallow = PRIVATE_DISALLOW_PATHS.map((path) => `Disallow: ${path}`).join(
    "\n",
  );
  return `User-agent: *
Allow: /
${disallow}

User-agent: Googlebot
Allow: /
${disallow}

Sitemap: ${getSiteUrl()}/sitemap.xml
`;
};

