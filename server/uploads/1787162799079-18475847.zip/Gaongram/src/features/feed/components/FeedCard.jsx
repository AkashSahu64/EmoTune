import React, { useRef, useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import {
  Heart,
  MessageCircle,
  Send,
  Bookmark,
  MoreVertical,
  Play,
  Volume2,
  VolumeX,
} from "lucide-react";
import Hls from "hls.js";
import { useAuthStore } from "../../../store/authStore.js";
import { useUIStore } from "../../../store/uiStore.js";
import { useMediaStore } from "../../../store/mediaStore.js";
import { useVisibility } from "../../../hooks/useVisibility.js";
import { formatTime, formatNumber } from "../../../utils/formatTime.js";
import { showError, showSuccess } from "../../../utils/toast.js";
import Avatar from "../../../components/common/Avatar.jsx";
import Button from "../../../components/common/Button.jsx";
import FollowButton from "../../../components/common/FollowButton.jsx";
import MusicMarquee from "../../../components/music/MusicMarquee.jsx";
import { getMusicMetadata } from "../../../components/music/musicMetadata.js";

const FeedCard = ({ post, onUpdate }) => {
  const { isAuthenticated, user } = useAuthStore();
  const { openModal } = useUIStore();
  const {
    activePostId,
    isMuted,
    toggleMute,
    shouldPlay,
    shouldMute,
    setActivePost,
    clearActivePost,
  } = useMediaStore();

  const videoRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLiked, setIsLiked] = useState(post.is_liked || false);
  const [likeCount, setLikeCount] = useState(post.likes_count || 0);
  const [commentCount, setCommentCount] = useState(post.comments_count || 0);
  const [isSaved, setIsSaved] = useState(post.is_saved || false);
  const [showFullCaption, setShowFullCaption] = useState(false);

  const [isFollowing, setIsFollowing] = useState(
    post.user?.is_following || false,
  );

  const { elementRef, isVisible } = useVisibility(post.id, {
    threshold: 0.6,
  });

  useEffect(() => {
    if (isVisible && activePostId !== post.id) {
      setActivePost(post.id);
    }
  }, [isVisible, post.id]);

  const isVideo =
    post.media_type === "video" ||
    (Array.isArray(post.videos) && post.videos.length > 0);

  const isImage =
    post.media_type === "image" ||
    (Array.isArray(post.images) && post.images.length > 0);
  const shouldTruncate = post.caption?.length > 150;

  const handleFollowChange = (newFollowState) => {
    setIsFollowing(newFollowState);
    if (onUpdate) {
      onUpdate(post.id, {
        ...post,
        user: {
          ...post.user,
          is_following: newFollowState,
        },
      });
    }
  };

  useEffect(() => {
    if (!videoRef.current || !isVideo) return;
    const video = videoRef.current;
    const isActive = activePostId === post.id;

    if (isVisible) {
      video.muted = true;
      const playPromise = video.play();
      if (playPromise !== undefined) {
        playPromise.catch(() => {});
      }
    } else {
      video.pause();
    }
  }, [activePostId, isVisible, post.id, isVideo]);

  useEffect(() => {
    if (!videoRef.current || !isVideo) return;
    const video = videoRef.current;
    video.muted = shouldMute(post.id);
  }, [isMuted, activePostId, post.id, isVideo, shouldMute]);

  const handleLike = async () => {
    if (!isAuthenticated) {
      openModal("login");
      return;
    }
    try {
      setIsLiked(!isLiked);
      setLikeCount((prev) => (isLiked ? prev - 1 : prev + 1));
      // API call would be here
    } catch (error) {
      setIsLiked(!isLiked);
      setLikeCount((prev) => (isLiked ? prev + 1 : prev - 1));
      showError("Failed to like post");
    }
  };

  const handleSave = async () => {
    if (!isAuthenticated) {
      openModal("login");
      return;
    }
    try {
      setIsSaved(!isSaved);
      // API call would be here
    } catch (error) {
      setIsSaved(!isSaved);
      showError("Failed to save post");
    }
  };

  const handleCommentClick = () => {
    if (!isAuthenticated) {
      openModal("login");
      return;
    }
    openModal("comments", { postId: post.id });
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator
        .share({
          title: `Post by ${post.user.username}`,
          text: post.caption,
          url: window.location.origin + `/post/${post.id}`,
        })
        .catch(() => {
          navigator.clipboard.writeText(
            window.location.origin + `/post/${post.id}`,
          );
          showSuccess("Link copied to clipboard!");
        });
    } else {
      navigator.clipboard.writeText(window.location.origin + `/post/${post.id}`);
      showSuccess("Link copied to clipboard!");
    }
  };

  const handleMoreOptions = () => {
    openModal("post-options", {
      postId: post.id,
      isOwner: post.user.id === user?.id,
      authorId: post.user.id,
      post,
    });
  };

  const togglePlayVideo = () => {
    if (!videoRef.current || !isVideo) return;
    const video = videoRef.current;
    if (video.paused) {
      video
        .play()
        .then(() => setIsPlaying(true))
        .catch(console.error);
    } else {
      video.pause();
      setIsPlaying(false);
    }
  };

  const handleGlobalMuteToggle = () => {
    const newMuted = toggleMute();
    if (videoRef.current) {
      videoRef.current.muted = newMuted;
    }
  };

  const videoUrl =
    post.videos?.[0]?.hls_playlist || post.videos?.[0]?.video || null;
  const imageUrl = post.images?.[0]?.image || post.media_url || null;
  const music = getMusicMetadata(post);

  useEffect(() => {
    if (!videoRef.current || !videoUrl) return;
    const video = videoRef.current;
    if (videoUrl.endsWith(".m3u8")) {
      if (Hls.isSupported()) {
        const hls = new Hls();
        hls.loadSource(videoUrl);
        hls.attachMedia(video);
        return () => hls.destroy();
      } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
        video.src = videoUrl;
      }
    } else {
      video.src = videoUrl;
    }
  }, [videoUrl]);

  return (
    <motion.article
      ref={elementRef}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card dark:bg-card-dark rounded-xl border border-border dark:border-border-dark mb-6 overflow-hidden max-w-xl mx-auto w-full shadow-soft"
    >
      {/* Post Header */}
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex min-w-0 items-center space-x-3">
          <Link to={`/profile/${post.user.username}`}>
            <Avatar
              src={post.user.avatar}
              alt={post.user.username}
              size="medium"
              isStory={post.user.has_story}
            />
          </Link>
          <div className="min-w-0">
            <Link
              to={`/profile/${post.user.username}`}
              className="font-semibold text-foreground dark:text-foreground-dark hover:text-primary dark:hover:text-primary-light"
            >
              {post.user.username}
            </Link>
            {music && (
              <MusicMarquee
                title={music.title}
                artist={music.artist}
                className="max-w-[13rem] text-xs text-mutedForeground dark:text-mutedForeground-dark sm:max-w-[18rem]"
                textClassName="font-medium"
              />
            )}
            <p className="text-xs text-mutedForeground dark:text-mutedForeground-dark">
              {formatTime(post.created_at)}
              {post.location && <span> • {post.location}</span>}
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {post.user.id !== user?.id && (
            <FollowButton
              profileId={post.user.id}
              isFollowing={isFollowing}
              onFollowChange={handleFollowChange}
              size="small"
              variant="default"
              className="px-3 py-1 text-xs"
            />
          )}
          <button
            onClick={handleMoreOptions}
            className="p-1 text-mutedForeground dark:text-mutedForeground-dark hover:text-foreground dark:hover:text-foreground-dark"
            aria-label="More options"
          >
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Post Media */}
      <div className="relative bg-black w-full h-[360px] md:h-[420px] overflow-hidden">
        {isVideo && videoUrl ? (
          <div className="w-full h-full flex items-center justify-center bg-black">
            <video
              ref={videoRef}
              src={videoUrl}
              className="max-h-full max-w-full object-contain"
              playsInline
              muted
              loop
              preload="metadata"
              onClick={togglePlayVideo}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
            />
          </div>
        ) : isImage && imageUrl ? (
          <img
            src={imageUrl}
            alt={post.caption}
            className="w-full h-full object-contain"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-900 to-black">
            <p className="text-white/70 text-sm">Audio post</p>
          </div>
        )}
      </div>

      {/* Post Actions */}
      <div className="px-4 pt-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handleLike}
              className={`p-1 ${
                isLiked ? "text-viral-pink" : "text-mutedForeground dark:text-mutedForeground-dark hover:text-viral-pink"
              }`}
              aria-label={isLiked ? "Unlike" : "Like"}
            >
              <Heart className={`w-7 h-7 ${isLiked ? "fill-current" : ""}`} />
            </motion.button>

            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handleCommentClick}
              className="p-1 text-mutedForeground dark:text-mutedForeground-dark hover:text-foreground dark:hover:text-foreground-dark relative"
              aria-label="Comment"
            >
              <MessageCircle className="w-7 h-7" />
              {commentCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {commentCount > 9 ? "9+" : commentCount}
                </span>
              )}
            </motion.button>

            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handleShare}
              className="p-1 text-mutedForeground dark:text-mutedForeground-dark hover:text-foreground dark:hover:text-foreground-dark"
              aria-label="Share"
            >
              <Send className="w-7 h-7" />
            </motion.button>
          </div>

          <button
            onClick={handleSave}
            className={`p-1 ${
              isSaved
                ? "text-accent"
                : "text-mutedForeground dark:text-mutedForeground-dark hover:text-accent"
            }`}
            aria-label={isSaved ? "Unsave" : "Save"}
          >
            <Bookmark className={`w-7 h-7 ${isSaved ? "fill-current" : ""}`} />
          </button>
        </div>

        {likeCount > 0 && (
          <div className="mt-2">
            <p className="text-sm font-semibold text-foreground dark:text-foreground-dark">
              {formatNumber(likeCount)} like{likeCount !== 1 ? "s" : ""}
            </p>
          </div>
        )}

        {commentCount > 0 && (
          <div className="mt-2 text-sm text-mutedForeground dark:text-mutedForeground-dark">
            {commentCount} comment{commentCount !== 1 ? "s" : ""}
          </div>
        )}

        {post.caption && (
          <div className="mt-2">
            <p className="text-sm text-foreground dark:text-foreground-dark">
              <Link
                to={`/profile/${post.user.username}`}
                className="font-semibold mr-2 hover:text-primary"
              >
                {post.user.username}
              </Link>
              <span>
                {shouldTruncate && !showFullCaption
                  ? `${post.caption.substring(0, 150)}...`
                  : post.caption}
              </span>
              {shouldTruncate && (
                <button
                  onClick={() => setShowFullCaption(!showFullCaption)}
                  className="ml-1 text-primary hover:text-primary-light"
                >
                  {showFullCaption ? "Show less" : "Show more"}
                </button>
              )}
            </p>
          </div>
        )}

        <p className="mt-2 text-xs text-mutedForeground dark:text-mutedForeground-dark uppercase">
          {formatTime(post.created_at, "relative")}
        </p>
      </div>

      {/* Add Comment Input */}
      <div className="px-4 py-3 border-t border-border dark:border-border-dark">
        <form className="flex items-center" onSubmit={(e) => e.preventDefault()}>
          <input
            type="text"
            placeholder="Add a comment..."
            className="flex-1 bg-muted dark:bg-muted-dark border-none focus:ring-0 focus:outline-none text-sm rounded-l-lg px-3 py-2 text-foreground dark:text-foreground-dark placeholder-mutedForeground dark:placeholder-mutedForeground-dark"
            disabled={!isAuthenticated}
          />
          <Button
            type="submit"
            variant="ghost"
            size="small"
            disabled={!isAuthenticated}
            className="text-primary hover:text-primary-light font-semibold"
          >
            Post
          </Button>
        </form>
      </div>
    </motion.article>
  );
};

export default FeedCard;
