import {
  exportImageStoryWithMusic,
  exportStory,
  exportStoryVideo,
} from "../../story/editor/utils/exportStory.js";

export class ExportManager {
  constructor({ engine, store, config }) {
    this.engine = engine;
    this.store = store;
    this.config = config;
  }

  async export({ fileName, onProgress } = {}) {
    const canvas = this.engine?.canvas;
    if (!canvas) throw new Error("Editor canvas is not ready");

    const state = this.store.getState();
    const baseLayer = state.layers.find((layer) => layer.type === "base");
    const isVideo = baseLayer?.mediaType === "video";
    const hasMusic = !isVideo && Boolean(state.music?.audio);

    if (!hasMusic) {
      this.engine.applyFiltersToAll({ preview: false, immediate: true, rebuild: true });
    }

    if (isVideo) {
      return exportStoryVideo({
        canvas,
        engine: this.engine,
        video: this.engine.getPrimaryVideoElement(),
        aspectRatio: state.aspectRatio || this.config.aspectRatio,
        fileName,
        music: state.music,
      });
    }

    if (hasMusic) {
      return exportImageStoryWithMusic({
        canvas,
        aspectRatio: state.aspectRatio || this.config.aspectRatio,
        fileName,
        music: state.music,
        onProgress,
      });
    }

    return exportStory({
      canvas,
      aspectRatio: state.aspectRatio || this.config.aspectRatio,
      quality: this.config.exportQuality,
      fileName,
    });
  }
}

export default ExportManager;
