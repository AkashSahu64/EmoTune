// EmojiTool.jsx
import React, { useEffect, useMemo, useRef, useState } from "react";
import { Search, Sparkles } from "lucide-react";
import { LOCAL_STICKERS } from "../utils/stickerPresets.js";

/* -------------------------------------------------------------------------- */
/*  API KEYS                                                                  */
/* -------------------------------------------------------------------------- */
const GIPHY_KEY = "OdG065DqUm7iwYzY7Ra9ptLcGuPgdRAX";
// const EMOJI_API_KEY = import.meta.env.VITE_EMOJI_API_KEY || "a4b567ee06ecbcc4187d667f5ab4b6146b15cdcc";
const EMOJI_API_KEY = "a4b567ee06ecbcc4187d667f5ab4b6146b15cdcc";

/* -------------------------------------------------------------------------- */
/*  OPENMOJI STATIC DATASET (popular emojis)                                   */
/* -------------------------------------------------------------------------- */
const OPENMOJI_EMOJIS = [
  { name: "Grinning Face", hex: "1F600" },
  { name: "Smiling Face with Hearts", hex: "1F60D" },
  { name: "Face with Tears of Joy", hex: "1F602" },
  { name: "Heart", hex: "2764" },
  { name: "Thumbs Up", hex: "1F44D" },
  { name: "Clapping Hands", hex: "1F44F" },
  { name: "Fire", hex: "1F525" },
  { name: "Party Popper", hex: "1F389" },
  { name: "Rocket", hex: "1F680" },
  { name: "Star", hex: "2B50" },
  { name: "Sparkles", hex: "2728" },
  { name: "Smiling Face", hex: "263A" },
  { name: "Winking Face", hex: "1F609" },
  { name: "Kissing Face", hex: "1F618" },
  { name: "Thinking Face", hex: "1F914" },
  { name: "Smirking Face", hex: "1F60F" },
  { name: "Unamused Face", hex: "1F612" },
  { name: "Pensive Face", hex: "1F614" },
  { name: "Angry Face", hex: "1F620" },
  { name: "Crying Face", hex: "1F622" },
  { name: "Loudly Crying Face", hex: "1F62D" },
  { name: "Sleeping Face", hex: "1F634" },
  { name: "Nerd Face", hex: "1F913" },
  { name: "Cowboy Hat Face", hex: "1F920" },
  { name: "Clown Face", hex: "1F921" },
  { name: "Ghost", hex: "1F47B" },
  { name: "Alien", hex: "1F47D" },
  { name: "Robot", hex: "1F916" },
  { name: "Skull", hex: "1F480" },
  { name: "Pile of Poo", hex: "1F4A9" },
  { name: "Sun", hex: "2600" },
  { name: "Moon", hex: "1F31D" },
  { name: "Cloud", hex: "2601" },
  { name: "Rainbow", hex: "1F308" },
  { name: "Zap", hex: "26A1" },
  { name: "Water Wave", hex: "1F30A" },
  { name: "Christmas Tree", hex: "1F384" },
  { name: "Gift", hex: "1F381" },
  { name: "Trophy", hex: "1F3C6" },
  { name: "Medal", hex: "1F3C5" },
  { name: "Soccer Ball", hex: "26BD" },
  { name: "Basketball", hex: "1F3C0" },
  { name: "Musical Note", hex: "1F3B5" },
  { name: "Guitar", hex: "1F3B8" },
  { name: "Camera", hex: "1F4F7" },
  { name: "Television", hex: "1F4FA" },
  { name: "Mobile Phone", hex: "1F4F1" },
  { name: "Money Bag", hex: "1F4B0" },
  { name: "Credit Card", hex: "1F4B3" },
  { name: "Lock", hex: "1F512" },
  { name: "Key", hex: "1F511" },
  { name: "Bell", hex: "1F514" },
  { name: "Check Mark", hex: "2705" },
  { name: "Cross Mark", hex: "274C" },
  { name: "Warning", hex: "26A0" },
  { name: "Question", hex: "2753" },
  { name: "Exclamation", hex: "2757" },
  { name: "Arrow Right", hex: "27A1" },
  { name: "Recycle", hex: "267B" },
  { name: "Wheelchair Symbol", hex: "267F" },
  { name: "Peace Symbol", hex: "262E" },
  { name: "Yin Yang", hex: "262F" },
];

/* -------------------------------------------------------------------------- */
/*  HELPER: convert emoji character to PNG data URL                            */
/* -------------------------------------------------------------------------- */
const emojiToDataURL = (emoji, size = 64) => {
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  ctx.font = `${size * 0.8}px "Apple Color Emoji", "Segoe UI Emoji", "Noto Color Emoji", sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(emoji, size / 2, size / 2);
  return canvas.toDataURL("image/png");
};

/* -------------------------------------------------------------------------- */
/*  PROVIDER FETCH FUNCTIONS                                                  */
/* -------------------------------------------------------------------------- */

/**
 * GIPHY – always animated GIFs
 */
const fetchGiphy = async (query) => {
  if (!GIPHY_KEY || !query.trim()) return [];
  const url = `https://api.giphy.com/v1/stickers/search?api_key=${GIPHY_KEY}&q=${encodeURIComponent(
    query.trim(),
  )}&limit=24&rating=g`;
  try {
    const res = await fetch(url);
    if (!res.ok) return [];
    const json = await res.json();
    return (json.data || [])
      .map((item) => ({
        id: item.id,
        title: item.title || "GIPHY sticker",
        source: "giphy",
        url: item.images?.fixed_height?.url || item.images?.original?.url, // animated only
        preview:
          item.images?.fixed_height?.url ||
          item.images?.fixed_width_small?.url ||
          item.images?.fixed_height_small?.url,
        type: "gif",
      }))
      .filter((s) => s.url);
  } catch {
    return [];
  }
};

/**
 * OpenMoji – static SVG emojis from the predefined list
 */
const fetchOpenMoji = (query) => {
  const q = query.trim().toLowerCase();
  if (!q) return OPENMOJI_EMOJIS.map(createOpenmojiSticker);
  const filtered = OPENMOJI_EMOJIS.filter((e) =>
    e.name.toLowerCase().includes(q),
  );
  return filtered.map(createOpenmojiSticker);
};

const createOpenmojiSticker = (emoji) => ({
  id: `openmoji-${emoji.hex}`,
  title: emoji.name,
  source: "openmoji",
  url: `https://openmoji.org/data/color/svg/${emoji.hex}.svg`,
  preview: `https://openmoji.org/data/color/svg/${emoji.hex}.svg`,
  type: "svg",
});

/**
 * Emoji API – PNG emojis (requires API key)
 * Fetches emoji characters and converts them to PNG data URLs.
 */
const fetchEmojiAPI = async (query) => {
  if (!EMOJI_API_KEY || !query.trim()) return [];
  const url = `https://emoji-api.com/emojis?search=${encodeURIComponent(
    query.trim(),
  )}&access_key=${EMOJI_API_KEY}`;
  try {
    const res = await fetch(url);
    if (!res.ok) return [];
    const json = await res.json();
    return (json || [])
      .map((item) => {
        const character = item.character;
        if (!character) return null;
        const dataUrl = emojiToDataURL(character);
        return {
          id: `emoji-api-${item.slug || item.codePoint}`,
          title: item.unicodeName || character,
          source: "emoji-api",
          url: dataUrl,
          preview: dataUrl,
          type: "png",
        };
      })
      .filter(Boolean);
  } catch {
    return [];
  }
};

/**
 * Iconify – rich SVG icon search
 */
const fetchIconify = async (query) => {
  if (!query.trim()) return [];
  const url = `https://api.iconify.design/search?query=${encodeURIComponent(
    query.trim(),
  )}&limit=24`;
  try {
    const res = await fetch(url);
    if (!res.ok) return [];
    const json = await res.json();
    const icons = json.icons || [];
    return icons.map((iconId) => ({
      id: `iconify-${iconId}`,
      title: iconId,
      source: "iconify",
      url: `https://api.iconify.design/${iconId}.svg`,
      preview: `https://api.iconify.design/${iconId}.svg`,
      type: "svg",
    }));
  } catch {
    return [];
  }
};

/**
 * Local stickers – already provided as SVG data URIs
 */
const fetchLocal = (query) => {
  const q = query.trim().toLowerCase();
  if (!q) return LOCAL_STICKERS.map((s) => ({ ...s, type: "svg" }));
  return LOCAL_STICKERS.filter((s) => s.title.toLowerCase().includes(q)).map(
    (s) => ({ ...s, type: "svg" }),
  );
};

/* -------------------------------------------------------------------------- */
/*  MAIN COMPONENT                                                            */
/* -------------------------------------------------------------------------- */
const EmojiTool = ({ engine }) => {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [sourceLabel, setSourceLabel] = useState("LOCAL");
  const [isLoading, setIsLoading] = useState(false);
  const cacheRef = useRef(new Map());

  const trimmedQuery = useMemo(() => query.trim(), [query]);

  useEffect(() => {
    // initial load with empty query – show local + openmoji
    if (!trimmedQuery && results.length === 0) {
      const merged = shuffleLimited(
        [...fetchOpenMoji(trimmedQuery), ...fetchLocal(trimmedQuery)],
        60,
      );
      setResults(merged);
      setSourceLabel("LOCAL + OPENMOJI");
      return;
    }

    // return cached results
    if (cacheRef.current.has(trimmedQuery)) {
      const cached = cacheRef.current.get(trimmedQuery);
      setResults(cached.data);
      setSourceLabel(cached.label);
      return;
    }

    let cancelled = false;
    const run = async () => {
      setIsLoading(true);

      const providers = [
        fetchGiphy(trimmedQuery).then((d) => d),
        Promise.resolve(fetchOpenMoji(trimmedQuery)),
        fetchEmojiAPI(trimmedQuery),
        fetchIconify(trimmedQuery),
        Promise.resolve(fetchLocal(trimmedQuery)),
      ];

      const settled = await Promise.allSettled(providers);

      const fulfilled = settled
        .filter((s) => s.status === "fulfilled")
        .flatMap((s) => s.value)
        .filter(Boolean);

      const merged = shuffleLimited(fulfilled, 60);
      const activeSources = [...new Set(fulfilled.map((s) => s.source))]
        .join(" + ")
        .toUpperCase();

      if (!cancelled) {
        setResults(merged);
        setSourceLabel(activeSources || "STICKERS");
        setIsLoading(false);
        cacheRef.current.set(trimmedQuery, {
          data: merged,
          label: activeSources,
        });
      }
    };

    const timer = setTimeout(run, 250);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [trimmedQuery]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleAddSticker = async (item) => {
    let url = item.url;

    // For SVG type (external URLs), fetch and convert to data URI so the engine can load it
    if (item.type === "svg" && !url.startsWith("data:")) {
      try {
        const res = await fetch(url);
        const svgText = await res.text();
        url = "data:image/svg+xml," + encodeURIComponent(svgText);
      } catch {
        // fallback – engine may still try to load as image
      }
    }

    if (item.type === "gif") {
      engine?.addGifLayer({
        url,
        name: item.title || "GIF",
      });
    } else {
      engine?.addImageLayer({
        url,
        name: item.title || "Sticker",
        type: "emoji",
        source: item.source,
      });
    }
  };

  return (
    <div className="space-y-2">
      {/* Search input */}
      <label className="relative block">
        <Search
          className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-mutedForeground dark:text-mutedForeground-dark"
          size={20}
        />
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search stickers"
          className="h-10 w-full rounded-lg border border-border dark:border-border-dark bg-gray-100 dark:bg-muted-dark pl-10 pr-3 text-sm text-foreground dark:text-foreground-dark outline-none transition placeholder:text-mutedForeground dark:placeholder:text-mutedForeground-dark focus:border-primary"
        />
      </label>

      {/* Source indicator */}
      <div className="flex items-center justify-between rounded-lg border border-border dark:border-border-dark bg-card dark:bg-card-dark px-3 py-2">
        <span className="flex items-center gap-2 text-sm font-semibold text-foreground dark:text-foreground-dark">
          <Sparkles size={16} />
          {isLoading ? "Searching..." : sourceLabel}
        </span>
        {isLoading && (
          <span className="text-xs text-mutedForeground dark:text-mutedForeground-dark">
            Loading…
          </span>
        )}
      </div>

      {/* Skeleton loader */}
      {isLoading && results.length === 0 && (
        <div className="grid grid-cols-5 gap-2">
          {Array.from({ length: 9 }).map((_, i) => (
            <div
              key={i}
              className="aspect-square animate-pulse rounded-lg bg-muted dark:bg-muted-dark"
            />
          ))}
        </div>
      )}

      {/* Empty state */}
      {!isLoading && results.length === 0 && (
        <div className="rounded-lg border border-border dark:border-border-dark bg-card dark:bg-card-dark p-5 text-center text-sm text-mutedForeground dark:text-mutedForeground-dark">
          No stickers found.
        </div>
      )}

      {/* Stickers grid */}
      <div className="grid grid-cols-5 gap-2">
        {results.map((item) => (
          <button
            key={`${item.source}-${item.id}`}
            type="button"
            onClick={() => handleAddSticker(item)}
            className="aspect-square overflow-hidden rounded-lg border border-border dark:border-border-dark bg-card dark:bg-card-dark p-2 transition hover:scale-[1.03] hover:bg-muted dark:hover:bg-muted-dark"
            title={item.title}
            aria-label={`Add ${item.title}`}
          >
            {/* GIFs animate in <img>, SVGs use <object> for precise rendering */}
            {item.type === "svg" ? (
              <object
                data={item.preview || item.url}
                type="image/svg+xml"
                className="h-full w-full object-contain pointer-events-none"
                aria-label={item.title}
              >
                <img
                  src={item.preview || item.url}
                  alt=""
                  onError={(e) => (e.currentTarget.style.display = "none")}
                  className="h-full w-full object-contain"
                />
              </object>
            ) : (
              <img
                src={item.preview || item.url}
                alt=""
                loading="lazy"
                onError={(e) => (e.currentTarget.style.display = "none")}
                className="h-full w-full object-contain"
              />
            )}
          </button>
        ))}
      </div>
    </div>
  );
};

/* -------------------------------------------------------------------------- */
/*  UTILITY                                                                   */
/* -------------------------------------------------------------------------- */
const shuffleLimited = (arr, limit = 60) => {
  const shuffled = [...arr];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled.slice(0, limit);
};

export default React.memo(EmojiTool);
