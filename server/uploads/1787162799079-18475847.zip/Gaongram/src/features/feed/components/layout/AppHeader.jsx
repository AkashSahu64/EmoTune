import React, { useState } from "react";
import { Menu } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useAuthStore } from "../../../../store/authStore.js";
import Avatar from "../../../../components/common/Avatar.jsx";
import AppSidebar from "./AppSidebar.jsx";

const AppHeader = () => {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-50 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md border-b border-border dark:border-border-dark">
        <div className="max-w-7xl mx-auto px-4 h-16 flex justify-between items-center">
          
          {/* LEFT - MENU */}
          <button
            onClick={() => setIsSidebarOpen(true)}
            className="p-2"
          >
            <Menu className="w-6 h-6" />
          </button>

          {/* RIGHT */}
          <div className="flex items-center gap-4">
            {!user && (
              <button
                onClick={() => navigate("/login")}
                className="text-sm font-medium hover:text-primary"
              >
                Log in
              </button>
            )}

            {user && (
              <Link
                to={`/profile/${user?.username}`}
                className="flex items-center gap-2"
              >
                <Avatar
                  src={user?.photo}
                  alt={user?.username}
                  size="sm"
                  className="w-8 h-8 rounded-full"
                />
                <span className="text-sm">{user?.username}</span>
              </Link>
            )}
          </div>
        </div>
      </header>

      {/* 🔥 Sidebar */}
      <AppSidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />
    </>
  );
};

export default AppHeader;