import React, { useEffect, useRef, useState } from "react";
import { Play } from "lucide-react";

const VideoThumbnail = ({ src }) => {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [thumbnail, setThumbnail] = useState(null);

  useEffect(() => {
    const video = videoRef.current;

    const capture = () => {
      const canvas = canvasRef.current;
      const ctx = canvas.getContext("2d");

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;

      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      setThumbnail(canvas.toDataURL("image/png"));
    };

    video.addEventListener("loadeddata", capture);

    return () => {
      video.removeEventListener("loadeddata", capture);
    };
  }, [src]);

  return (
    <div className="relative">
      {thumbnail && (
        <img src={thumbnail} className="w-full h-32 object-cover rounded-lg" />
      )}
      <video ref={videoRef} src={src} className="hidden" />
      <canvas ref={canvasRef} className="hidden" />

      <div className="absolute inset-0 flex items-center justify-center">
        <Play className="w-8 h-8 text-white" />
      </div>
    </div>
  );
};

export default VideoThumbnail;