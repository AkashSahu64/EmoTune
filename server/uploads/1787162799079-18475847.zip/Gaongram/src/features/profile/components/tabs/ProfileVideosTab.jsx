// src/features/profile/tabs/ProfileVideosTab.jsx
import React, { useRef, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Clock3, Eye, Play, Video } from "lucide-react";
import { useMediaStore } from "../../../../store/mediaStore";
import { useProfileContent } from "../../useProfileContent";
import SensitiveContentOverlay from "../../../../components/vibe/SensitiveContentOverlay.jsx";
import { useAuthStore } from "../../../../store/authStore.js";
import { calculateAge } from "../../../../utils/calculateAge.js";

const compactNumberFormatter = new Intl.NumberFormat("en", {
  notation: "compact",
  maximumFractionDigits: 1,
});

const formatCompactNumber = (value) =>
  compactNumberFormatter.format(Number(value || 0));

const formatDuration = (value) => {
  const totalSeconds = Math.max(0, Math.floor(Number(value || 0)));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${seconds.toString().padStart(2, "0")}`;
};

/* ✅ Deterministic stable height based on item ID */
const getStableHeight = (id) => {
  const heights = ["h-[160px]", "h-[200px]", "h-[240px]", "h-[280px]"];
  const index = id ? Math.abs(id % heights.length) : 0;
  return heights[index];
};

/* Skeleton */
const GridSkeleton = () => (
  <div className="columns-2 sm:columns-3 gap-3 space-y-3">
    {Array.from({ length: 6 }).map((_, index) => (
      <div
        key={index}
        className="break-inside-avoid h-[200px] animate-pulse rounded-2xl bg-muted"
      />
    ))}
  </div>
);

/* Empty State */
const EmptyState = ({ username }) => (
  <div className="flex flex-col items-center px-6 py-14 text-center">
    <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted dark:bg-muted-dark text-foreground dark:text-foreground-dark">
      <Video className="h-7 w-7" />
    </div>
    <h3 className="mt-5 text-xl font-semibold text-foreground dark:text-foreground-dark">
      No videos from @{username}
    </h3>
    <p className="mt-2 max-w-sm text-sm text-mutedForeground dark:text-mutedForeground-dark">
      New video uploads will appear here once this creator starts sharing them.
    </p>
  </div>
);

const ProfileVideosTab = ({ profileUserId, username }) => {
  const navigate = useNavigate();
  const loadMoreRef = useRef(null);
  const setActivePost = useMediaStore((state) => state.setActivePost);

  const { user } = useAuthStore();

  const profileDob = user?.dob || user?.profile?.dob;

  const age = calculateAge(profileDob);

  const isUnder18 = typeof age === "number" && age < 18;

  const sensitiveAllowed =
    user?.is_sensitive_allowed ?? user?.profile?.is_sensitive_allowed;

  const canViewSensitive =
    sensitiveAllowed === true && typeof age === "number" && !isUnder18;

  const { items, isLoading, hasNextPage, fetchNextPage, isFetchingNextPage } =
    useProfileContent(profileUserId, "videos");

  // Navigate to the new profile video feed page
  const handleVideoClick = useCallback(
    (videoId) => {
      setActivePost(videoId);
      navigate(`/profile-videos?start=${videoId}&user=${profileUserId}`);
    },
    [navigate, profileUserId, setActivePost],
  );

  const handleSensitiveClick = useCallback(
    (event, item) => {
      event.stopPropagation();

      navigate(`/profile/${username}/post/${item.id}`);
    },
    [navigate, username],
  );

  // Infinite scroll observer
  useEffect(() => {
    if (!loadMoreRef.current) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasNextPage && !isFetchingNextPage) {
          fetchNextPage();
        }
      },
      { threshold: 1 },
    );
    observer.observe(loadMoreRef.current);
    return () => observer.disconnect();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  if (isLoading && !items.length) return <GridSkeleton />;
  if (!items.length) return <EmptyState username={username} />;
  console.log("VIDEO ITEMS", items);

  return (
    <div className="space-y-5">
      <div className="columns-2 sm:columns-4 gap-1.5 lg:gap-2 space-y-3">
        {items.map((item) => {
          const isSensitiveBlocked =
            item.is_sensitive === true && !canViewSensitive;

          return (
            <motion.div
              key={item.id}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleVideoClick(item.id)}
              onMouseEnter={() => {
                if (!isSensitiveBlocked) {
                  handleMouseEnter(item);
                }
              }}
              onMouseLeave={() => {
                handleMouseLeave(item.id);
              }}
              className={`break-inside-avoid relative overflow-hidden rounded-xl bg-black cursor-pointer ${getStableHeight(item.id)}`}
            >
              {/* Thumbnail */}
              {item.previewImage ? (
                <img
                  src={item.previewImage}
                  alt="Video thumbnail"
                  loading="lazy"
                  className={`h-full w-full object-cover transition duration-500 group-hover:scale-[1.03] ${
                    isSensitiveBlocked ? "blur-xl scale-105 brightness-75" : ""
                  }`}
                  onError={(e) => {
                    e.currentTarget.src =
                      "https://placehold.co/600x900/111827/FFFFFF?text=Video";
                  }}
                />
              ) : (
                <div className="flex h-full items-center justify-center bg-gradient-to-br from-gray-900 to-gray-700">
                  <Play className="h-10 w-10 text-white/70" />
                </div>
              )}

              {/* Overlay */}
              <div className="absolute inset-0 bg-black/20 hover:bg-black/40 transition" />

              {isSensitiveBlocked && (
                <SensitiveContentOverlay
                  compact
                  onClick={(event) => handleSensitiveClick(event, item)}
                />
              )}

              {/* Center Play Button */}
              <div className="absolute inset-0 flex items-center justify-center opacity-80">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-white/20 backdrop-blur">
                  <Play className="h-5 w-5 text-white fill-current" />
                </div>
              </div>

              {/* Video Tag */}
              <div className="absolute top-2 left-2 text-[10px] p-2 rounded-full bg-black/50 text-white">
                <Play className="h-3 w-3" />
              </div>

              {/* Duration */}
              {item.videoDuration > 0 && (
                <div className="absolute top-2 right-2 flex items-center gap-1 text-[10px] px-2 py-1 rounded-full bg-black/50 text-white">
                  <Clock3 className="h-3 w-3" />
                  {formatDuration(item.videoDuration)}
                </div>
              )}

              {/* Views */}
              {/* <div className="absolute bottom-2 left-2 flex items-center gap-1 text-[10px] px-2 py-1 rounded-full bg-black/50 text-white">
              <Eye className="h-3 w-3" />
              {formatCompactNumber(item.viewsCount)}
            </div> */}
            </motion.div>
          );
        })}
      </div>

      {/* Load More Sentinel */}
      <div ref={loadMoreRef} className="h-10" />
    </div>
  );
};

export default React.memo(ProfileVideosTab);
