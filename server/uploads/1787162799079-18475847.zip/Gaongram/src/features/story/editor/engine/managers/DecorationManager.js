import { clamp } from "../helpers/math.js";
import { FRAME_OPTIONS } from "../../utils/filterPresets.js";
import { fabric } from "fabric";

export class DecorationManager {
  constructor(engine) {
    this.engine = engine;
    this.vignetteObject = null;
    this.frameObject = null;
  }

  syncVignette(amount) {
    const { canvas } = this.engine;
    if (!canvas) return;
    if (this.vignetteObject) {
      canvas.remove(this.vignetteObject);
      this.vignetteObject = null;
    }
    if (!amount) return;
    const w = canvas.getWidth();
    const h = canvas.getHeight();
    this.vignetteObject = new fabric.Rect({
      left: 0,
      top: 0,
      width: w,
      height: h,
      selectable: false,
      evented: false,
      excludeFromExport: false,
      excludeFromLayoutScale: true,
      layerId: "global-vignette",
      fill: new fabric.Gradient({
        type: "radial",
        coords: {
          x1: w / 2,
          y1: h / 2,
          r1: Math.min(w, h) * 0.18,
          x2: w / 2,
          y2: h / 2,
          r2: Math.max(w, h) * 0.68,
        },
        colorStops: [
          { offset: 0, color: "rgba(0,0,0,0)" },
          { offset: 0.58, color: "rgba(0,0,0,0)" },
          { offset: 1, color: `rgba(0,0,0,${clamp(amount, 0, 0.8)})` },
        ],
      }),
    });
    canvas.add(this.vignetteObject);
    canvas.bringToFront(this.vignetteObject);
  }

  syncFrame(frameId) {
    const { canvas } = this.engine;
    if (!canvas) return;
    if (this.frameObject) {
      canvas.remove(this.frameObject);
      this.frameObject = null;
    }
    const frame = FRAME_OPTIONS.find((f) => f.id === frameId);
    if (!frame || frame.id === "none") return;
    const w = canvas.getWidth();
    const h = canvas.getHeight();
    const inset = Math.min(w, h) * frame.insetRatio;
    const strokeWidth = Math.max(
      5,
      Math.min(Math.min(w, h) * frame.strokeWidthRatio, 14)
    );

    this.frameObject = new fabric.Rect({
      originX: "center",   
      originY: "center",   
      left: w / 2,         
      top: h / 2,         

      width: w - inset * 2 - strokeWidth,
      height: h - inset * 2 - strokeWidth,

      rx: Math.min(w, h) * frame.radiusRatio,
      ry: Math.min(w, h) * frame.radiusRatio,

      fill: "rgba(0,0,0,0)",
      stroke: frame.stroke,
      strokeWidth: strokeWidth,

      shadow: frame.shadow ? new fabric.Shadow(frame.shadow) : null,

      selectable: false,
      evented: false,
      excludeFromLayoutScale: true,
      layerId: "frame-overlay",
    });
    canvas.add(this.frameObject);
    canvas.bringToFront(this.frameObject);
  }
}