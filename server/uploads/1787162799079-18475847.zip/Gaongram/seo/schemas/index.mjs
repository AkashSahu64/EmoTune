import { SEO_CONFIG } from "../metadata/config.mjs";
import { compactObject } from "../metadata/utils.mjs";
import { getSocialImage } from "../metadata/utils.mjs";

export const createOrganizationSchema = () =>
  compactObject({
    "@context": "https://schema.org",
    "@type": "Organization",
    name: SEO_CONFIG.siteName,
    legalName: SEO_CONFIG.organizationName,
    url: SEO_CONFIG.siteUrl,
    logo: {
      "@type": "ImageObject",
      url: getSocialImage(SEO_CONFIG.defaultImage),
    },
    email: SEO_CONFIG.contactEmail,
    sameAs: SEO_CONFIG.socialProfiles,
  });

export const createWebsiteSchema = () =>
  compactObject({
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: SEO_CONFIG.siteName,
    url: SEO_CONFIG.siteUrl,
    description: SEO_CONFIG.defaultDescription,
    publisher: createOrganizationSchema(),
    potentialAction: {
      "@type": "SearchAction",
      target: `${SEO_CONFIG.siteUrl}/search?q={search_term_string}`,
      "query-input": "required name=search_term_string",
    },
  });

export const createWebPageSchema = ({
  title,
  description,
  url,
  type = "WebPage",
}) =>
  compactObject({
    "@context": "https://schema.org",
    "@type": type,
    name: title,
    description,
    url,
    isPartOf: {
      "@type": "WebSite",
      name: SEO_CONFIG.siteName,
      url: SEO_CONFIG.siteUrl,
    },
  });

