// services/vibe.service.js
import api from "../config/axios.js";

export const vibeService = {
  /**
   * Fetch feed posts.
   * Returns normalized posts with ALL fields preserved, deduplicated.
   */
  getVibePosts: async (params = {}) => {
    try {
      const res = await api.get("/feeds/", {
        params: {
          ...params,
          page: params.page || 1,
          page_size: params.page_size || 10,
        },
      });

      const apiData = res.data?.data;

      let postsArray = Array.isArray(apiData)
        ? apiData
        : apiData?.results || [];

      if (!Array.isArray(postsArray)) {
        return {
          data: [],
          hasMore: false,
        };
      }

      const normalized = postsArray.map((item) => {
        let mediaType = "text";
        let mediaUrl = null;

        const normalizedPollOptions = Array.isArray(item.poll_options)
          ? item.poll_options
          : typeof item.poll_options === "string"
            ? item.poll_options
                .split(",")
                .map((opt) => opt.trim())
                .filter(Boolean)
            : [];

        const hasPoll =
          !!item.poll_question || normalizedPollOptions.length > 0;

        if (item.videos?.length > 0) {
          mediaType = "video";
          mediaUrl = item.videos[0]?.hls_playlist || item.videos[0]?.video;
        } else if (item.audio) {
          mediaType = "audio";
          mediaUrl = item.audio.audio;
        } else if (item.images?.length > 0) {
          mediaType = "image";
          mediaUrl = item.images[0]?.image;
        } else if (hasPoll) {
          mediaType = "poll";
        }

        return {
          id: item.id,

          user: {
            id: item.author,
            username: item.user_name,
            avatar: item.profile_image,
            is_private: item.is_private,
            is_verified: item.is_verified,
          },

          caption: item.content || "",
          created_at: item.created_at,
          times_ago: item.times_ago,

          views_count: item.views_count ?? 0,
          likes_count: item.total_likes ?? 0,
          comments_count: item.comments_count ?? 0,

          is_liked: item.is_liked === true,
          is_following: item.is_following ?? false,
          is_sensitive: item.is_sensitive === true,

          media_type: mediaType,
          media_url: mediaUrl,

          videos: item.videos || [],
          audio: item.audio || null,
          images: item.images || [],

          poll_question: item.poll_question || null,

          poll_options: normalizedPollOptions,

          poll_votes: item.poll_votes || {},

          poll: hasPoll
            ? {
                poll_question: item.poll_question || "Poll",

                poll_options: normalizedPollOptions,

                poll_votes: item.poll_votes || {},

                user_vote: item.user_vote ?? null,

                expires_at: item.expires_at || null,
              }
            : null,

          user_vote: item.user_vote,

          engagement_score: item.engagement_score,
          author_affinity_score: item.author_affinity_score,
          recency_score: item.recency_score,
          popularity_score: item.popularity_score,
          following_score: item.following_score,
          following_weight: item.following_weight,
          unwatched_bonus: item.unwatched_bonus,
          new_post_boost: item.new_post_boost,
          rule_score: item.rule_score,
          ml_score: item.ml_score,
          final_score: item.final_score,
          is_repeated: item.is_repeated,
        };
      });

      return {
        data: normalized,

        // IMPORTANT
        hasMore: normalized.length > 0,
      };
    } catch (err) {
      console.error("Error fetching feed:", err);

      return {
        data: [],
        hasMore: false,
      };
    }
  },

  getVideoPosts: async (params = {}) => {
    try {
      const res = await api.get("/feeds/", {
        params: {
          video: true,
          page: params.page || 1,
          page_size: params.page_size || 10,
        },
      });

      console.log("[getVideoPosts] raw response:", res.data);

      const apiData = res.data?.data;
      const results = Array.isArray(apiData) ? apiData : [];

      return {
        results,
        hasMore: results.length > 0,
      };
    } catch (error) {
      console.error("[getVideoPosts] error:", error);

      return {
        results: [],
        hasMore: false,
      };
    }
  },

  getProfileUserVideos: async (userId, params = {}) => {
    if (!userId) {
      return {
        data: {
          results: [],
          next: null,
        },
        hasMore: false,
      };
    }

    try {
      const page = params.page || 1;

      const response = await api.get("/vibe-videos/", {
        params: {
          user_id: userId,
          page,
        },
      });

      const payload = response.data?.data || {};

      const results = (payload.results || []).map((item) => ({
        ...item,

        // Minimal normalization ONLY
        user: {
          id: item.author,
          username: item.username,
          avatar: item.profile_image,
          is_verified: item.is_verified,
        },
      }));

      return {
        data: {
          results,
          next: payload.next || null,
        },

        hasMore: Boolean(payload.next),
      };
    } catch (error) {
      console.error(`[getUserVideos] error for user ${userId}:`, error);

      return {
        data: {
          results: [],
          next: null,
        },

        hasMore: false,
      };
    }
  },

  /* -------------------------
     Other methods kept for compatibility (unchanged)
  -------------------------- */
  getVibePost: async (id) => {
    try {
      const res = await api.get(`/vibe-posts/${id}/`);
      return res.data;
    } catch (error) {
      console.error(`Error fetching vibe post ${id}:`, error);
      return { success: false, data: null };
    }
  },

  createVibePost: async (postData) => {
    try {
      const res = await api.post("/vibe-posts/", postData);
      return res.data;
    } catch (error) {
      console.error("Error creating vibe post:", error);
      throw error;
    }
  },

  updateVibePost: async (id, postData) => {
    if (!id) throw new Error("Post ID required");
    try {
      const res = await api.put(`/vibe-posts/${id}/`, postData);
      return res.data;
    } catch (error) {
      console.error(`Error updating vibe post ${id}:`, error);
      throw error;
    }
  },

  patchVibePost: async (id, postData) => {
    if (!id) throw new Error("Post ID required");
    try {
      const res = await api.patch(`/vibe-posts/${id}/`, postData);
      return res.data;
    } catch (error) {
      console.error(`Error patching vibe post ${id}:`, error);
      throw error;
    }
  },

  deleteVibePost: async (id) => {
    if (!id) throw new Error("Post ID required");
    try {
      await api.delete(`/vibe-posts/${id}/`);
      return { success: true };
    } catch (error) {
      console.error(`Error deleting vibe post ${id}:`, error);
      throw error;
    }
  },

  likePost: async (id) => {
    return api.post(`/vibe-posts/${id}/like_post/`);
  },

  unlikePost: async (id) => {
    return api.post(`/vibe-posts/${id}/like_post/`);
  },

  votePoll: async (postId, optionId) => {
    if (postId == null || optionId == null) {
      throw new Error("Post ID and option ID required");
    }
    try {
      const res = await api.post(`/vibe-posts/${postId}/vote_poll/`, {
        option: optionId,
      });
      return res.data;
    } catch (error) {
      console.error(`Error voting on poll ${postId}:`, error);
      throw error;
    }
  },

  getUserPosts: async (userId, params = {}) => {
    if (!userId) return { data: { results: [] }, success: false };
    try {
      const res = await api.get(`/vibe-posts/${userId}/user_posts/`, {
        params,
      });
      return res.data;
    } catch (error) {
      console.error(`Error fetching user posts for ${userId}:`, error);
      return { success: false, data: { results: [] } };
    }
  },

  getUserVideos: async (userId, params = {}) => {
    if (!userId) return { data: { results: [] }, success: false };
    try {
      const res = await api.get(`/vibe-posts/${userId}/user_videos/`, {
        params,
      });
      return res.data;
    } catch (error) {
      console.error(`Error fetching user videos for ${userId}:`, error);
      return { success: false, data: { results: [] } };
    }
  },

  getAllVibePosts: async (page = 1) => {
  try {

    const res = await api.get(
      "/vibe-posts/",
      {
        params: { page },
      }
    );

    const apiData =
      res.data?.data;

    const postsArray =
      apiData?.results || [];

    const normalizePost = (
      item
    ) => {

      let mediaType = "text";
      let mediaUrl = null;

      if (
        item.videos?.length > 0
      ) {

        mediaType = "video";

        mediaUrl =
          item.videos[0]
            ?.hls_playlist ||
          item.videos[0]
            ?.video;

      } else if (
        item.audio
      ) {

        mediaType = "audio";

        mediaUrl =
          item.audio.audio;

      } else if (
        item.images?.length > 0
      ) {

        mediaType = "image";

        mediaUrl =
          item.images[0]
            ?.image;

      } else if (
        item.poll_question
      ) {

        mediaType = "poll";
      }

      return {
        id: item.id,

        user: {
          id: item.author,

          username:
            item.user_name,

          avatar:
            item.profile_image,

          is_private:
            item.is_private,

          is_verified:
            item.is_verified,

          is_following:
            item.is_following ??
            false,

          is_requested:
            item.is_requested ??
            false,
        },

        caption:
          item.content || "",

        created_at:
          item.created_at,

        times_ago:
          item.times_ago,

        views_count:
          item.views_count ??
          0,

        likes_count:
          item.total_likes ??
          0,

        comments_count:
          item.comments_count ??
          0,

        is_liked:
          item.is_liked ===
          true,

        is_following:
          item.is_following ??
          false,

        is_sensitive:
          item.is_sensitive === true,

        media_type:
          mediaType,

        media_url:
          mediaUrl,

        videos:
          item.videos || [],

        audio:
          item.audio || null,

        images:
          item.images || [],

        poll:
  item.poll_question
    ? {
        poll_question:
          item.poll_question,

        poll_options:
          Array.isArray(item.poll_options)
            ? item.poll_options
            : [],

        poll_votes:
          item.poll_votes || {},

        user_vote:
          item.user_vote ?? null,

        expires_at:
          item.expires_at || null,
      }
    : null,

        user_vote:
          item.user_vote,
      };
    };

    const normalized =
      postsArray.map(
        normalizePost
      );

    return {
      data: normalized,

      next:
        apiData?.next,

      hasMore:
        !!apiData?.next,
    };

  } catch (err) {

    console.error(
      "Error fetching vibe posts:",
      err
    );

    return {
      data: [],
      next: null,
      hasMore: false,
    };
  }
},

getVibePost: async (id) => {
  try {

    const res = await api.get(
      `/vibe-posts/${id}/`
    );

    const item =
      res.data?.data;

    if (!item) {
      return {
        success: false,
        data: null,
      };
    }

    let mediaType = "text";
    let mediaUrl = null;

    if (
      item.videos?.length > 0
    ) {

      mediaType = "video";

      mediaUrl =
        item.videos[0]
          ?.hls_playlist ||
        item.videos[0]
          ?.video;

    } else if (
      item.audio
    ) {

      mediaType = "audio";

      mediaUrl =
        item.audio.audio;

    } else if (
      item.images?.length > 0
    ) {

      mediaType = "image";

      mediaUrl =
        item.images[0]
          ?.image;

    } else if (
      item.poll_question
    ) {

      mediaType = "poll";
    }

    return {
      success: true,

      data: {
        id: item.id,

        user: {
          id: item.author,

          username:
            item.user_name,

          avatar:
            item.profile_image,

          is_private:
            item.is_private,

          is_verified:
            item.is_verified,

          is_following:
            item.is_following ??
            false,

          is_requested:
            item.is_requested ??
            false,
        },

        caption:
          item.content || "",

        created_at:
          item.created_at,

        times_ago:
          item.times_ago,

        views_count:
          item.views_count ??
          0,

        likes_count:
          item.total_likes ??
          0,

        comments_count:
          item.comments_count ??
          0,

        is_liked:
          item.is_liked ===
          true,

        is_following:
          item.is_following ??
          false,

        is_sensitive:
          item.is_sensitive === true,

        media_type:
          mediaType,

        media_url:
          mediaUrl,

        videos:
          item.videos || [],

        audio:
          item.audio || null,

        images:
          item.images || [],

        poll:
          item.poll_question
            ? {
                question:
                  item.poll_question,

                options:
                  item.poll_options,

                total_votes:
                  item.poll_votes,
              }
            : null,

        user_vote:
          item.user_vote,
      },
    };

  } catch (error) {

    console.error(
      `Error fetching vibe post ${id}:`,
      error
    );

    return {
      success: false,
      data: null,
    };
  }
},
};
