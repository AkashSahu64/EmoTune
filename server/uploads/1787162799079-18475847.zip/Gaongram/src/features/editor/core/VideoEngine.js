export class VideoEngine {
  constructor(file) {
    this.file = file;
    this.url = file ? URL.createObjectURL(file) : "";
  }

  dispose() {
    if (this.url?.startsWith("blob:")) URL.revokeObjectURL(this.url);
  }

  buildMetadata({ trimStart = 0, trimEnd = null, muted = false, volume = 1, thumbnail = null } = {}) {
    return {
      trimStart,
      trimEnd,
      muted,
      volume,
      thumbnail,
      originalName: this.file?.name,
      originalType: this.file?.type,
      originalSize: this.file?.size,
    };
  }
}

export default VideoEngine;
