// src/layouts/PublicLayout.jsx
import React from "react";
import AppHeader from "./AppHeader";
import AppFooter from "./AppFooter";

const PublicLayout = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col">
      
      {/* Header */}
      <AppHeader />

      {/* Content */}
      <main className="flex-1">{children}</main>

      {/* Footer */}
      <AppFooter />
    </div>
  );
};

export default PublicLayout;