// media/MediaTypes.js
/**
 * Media type constants and utilities
 */
export const MediaTypes = {
  VIDEO: 'video',
  AUDIO: 'audio',
  POLL: 'poll',
  IMAGE: 'image'
};

export const MediaEvents = {
  PLAY: 'play',
  PAUSE: 'pause',
  STOP: 'stop',
  SEEK: 'seek',
  MUTE: 'mute',
  ENDED: 'ended',
  LOADED: 'loaded',
  ERROR: 'error',
  PROGRESS: 'progress',
  VISIBILITY_CHANGE: 'visibilityChange'
};

export const MediaPlaybackModes = {
  AUTOPLAY: 'autoplay',
  MANUAL: 'manual',
  SINGLE: 'single', // Only one media plays at a time
  MULTIPLE: 'multiple' // Multiple media can play simultaneously
};

// Helper to determine media type from post data
export function getMediaType(post) {
  if (post.media_type === 'video' || post.videos?.length > 0) {
    return MediaTypes.VIDEO;
  } else if (post.media_type === 'audio' || post.audio) {
    return MediaTypes.AUDIO;
  } else if (post.media_type === 'poll') {
    return MediaTypes.POLL;
  }
  return null;
}

// Helper to get media URL from post
export function getMediaUrl(post) {
  const type = getMediaType(post);
  
  switch (type) {
    case MediaTypes.VIDEO:
      return post.videos?.[0]?.hls_playlist || post.videos?.[0]?.video || null;
    case MediaTypes.AUDIO:
      return post.audio?.audio || null;
    default:
      return null;
  }
}