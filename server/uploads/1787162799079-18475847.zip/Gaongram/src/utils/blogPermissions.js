// src/features/blogs/utils/blogPermissions.js
import { getCurrentUserId } from "./getCurrentUser";

/**
 * Checks if the current logged-in user is the author of a given blog.
 * @param {Object} blog - Blog object containing at least `author` field.
 * @returns {boolean} True if current user is the blog owner.
 */
export const isBlogOwner = (blog) => {
  if (!blog || !blog.author) return false;
  const currentUserId = getCurrentUserId();
  return currentUserId != null && blog.author === currentUserId;
};

/**
 * Determines if the current user can edit the blog.
 * @param {Object} blog - Blog object.
 * @returns {boolean}
 */
export const canEditBlog = (blog) => isBlogOwner(blog);

/**
 * Determines if the current user can delete the blog.
 * @param {Object} blog - Blog object.
 * @returns {boolean}
 */
export const canDeleteBlog = (blog) => isBlogOwner(blog);