import React from "react";
import { EyeOff, AlertTriangle } from "lucide-react";

const SensitiveContentOverlay = ({
  onClick,
  className = "",
  compact = false,
}) => {
  return (
    <button
      type="button"
      onClick={(event) => {
        event.stopPropagation();
        onClick?.();
      }}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") {
          event.preventDefault();
          event.stopPropagation();
          onClick?.();
        }
      }}
      aria-label="View sensitive content options"
      className={`absolute inset-0 z-40 flex items-center justify-center bg-black/45 px-6 text-center backdrop-blur-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-white/80 ${className}`}
    >
      {compact ? (
        <span className="flex flex-col items-center text-white">
          <span className="mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-white/10 backdrop-blur">
            <EyeOff
              className="h-6 w-6"
              aria-hidden="true"
            />
          </span>

          <span className="text-sm font-semibold">
            Sensitive Content
          </span>
        </span>
      ) : (
        <span className="flex max-w-[260px] flex-col items-center text-muted">
          <span className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-white/10">
            <EyeOff
              className="h-7 w-7"
              aria-hidden="true"
            />
          </span>

          <span className="text-base font-semibold">
            Sensitive Content
          </span>

          <span className="mt-1 text-sm font-medium text-white/90">
            Enable from settings to view
          </span>

          <span className="mt-4 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm font-semibold">
            <AlertTriangle
              className="h-4 w-4"
              aria-hidden="true"
            />
            View Options
          </span>
        </span>
      )}
    </button>
  );
};

export default SensitiveContentOverlay;