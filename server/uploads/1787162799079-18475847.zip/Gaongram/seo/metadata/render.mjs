import {
  INDEX_ROBOTS,
  NOINDEX_ROBOTS,
  SEO_CONFIG,
} from "./config.mjs";
import {
  cleanText,
  escapeHtml,
  getImageMimeType,
  getSocialImage,
  truncateText,
} from "./utils.mjs";
import { getCanonicalUrl } from "../canonical/index.mjs";
import {
  createOrganizationSchema,
  createWebsiteSchema,
  formatSeoTitle,
} from "../builders/index.mjs";

const normalizeSchemaList = (schema) => {
  if (!schema) return [];
  return Array.isArray(schema) ? schema : [schema];
};

const normalizeImageEntry = (value, alt, { required = false } = {}) => {
  if (!value && !required) return null;

  const input = value && typeof value === "object" ? value : { url: value };
  const rawUrl = input.url || input.content || input.image || input.secureUrl || "";

  if (!rawUrl && !required) return null;

  const url = getSocialImage(rawUrl || SEO_CONFIG.defaultImage);
  const secureUrl = getSocialImage(input.secureUrl || input.secure_url || url);

  return {
    url,
    secureUrl,
    type: input.type || getImageMimeType(url),
    width: input.width || SEO_CONFIG.defaultImageWidth,
    height: input.height || SEO_CONFIG.defaultImageHeight,
    alt: truncateText(input.alt || alt || SEO_CONFIG.defaultImageAlt, 140),
  };
};

const normalizeImageEntries = (seo, imageAlt) => {
  const entries = [
    normalizeImageEntry(seo.ogImage || seo.image || SEO_CONFIG.defaultImage, imageAlt, {
      required: true,
    }),
    ...(Array.isArray(seo.ogImages)
      ? seo.ogImages.map((entry) => normalizeImageEntry(entry, imageAlt))
      : []),
    normalizeImageEntry(
      seo.ogImageFallback || seo.generatedOgImage || seo.fallbackImage,
      imageAlt,
    ),
  ].filter(Boolean);

  const seen = new Set();
  return entries.filter((entry) => {
    const key = entry.url;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
};

export const normalizeSeo = (seo = {}, requestPath = "/") => {
  const canonical = getCanonicalUrl(seo.canonical || seo.ogUrl || requestPath);
  const pageUrl = getCanonicalUrl(seo.ogUrl || seo.canonical || requestPath);
  const title =
    seo.appendSiteName === false
      ? cleanText(seo.title || SEO_CONFIG.defaultTitle)
      : formatSeoTitle(seo.title || SEO_CONFIG.defaultTitle);
  const description = truncateText(
    seo.description || SEO_CONFIG.defaultDescription,
    300,
  );
  const imageAlt = truncateText(
    seo.ogImageAlt || SEO_CONFIG.defaultImageAlt || `${title} preview image`,
    140,
  );
  const ogImages = normalizeImageEntries(seo, imageAlt);
  const primaryImage = ogImages[0] || normalizeImageEntry(SEO_CONFIG.defaultImage, imageAlt, {
    required: true,
  });
  const noindex = Boolean(seo.noindex);

  return {
    ...seo,
    title,
    description,
    keywords: seo.keywords || SEO_CONFIG.defaultKeywords,
    canonical,
    ogUrl: pageUrl,
    ogImage: primaryImage.url,
    ogImageSecureUrl: primaryImage.secureUrl,
    ogImageAlt: imageAlt,
    ogImages,
    ogType: seo.ogType || "website",
    robots: seo.robots || (noindex ? NOINDEX_ROBOTS : INDEX_ROBOTS),
    schema: [
      createOrganizationSchema(),
      createWebsiteSchema(),
      ...normalizeSchemaList(seo.schema),
    ],
  };
};

const renderOgImageTags = (images = []) =>
  images
    .map(
      (image) => `
    <meta data-rh="true" property="og:image" content="${escapeHtml(image.url)}" />
    <meta data-rh="true" property="og:image:secure_url" content="${escapeHtml(image.secureUrl || image.url)}" />
    <meta data-rh="true" property="og:image:type" content="${escapeHtml(image.type || getImageMimeType(image.url))}" />
    <meta data-rh="true" property="og:image:width" content="${String(image.width || SEO_CONFIG.defaultImageWidth)}" />
    <meta data-rh="true" property="og:image:height" content="${String(image.height || SEO_CONFIG.defaultImageHeight)}" />
    <meta data-rh="true" property="og:image:alt" content="${escapeHtml(image.alt || SEO_CONFIG.defaultImageAlt)}" />`,
    )
    .join("");

export const renderSeoHead = (seoInput = {}, requestPath = "/") => {
  const seo = normalizeSeo(seoInput, requestPath);

  return `
    <title data-rh="true">${escapeHtml(seo.title)}</title>
    <meta data-rh="true" name="description" content="${escapeHtml(seo.description)}" />
    <meta data-rh="true" name="keywords" content="${escapeHtml(seo.keywords)}" />
    <meta data-rh="true" name="author" content="${escapeHtml(SEO_CONFIG.organizationName)}" />
    <meta data-rh="true" name="robots" content="${escapeHtml(seo.robots)}" />
    <meta data-rh="true" name="googlebot" content="${escapeHtml(seo.robots)}" />
    <meta data-rh="true" name="theme-color" content="${escapeHtml(SEO_CONFIG.themeColor)}" />
    <link data-rh="true" rel="preconnect" href="https://gaongram.com" />
    <link data-rh="true" rel="dns-prefetch" href="//gaongram.com" />
    <link data-rh="true" rel="canonical" href="${escapeHtml(seo.canonical)}" />
    <meta data-rh="true" property="og:type" content="${escapeHtml(seo.ogType)}" />
    <meta data-rh="true" property="og:locale" content="${escapeHtml(SEO_CONFIG.locale)}" />
    <meta data-rh="true" property="og:site_name" content="${escapeHtml(SEO_CONFIG.siteName)}" />
    <meta data-rh="true" property="og:title" content="${escapeHtml(seo.title)}" />
    <meta data-rh="true" property="og:description" content="${escapeHtml(seo.description)}" />
    <meta data-rh="true" property="og:url" content="${escapeHtml(seo.ogUrl)}" />
    ${renderOgImageTags(seo.ogImages)}${
      seo.profile?.username
        ? `
    <meta data-rh="true" property="profile:username" content="${escapeHtml(seo.profile.username)}" />`
        : ""
    }${
      seo.profile?.firstName
        ? `
    <meta data-rh="true" property="profile:first_name" content="${escapeHtml(seo.profile.firstName)}" />`
        : ""
    }${
      seo.profile?.lastName
        ? `
    <meta data-rh="true" property="profile:last_name" content="${escapeHtml(seo.profile.lastName)}" />`
        : ""
    }${
      seo.article?.publishedTime
        ? `
    <meta data-rh="true" property="article:published_time" content="${escapeHtml(seo.article.publishedTime)}" />`
        : ""
    }${
      seo.article?.modifiedTime
        ? `
    <meta data-rh="true" property="article:modified_time" content="${escapeHtml(seo.article.modifiedTime)}" />
    <meta data-rh="true" property="og:updated_time" content="${escapeHtml(seo.article.modifiedTime)}" />`
        : ""
    }${
      seo.article?.author
        ? `
    <meta data-rh="true" property="article:author" content="${escapeHtml(seo.article.author)}" />`
        : ""
    }${
      seo.article?.section
        ? `
    <meta data-rh="true" property="article:section" content="${escapeHtml(seo.article.section)}" />`
        : ""
    }${
      Array.isArray(seo.article?.tags)
        ? seo.article.tags
            .map((tag) => {
              const value = cleanText(tag?.name || tag?.slug || tag);
              return value
                ? `
    <meta data-rh="true" property="article:tag" content="${escapeHtml(value)}" />`
                : "";
            })
            .join("")
        : ""
    }${
      seo.video?.url
        ? `
    <meta data-rh="true" property="og:video" content="${escapeHtml(seo.video.url)}" />
    <meta data-rh="true" property="og:video:secure_url" content="${escapeHtml(seo.video.secureUrl || seo.video.url)}" />
    <meta data-rh="true" property="og:video:type" content="${escapeHtml(seo.video.type || "video/mp4")}" />${
      seo.video.width
        ? `
    <meta data-rh="true" property="og:video:width" content="${escapeHtml(seo.video.width)}" />`
        : ""
    }${
      seo.video.height
        ? `
    <meta data-rh="true" property="og:video:height" content="${escapeHtml(seo.video.height)}" />`
        : ""
    }`
        : ""
    }
    <meta data-rh="true" name="twitter:card" content="summary_large_image" />
    <meta data-rh="true" name="twitter:site" content="${escapeHtml(SEO_CONFIG.twitterSite)}" />
    <meta data-rh="true" name="twitter:url" content="${escapeHtml(seo.ogUrl)}" />
    <meta data-rh="true" name="twitter:title" content="${escapeHtml(seo.title)}" />
    <meta data-rh="true" name="twitter:description" content="${escapeHtml(seo.description)}" />
    <meta data-rh="true" name="twitter:image" content="${escapeHtml(seo.ogImage)}" />
    <meta data-rh="true" name="twitter:image:alt" content="${escapeHtml(seo.ogImageAlt)}" />
    <script data-rh="true" type="application/ld+json">${JSON.stringify(seo.schema)}</script>`;
};

export const stripSeoHead = (html) =>
  html
    .replace(/\s*<title\b[^>]*>[\s\S]*?<\/title>/gi, "")
    .replace(
      /\s*<meta\b[^>]*(?:name|property)=["'](?:description|robots|googlebot|keywords|author|theme-color|twitter:[^"']+|og:[^"']+|profile:[^"']+|article:[^"']+)["'][^>]*>/gi,
      "",
    )
    .replace(/\s*<link\b[^>]*rel=["'](?:canonical|preconnect|dns-prefetch)["'][^>]*>/gi, "")
    .replace(
      /\s*<script\b[^>]*type=["']application\/ld\+json["'][^>]*>[\s\S]*?<\/script>/gi,
      "",
    );

export const injectSeoHead = (html, seoHead) =>
  stripSeoHead(html).replace(/<head>/i, `<head>${seoHead}`);
