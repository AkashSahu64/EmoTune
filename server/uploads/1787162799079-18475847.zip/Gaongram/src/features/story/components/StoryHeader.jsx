import React from 'react';
import { BadgeCheck, X } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import MusicMarquee from '../../../components/music/MusicMarquee.jsx';
import { getMusicMetadata } from '../../../components/music/musicMetadata.js';
import { normalizeStoryMusic } from '../audio/storyAudioManager.js';

const StoryHeader = ({ story, onClose }) => {
  const timeAgo = story.created_at
    ? formatDistanceToNow(new Date(story.created_at), { addSuffix: true })
    : '';
  const music = normalizeStoryMusic(story) || getMusicMetadata(story);

  return (
    <div className="absolute left-3 right-3 top-[calc(env(safe-area-inset-top)+2rem)] z-40 flex items-start justify-between gap-3 sm:left-4 sm:right-4">
      <div className="flex min-w-0 items-center gap-3">
        <div className="h-10 w-10 shrink-0 overflow-hidden rounded-full ring-2 ring-white">
          <img
            src={story.profile_image || `https://ui-avatars.com/api/?name=${story.username}`}
            alt={story.username}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="min-w-0">
          <div className="flex min-w-0 items-center gap-1.5">
            <p className="truncate font-semibold text-white">{story.username}</p>
            {(story.is_verified || story.user?.is_verified) && (
              <BadgeCheck className="h-4 w-4 shrink-0 fill-sky-500 text-white" aria-hidden="true" />
            )}
            {music && timeAgo && <span className="shrink-0 text-sm text-white/80">{timeAgo}</span>}
          </div>
          {music ? (
            <div className="mt-0.5 flex min-w-0 items-center gap-2 text-white/90">
              {music.cover_image || music.coverImage ? (
                <img
                  src={music.cover_image || music.coverImage}
                  alt=""
                  className="h-5 w-5 shrink-0 rounded-full object-cover ring-1 ring-white/30"
                />
              ) : null}
              <MusicMarquee
                title={music.title}
                artist={music.artist}
                className="max-w-[15rem] text-xs text-white/90 sm:max-w-[20rem]"
                textClassName="font-medium"
              />
            </div>
          ) : (
            <p className="text-xs text-white/80">{timeAgo}</p>
          )}
        </div>
      </div>

      <div className="flex shrink-0 items-center gap-2">
        {/* {isOwner && (
          <button
            onClick={onViewersClick}
            className="p-2 text-white hover:bg-white/10 rounded-full transition-colors"
            aria-label="Viewers"
          >
            <Eye size={20} />
          </button>
        )} */}
        <button
          onClick={onClose}
          className="flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/10"
          aria-label="Close"
        >
          <X size={20} />
        </button>
      </div>

      {/* Three-dot menu is separate component, but we can place it here or as a separate floating button */}
      {/* We'll keep it separate for clarity, so it's not in this component */}
    </div>
  );
};

export default React.memo(StoryHeader);
