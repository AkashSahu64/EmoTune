import React from "react";
import { Link } from "react-router-dom";

import Avatar from "../../../components/common/Avatar.jsx";
import FollowButton from "../../../components/common/FollowButton.jsx";
import MusicMarquee from "../../../components/music/MusicMarquee.jsx";
import { getMusicMetadata } from "../../../components/music/musicMetadata.js";

import { formatTime } from "../../../utils/formatTime.js";

const VibeHeader = ({
  post,
  isOwner,
  showFullCaption,
  setShowFullCaption,
  shouldTruncate,
}) => {
  const postUser = post.user;
  const music = getMusicMetadata(post);

  return (
    <div className="px-4 pt-3 pb-1">
      {/* HEADER ROW */}
      <div className="flex items-start justify-between">
        {/* LEFT */}
        <div className="flex min-w-0 items-start space-x-3">
          <Link to={`/profile/${postUser?.username}`}>
            <Avatar
              src={postUser?.avatar}
              alt={postUser?.username}
              size="medium"
              isStory={postUser?.has_story}
            />
          </Link>

          <div className="min-w-0 flex flex-col">
            {/* Username */}
            <Link
              to={`/profile/${postUser?.username}`}
              className="
                font-semibold
                text-sm
                text-foreground
                dark:text-foreground-dark
                hover:text-primary
                transition
              "
            >
              {postUser?.username}
            </Link>

            {music ? (
              <MusicMarquee
                title={music.title}
                artist={music.artist}
                className="mt-0.5 max-w-[14rem] text-xs text-mutedForeground dark:text-mutedForeground-dark sm:max-w-[18rem]"
                textClassName="font-medium"
              />
            ) : (
              <p className="text-xs text-mutedForeground dark:text-mutedForeground-dark">
                {formatTime(post.created_at)}
              </p>
            )}
          </div>
        </div>

        {/* RIGHT */}
        <div className="flex items-center space-x-2">
          {postUser?.id && !isOwner && (
            <FollowButton
              profileId={postUser.id}
              isPrivate={postUser.is_private}
              size="small"
              variant="default"
              className="px-3 py-1 text-xs"

              // ✅ IMPORTANT
              isFeed
            />
          )}
        </div>
      </div>

      {/* CAPTION */}
      {post.media_type !== "text" && post.caption && (
        <div className="px-1 mt-1">
          <p className="text-sm text-foreground dark:text-foreground-dark">
            {shouldTruncate && !showFullCaption
              ? `${post.caption.substring(0, 150)}...`
              : post.caption}

            {shouldTruncate && (
              <button
                onClick={() =>
                  setShowFullCaption(!showFullCaption)
                }
                className="
                  ml-1
                  text-mutedForeground
                  dark:text-mutedForeground-dark
                  hover:text-foreground
                  dark:hover:text-foreground-dark
                "
              >
                {showFullCaption
                  ? "Show less"
                  : "Show more"}
              </button>
            )}
          </p>
        </div>
      )}
    </div>
  );
};

export default VibeHeader;
