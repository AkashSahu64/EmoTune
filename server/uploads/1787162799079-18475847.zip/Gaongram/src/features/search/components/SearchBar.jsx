import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, Search, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const SearchBar = ({ value, onChange, onClear }) => {
  const navigate = useNavigate();
  const inputRef = useRef(null);

  const handleChange = (e) => {
    onChange(e.target.value);
  };

  const handleClear = () => {
    onClear();
    inputRef.current?.focus();
  };

  return (
    <div className="flex items-center gap-3 px-4 py-3">
      <button
        onClick={() => navigate(-1)}
        className="p-2 -ml-2 rounded-full hover:bg-muted dark:hover:bg-muted-dark transition-colors"
        aria-label="Go back"
      >
        <ChevronLeft className="w-5 h-5 text-foreground dark:text-foreground-dark" />
      </button>

      <div className="flex-1 relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-mutedForeground dark:text-mutedForeground-dark" />
        <input
          ref={inputRef}
          type="text"
          value={value}
          onChange={handleChange}
          placeholder="Search"
          className="w-full h-10 pl-9 pr-10 bg-muted dark:bg-muted-dark border border-border dark:border-border-dark rounded-full text-sm text-foreground dark:text-foreground-dark placeholder-mutedForeground dark:placeholder-mutedForeground-dark focus:outline-none focus:ring-2 focus:ring-primary/30"
          autoFocus
        />
        {value && (
          <motion.button
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
            onClick={handleClear}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1 rounded-full hover:bg-mutedForeground/20 transition-colors"
            aria-label="Clear search"
          >
            <X className="w-4 h-4 text-mutedForeground dark:text-mutedForeground-dark" />
          </motion.button>
        )}
      </div>
    </div>
  );
};

export default SearchBar;