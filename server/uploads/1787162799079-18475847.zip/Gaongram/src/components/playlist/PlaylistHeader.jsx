import React from 'react';
import { Play, MoreHorizontal, Globe, Lock } from 'lucide-react';
import Avatar from '../common/Avatar.jsx';

const PlaylistHeader = ({
  playlist,
  onPlayAll,
  onOptions,
  onPrivacyToggle,
}) => {
  const trackCount = playlist.items?.length || 0;

  return (
    <div className="relative">
      {/* Background blur */}
      <div
        className="absolute inset-0 bg-cover bg-center blur-2xl opacity-30"
        style={{ backgroundImage: `url(${playlist.cover_image})` }}
      />
      
      <div className="relative z-10 p-6 flex flex-col items-center text-center">
        <Avatar
          src={playlist.cover_image}
          alt={playlist.title}
          size="2xl"
          className="rounded-2xl shadow-2xl mb-4"
        />
        
        <h1 className="text-2xl font-bold text-white mb-1">
          {playlist.title}
        </h1>
        
        <div className="flex items-center gap-2 text-sm text-gray-400 mb-4">
          <span>{trackCount} tracks</span>
          {!playlist.is_system && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onPrivacyToggle?.();
              }}
              className="flex items-center gap-1 hover:text-white transition"
            >
              {playlist.is_public ? (
                <><Globe className="w-3.5 h-3.5" /> Public</>
              ) : (
                <><Lock className="w-3.5 h-3.5" /> Private</>
              )}
            </button>
          )}
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-4">
          <button
            onClick={onPlayAll}
            className="px-6 py-2 bg-gradient-to-r from-instagram-purple to-instagram-pink text-white font-medium rounded-full flex items-center gap-2"
          >
            <Play className="w-4 h-4 fill-current" />
            Play
          </button>
          
          <button
            onClick={onOptions}
            className="p-2 bg-gray-800/80 backdrop-blur-sm rounded-full text-white hover:bg-gray-700 transition"
          >
            <MoreHorizontal className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default React.memo(PlaylistHeader);