import api from '../config/axios';

export const notificationService = {
  /**
   * Fetch notifications (paginated)
   * @param {string} url - API endpoint (default: '/notifications/')
   * @returns {Promise<Object>} { count, next, previous, results }
   */
  async getNotifications(url = '/notifications/') {
    if (url.startsWith('http')) {
      const parsed = new URL(url);
      // Remove /api/v1 prefix if present
      url = parsed.pathname.replace('/api/v1', '') + parsed.search;
    }
    const response = await api.get(url);
    return response.data.data;
  },

  /**
   * Get unread notifications count
   * @returns {Promise<number>}
   */
  async getUnreadCount() {
    const response = await api.get('/notification_unread_count/');
    return response.data.data.unread_count;
  },

  /**
   * Mark notifications as read
   * @param {number[]} ids - Array of notification IDs
   * @returns {Promise}
   */
  async markAsRead(ids) {
    const response = await api.post('/notifications/mark-read/', { ids });
    return response.data;
  },

  /**
   * Follow a user
   * @param {string} username
   */
  async followUser(username) {
    const response = await api.post(`/user/follow/${username}/`);
    return response.data;
  },

  /**
   * Unfollow a user
   * @param {string} username
   */
  async unfollowUser(username) {
    const response = await api.post(`/user/unfollow/${username}/`);
    return response.data;
  },

  /**
   * Accept a follow request
   * @param {string|number} requestId - ID of the follow request
   */
  async acceptFollowRequest(requestId) {
    const formData = new FormData();
    formData.append('request_id', requestId);
    formData.append('action', 'accept');

    const response = await api.post(
      `/handle-follow-request/${requestId}/`,
      formData,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }
    );

    return response.data;
  },

  async rejectFollowRequest(requestId) {
    const formData = new FormData();
    formData.append('request_id', requestId);
    formData.append('action', 'reject');

    const response = await api.post(
      `/handle-follow-request/${requestId}/`,
      formData,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }
    );

    return response.data;
  }
};