import React from "react";
import { Pause, Play } from "lucide-react";

const MediaControls = ({ isPlaying, progress = 0, onTogglePlay, onSeek }) => (
  <div className="flex items-center gap-3 rounded-full bg-black/45 px-3 py-2 text-white backdrop-blur-xl">
    <button
      type="button"
      onClick={onTogglePlay}
      className="flex h-9 w-9 items-center justify-center rounded-full bg-white/15 transition hover:bg-white/25"
      aria-label={isPlaying ? "Pause" : "Play"}
    >
      {isPlaying ? <Pause size={17} fill="currentColor" /> : <Play size={17} fill="currentColor" />}
    </button>
    <input
      type="range"
      min="0"
      max="100"
      value={progress}
      onChange={(event) => onSeek?.(Number(event.target.value))}
      className="h-1 flex-1 accent-white"
      aria-label="Seek media"
    />
  </div>
);

export default React.memo(MediaControls);
