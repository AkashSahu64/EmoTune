// PostActionButtons.jsx
import React from "react";
import {
  Heart,
  MessageCircle,
  MoreVertical,
  Eye,
  BarChart3,
  Music,
} from "lucide-react";
import { PiShareFat } from "react-icons/pi";

import { usePostActions } from "../../hooks/usePostActions.js";
import { useRequireAuth } from "../../hooks/useRequireAuth.js";
import { formatNumber } from "../../utils/formatTime.js";

const PostActionButtons = ({
  postId,
  post,
  postType = "vibe",
  isLiked = false,
  likeCount = 0,
  commentCount = 0,
  viewCount = 0,
  pollVotes = 0,
  isOwner = false,
  isPoll = false,
  isAudio = false,
  shareUrl,
  shareTitle,
  shareText,
  onUpdate,
  size = "medium",
  layout = "horizontal",
  className = "",
  showViewCount = false,
  showPollStats = false,
  showCommentsCount = true,
}) => {
  const requireAuth = useRequireAuth();

  const {
    handleLike: baseHandleLike,
    handleShare,
    handleOptions,
    handleComments,
  } = usePostActions();

  const isVertical = layout === "vertical";

  const sizes = {
    small: {
      icon: "w-5 h-5",
      text: "text-xs",
      button: "p-0.5",
    },

    medium: {
      icon: "w-6 h-6",
      text: "text-xs",
      button: "p-1",
    },

    large: {
      icon: "w-7 h-7",
      text: "text-base",
      button: "p-1",
    },
  };

  const currentSize = sizes[size] || sizes.medium;
  const themeClasses = isVertical
    ? {
        text: "text-white",
        mutedText: "text-white/80",
        hover: "hover:bg-white/10",
        likeHover: "hover:bg-red-500/20",
      }
    : {
        text: "text-foreground dark:text-foreground-dark",
        mutedText: "text-mutedForeground dark:text-mutedForeground-dark",
        hover: "hover:bg-muted dark:hover:bg-muted-dark",
        likeHover: "hover:bg-red-50/40 dark:hover:bg-red-500/10",
      };

  const handleLikeClick = () => {
    requireAuth(() => baseHandleLike(postId, isLiked, likeCount, onUpdate));
  };

  const handleShareClick = () => {
    requireAuth(() =>
      handleShare(postId, postType, {
        url: shareUrl,
        title: shareTitle,
        text: shareText,
      }),
    );
  };

  const handleOptionsClick = () => {
    requireAuth(() => handleOptions(postId, isOwner, post));
  };

  const handleCommentsClick = () => {
    requireAuth(() => handleComments(postId, onUpdate));
  };

  return (
    <div
      className={`
        ${
          isVertical
            ? "flex flex-col items-center gap-1"
            : "flex items-center justify-between"
        }
        ${className}
      `}
    >
      {/* LEFT ACTIONS */}
      <div
        className={
          isVertical
            ? "flex flex-col items-center gap-1"
            : "flex items-center space-x-2 md:space-x-4"
        }
      >
        {/* LIKE */}
        <div className="flex flex-col items-center font-bold">
          <button
            onClick={handleLikeClick}
            className={`
              ${currentSize.button}
              rounded-full
              transition-all
              duration-200
              ${
                isLiked
                  ? "text-red-500 hover:bg-red-500/20"
                  : `${themeClasses.text} ${themeClasses.likeHover}`
              }
            `}
            aria-label={isLiked ? "Unlike" : "Like"}
          >
            <Heart
              className={`
                ${currentSize.icon}
                ${isLiked ? "fill-current" : ""}
              `}
            />
          </button>

          <span
            className={`
              ${currentSize.text}
              font-normal
              ${themeClasses.text}
              -mt-2
            `}
          >
            {formatNumber(likeCount ?? 0)}
          </span>
        </div>

        {/* COMMENTS */}
        <div className="flex flex-col items-center font-bold">
          <button
            onClick={handleCommentsClick}
            className={`
              ${currentSize.button}
              ${themeClasses.text}
              ${themeClasses.hover}
              rounded-full
              transition-all
              duration-200
            `}
            aria-label="Comments"
          >
            <MessageCircle className={currentSize.icon} />
          </button>

          {showCommentsCount && (
            <span
              className={`
                ${currentSize.text}
                font-normal
                ${themeClasses.text}
                -mt-2
              `}
            >
              {formatNumber(commentCount ?? 0)}
            </span>
          )}
        </div>

        {/* SHARE */}
        <div className="flex flex-col items-center font-bold">
          <button
            onClick={handleShareClick}
            className={`
              ${currentSize.button}
              ${themeClasses.text}
              ${themeClasses.hover}
              rounded-full
              transition-all
              duration-200
            `}
            aria-label="Share"
          >
            <PiShareFat className={currentSize.icon} />
          </button>
        </div>

        {/* VIEW COUNT */}
        {showViewCount && viewCount > 0 && (
          <div className="flex flex-col items-center ml-2">
            <div
              className={`
                ${currentSize.button}
                ${themeClasses.mutedText}
              `}
            >
              <Eye className={currentSize.icon} />
            </div>

            <span
              className={`
                ${currentSize.text}
                font-medium
                ${themeClasses.mutedText}
              `}
            >
              {formatNumber(viewCount)}
            </span>
          </div>
        )}

        {/* POLL STATS */}
        {showPollStats && pollVotes > 0 && (
          <div className="flex flex-col items-center ml-2">
            <div
              className={`
                ${currentSize.button}
                ${themeClasses.mutedText}
              `}
            >
              <BarChart3 className={currentSize.icon} />
            </div>

            <span
              className={`
                ${currentSize.text}
                font-medium
                ${themeClasses.mutedText}
              `}
            >
              {formatNumber(pollVotes)}
            </span>
          </div>
        )}

        {/* AUDIO INDICATOR */}
        {isAudio && (
          <div className="flex flex-col items-center ml-2">
            <div
              className={`
                ${currentSize.button}
                ${
                  isVertical
                    ? "text-white"
                    : "text-primary dark:text-primary-light"
                }
              `}
            >
              <Music className={currentSize.icon} />
            </div>
          </div>
        )}
      </div>

      {/* OPTIONS */}
      <button
        onClick={handleOptionsClick}
        className={`
          ${currentSize.button}
          ${themeClasses.text}
          ${themeClasses.hover}
          rounded-full
          transition-all
          duration-200
        `}
        aria-label="More options"
      >
        <MoreVertical className={currentSize.icon} />
      </button>
    </div>
  );
};

export default PostActionButtons;
