// src/features/messages/components/ChatInput.jsx
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Send, Paperclip, Mic, Smile, X, Loader2 } from 'lucide-react';
import EmojiPicker from 'emoji-picker-react';
import AudioRecorder from './AudioRecorder';

const ChatInput = ({ onSend, isBlocked, onTyping, isSending, editingMessage,
  onCancelEdit,
  onSaveEdit, replyingTo,
  onCancelReply, }) => {
  const [message, setMessage] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showAudioRecorder, setShowAudioRecorder] = useState(false);
  const [attachments, setAttachments] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef(null);
  const typingTimeoutRef = useRef(null);


  const handleSend = useCallback(async () => {
    if (isBlocked || isSending || isUploading) return;

    // 🔥 EDIT MODE
    if (editingMessage) {
      if (!message.trim()) return;

      await onSaveEdit({
        messageId: editingMessage.id,
        newMessage: message.trim(),
      });

      setMessage("");
      return;
    }

    // 🔥 NORMAL SEND
    if (!message.trim() && attachments.length === 0) return;

    if (attachments.length > 0) {
      setIsUploading(true);
    }

    try {
      await onSend({ message: message.trim(), files: attachments });
      setMessage('');
      setAttachments([]);
      setShowAudioRecorder(false);
    } finally {
      setIsUploading(false);
    }
  }, [message, attachments, isBlocked, isSending, isUploading, editingMessage]);


  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };


  const handleTyping = useCallback(() => {
    onTyping?.();
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    typingTimeoutRef.current = setTimeout(() => {
      // Stop typing indicator (already handled by parent)
    }, 2000);
  }, [onTyping]);

  const handleFileSelect = (e) => {
    const files = Array.from(e.target.files);
    setAttachments(prev => [...prev, ...files]);
    // Reset file input so same file can be selected again
    e.target.value = '';
  };

  const removeAttachment = (index) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const handleEmojiSelect = (emojiData) => {
    setMessage(prev => prev + emojiData.emoji);
    setShowEmojiPicker(false);
  };

  const handleAudioRecorded = (audioBlob) => {
    const audioFile = new File([audioBlob], 'audio.webm', { type: 'audio/webm' });
    setAttachments(prev => [...prev, audioFile]);
    setShowAudioRecorder(false);
  };

  useEffect(() => {
    if (editingMessage) {
      setMessage(editingMessage.message || "");
    }
  }, [editingMessage]);

  // Blocked user banner
  if (isBlocked) {
    return (
      <div className="p-4 text-center text-gray-500 bg-gray-50 dark:bg-gray-800 rounded-lg border-t border-gray-200 dark:border-gray-700">
        You blocked this user. Unblock to send messages.
      </div>
    );
  }

  return (
    <div className="border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 p-2">
      {/* Attachments Preview */}
      {attachments.length > 0 && (
        <div className="flex gap-2 mb-2 overflow-x-auto pb-2">
          {attachments.map((file, index) => (
            <div key={index} className="relative flex-shrink-0">
              {file.type.startsWith('image/') ? (
                <img
                  src={URL.createObjectURL(file)}
                  alt="preview"
                  className="w-16 h-16 object-cover rounded-lg border border-gray-200 dark:border-gray-700"
                />
              ) : file.type.startsWith('audio/') ? (
                <div className="w-16 h-16 bg-primary/10 rounded-lg flex flex-col items-center justify-center">
                  <Mic className="w-6 h-6 text-primary" />
                  <span className="text-[10px] text-gray-500 mt-1">Audio</span>
                </div>
              ) : (
                <div className="w-16 h-16 bg-gray-200 dark:bg-gray-700 rounded-lg flex items-center justify-center text-xs text-center p-1 break-words">
                  {file.name.slice(0, 10)}
                </div>
              )}
              <button
                onClick={() => removeAttachment(index)}
                className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-0.5 hover:bg-red-600 transition"
                disabled={isUploading}
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      <div className="flex items-center gap-2 px-2 pb-1">
        {/* Emoji Picker Button */}


        {editingMessage && (
          <div className="flex items-center justify-between bg-blue-50 dark:bg-gray-800 px-3 py-1 rounded mb-1">
            <span className="text-xs text-gray-600 dark:text-gray-300">
              Editing message...
            </span>
            <button onClick={onCancelEdit}>
              <X className="w-4 h-4 text-red-500" />
            </button>
          </div>
        )}

        {replyingTo && (
          <div className="flex items-center justify-between bg-gray-100 dark:bg-gray-800 px-3 py-2 rounded mb-2">
            <div className="text-xs">
              <span className="font-semibold">
                Replying to {replyingTo.sender_name}
              </span>
              <p className="truncate max-w-[200px]">
                {replyingTo.message || "Attachment"}
              </p>
            </div>
            <button onClick={() => onCancelReply()}>
              <X className="w-4 h-4 text-red-500" />
            </button>
          </div>
        )}

        <div className="flex-1 relative">

          <input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            onKeyUp={handleTyping}
            placeholder="Type a message..."
            disabled={isUploading || isSending}
            className="w-full h-10 rounded-[28px] pl-5 pr-16 border-0 outline-none shadow-none ring-0 focus:ring-0 bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white" />
          {/* Emoji */}
          <div className="absolute right-3 top-1/2 -translate-y-1/2">
            <button
              onClick={() => setShowEmojiPicker(!showEmojiPicker)}
              className="text-gray-500 hover:text-primary"
              type="button"
            >
              <Smile className="w-5 h-5" />
            </button>

            {showEmojiPicker && (
              <div className="absolute bottom-full mb-2 left-0 z-50">
                <EmojiPicker onEmojiClick={handleEmojiSelect} />
              </div>
            )}
          </div>

          {/* Attachment */}
          <button
            onClick={() => fileInputRef.current?.click()}
            className="absolute right-12 top-1/2 -translate-y-1/2 text-gray-500 hover:text-primary"
            type="button"
          >
            <Paperclip className="w-5 h-5" />
          </button>

          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="image/*,video/*,audio/*"
            onChange={handleFileSelect}
            className="hidden"
          />
        </div>

        {message.trim() || attachments.length > 0 ? (
          <button
            onClick={handleSend}
            disabled={isSending || isUploading}
            className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center self-center shadow-lg shrink-0"
          >
            {isSending || isUploading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </button>
        ) : (
          <button
            onClick={() => setShowAudioRecorder(true)}
            className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center shadow-lg"
            type="button"
          >
            <Mic className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Audio Recorder Modal */}
      {showAudioRecorder && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 max-w-md w-full mx-4">
            <AudioRecorder
              onSave={handleAudioRecorded}
              onCancel={() => setShowAudioRecorder(false)}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatInput;