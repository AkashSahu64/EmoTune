import React from "react";
import { Download, Eye, Loader2, Save } from "lucide-react";

const StoryControls = ({ disabled, isBusy, isUploading, onPreview, onDownload, onUpload }) => (
  <div className="flex items-center gap-2">
    <button type="button" onClick={onPreview} disabled={disabled} className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-foreground transition hover:bg-border disabled:opacity-40 dark:bg-muted-dark dark:text-foreground-dark" aria-label="Preview" title="Preview">
      <Eye size={20} />
    </button>
    <button type="button" onClick={onDownload} disabled={disabled} className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-foreground transition hover:bg-border disabled:opacity-40 dark:bg-muted-dark dark:text-foreground-dark" aria-label="Download" title="Download">
      <Download size={20} />
    </button>
    <button
      type="button"
      onClick={onUpload}
      disabled={disabled}
      className="flex h-10 items-center justify-center gap-2 rounded-full bg-primary px-3 text-md font-semibold text-white shadow-lg transition hover:bg-primary-light disabled:opacity-50"
    >
      {isBusy ? <Loader2 size={20} className="animate-spin" /> : <Save size={20} />}
      <span>{isUploading ? "Uploading" : "Upload"}</span>
    </button>
  </div>
);

export default React.memo(StoryControls);
