// import React, { useState } from 'react';
// import { motion } from 'framer-motion';
// import { CheckCircle, BarChart3 } from 'lucide-react';
// import { useAuthStore } from '../../../store/authStore.js';
// import { useUIStore } from '../../../store/uiStore.js';
// import { showError, showSuccess } from '../../../utils/toast.js';
// import { vibeService } from '../../../services/vibe.service.js';
// import { useTranslation } from 'react-i18next';

// const Poll = ({ poll, postId, onVote }) => {
//   const { isAuthenticated } = useAuthStore();
//   const { openModal } = useUIStore();
//   const { t } = useTranslation(); 

//   const [selectedOption, setSelectedOption] = useState(null);
//   const [hasVoted, setHasVoted] = useState(poll.has_voted || false);
//   const [totalVotes, setTotalVotes] = useState(poll.total_votes || 0);
//   const [options, setOptions] = useState(poll.options || []);
//   const [isSubmitting, setIsSubmitting] = useState(false);

//   const handleVote = async (optionId) => {
//     if (!isAuthenticated) {
//       openModal('login');
//       return;
//     }

//     if (hasVoted) {
//       showError(t("already_voted"));
//       return;
//     }

//     setSelectedOption(optionId);
//     setIsSubmitting(true);

//     try {
//       await vibeService.votePoll(postId, optionId);

//       setHasVoted(true);

//       const updatedOptions = options.map(option => {
//         if (option.id === optionId) {
//           return { ...option, votes: option.votes + 1 };
//         }
//         return option;
//       });

//       setOptions(updatedOptions);
//       setTotalVotes(prev => prev + 1);

//       if (onVote) onVote();

//       showSuccess(t("vote_submitted")); 
//     } catch (error) {
//       setSelectedOption(null);
//       showError(t("vote_failed"));
//     } finally {
//       setIsSubmitting(false);
//     }
//   };

//   const calculatePercentage = (votes) => {
//     if (totalVotes === 0) return 0;
//     return Math.round((votes / totalVotes) * 100);
//   };

//   const isExpired = () => {
//     if (!poll.expires_at) return false;
//     return new Date(poll.expires_at) < new Date();
//   };

//   return (
//     <div className="bg-muted dark:bg-muted-dark rounded-xl p-4">
      
//       {/* Poll Header */}
//       <div className="flex items-center justify-between mb-4">
//         <h3 className="font-semibold text-foreground dark:text-foreground-dark">
//           {poll.question}
//         </h3>

//         <div className="flex items-center space-x-2 text-sm text-mutedForeground dark:text-mutedForeground-dark">
//           <BarChart3 className="w-4 h-4" />
//           <span>
//             {t("votes_count", { count: totalVotes })} 
//           </span>
//         </div>
//       </div>

//       {/* Poll Options */}
//       <div className="space-y-1">
//         {options.map((option) => {
//           const percentage = calculatePercentage(option.votes);
//           const isSelected = selectedOption === option.id;
//           const isWinner = hasVoted && Math.max(...options.map(o => o.votes)) === option.votes;

//           return (
//             <div key={option.id} className="relative">
//               <button
//                 onClick={() => handleVote(option.id)}
//                 disabled={hasVoted || isExpired() || isSubmitting}
//                 className={`w-full text-left p-3 rounded-lg border transition-all ${
//                   isSelected
//                     ? 'border-primary bg-primary/5 dark:bg-primary/10'
//                     : 'border-border dark:border-border-dark hover:border-primary'
//                 } ${hasVoted ? 'cursor-default' : ''}`}
//               >
//                 <div className="flex items-center justify-between">
//                   <div className="flex items-center space-x-3">
//                     {hasVoted && isWinner && (
//                       <CheckCircle className="w-5 h-5 text-success" />
//                     )}
//                     <span className="font-medium text-foreground dark:text-foreground-dark">
//                       {option.text}
//                     </span>
//                   </div>

//                   {hasVoted && (
//                     <div className="flex items-center space-x-3">
//                       <span className="text-sm font-semibold text-foreground dark:text-foreground-dark">
//                         {percentage}%
//                       </span>
//                       <span className="text-sm text-mutedForeground dark:text-mutedForeground-dark">
//                         ({option.votes})
//                       </span>
//                     </div>
//                   )}
//                 </div>

//                 {hasVoted && (
//                   <div className="mt-2">
//                     <div className="h-2 bg-border dark:bg-border-dark rounded-full overflow-hidden">
//                       <motion.div
//                         initial={{ width: 0 }}
//                         animate={{ width: `${percentage}%` }}
//                         transition={{ duration: 1, ease: 'easeOut' }}
//                         className={`h-full rounded-full ${
//                           isWinner ? 'bg-success' : 'bg-primary'
//                         }`}
//                       />
//                     </div>
//                   </div>
//                 )}
//               </button>
//             </div>
//           );
//         })}
//       </div>

//       {/* Poll Footer */}
//       <div className="mt-4 pt-4 border-t border-border dark:border-border-dark">
//         <div className="flex items-center justify-between text-sm text-mutedForeground dark:text-mutedForeground-dark">
//           <div>
//             {hasVoted ? (
//               <span>{t("thank_you_voting")}</span>
//             ) : isExpired() ? (
//               <span className="text-danger">{t("poll_ended")}</span>
//             ) : (
//               <span>{t("select_choice")}</span>
//             )}
//           </div>

//           {poll.expires_at && !isExpired() && (
//             <div className="flex items-center space-x-1">
//               <span>{t("ends_in")}</span>
//               <span className="font-semibold">
//                 {t("days_count", {
//                   count: Math.ceil(
//                     (new Date(poll.expires_at) - new Date()) /
//                       (1000 * 60 * 60 * 24)
//                   ),
//                 })}
//               </span>
//             </div>
//           )}
//         </div>
//       </div>

//       {/* Vote Status */}
//       {hasVoted && (
//         <motion.div
//           initial={{ opacity: 0, y: 10 }}
//           animate={{ opacity: 1, y: 0 }}
//           className="mt-3 p-2 bg-success/10 border border-success/20 rounded-lg"
//         >
//           <div className="flex items-center space-x-2 text-success">
//             <CheckCircle className="w-4 h-4" />
//             <span className="text-sm font-medium">
//               {t("vote_recorded")}
//             </span>
//           </div>
//         </motion.div>
//       )}
//     </div>
//   );
// };

// export default Poll;