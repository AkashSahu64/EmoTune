import React from "react";
import { motion } from "framer-motion";
import { X } from "lucide-react";

import Button from "../../../components/common/Button";
import EmptyState from "../../../components/common/EmptyState";
import Avatar from "../../../components/common/Avatar";

import { useTranslation } from "react-i18next";

const SearchHistory = ({ history, onSelect, onRemove, onClear }) => {
  const { t } = useTranslation();

  // Empty state
  if (history.length === 0) {
    return (
      <EmptyState
        icon="clock"
        title={t("no_recent_searches")}
        description={t("search_prompt")}
      />
    );
  }

  return (
    <div className="space-y-2">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-foreground dark:text-foreground-dark">
          {t("recent")}
        </h2>

        <Button
          variant="ghost"
          size="small"
          onClick={onClear}
          className="text-xs text-mutedForeground hover:text-foreground"
        >
          {t("clear_all")}
        </Button>
      </div>

      {/* Recent profiles */}
      <ul className="space-y-1">
        {history.map((profile) => (
          <motion.li
            key={profile.username}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, height: 0 }}
            className="
              flex items-center justify-between
              group rounded-lg px-2 py-1
              hover:bg-muted dark:hover:bg-muted-dark
              transition
            "
          >
            {/* Profile item */}
            <button
              onClick={() => onSelect(profile)}
              className="
                flex items-center gap-3
                flex-1 text-left min-w-0
              "
            >
              {/* Avatar */}
              <Avatar
                src={profile.avatar}
                alt={profile.username}
                size="medium"
              />

              {/* Info */}
              <div className="min-w-0 leading-tight">
                <p className="font-medium truncate text-foreground dark:text-foreground-dark">
                  {profile.username}
                </p>

                <p className="text-xs truncate text-mutedForeground dark:text-mutedForeground-dark">
                  {profile.name}
                </p>
              </div>
            </button>

            {/* Remove button */}
            <button
              onClick={() => onRemove(profile.username)}
              className="
                p-1.5
                opacity-0 group-hover:opacity-100
                transition-opacity
                rounded-full
                hover:bg-muted dark:hover:bg-muted-dark
                flex-shrink-0
              "
              aria-label={t("remove_from_history", {
                term: profile.username,
              })}
            >
              <X
                className="
                  w-4 h-4
                  text-mutedForeground
                "
              />
            </button>
          </motion.li>
        ))}
      </ul>
    </div>
  );
};

export default SearchHistory;