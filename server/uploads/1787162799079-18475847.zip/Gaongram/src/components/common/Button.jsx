import React from 'react';
import { motion } from 'framer-motion';

const Button = React.forwardRef(({
  children,
  variant = 'primary',
  size = 'medium',
  loading = false,
  disabled = false,
  fullWidth = false,
  startIcon,
  endIcon,
  className = '',
  onClick,
  type = 'button',
  ...props
}, ref) => {
  const baseClasses = 'inline-flex items-center justify-center font-medium rounded-lg transition-all duration-200 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed smooth-transition';
  
  const variants = {
    primary:   'bg-primary text-white hover:bg-primary-light focus:ring-primary',
    secondary: 'bg-muted dark:bg-muted-dark text-foreground dark:text-foreground-dark hover:bg-muted/80 dark:hover:bg-muted-dark/80 focus:ring-border dark:focus:ring-border-dark',
    outline:   'border border-border dark:border-border-dark text-foreground dark:text-foreground-dark hover:bg-muted dark:hover:bg-muted-dark focus:ring-border dark:focus:ring-border-dark',
    ghost:     'text-foreground dark:text-foreground-dark hover:bg-muted dark:hover:bg-muted-dark focus:ring-border dark:focus:ring-border-dark',
    danger:    'bg-danger text-white hover:bg-danger/90 focus:ring-danger',
    success:   'bg-success text-white hover:bg-success/90 focus:ring-success',
  };
  
  const sizes = {
    small: 'px-2 py-1.5 text-base',
    medium: 'px-3 py-2 text-base',
    large: 'px-4 py-3 text-lg',
  };
  
  const widthClass = fullWidth ? 'w-full' : '';
  
  const classes = `${baseClasses} ${variants[variant]} ${sizes[size]} ${widthClass} ${className}`;
  
  const handleClick = (e) => {
    if (!loading && !disabled && onClick) {
      onClick(e);
    }
  };
  
  return (
    <motion.button
      ref={ref}
      type={type}
      className={classes}
      disabled={disabled || loading}
      onClick={handleClick}
      whileTap={{ scale: disabled || loading ? 1 : 0.98 }}
      {...props}
    >
      {loading && (
        <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-current" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
        </svg>
      )}
      {!loading && startIcon && <span className="mr-2">{startIcon}</span>}
      {children}
      {!loading && endIcon && <span className="ml-2">{endIcon}</span>}
    </motion.button>
  );
});

Button.displayName = 'Button';

export default Button;