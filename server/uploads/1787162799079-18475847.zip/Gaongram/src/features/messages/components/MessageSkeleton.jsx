// src/features/messages/components/MessageSkeleton.jsx
import React from 'react';

const MessageSkeleton = () => {
  return (
    <div className="flex items-center gap-3 p-4 animate-pulse">
      <div className="w-12 h-12 bg-gray-200 dark:bg-gray-700 rounded-full" />
      <div className="flex-1">
        <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-32 mb-2" />
        <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-48" />
      </div>
      <div className="w-10 h-3 bg-gray-200 dark:bg-gray-700 rounded" />
    </div>
  );
};

export default MessageSkeleton;