// src/components/auth/InitialRouteGuard.jsx
import { Navigate, useLocation } from "react-router-dom";
import { useAuthStore } from "../../../store/authStore";

const InitialRouteGuard = ({ children }) => {
  const { isAuthenticated } = useAuthStore();
  const location = useLocation();

  // Only redirect from "/" when not authenticated
  if (location.pathname === "/" && !isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return children;
};

export default InitialRouteGuard;