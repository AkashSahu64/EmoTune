export const formatStoryDuration = (ms) => {
  const seconds = Math.floor(ms / 1000);
  return `${seconds}s`;
};