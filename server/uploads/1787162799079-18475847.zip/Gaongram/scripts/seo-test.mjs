/* eslint-env node */
/* global console */
import assert from "node:assert/strict";
import {
  buildAudioSeo,
  buildBlogSeo,
  buildHashtagSeo,
  buildPlaylistSeo,
  buildPostSeo,
  buildProfileSeo,
  buildReelSeo,
  buildStorySeo,
} from "../seo/builders/index.mjs";
import { renderSeoHead } from "../seo/metadata/render.mjs";
import { getImageMimeType } from "../seo/metadata/utils.mjs";
import { renderRobotsTxt } from "../seo/robots/index.mjs";
import {
  normalizeSitemapItems,
  renderSitemapIndex,
  renderUrlSet,
  SITEMAP_SECTIONS,
} from "../seo/sitemap/index.mjs";

const REQUIRED_META = [
  'property="og:title"',
  'property="og:description"',
  'property="og:url"',
  'property="og:image"',
  'property="og:image:width"',
  'property="og:image:height"',
  'property="og:image:type"',
  'property="og:image:alt"',
  'name="twitter:card"',
  'name="twitter:title"',
  'name="twitter:description"',
  'name="twitter:image"',
  'rel="canonical"',
  'type="application/ld+json"',
];

const countOccurrences = (haystack, needle) =>
  (haystack.match(new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g")) || [])
    .length;

const assertNoDuplicateSingletons = (html, label) => {
  for (const needle of [
    "<title",
    'name="description"',
    'name="robots"',
    'name="googlebot"',
    'rel="canonical"',
    'property="og:title"',
    'property="og:description"',
    'property="og:url"',
    'name="twitter:title"',
    'name="twitter:description"',
    'name="twitter:image"',
  ]) {
    assert.equal(countOccurrences(html, needle), 1, `${label} duplicated ${needle}`);
  }
};

const assertSeoHead = (label, seo, expected = []) => {
  const html = renderSeoHead(seo, seo.canonical || "/");
  for (const needle of REQUIRED_META) {
    assert.ok(html.includes(needle), `${label} missing ${needle}`);
  }
  for (const needle of expected) {
    assert.ok(html.includes(needle), `${label} missing expected text: ${needle}`);
  }
  assertNoDuplicateSingletons(html, label);
  return html;
};

const profile = {
  id: 3,
  user_id: "3",
  username: "akash_a90f",
  full_name: "Akash Sahu",
  bio: "This is bio",
  profile_image: "http://gaongram.com/media/profile_photos/profile-image.jpg",
  followers_count: 6,
  following_count: 12,
  posts_count: 33,
  updated_at: "2026-06-02T10:00:00Z",
};

assertSeoHead("profile", buildProfileSeo(profile, { identifier: "akash_a90f" }), [
  "Akash Sahu (@akash_a90f)",
  "6 Followers",
  "12 Following",
  "33 Posts",
  "This is bio",
  "See Akash Sahu",
  "/media/profile_photos/profile-image.jpg",
]);

assertSeoHead(
  "profile numeric canonical",
  buildProfileSeo(profile, { identifier: "3" }),
  ["https://gaongram.com/profile/akash_a90f"],
);

assertSeoHead(
  "post",
  buildPostSeo(
    {
      id: 10,
      caption: "A field update from GaonGram",
      images: [{ url: "/media/posts/10.jpg" }],
      user: profile,
    },
    profile,
    { postId: 10, path: "/posts/10" },
  ),
  ["/media/posts/10.jpg"],
);

assertSeoHead(
  "image post",
  buildPostSeo(
    {
      id: 11,
      caption: "Image post",
      media_type: "image",
      images: [{ url: "/media/posts/11.jpg" }],
      user: profile,
    },
    profile,
    { postId: 11, path: "/posts/11" },
  ),
  ["/media/posts/11.jpg"],
);

assertSeoHead(
  "reel",
  buildReelSeo(
    {
      id: 12,
      caption: "Reel caption",
      videos: [{ thumbnail: "/media/reels/12.jpg", video: "/media/reels/12.mp4" }],
      user: profile,
    },
    { reelId: 12, path: "/reels/12" },
  ),
  ["/media/reels/12.jpg", 'property="og:video"'],
);

assertSeoHead(
  "audio",
  buildAudioSeo(
    {
      id: 13,
      caption: "Audio caption",
      audio: { title: "Morning track", cover_image: "/media/audio/13.jpg" },
      user: profile,
    },
    { audioId: 13, path: "/audio/13" },
  ),
  ["/media/audio/13.jpg"],
);

assertSeoHead(
  "blog",
  buildBlogSeo(
    {
      id: 14,
      slug: "gaon-update",
      title: "Gaon update",
      excerpt: "A long form update",
      cover_image: "/media/blogs/14.jpg",
      author: profile,
      tags: ["gaon", "update"],
    },
    { blogId: "gaon-update", path: "/blogs/gaon-update" },
  ),
  ["/media/blogs/14.jpg", 'property="article:tag"'],
);

assertSeoHead(
  "playlist",
  buildPlaylistSeo(
  { id: 15, name: "Village sounds", items_count: 8, cover_image: "/media/playlists/15.jpg" },
    { id: 15, path: "/playlists/15" },
  ),
  ["/media/playlists/15.jpg"],
);

assertSeoHead(
  "hashtag",
  buildHashtagSeo({ name: "gaon", posts_count: 42 }, { tag: "gaon", path: "/hashtags/gaon" }),
  ["/api/og/hashtag/gaon"],
);

assertSeoHead(
  "story",
  buildStorySeo({ id: 16, caption: "Story caption", user: profile }, { path: "/story/16" }),
  ["/media/profile_photos/profile-image.jpg", "noindex"],
);

assert.equal(
  getImageMimeType("https://gaongram.com/api/og/profile/akash_a90f"),
  "image/png",
);

const robots = renderRobotsTxt();
for (const path of ["/login", "/register", "/messages", "/settings", "/notifications"]) {
  assert.ok(robots.includes(`Disallow: ${path}`), `robots missing ${path}`);
}
assert.ok(robots.includes("User-agent: Googlebot"), "robots missing Googlebot block");
assert.ok(robots.includes("Sitemap: https://gaongram.com/sitemap.xml"), "robots missing sitemap");

const sitemapIndex = renderSitemapIndex();
for (const section of SITEMAP_SECTIONS) {
  assert.ok(
    sitemapIndex.includes(`/sitemap-${section}.xml`),
    `sitemap index missing ${section}`,
  );
}

assert.ok(
  renderUrlSet(normalizeSitemapItems("profiles", [profile])).includes(
    "https://gaongram.com/profile/akash_a90f",
  ),
  "profile sitemap did not use username route",
);

const previousFetch = globalThis.fetch;
const requestedUrls = [];
globalThis.fetch = async (url) => {
  requestedUrls.push(String(url));
  const body = String(url).endsWith("/profiles/akash_a90f/")
    ? { success: true, data: profile }
    : { success: false, data: null };
  return {
    ok: String(url).endsWith("/profiles/akash_a90f/"),
    status: String(url).endsWith("/profiles/akash_a90f/") ? 200 : 404,
    statusText: String(url).endsWith("/profiles/akash_a90f/") ? "OK" : "Not Found",
    json: async () => body,
  };
};

const { fetchProfileByIdentifier } = await import("./profile-seo.mjs");
const resolvedProfile = await fetchProfileByIdentifier("akash_a90f");
assert.equal(resolvedProfile.username, "akash_a90f");
assert.equal(resolvedProfile.followers_count, 6);
assert.ok(
  requestedUrls.some((url) => url.endsWith("/profiles/akash_a90f/")),
  "username resolver did not try the public detail route",
);
globalThis.fetch = previousFetch;

console.log("SEO validation passed.");
