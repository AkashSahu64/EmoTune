import React, { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Heart, Reply, MoreVertical, Check, X } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuthStore } from "../../store/authStore.js";
import { useUIStore } from "../../store/uiStore.js";
import { commentService } from "../../services/comment.service.js";
import { formatTime } from "../../utils/formatTime.js";
import { showSuccess, showError } from "../../utils/toast.js";
import Avatar from "../../components/common/Avatar.jsx";
import Button from "../../components/common/Button.jsx";
import CommentBox from "./CommentBox.jsx";
import { useTranslation } from "react-i18next";

const MotionDiv = motion.div;

const isSameId = (a, b) => String(a) === String(b);

const toBoolean = (value) => {
  if (typeof value === "boolean") return value;
  if (typeof value === "string") return value.toLowerCase() === "true";
  return Boolean(value);
};

const withCommentResults = (old, updateResults, updateCount) => {
  if (!old) return old;

  if (Array.isArray(old)) {
    return updateResults(old);
  }

  if (Array.isArray(old?.data?.results)) {
    return {
      ...old,
      data: {
        ...old.data,
        results: updateResults(old.data.results),
        count: updateCount ? updateCount(old.data.count) : old.data.count,
      },
    };
  }

  if (Array.isArray(old?.data)) {
    return {
      ...old,
      data: updateResults(old.data),
    };
  }

  return old;
};

const updateCommentInTree = (comments, commentId, updater) =>
  comments.map((item) => {
    if (isSameId(item.id, commentId)) {
      return updater(item);
    }

    if (Array.isArray(item.replies) && item.replies.length > 0) {
      return {
        ...item,
        replies: updateCommentInTree(item.replies, commentId, updater),
      };
    }

    return item;
  });

const removeCommentFromTree = (comments, commentId) =>
  comments
    .filter((item) => !isSameId(item.id, commentId))
    .map((item) => ({
      ...item,
      replies: Array.isArray(item.replies)
        ? removeCommentFromTree(item.replies, commentId)
        : [],
    }));

const getRootComments = (commentsData) => {
  if (Array.isArray(commentsData)) return commentsData;
  if (Array.isArray(commentsData?.data?.results)) {
    return commentsData.data.results;
  }
  if (Array.isArray(commentsData?.data)) return commentsData.data;
  return [];
};

const getUpdatedComment = (response) => {
  const candidates = [response?.data?.data, response?.data, response];

  return candidates.find(
    (candidate) =>
      candidate &&
      typeof candidate === "object" &&
      !Array.isArray(candidate) &&
      (candidate.id || candidate.comment || "likes_count" in candidate),
  );
};

const CommentItem = ({ comment, blogId, postId, level = 0 }) => {
  const { user, isAuthenticated } = useAuthStore();
  const { openModal } = useUIStore();
  const queryClient = useQueryClient();
  const { t } = useTranslation();

  const [showReplies, setShowReplies] = useState(false);
  const [isReplying, setIsReplying] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editedContent, setEditedContent] = useState(comment.comment);

  const replies = Array.isArray(comment.replies) ? comment.replies : [];
  const isOwner = Number(user?.id) === Number(comment.user);
  const isLiked = toBoolean(comment.is_liked);
  const likeCount = comment.likes_count || 0;
  const commentQueryKey = postId
    ? ["comments", postId]
    : blogId
      ? ["blog-comments", blogId]
      : null;

  const likeMutation = useMutation({
    mutationFn: () => commentService.likeComment(comment.id),
    onMutate: async () => {
      if (!commentQueryKey) return {};

      await queryClient.cancelQueries({ queryKey: commentQueryKey });
      const previousComments = queryClient.getQueryData(commentQueryKey);

      queryClient.setQueryData(commentQueryKey, (old) =>
        withCommentResults(old, (comments) =>
          updateCommentInTree(comments, comment.id, (item) => {
            const alreadyLiked = toBoolean(item.is_liked);

            return {
              ...item,
              is_liked: !alreadyLiked,
              likes_count: !alreadyLiked
                ? (item.likes_count || 0) + 1
                : Math.max(0, (item.likes_count || 0) - 1),
            };
          }),
        ),
      );

      return { previousComments };
    },
    onSuccess: (data) => {
      const updated = getUpdatedComment(data);

      if (
        commentQueryKey &&
        updated &&
        ("likes_count" in updated || "is_liked" in updated)
      ) {
        queryClient.setQueryData(commentQueryKey, (old) =>
          withCommentResults(old, (comments) =>
            updateCommentInTree(comments, comment.id, (item) => ({
              ...item,
              is_liked:
                typeof updated.is_liked === "undefined"
                  ? item.is_liked
                  : toBoolean(updated.is_liked),
              likes_count: updated.likes_count ?? item.likes_count,
            })),
          ),
        );
      }
    },
    onError: (err, variables, context) => {
      if (commentQueryKey && context?.previousComments) {
        queryClient.setQueryData(commentQueryKey, context.previousComments);
      }

      showError(t("like_failed"));
    },
  });

  const deleteMutation = useMutation({
    mutationFn: () => commentService.deleteComment(comment.id),
    onMutate: async () => {
      if (!commentQueryKey) return {};

      await queryClient.cancelQueries({ queryKey: commentQueryKey });
      const previousComments = queryClient.getQueryData(commentQueryKey);
      const wasTopLevel = getRootComments(previousComments).some((item) =>
        isSameId(item.id, comment.id),
      );

      queryClient.setQueryData(commentQueryKey, (old) =>
        withCommentResults(
          old,
          (comments) => removeCommentFromTree(comments, comment.id),
          (count = 0) => Math.max(0, count - 1),
        ),
      );

      return { previousComments };
    },
    onSuccess: () => {
      showSuccess(t("comment_deleted"));
    },
    onError: (err, variables, context) => {
      if (commentQueryKey && context?.previousComments) {
        queryClient.setQueryData(commentQueryKey, context.previousComments);
      }

      showError(t("delete_failed"));
    },
  });

  const updateMutation = useMutation({
    mutationFn: (updatedContent) =>
      commentService.updateComment(comment.id, { comment: updatedContent }),
    onMutate: async (updatedContent) => {
      if (!commentQueryKey) return {};

      await queryClient.cancelQueries({ queryKey: commentQueryKey });
      const previousComments = queryClient.getQueryData(commentQueryKey);

      queryClient.setQueryData(commentQueryKey, (old) =>
        withCommentResults(old, (comments) =>
          updateCommentInTree(comments, comment.id, (item) => ({
            ...item,
            comment: updatedContent,
            edited: true,
          })),
        ),
      );

      return { previousComments };
    },
    onSuccess: (data, updatedContent) => {
      const updated = getUpdatedComment(data);

      if (commentQueryKey) {
        queryClient.setQueryData(commentQueryKey, (old) =>
          withCommentResults(old, (comments) =>
            updateCommentInTree(comments, comment.id, (item) => ({
              ...item,
              ...updated,
              comment: updated?.comment ?? updatedContent,
            })),
          ),
        );
      }

      showSuccess(t("comment_updated"));
      setIsEditing(false);
    },
    onError: (err, variables, context) => {
      if (commentQueryKey && context?.previousComments) {
        queryClient.setQueryData(commentQueryKey, context.previousComments);
      }

      setEditedContent(comment.comment);
      showError(t("update_failed"));
    },
  });

  const handleLike = () => {
    if (!isAuthenticated) {
      openModal("login");
      return;
    }

    if (!likeMutation.isPending) {
      likeMutation.mutate();
    }
  };

  const handleDelete = () => {
    openModal("confirm", {
      title: t("delete_comment"),
      message: t("confirm_delete_comment"),
      onConfirm: () => deleteMutation.mutate(),
    });
  };

  const handleReport = () => {
    openModal("report", {
      type: "comment",
      id: comment.id,
    });
  };

  const handleEdit = () => {
    if (isEditing) {
      if (editedContent.trim() && editedContent !== comment.comment) {
        updateMutation.mutate(editedContent.trim());
      } else {
        setIsEditing(false);
        setEditedContent(comment.comment);
      }
    } else {
      setEditedContent(comment.comment);
      setIsEditing(true);
    }
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditedContent(comment.comment);
  };

  const handleReply = () => {
    if (isReply) return;

    if (!isAuthenticated) {
      openModal("login");
      return;
    }

    setIsReplying((prev) => !prev);
  };

  const handleReplyAdded = () => {
    setShowReplies(true);
    setIsReplying(false);
  };

  return (
    <MotionDiv
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      className={`bg-white dark:bg-card-dark rounded-lg ${
        level > 0
          ? "ml-8 border-l-2 border-border dark:border-border-dark pl-4"
          : ""
      }`}
    >
      <div className="flex items-start justify-between p-4">
        <div className="flex items-start space-x-3">
          <Link to={`/profile/${comment.username}`}>
            <Avatar
              src={comment.profile_image}
              alt={comment.username}
              size={level > 0 ? "sm" : "medium"}
            />
          </Link>

          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-1">
              <Link
                to={`/profile/${comment.username}`}
                className="font-semibold text-foreground dark:text-foreground-dark hover:text-instagram-pink"
              >
                {comment.username}
              </Link>

              <span className="text-xs text-mutedForeground dark:text-mutedForeground-dark">
                {formatTime(comment.created_at, "relative")}
                {comment.edited && ` ${t("edited")}`}
              </span>
            </div>

            {isEditing ? (
              <div className="space-y-2">
                <textarea
                  value={editedContent}
                  onChange={(event) => setEditedContent(event.target.value)}
                  className="w-full p-3 border border-border dark:border-border-dark bg-white dark:bg-card-dark rounded-lg focus:ring-2 focus:ring-instagram-pink focus:border-transparent text-foreground dark:text-foreground-dark"
                  rows={3}
                />

                <div className="flex items-center space-x-2">
                  <Button
                    size="small"
                    onClick={handleEdit}
                    loading={updateMutation.isPending}
                    disabled={!editedContent.trim() || updateMutation.isPending}
                    startIcon={<Check className="w-4 h-4" />}
                  >
                    {t("save")}
                  </Button>

                  <Button
                    variant="outline"
                    size="small"
                    onClick={handleCancelEdit}
                    disabled={updateMutation.isPending}
                    startIcon={<X className="w-4 h-4" />}
                  >
                    {t("cancel")}
                  </Button>
                </div>
              </div>
            ) : (
              <p className="text-foreground dark:text-foreground-dark whitespace-pre-wrap">
                {comment.comment}
              </p>
            )}

            {comment.images && comment.images.length > 0 && (
              <div className="mt-3 grid grid-cols-2 gap-2">
                {comment.images.map((image, index) => (
                  <img
                    key={index}
                    src={image}
                    alt={t("comment_image", { index: index + 1 })}
                    className="w-full h-auto rounded-lg object-cover"
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="relative">
          <button
            type="button"
            onClick={() =>
              openModal("comment-options", {
                isOwner,
                onEdit: () => setIsEditing(true),
                onDelete: handleDelete,
                onReport: handleReport,
              })
            }
            className="p-1 text-mutedForeground dark:text-mutedForeground-dark hover:text-foreground dark:hover:text-foreground-dark"
            aria-label={t("more_options")}
          >
            <MoreVertical className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="px-4 pb-4 flex items-center space-x-6">
        <button
          type="button"
          onClick={handleLike}
          disabled={likeMutation.isPending}
          className={`flex items-center space-x-1 ${
            isLiked
              ? "text-red-500"
              : "text-mutedForeground dark:text-mutedForeground-dark hover:text-red-500"
          }`}
        >
          <Heart className={`w-5 h-5 ${isLiked ? "fill-current" : ""}`} />
          <span className="text-sm font-medium">{likeCount}</span>
        </button>

        <button
          type="button"
          onClick={handleReply}
          className="flex items-center space-x-1 text-mutedForeground dark:text-mutedForeground-dark hover:text-foreground dark:hover:text-foreground-dark"
        >
          <Reply className="w-5 h-5" />
          <span className="text-sm font-medium">{t("reply")}</span>
        </button>

        {replies.length > 0 && (
          <button
            type="button"
            onClick={() => setShowReplies((prev) => !prev)}
            className="text-sm text-instagram-pink hover:text-pink-600 font-medium"
          >
            {showReplies
              ? t("hide_replies")
              : t("view_replies", { count: replies.length })}
          </button>
        )}
      </div>

      {isReplying && (
        <div className="px-4 pb-4">
          <CommentBox
            blogId={blogId}
            postId={postId}
            replyTo={comment.id}
            onCommentAdded={handleReplyAdded}
          />
        </div>
      )}

      {showReplies && replies.length > 0 && (
        <div className="space-y-4 border-t border-border dark:border-border-dark pt-4">
          {replies.map((reply) => (
            <CommentItem
              key={reply.id}
              comment={reply}
              blogId={blogId}
              postId={postId}
              level={level + 1}
            />
          ))}
        </div>
      )}
    </MotionDiv>
  );
};

export default CommentItem;
