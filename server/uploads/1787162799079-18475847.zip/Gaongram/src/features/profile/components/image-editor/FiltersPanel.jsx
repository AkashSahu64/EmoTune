import React from 'react';
import { motion } from 'framer-motion';
import Button from '../../../../components/common/Button';
import { Sun, Contrast, Zap } from 'lucide-react';

const FiltersPanel = ({
  imagePreview,
  filters,
  onFilterChange,
  onBack,
  onResetFilters,
  config
}) => (
  <motion.div
    key="filters"
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    className="space-y-4"
  >
    {/* Preview */}
    <div className="flex justify-center">
      <div
        className={`
          ${config.type === 'profile'
            ? 'w-40 h-40 rounded-lg'
            : 'w-full max-w-2xl h-32 rounded-md'}
          overflow-hidden bg-gray-100
        `}
      >
        <img
          src={imagePreview}
          alt="Preview"
          className="w-full h-full object-cover"
          style={{
            filter: `
              brightness(${filters.brightness}%)
              contrast(${filters.contrast}%)
              saturate(${filters.saturation}%)
            `,
          }}
        />
      </div>
    </div>

    {/* Controls */}
    <div className="space-y-3">
      {/* Brightness */}
      <div className="space-y-1">
        <div className="flex items-center justify-between text-sm text-gray-800">
          <span className="flex items-center gap-2">
            <Sun size={13} className="text-gray-500" />
            Brightness
          </span>
          <span className="text-gray-400 tabular-nums">
            {filters.brightness}%
          </span>
        </div>
        <input
          type="range"
          min="0"
          max="200"
          value={filters.brightness}
          onChange={(e) =>
            onFilterChange({ ...filters, brightness: parseInt(e.target.value) })
          }
          className="w-full h-1.5 bg-gray-200 rounded cursor-pointer"
        />
      </div>

      {/* Contrast */}
      <div className="space-y-1">
        <div className="flex items-center justify-between text-sm text-gray-800">
          <span className="flex items-center gap-2">
            <Contrast size={13} className="text-gray-500" />
            Contrast
          </span>
          <span className="text-gray-400 tabular-nums">
            {filters.contrast}%
          </span>
        </div>
        <input
          type="range"
          min="0"
          max="200"
          value={filters.contrast}
          onChange={(e) =>
            onFilterChange({ ...filters, contrast: parseInt(e.target.value) })
          }
          className="w-full h-1.5 bg-gray-200 rounded cursor-pointer"
        />
      </div>

      {/* Saturation */}
      <div className="space-y-1">
        <div className="flex items-center justify-between text-sm text-gray-800">
          <span className="flex items-center gap-2">
            <Zap size={13} className="text-gray-500" />
            Saturation
          </span>
          <span className="text-gray-400 tabular-nums">
            {filters.saturation}%
          </span>
        </div>
        <input
          type="range"
          min="0"
          max="200"
          value={filters.saturation}
          onChange={(e) =>
            onFilterChange({ ...filters, saturation: parseInt(e.target.value) })
          }
          className="w-full h-1.5 bg-gray-200 rounded cursor-pointer"
        />
      </div>

      {/* Presets */}
      {config.filterPresets && (
        <div className="pt-1">
          <div className="flex flex-wrap gap-3 text-sm text-gray-600">
            {Object.entries(config.filterPresets).map(([name, preset]) => (
              <button
                key={name}
                onClick={() => onFilterChange(preset)}
                className="hover:text-gray-800 transition capitalize"
              >
                {name}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>

    {/* Actions */}
    <div className="flex justify-between items-center pt-3">
      <Button variant="ghost" size="small" onClick={onBack}>
        Back
      </Button>

      <Button variant="secondary" size="small" onClick={onResetFilters}>
        Reset
      </Button>
    </div>
  </motion.div>
);

export default FiltersPanel;
