import { useState, useCallback, useEffect, useRef } from 'react';
import { useInView } from 'react-intersection-observer';

export const useInfiniteScroll = (fetchFn, options = {}) => {
  const {
    initialPage = 1,
    limit = 10,
    initialData = [],
    enabled = true,
    onError,
  } = options;
  
  const [data, setData] = useState(initialData);
  const [page, setPage] = useState(initialPage);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [ref, inView] = useInView();
  const isMounted = useRef(true);
  
  useEffect(() => {
    isMounted.current = true;
    return () => {
      isMounted.current = false;
    };
  }, []);
  
  const loadMore = useCallback(async () => {
    if (!hasMore || loading || !enabled) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const result = await fetchFn({ page, limit });
      
      if (!isMounted.current) return;
      
      if (result && Array.isArray(result.data)) {
        const newData = result.data;
        setData(prev => [...prev, ...newData]);
        setHasMore(result.hasMore === true);
        setPage(prev => prev + 1);
      } else {
        setHasMore(false);
      }
    } catch (err) {
      if (!isMounted.current) return;
      
      setError(err.message);
      onError?.(err);
    } finally {
      if (isMounted.current) {
        setLoading(false);
      }
    }
  }, [page, hasMore, loading, enabled, fetchFn, limit, onError]);
  
  const refresh = async () => {
  if (!enabled) return;

  setLoading(true);
  setError(null);

  try {
    const result = await fetchFn({ page: initialPage, limit });

    const list = Array.isArray(result?.data) ? result.data : [];

    setData(list);
    setHasMore(result.hasMore === true);
    setPage(initialPage + 1);
  } catch (err) {
    setError(err.message);
    onError?.(err);
  } finally {
    setLoading(false);
  }
};


  
  useEffect(() => {
    if (inView && hasMore && !loading) {
      loadMore();
    }
  }, [inView, hasMore, loading, loadMore]);
  
  return {
    data,
    loading,
    error,
    hasMore,
    ref,
    refresh,
    loadMore,
    setData,
  };
};