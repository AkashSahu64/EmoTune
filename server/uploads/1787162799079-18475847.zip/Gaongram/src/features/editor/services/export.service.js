import {
  downloadExportedStory,
  exportImageStoryWithMusic,
  exportStory,
  exportStoryVideo,
} from "../../story/editor/utils/exportStory.js";

export const exportService = {
  exportImage: exportStory,
  exportImageWithMusic: exportImageStoryWithMusic,
  exportVideo: exportStoryVideo,
  download: downloadExportedStory,
};

export default exportService;
