import api from '../../../config/axios.js';

export const blogsAPI = {
  // Get all blogs
  getBlogs: async (params = {}) => {
    const response = await api.get('/blogs/', { params });
    return response.data;
  },

  // Get single blog
  getBlog: async (blogId) => {
    const response = await api.get(`/blogs/${blogId}/`);
    return response.data;
  },

  // Create blog
  createBlog: async (blogData) => {
    const response = await api.post('/blogs/', blogData);
    return response.data;
  },

  // Update blog
  updateBlog: async (blogId, blogData) => {
    const response = await api.put(`/blogs/${blogId}/`, blogData);
    return response.data;
  },

  // Partial update blog
  patchBlog: async (blogId, blogData) => {
    const response = await api.patch(`/blogs/${blogId}/`, blogData);
    return response.data;
  },

  // Delete blog
  deleteBlog: async (blogId) => {
    const response = await api.delete(`/blogs/${blogId}/`);
    return response.data;
  },

  // Like blog
  likeBlog: async (blogId) => {
    const response = await api.post(`/blogs/${blogId}/like/`);
    return response.data;
  },

  // Unlike blog
  unlikeBlog: async (blogId) => {
    const response = await api.delete(`/blogs/${blogId}/like/`);
    return response.data;
  },

  // Save blog
  saveBlog: async (blogId) => {
    const response = await api.post(`/blogs/${blogId}/save/`);
    return response.data;
  },

  // Unsave blog
  unsaveBlog: async (blogId) => {
    const response = await api.delete(`/blogs/${blogId}/save/`);
    return response.data;
  },

  // Add blog view
  addView: async (blogId) => {
    const response = await api.post(`/blogs/${blogId}/view/`);
    return response.data;
  },

  // Get blog categories
  getCategories: async () => {
    const response = await api.get('/blogs/categories/');
    return response.data;
  },

  // Get blog tags
  getTags: async () => {
    const response = await api.get('/blogs/tags/');
    return response.data;
  },

  // Search blogs
  searchBlogs: async (query, params = {}) => {
    const response = await api.get('/blogs/search/', {
      params: { q: query, ...params },
    });
    return response.data;
  },

  // Get trending blogs
  getTrendingBlogs: async (params = {}) => {
    const response = await api.get('/blogs/trending/', { params });
    return response.data;
  },

  // Get user blogs
  getUserBlogs: async (userId, params = {}) => {
    const response = await api.get(`/users/${userId}/blogs/`, { params });
    return response.data;
  },

  // Get saved blogs
  getSavedBlogs: async (params = {}) => {
    const response = await api.get('/blogs/saved/', { params });
    return response.data;
  },
};