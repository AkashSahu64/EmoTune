import React, { useEffect, useMemo, useRef, useState } from "react";
import { Music } from "lucide-react";

const MusicMarquee = ({
  title = "",
  artist = "",
  className = "",
  textClassName = "",
  icon = true,
}) => {
  const containerRef = useRef(null);
  const textRef = useRef(null);
  const [overflow, setOverflow] = useState(false);
  const [distance, setDistance] = useState(0);

  const label = useMemo(
    () => [title, artist].filter(Boolean).join(" • "),
    [artist, title],
  );

  useEffect(() => {
    const measure = () => {
      const container = containerRef.current;
      const text = textRef.current;
      if (!container || !text) return;
      const nextDistance = Math.max(0, text.scrollWidth - container.clientWidth);
      setDistance(nextDistance);
      setOverflow(nextDistance > 4);
    };

    measure();
    const observer = new ResizeObserver(measure);
    if (containerRef.current) observer.observe(containerRef.current);
    if (textRef.current) observer.observe(textRef.current);
    return () => observer.disconnect();
  }, [label]);

  if (!label) return null;

  return (
    <div className={`flex min-w-0 items-center gap-1.5 ${className}`}>
      {icon && <Music className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />}
      <div ref={containerRef} className="min-w-0 flex-1 overflow-hidden">
        <span
          ref={textRef}
          className={`block w-max whitespace-nowrap will-change-transform ${overflow ? "music-marquee__text" : ""} ${textClassName}`}
          style={{
            "--music-marquee-distance": `${distance}px`,
            "--music-marquee-duration": `${Math.max(5, Math.min(12, distance / 22))}s`,
          }}
          title={label}
        >
          {label}
        </span>
      </div>
    </div>
  );
};

export default React.memo(MusicMarquee);
