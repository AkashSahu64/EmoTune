import { getPointerDistance, getPointerMidpoint } from "../utils/gestureHelpers.js";

export class GestureManager {
  constructor({ onPinch, onRotate, onDrag } = {}) {
    this.onPinch = onPinch;
    this.onRotate = onRotate;
    this.onDrag = onDrag;
    this.pointers = new Map();
    this.lastGesture = null;
  }

  pointerDown(event) {
    this.pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
  }

  pointerMove(event) {
    if (!this.pointers.has(event.pointerId)) return;
    const previous = this.pointers.get(event.pointerId);
    this.pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
    const points = [...this.pointers.values()];

    if (points.length === 1) {
      this.onDrag?.({
        dx: event.clientX - previous.x,
        dy: event.clientY - previous.y,
        point: points[0],
      });
      return;
    }

    if (points.length >= 2) {
      const [a, b] = points;
      const distance = getPointerDistance(a, b);
      const midpoint = getPointerMidpoint(a, b);
      if (this.lastGesture?.distance) {
        this.onPinch?.({ scale: distance / this.lastGesture.distance, midpoint });
      }
      this.lastGesture = { distance, midpoint };
    }
  }

  pointerUp(event) {
    this.pointers.delete(event.pointerId);
    if (this.pointers.size < 2) this.lastGesture = null;
  }
}
