// src/features/auth/pages/Login.jsx
import React from "react";
import { motion } from "framer-motion";
import Seo from "../../../components/seo/Seo.jsx";
import { buildStaticPageSeo } from "../../../seo/seoBuilders.js";
import LoginCard from "../components/LoginCard.jsx";
import { useUIStore } from "../../../store/uiStore.js";

// Hero components
import SocialHeroStack from "../components/authHero/SocialHeroStack.jsx";
import AnalyticsGlassPanel from "../components/authHero/AnalyticsGlassPanel";
import ReelPreviewCard from "../components/authHero/ReelPreviewCard";
import FloatingEmojis from "../components/authHero/FloatingEmojis";
import SidebarFooter from "../../feed/components/SidebarFooter.jsx";

const Login = () => {
  const { modal } = useUIStore();
  const isModal = modal?.type === "login";

  const cardImages = [
    "https://images.unsplash.com/photo-1532635241-17e820acc59f?w=400&h=600&fit=crop&auto=format",
    "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=400&h=600&fit=crop&auto=format",
    "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=400&h=600&fit=crop&auto=format",
  ];

  if (isModal) {
    return (
      <div className="w-full max-w-md mx-auto">
        <LoginCard />
      </div>
    );
  }

  return (
    <>
      <Seo {...buildStaticPageSeo("login")} />

      {/* 🔥 Main Layout */}
      <div className="min-h-screen bg-login-hero flex flex-col">
        {/* ================= MAIN CONTENT ================= */}
        <div className="flex-1 flex items-center justify-center px-3 sm:px-4 lg:px-6">
          <div className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-3 gap-2 lg:gap-4 items-center relative">
            {/* Left side - Hero Stack */}
            <div className="hidden lg:block relative h-[680px] w-full col-span-2 overflow-visible pt-20">
              <div className="absolute inset-0 blur-3xl opacity-20 bg-viral-purple/60 rounded-full z-0" />
              <SocialHeroStack images={cardImages} />
            </div>

            {/* Floating elements */}
            <AnalyticsGlassPanel />
            <ReelPreviewCard />
            <FloatingEmojis />

            {/* Right side - Login Card */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
              className="w-full max-w-sm mx-auto lg:mx-0 lg:ml-auto col-span-1"
            >
              <LoginCard />
            </motion.div>
          </div>
        </div>

        {/* ================= FOOTER ================= */}
        <div className="w-full px-4 pb-6 pt-12">
          <div className="w-full max-w-6xl mx-auto flex justify-center text-center">
            <SidebarFooter />
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;
