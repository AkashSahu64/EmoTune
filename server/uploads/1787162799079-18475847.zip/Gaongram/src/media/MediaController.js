// media/MediaController.js
const normalizeMediaId = (mediaId) => {
  if (mediaId === null || mediaId === undefined) return "";
  return String(mediaId);
};

class MediaController {
  constructor() {
    this.activeMedia = null;
    this.mediaInstances = new Map();
    this.globalMuted = true;
    this.userInteracted = false;
    this.listeners = new Map();
    this.playRequests = new Map();
    this.lastManualPlayAt = 0;
    this.manualOverrideMs = 12000;
  }

  static getInstance() {
    if (!MediaController.instance) {
      MediaController.instance = new MediaController();
    }
    return MediaController.instance;
  }

  // Register media
  register(mediaId, element, type) {
    const key = normalizeMediaId(mediaId);
    if (!key || !element) return null;

    if (this.mediaInstances.has(key)) {
      const existing = this.mediaInstances.get(key);
      if (existing.element !== element) {
        this.cleanupMediaListeners(existing);
        existing.element = element;
        existing.type = type || existing.type;
        existing.muted = element.muted;
        existing.playing = !element.paused;
        this.restoreElementState(existing);
        this.setupMediaListeners(key);
      }
      return existing.controls;
    }

    const instance = {
      mediaId,
      key,
      element,
      type,
      playing: !element.paused,
      muted: element.muted,
      isLoading: true,
      state: {
        currentTime: element.currentTime || 0,
        duration: element.duration || 0,
        playbackRate: element.playbackRate || 1,
        muted: element.muted,
        volume: element.volume ?? 1,
      },
    };

    this.mediaInstances.set(key, instance);

    // Setup event listeners
    this.setupMediaListeners(key);
    
    const controls = {
      play: (options) => this.play(key, options),
      pause: () => this.pause(key),
      stop: () => this.stop(key),
      togglePlay: (options) => this.togglePlay(key, options),
      seek: (time) => this.seek(key, time),
      toggleMute: () => this.toggleMediaMute(key),
      isPlaying: () => instance.playing,
      isMuted: () => instance.muted
    };

    instance.controls = controls;
    return controls;
  }

  // Unregister media
  unregister(mediaId) {
    const key = normalizeMediaId(mediaId);
    const instance = this.mediaInstances.get(key);
    if (instance) {
      if (this.activeMedia === key) {
        this.snapshotState(instance);
        instance.playing = !instance.element.paused;
      } else {
        this.pause(key);
      }
      this.cleanupMediaListeners(instance);
      this.mediaInstances.delete(key);
    }
  }

  // Safe play method
  async play(mediaId, options = {}) {
    const key = normalizeMediaId(mediaId);
    const instance = this.mediaInstances.get(key);
    if (!instance || !instance.element) return false;

    const { manual = true, autoplay = false, muted } = options;
    if (autoplay && this.hasManualOverride(key)) {
      return false;
    }

    if (manual) {
      this.lastManualPlayAt = Date.now();
      this.notify('manualPlay', { mediaId: key, instance });
    }

    if (muted !== undefined) {
      instance.element.muted = muted;
      instance.muted = muted;
      this.snapshotState(instance);
    }

    if (instance.playing && this.activeMedia === key && !instance.element.paused) {
      return true;
    }

    const requestId = (this.playRequests.get(key) || 0) + 1;
    this.playRequests.set(key, requestId);

    try {
      // Set user interaction flag
      if (manual && !this.userInteracted) {
        this.userInteracted = true;
        this.setGlobalMute(false);
        this.notify('userInteracted', true);
      }

      // Pause any currently playing media without resetting progress.
      if (this.activeMedia && this.activeMedia !== key) {
        this.pause(this.activeMedia);
      }

      instance.playing = true;
      this.activeMedia = key;
      this.restoreElementState(instance);

      const playPromise = instance.element.play();
      
      if (playPromise !== undefined) {
        await playPromise;
        if (this.playRequests.get(key) !== requestId) return false;
        instance.playing = !instance.element.paused;
        this.activeMedia = key;
        this.snapshotState(instance);
        this.notify('play', { mediaId: key, instance });
        return true;
      }
      this.snapshotState(instance);
      this.notify('play', { mediaId: key, instance });
      return true;
    } catch (error) {
      console.warn('Playback failed:', error.name);
      
      // Handle autoplay restrictions gracefully
      if (error.name === 'NotAllowedError') {
        instance.playing = false;
        if (this.activeMedia === key) {
          this.activeMedia = null;
        }
        
        this.notify('autoplayBlocked', { mediaId: key, error });
      }
      
      instance.playing = false;
      if (this.activeMedia === key) {
        this.activeMedia = null;
      }
    }
    
    return false;
  }

  // Safe pause method - does NOT reset currentTime, does NOT clear activeMedia
  pause(mediaId) {
    const key = normalizeMediaId(mediaId);
    const instance = this.mediaInstances.get(key);
    if (instance && instance.element) {
      try {
        if (!instance.element.paused) {
          instance.element.pause();
        }
        this.snapshotState(instance);
        instance.playing = false;
        
        // DO NOT clear activeMedia on pause
        // this.activeMedia = null;
        
        this.notify('pause', { mediaId: key, instance });
        return true;
      } catch (error) {
        console.warn('Pause failed:', error);
      }
    }
    return false;
  }

  // Stop method - pauses AND resets to 0, clears activeMedia
  stop(mediaId) {
    const key = normalizeMediaId(mediaId);
    const instance = this.mediaInstances.get(key);
    if (instance && instance.element) {
      try {
        // Pause if playing
        if (instance.playing) {
          instance.element.pause();
        }
        
        // Reset to beginning
        instance.element.currentTime = 0;
        instance.playing = false;
        this.snapshotState(instance);
        
        // Clear activeMedia if this was the active one
        if (this.activeMedia === key) {
          this.activeMedia = null;
        }
        
        this.notify('stop', { mediaId: key, instance });
        return true;
      } catch (error) {
        console.warn('Stop failed:', error);
      }
    }
    return false;
  }

  // Toggle play/pause
  togglePlay(mediaId, options = {}) {
    const key = normalizeMediaId(mediaId);
    const instance = this.mediaInstances.get(key);
    if (!instance) return;
    
    if (instance.playing) {
      this.pause(key);
    } else {
      this.play(key, options);
    }
  }

  // Seek to time
  seek(mediaId, time) {
    const key = normalizeMediaId(mediaId);
    const instance = this.mediaInstances.get(key);
    if (instance && instance.element) {
      try {
        instance.element.currentTime = Math.max(0, time);
        this.snapshotState(instance);
        this.notify('seek', { mediaId: key, time });
      } catch (error) {
        console.warn('Seek failed:', error);
      }
    }
  }

  // Toggle mute for specific media
  toggleMediaMute(mediaId) {
    const key = normalizeMediaId(mediaId);
    const instance = this.mediaInstances.get(key);
    if (instance && instance.element) {
      try {
        instance.element.muted = !instance.element.muted;
        instance.muted = instance.element.muted;
        this.snapshotState(instance);
        this.notify('mute', { mediaId: key, muted: instance.muted });
      } catch (error) {
        console.warn('Toggle mute failed:', error);
      }
    }
  }

  // Toggle global mute
  toggleGlobalMute() {
    this.globalMuted = !this.globalMuted;
    
    this.mediaInstances.forEach((instance) => {
      if (instance && instance.element) {
        try {
          instance.element.muted = this.globalMuted;
          instance.muted = this.globalMuted;
        } catch (error) {
          console.warn('Set global mute failed:', error);
        }
      }
    });
    
    this.notify('globalMute', this.globalMuted);
  }

  // Set global mute
  setGlobalMute(muted) {
    this.globalMuted = muted;
    
    this.mediaInstances.forEach((instance) => {
      if (instance && instance.element) {
        try {
          instance.element.muted = muted;
          instance.muted = muted;
        } catch (error) {
          console.warn('Set global mute failed:', error);
        }
      }
    });
    
    this.notify('globalMute', muted);
  }

  // Set user interaction
  setUserInteracted() {
    if (!this.userInteracted) {
      this.userInteracted = true;
      this.setGlobalMute(false);
      this.notify('userInteracted', true);
    }
  }

  // Skip forward
  skipForward(mediaId, seconds = 5) {
    const key = normalizeMediaId(mediaId);
    const instance = this.mediaInstances.get(key);
    if (instance && instance.element) {
      try {
        const newTime = Math.min(
          instance.element.duration || 0,
          instance.element.currentTime + seconds
        );
        this.seek(key, newTime);
      } catch (error) {
        console.warn('Skip forward failed:', error);
      }
    }
  }

  // Skip backward
  skipBackward(mediaId, seconds = 5) {
    const key = normalizeMediaId(mediaId);
    const instance = this.mediaInstances.get(key);
    if (instance && instance.element) {
      try {
        const newTime = Math.max(0, instance.element.currentTime - seconds);
        this.seek(key, newTime);
      } catch (error) {
        console.warn('Skip backward failed:', error);
      }
    }
  }

  // Setup event listeners
  setupMediaListeners(mediaId) {
    const key = normalizeMediaId(mediaId);
    const instance = this.mediaInstances.get(key);
    if (!instance || !instance.element) return;

    const element = instance.element;
    
    const onPlay = () => {
      instance.playing = true;
      this.activeMedia = key;
      this.snapshotState(instance);
      this.notify('mediaPlay', { mediaId: key, instance });
    };

    const onPause = () => {
      instance.playing = false;
      this.snapshotState(instance);
      // DO NOT clear activeMedia on element pause
      this.notify('mediaPause', { mediaId: key, instance });
    };

    const onEnded = () => {
      instance.playing = false;
      this.snapshotState(instance);
      if (this.activeMedia === key) {
        this.activeMedia = null;
      }
      this.notify('mediaEnded', { mediaId: key, instance });
    };

    const onError = (error) => {
      console.warn('Media error:', error);
      instance.isLoading = false;
      this.notify('mediaError', { mediaId: key, error });
    };

    const onLoadStart = () => {
      instance.isLoading = true;
    };

    const onCanPlay = () => {
      instance.isLoading = false;
    };

    const onStateChange = () => {
      this.snapshotState(instance);
      this.notify('stateChange', { mediaId: key, instance });
    };

    element.addEventListener('play', onPlay);
    element.addEventListener('pause', onPause);
    element.addEventListener('ended', onEnded);
    element.addEventListener('error', onError);
    element.addEventListener('loadstart', onLoadStart);
    element.addEventListener('canplay', onCanPlay);
    element.addEventListener('timeupdate', onStateChange);
    element.addEventListener('loadedmetadata', onStateChange);
    element.addEventListener('ratechange', onStateChange);
    element.addEventListener('volumechange', onStateChange);

    // Store listeners for cleanup
    instance._listeners = { onPlay, onPause, onEnded, onError, onLoadStart, onCanPlay, onStateChange };
  }

  // Cleanup listeners
  cleanupMediaListeners(instance) {
    if (!instance || !instance.element || !instance._listeners) return;

    const { element, _listeners } = instance;
    element.removeEventListener('play', _listeners.onPlay);
    element.removeEventListener('pause', _listeners.onPause);
    element.removeEventListener('ended', _listeners.onEnded);
    element.removeEventListener('error', _listeners.onError);
    element.removeEventListener('loadstart', _listeners.onLoadStart);
    element.removeEventListener('canplay', _listeners.onCanPlay);
    element.removeEventListener('timeupdate', _listeners.onStateChange);
    element.removeEventListener('loadedmetadata', _listeners.onStateChange);
    element.removeEventListener('ratechange', _listeners.onStateChange);
    element.removeEventListener('volumechange', _listeners.onStateChange);
  }

  hasManualOverride(nextMediaId) {
    if (!this.activeMedia) return false;
    if (this.activeMedia === nextMediaId) return false;
    return Date.now() - this.lastManualPlayAt < this.manualOverrideMs;
  }

  snapshotState(instance) {
    if (!instance?.element) return;
    const { element } = instance;
    instance.state = {
      currentTime: Number.isFinite(element.currentTime) ? element.currentTime : instance.state?.currentTime || 0,
      duration: Number.isFinite(element.duration) ? element.duration : instance.state?.duration || 0,
      playbackRate: element.playbackRate || 1,
      muted: element.muted,
      volume: element.volume ?? 1,
    };
    instance.muted = element.muted;
    instance.playing = !element.paused;
  }

  restoreElementState(instance) {
    if (!instance?.element || !instance.state) return;
    const { element, state } = instance;
    if (state.playbackRate && element.playbackRate !== state.playbackRate) {
      element.playbackRate = state.playbackRate;
    }
    element.muted = state.muted ?? this.globalMuted;
    if (state.volume !== undefined) {
      element.volume = state.volume;
    }
    if (
      state.currentTime > 0 &&
      Number.isFinite(element.duration) &&
      Math.abs(element.currentTime - state.currentTime) > 0.5
    ) {
      element.currentTime = Math.min(state.currentTime, element.duration || state.currentTime);
    }
  }

  // Event system
  on(event, callback) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event).add(callback);
  }

  off(event, callback) {
    if (this.listeners.has(event)) {
      this.listeners.get(event).delete(callback);
    }
  }

  // Backward compatibility
  addListener(event, callback) {
    return this.on(event, callback);
  }

  removeListener(event, callback) {
    return this.off(event, callback);
  }

  notify(event, data) {
    if (this.listeners.has(event)) {
      this.listeners.get(event).forEach(callback => {
        try {
          callback(data);
        } catch (error) {
          console.error('Listener error:', error);
        }
      });
    }
  }

  // Cleanup
  cleanup() {
    this.mediaInstances.forEach((instance) => {
      this.cleanupMediaListeners(instance);
      if (instance.element && typeof instance.element.pause === 'function') {
        instance.element.pause();
        instance.element.currentTime = 0;
      }
    });
    this.mediaInstances.clear();
    this.activeMedia = null;
    this.listeners.clear();
  }

  // Get media instance
  getMediaInstance(mediaId) {
    return this.mediaInstances.get(normalizeMediaId(mediaId));
  }
}

export const mediaController = MediaController.getInstance();
export { normalizeMediaId };
