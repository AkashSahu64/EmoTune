import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Heart,
  MessageCircle,
  Send,
  Bookmark,
  Flag,
  Trash2,
  Edit,
  Copy,
} from 'lucide-react';
import { useAuthStore } from '../../../store/authStore.js';
import { useUIStore } from '../../../store/uiStore.js';
import { showSuccess, showError } from '../../../utils/toast.js';

const FeedActions = ({
  postId,
  isLiked: initialIsLiked,
  likeCount: initialLikeCount,
  commentCount: initialCommentCount,
  isSaved: initialIsSaved,
  isOwner = false,
  onLike,
  onComment,
  onShare,
  onSave,
  onDelete,
  onEdit,
}) => {
  const { isAuthenticated } = useAuthStore();
  const { openModal } = useUIStore();

  const [isLiked, setIsLiked] = useState(initialIsLiked);
  const [likeCount, setLikeCount] = useState(initialLikeCount || 0);
  const [isSaved, setIsSaved] = useState(initialIsSaved);
  const [isCopied, setIsCopied] = useState(false);

  const handleLike = async () => {
    if (!isAuthenticated) {
      openModal('login');
      return;
    }

    const previousIsLiked = isLiked;
    const previousLikeCount = likeCount;

    setIsLiked(!isLiked);
    setLikeCount(prev => (isLiked ? prev - 1 : prev + 1));

    try {
      if (onLike) await onLike();
    } catch (error) {
      setIsLiked(previousIsLiked);
      setLikeCount(previousLikeCount);
      showError('Failed to like post');
    }
  };

  const handleSave = async () => {
    if (!isAuthenticated) {
      openModal('login');
      return;
    }

    const previousIsSaved = isSaved;
    setIsSaved(!isSaved);

    try {
      if (onSave) await onSave();
      showSuccess(isSaved ? 'Post removed from saved' : 'Post saved');
    } catch (error) {
      setIsSaved(previousIsSaved);
      showError('Failed to save post');
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Check out this post on GaonGram',
          url: `${window.location.origin}/post/${postId}`,
        });
      } catch (error) {
        if (error.name !== 'AbortError') {
          await handleCopyLink();
        }
      }
    } else {
      await handleCopyLink();
    }
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(
        `${window.location.origin}/post/${postId}`
      );
      setIsCopied(true);
      showSuccess('Link copied to clipboard!');
      setTimeout(() => setIsCopied(false), 2000);
    } catch (error) {
      showError('Failed to copy link');
    }
  };

  const handleComment = () => {
    if (!isAuthenticated) {
      openModal('login');
      return;
    }
    if (onComment) {
      onComment();
    } else {
      openModal('comments', { postId });
    }
  };

  const handleDelete = () => {
    openModal('confirm-delete', { postId, onConfirm: onDelete });
  };

  const handleReport = () => {
    openModal('report-post', { postId, type: 'post' });
  };

  return (
    <div className="space-y-3">
      {/* Like, Comment, Share Row */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={handleLike}
            className={`p-1 ${
              isLiked ? 'text-viral-pink' : 'text-mutedForeground dark:text-mutedForeground-dark hover:text-viral-pink'
            }`}
            aria-label={isLiked ? 'Unlike' : 'Like'}
          >
            <Heart className={`w-7 h-7 ${isLiked ? 'fill-current' : ''}`} />
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={handleComment}
            className="p-1 text-mutedForeground dark:text-mutedForeground-dark hover:text-foreground dark:hover:text-foreground-dark"
            aria-label="Comment"
          >
            <MessageCircle className="w-7 h-7" />
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={handleShare}
            className="p-1 text-mutedForeground dark:text-mutedForeground-dark hover:text-foreground dark:hover:text-foreground-dark"
            aria-label="Share"
          >
            <Send className="w-7 h-7" />
          </motion.button>
        </div>

        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={handleSave}
          className={`p-1 ${
            isSaved ? 'text-accent' : 'text-mutedForeground dark:text-mutedForeground-dark hover:text-accent'
          }`}
          aria-label={isSaved ? 'Unsave' : 'Save'}
        >
          <Bookmark className={`w-7 h-7 ${isSaved ? 'fill-current' : ''}`} />
        </motion.button>
      </div>

      {/* Like Count */}
      {likeCount > 0 && (
        <div className="text-sm font-semibold text-foreground dark:text-foreground-dark">
          {likeCount.toLocaleString()} like{likeCount !== 1 ? 's' : ''}
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex items-center space-x-4">
        {isOwner ? (
          <>
            <button
              onClick={() => onEdit && onEdit()}
              className="flex items-center space-x-2 text-sm text-mutedForeground dark:text-mutedForeground-dark hover:text-foreground dark:hover:text-foreground-dark"
            >
              <Edit className="w-4 h-4" />
              <span>Edit</span>
            </button>
            <button
              onClick={handleDelete}
              className="flex items-center space-x-2 text-sm text-danger hover:text-danger/80"
            >
              <Trash2 className="w-4 h-4" />
              <span>Delete</span>
            </button>
          </>
        ) : (
          <>
            <button
              onClick={handleCopyLink}
              className="flex items-center space-x-2 text-sm text-mutedForeground dark:text-mutedForeground-dark hover:text-foreground dark:hover:text-foreground-dark"
            >
              <Copy className="w-4 h-4" />
              <span>{isCopied ? 'Copied!' : 'Copy Link'}</span>
            </button>
            <button
              onClick={handleReport}
              className="flex items-center space-x-2 text-sm text-mutedForeground dark:text-mutedForeground-dark hover:text-foreground dark:hover:text-foreground-dark"
            >
              <Flag className="w-4 h-4" />
              <span>Report</span>
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default FeedActions;
