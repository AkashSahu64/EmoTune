// MiniPlayerWrapper.jsx
import { useLocation } from "react-router-dom";
import MiniPlayer from "./MiniPlayer.jsx";
const MiniPlayerWrapper = () => {
  const location = useLocation();

  if (location.pathname.startsWith("/audio")) return null;

  return <MiniPlayer />;
};

export default MiniPlayerWrapper;