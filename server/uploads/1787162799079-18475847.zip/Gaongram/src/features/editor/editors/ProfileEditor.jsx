import React from "react";
import BaseImageEditor from "../../profile/components/image-editor/BaseImageEditor.jsx";

const ProfileEditor = (props) => <BaseImageEditor {...props} />;

export default ProfileEditor;
