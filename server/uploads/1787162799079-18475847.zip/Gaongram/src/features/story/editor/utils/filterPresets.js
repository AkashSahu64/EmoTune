export const DEFAULT_FILTERS = {
  brightness: 0,
  contrast: 0,
  saturation: 0,
  blur: 0,
  sepia: 0,
  grayscale: 0,
  vintage: 0,
  warm: 0,
  cool: 0,
  cinematic: 0,
  vignette: 0,
};

export const FILTER_PRESETS = [
  {
    id: "original",
    label: "Original",
    values: { ...DEFAULT_FILTERS },
  },
  {
    id: "bright",
    label: "Bright",
    values: {
      ...DEFAULT_FILTERS,
      brightness: 0.12,
      contrast: 0.08,
      saturation: 0.12,
    },
  },
  {
    id: "sepia",
    label: "Sepia",
    values: {
      ...DEFAULT_FILTERS,
      sepia: 0.85,
      brightness: 0.04,
      contrast: 0.08,
    },
  },
  {
    id: "mono",
    label: "Mono",
    values: {
      ...DEFAULT_FILTERS,
      grayscale: 1,
      contrast: 0.12,
    },
  },
  {
    id: "vintage",
    label: "Vintage",
    values: {
      ...DEFAULT_FILTERS,
      vintage: 0.6,
      sepia: 0.28,
      contrast: 0.08,
      saturation: -0.05,
      vignette: 0.18,
    },
  },
  {
    id: "warm",
    label: "Warm",
    values: {
      ...DEFAULT_FILTERS,
      warm: 0.5,
      brightness: 0.05,
      saturation: 0.1,
    },
  },
  {
    id: "cool",
    label: "Cool",
    values: {
      ...DEFAULT_FILTERS,
      cool: 0.45,
      contrast: 0.05,
      saturation: 0.04,
    },
  },
  {
    id: "cinematic",
    label: "Cinema",
    values: {
      ...DEFAULT_FILTERS,
      cinematic: 0.55,
      contrast: 0.2,
      saturation: -0.08,
      vignette: 0.24,
    },
  },
  {
    id: "soft",
    label: "Soft",
    values: {
      ...DEFAULT_FILTERS,
      brightness: 0.08,
      contrast: -0.08,
      blur: 0.12,
      saturation: 0.06,
    },
  },
];

export const FRAME_OPTIONS = [
  {
    id: "none",
    label: "None",
    className: "",
  },
  {
    id: "soft-white",
    label: "Soft",
    stroke: "rgba(255,255,255,0.82)",
    strokeWidthRatio: 0.01,
    insetRatio: 0.015,
    radiusRatio: 0.045,
  },
  {
    id: "film",
    label: "Film",
    stroke: "rgba(12,12,16,0.92)",
    strokeWidthRatio: 0.02,
    insetRatio: 0.026,
    radiusRatio: 0.025,
  },
  {
    id: "gold",
    label: "Gold",
    stroke: "#E6C77A",
    strokeWidthRatio: 0.022,
    insetRatio: 0.035,
    radiusRatio: 0.04,
  },
  {
    id: "neon",
    label: "Neon",
    stroke: "#E1306C",
    strokeWidthRatio: 0.018,
    insetRatio: 0.03,
    radiusRatio: 0.05,
    shadow: "rgba(225,48,108,0.75) 0 0 22px",
  },

  // 🔥 NEW FRAMES (13)

  {
    id: "shadow-dark",
    label: "Shadow",
    stroke: "#000000",
    strokeWidthRatio: 0.015,
    insetRatio: 0.03,
    radiusRatio: 0.04,
    shadow: "rgba(0,0,0,0.6) 0 8px 25px",
  },
  {
    id: "glass",
    label: "Glass",
    stroke: "rgba(255,255,255,0.25)",
    strokeWidthRatio: 0.02,
    insetRatio: 0.035,
    radiusRatio: 0.05,
    shadow: "rgba(255,255,255,0.25) 0 0 10px",
  },
  {
    id: "soft-black",
    label: "Soft Black",
    stroke: "rgba(0,0,0,0.7)",
    strokeWidthRatio: 0.02,
    insetRatio: 0.03,
    radiusRatio: 0.045,
  },
  {
    id: "double-border",
    label: "Double",
    stroke: "#ffffff",
    strokeWidthRatio: 0.01,
    insetRatio: 0.025,
    radiusRatio: 0.04,
    shadow: "rgba(0,0,0,0.4) 0 0 0 4px",
  },
  {
    id: "minimal-gray",
    label: "Minimal",
    stroke: "#9ca3af",
    strokeWidthRatio: 0.012,
    insetRatio: 0.03,
    radiusRatio: 0.03,
  },
  {
    id: "aqua",
    label: "Aqua",
    stroke: "#22d3ee",
    strokeWidthRatio: 0.018,
    insetRatio: 0.03,
    radiusRatio: 0.04,
  },
  {
    id: "sunset",
    label: "Sunset",
    stroke: "#fb7185",
    strokeWidthRatio: 0.02,
    insetRatio: 0.035,
    radiusRatio: 0.05,
  },
  {
    id: "purple",
    label: "Purple",
    stroke: "#a855f7",
    strokeWidthRatio: 0.02,
    insetRatio: 0.035,
    radiusRatio: 0.05,
  },
  {
    id: "rgb-1",
    label: "RGB Glow",
    stroke: "#ff0000",
    strokeWidthRatio: 0.02,
    insetRatio: 0.03,
    radiusRatio: 0.05,
    shadow: "0 0 10px red, 0 0 20px lime, 0 0 30px blue",
  },
  {
    id: "rgb-2",
    label: "RGB Soft",
    stroke: "#00ffcc",
    strokeWidthRatio: 0.018,
    insetRatio: 0.03,
    radiusRatio: 0.05,
    shadow: "0 0 12px #ff00ff, 0 0 18px #00ffff",
  },
  {
    id: "rgb-3",
    label: "RGB Neon",
    stroke: "#ff00ff",
    strokeWidthRatio: 0.02,
    insetRatio: 0.035,
    radiusRatio: 0.05,
    shadow: "0 0 10px red, 0 0 20px green, 0 0 30px blue",
  },
  {
    id: "rgb-4",
    label: "RGB Pulse",
    stroke: "#ffffff",
    strokeWidthRatio: 0.02,
    insetRatio: 0.03,
    radiusRatio: 0.05,
    shadow: "0 0 8px red, 0 0 16px blue, 0 0 24px green",
  },
  {
    id: "gradient-sunset",
    label: "Sunset Grad",
    stroke: "#fb7185",
    strokeWidthRatio: 0.02,
    insetRatio: 0.03,
    radiusRatio: 0.05,
    shadow: "0 0 12px rgba(251,113,133,0.6), 0 0 20px rgba(251,191,36,0.4)",
  },
  {
    id: "gradient-ocean",
    label: "Ocean Grad",
    stroke: "#38bdf8",
    strokeWidthRatio: 0.02,
    insetRatio: 0.03,
    radiusRatio: 0.05,
    shadow: "0 0 12px rgba(56,189,248,0.6), 0 0 20px rgba(34,211,238,0.4)",
  },
  {
    id: "gradient-purple",
    label: "Purple Grad",
    stroke: "#a855f7",
    strokeWidthRatio: 0.02,
    insetRatio: 0.03,
    radiusRatio: 0.05,
    shadow: "0 0 12px rgba(168,85,247,0.6), 0 0 20px rgba(236,72,153,0.4)",
  },
  {
    id: "gradient-lime",
    label: "Lime Grad",
    stroke: "#84cc16",
    strokeWidthRatio: 0.02,
    insetRatio: 0.03,
    radiusRatio: 0.05,
    shadow: "0 0 12px rgba(132,204,22,0.6), 0 0 20px rgba(34,197,94,0.4)",
  },
];

export const ASPECT_RATIOS = {
  "9:16": {
    label: "9:16",
    width: 1080,
    height: 1920,
    ratio: 9 / 16,
  },
  "1:1": {
    label: "1:1",
    width: 1440,
    height: 1440,
    ratio: 1,
  },
  "4:5": {
    label: "4:5",
    width: 1080,
    height: 1350,
    ratio: 4 / 5,
  },
  "16:9": {
    label: "16:9",
    width: 1920,
    height: 1080,
    ratio: 16 / 9,
  },
  "2:3": {
    label: "2:3",
    width: 1000,
    height: 1500,
    ratio: 2 / 3,
  },
  "3:4": {
    label: "3:4",
    width: 1080,
    height: 1440,
    ratio: 3 / 4,
  }
};

export const clampFilterValue = (key, value) => {
  const numeric = Number(value);
  if (Number.isNaN(numeric)) return DEFAULT_FILTERS[key] ?? 0;
  if (key === "blur") return Math.min(Math.max(numeric, 0), 1);
  if (key === "grayscale" || key === "sepia") {
    return Math.min(Math.max(numeric, 0), 1);
  }
  if (key === "vignette") return Math.min(Math.max(numeric, 0), 0.8);
  return Math.min(Math.max(numeric, -1), 1);
};

export const mergeFilters = (...filters) =>
  Object.keys(DEFAULT_FILTERS).reduce((acc, key) => {
    const mergedValue = filters.reduce(
      (total, filterSet) => total + Number(filterSet?.[key] || 0),
      0,
    );

    acc[key] = clampFilterValue(key, mergedValue);
    return acc;
  }, { ...DEFAULT_FILTERS });
