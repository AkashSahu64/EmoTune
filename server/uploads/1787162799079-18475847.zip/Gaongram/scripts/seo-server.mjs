/* eslint-env node */
/* global process, console, URL */
import { createServer } from "node:http";
import { existsSync, readFileSync, statSync } from "node:fs";
import { extname, join, normalize, resolve } from "node:path";
import {
  buildEntitySeo,
  buildPlaceholderProfile,
  buildSeoHtml,
  fetchEntityById,
  buildProfileHtml,
  fetchProfileByIdentifier,
  fetchJson,
  apiUrl,
  getApiBaseUrl,
  getSiteUrl,
  inlineImageDataUri,
  normalizeProfile,
  readProfileSnapshot,
} from "./profile-seo.mjs";
import { buildProfileOgImagePayload } from "../seo/og/images.mjs";
import { renderOgPng } from "../seo/og/png.mjs";
import { renderRobotsTxt } from "../seo/robots/index.mjs";
import {
  endpointForSitemapSection,
  normalizeSitemapItems,
  renderSitemapIndex,
  renderStaticSitemap,
  renderUrlSet,
  SITEMAP_SECTIONS,
} from "../seo/sitemap/index.mjs";

const DIST_DIR = resolve("dist");
const PORT = Number(process.env.PORT || 4173);
const PROFILE_ROUTE_RE = /^\/profile\/([^/?#]+)\/?$/i;
const PROFILE_POST_ROUTE_RE = /^\/profile\/([^/?#]+)\/post\/([^/?#]+)\/?$/i;
const ENTITY_ROUTE_PATTERNS = [
  { entity: "post", re: /^\/posts\/([^/?#]+)\/?$/i },
  { entity: "reel", re: /^\/reels\/([^/?#]+)\/?$/i },
  { entity: "audio", re: /^\/audio\/([^/?#]+)\/?$/i },
  { entity: "blog", re: /^\/blogs\/([^/?#]+)\/?$/i },
  { entity: "playlist", re: /^\/playlists\/([^/?#]+)\/?$/i },
  { entity: "hashtag", re: /^\/hashtags\/([^/?#]+)\/?$/i },
  { entity: "story", re: /^\/story\/([^/?#]+)\/?$/i },
];
const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".xml": "application/xml; charset=utf-8",
  ".txt": "text/plain; charset=utf-8",
  ".webmanifest": "application/manifest+json; charset=utf-8",
};

const send = (res, status, body, headers = {}) => {
  res.writeHead(status, headers);
  res.end(body);
};

const isInsideDist = (filePath) => filePath.startsWith(`${DIST_DIR}`) || filePath === DIST_DIR;

const resolveStaticFile = (pathname) => {
  const decoded = decodeURIComponent(pathname);
  const safePath = normalize(decoded).replace(/^(\.\.[/\\])+/, "");
  let filePath = resolve(join(DIST_DIR, safePath));

  if (!isInsideDist(filePath) || !existsSync(filePath)) return "";
  if (statSync(filePath).isDirectory()) {
    filePath = join(filePath, "index.html");
  }

  return existsSync(filePath) && statSync(filePath).isFile() ? filePath : "";
};

const getProfileIdentifier = (pathname) => {
  const match = pathname.match(PROFILE_ROUTE_RE);
  if (!match) return "";

  try {
    return decodeURIComponent(match[1]);
  } catch {
    return match[1];
  }
};

const getEntityRoute = (requestUrl) => {
  const profilePostMatch = requestUrl.pathname.match(PROFILE_POST_ROUTE_RE);
  if (profilePostMatch) {
    return {
      entity: "post",
      identifier: decodeURIComponent(profilePostMatch[2]),
      path: requestUrl.pathname,
    };
  }

  for (const pattern of ENTITY_ROUTE_PATTERNS) {
    const match = requestUrl.pathname.match(pattern.re);
    if (match) {
      return {
        entity: pattern.entity,
        identifier: decodeURIComponent(match[1]),
        path: requestUrl.pathname,
      };
    }
  }

  const startId = requestUrl.searchParams.get("start") || requestUrl.searchParams.get("single");
  if (requestUrl.pathname === "/audio" && startId) {
    return {
      entity: "audio",
      identifier: startId,
      path: `${requestUrl.pathname}${requestUrl.search}`,
    };
  }
  if (requestUrl.pathname === "/reels" && startId) {
    return {
      entity: "reel",
      identifier: startId,
      path: `${requestUrl.pathname}${requestUrl.search}`,
    };
  }

  return null;
};

const sendProfileHtml = async (identifier, res) => {
  const templatePath = resolve(DIST_DIR, "index.html");
  const templateHtml = readFileSync(templatePath, "utf8");
  let profile;
  let html = "";

  try {
    profile = await fetchProfileByIdentifier(identifier);
    html = buildProfileHtml(templateHtml, profile, identifier);
  } catch (error) {
    const snapshot = readProfileSnapshot(identifier, DIST_DIR);
    if (snapshot) {
      html = snapshot;
      console.warn(
        `[seo-server] Used cached snapshot for /profile/${identifier}: ${error.message}`,
      );
    } else {
      profile = buildPlaceholderProfile(identifier);
      html = buildProfileHtml(templateHtml, profile, identifier);
      console.warn(
        `[seo-server] Using fallback metadata for /profile/${identifier}: ${error.message}`,
      );
    }
  }

  send(res, 200, html, {
    "Content-Type": "text/html; charset=utf-8",
    "Cache-Control": "public, max-age=300, stale-while-revalidate=86400",
  });
};

const sendEntityHtml = async ({ entity, identifier, path }, res) => {
  const templateHtml = readFileSync(resolve(DIST_DIR, "index.html"), "utf8");
  let seo;

  try {
    const payload = await fetchEntityById(entity, identifier);
    seo = buildEntitySeo(entity, payload, identifier, path);
  } catch (error) {
    seo = buildEntitySeo(entity, {}, identifier, path);
    console.warn(
      `[seo-server] Using fallback metadata for ${path}: ${error.message}`,
    );
  }

  send(res, 200, buildSeoHtml(templateHtml, seo, path), {
    "Content-Type": "text/html; charset=utf-8",
    "Cache-Control": "public, max-age=300, stale-while-revalidate=86400",
  });
};

const sendOgImage = async (entity, identifier, res) => {
  let payload = {};

  try {
    payload =
      entity === "profile"
        ? normalizeProfile(await fetchProfileByIdentifier(identifier), identifier)
        : await fetchEntityById(entity, identifier);
  } catch (error) {
    if (entity === "profile") {
      payload = normalizeProfile(buildPlaceholderProfile(identifier), identifier);
    }
    console.warn(
      `[seo-server] Using fallback OG image for ${entity}/${identifier}: ${error.message}`,
    );
  }

  const png =
    entity === "profile"
      ? renderOgPng(
          buildProfileOgImagePayload({
            ...payload,
            profileImage: payload.profileImage,
          }),
        )
      : renderOgPng({
          entity,
          title:
            payload.title ||
            payload.caption ||
            payload.name ||
            `${entity} on GaonGram`,
          description:
            payload.description ||
            payload.excerpt ||
            payload.content ||
            "Shared from GaonGram",
          image: await inlineImageDataUri(
            payload.image ||
              payload.cover_image ||
              payload.thumbnail ||
              payload.profile_image,
          ),
        });

  send(res, 200, png, {
    "Content-Type": "image/png",
    "Cache-Control": "public, max-age=300, stale-while-revalidate=86400",
  });
};

const sendSitemap = async (pathname, res) => {
  if (pathname === "/sitemap.xml") {
    send(res, 200, renderSitemapIndex(), {
      "Content-Type": "application/xml; charset=utf-8",
      "Cache-Control": "public, max-age=300, stale-while-revalidate=86400",
    });
    return true;
  }

  const match = pathname.match(/^\/sitemap-([a-z]+)\.xml$/i);
  if (!match) return false;

  const section = match[1].toLowerCase();
  if (!SITEMAP_SECTIONS.includes(section)) return false;

  try {
    const endpoint = endpointForSitemapSection(section);
    const entries = normalizeSitemapItems(
      section,
      endpoint ? await fetchJson(apiUrl(endpoint)) : null,
    );
    send(res, 200, renderUrlSet(entries), {
      "Content-Type": "application/xml; charset=utf-8",
      "Cache-Control": "public, max-age=300, stale-while-revalidate=86400",
    });
  } catch (error) {
    console.warn(`[seo-server] Sitemap fallback for ${section}: ${error.message}`);
    send(res, 200, renderStaticSitemap(), {
      "Content-Type": "application/xml; charset=utf-8",
      "Cache-Control": "public, max-age=300, stale-while-revalidate=86400",
    });
  }

  return true;
};

const server = createServer(async (req, res) => {
  try {
    const requestUrl = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);
    const profileIdentifier = getProfileIdentifier(requestUrl.pathname);

    const ogMatch = requestUrl.pathname.match(/^\/api\/og\/([^/]+)\/([^/]+)\/?$/i);
    if ((req.method === "GET" || req.method === "HEAD") && ogMatch) {
      await sendOgImage(decodeURIComponent(ogMatch[1]), decodeURIComponent(ogMatch[2]), res);
      return;
    }

    if (requestUrl.pathname === "/robots.txt") {
      send(res, 200, renderRobotsTxt(), {
        "Content-Type": "text/plain; charset=utf-8",
        "Cache-Control": "public, max-age=300, stale-while-revalidate=86400",
      });
      return;
    }

    if (await sendSitemap(requestUrl.pathname, res)) return;

    if ((req.method === "GET" || req.method === "HEAD") && profileIdentifier) {
      await sendProfileHtml(profileIdentifier, res);
      return;
    }

    const entityRoute = getEntityRoute(requestUrl);
    if ((req.method === "GET" || req.method === "HEAD") && entityRoute) {
      await sendEntityHtml(entityRoute, res);
      return;
    }

    if (req.method !== "GET" && req.method !== "HEAD") {
      send(res, 405, "Method Not Allowed", {
        Allow: "GET, HEAD",
        "Content-Type": "text/plain; charset=utf-8",
      });
      return;
    }

    const staticFile = resolveStaticFile(requestUrl.pathname);
    if (staticFile) {
      send(res, 200, readFileSync(staticFile), {
        "Content-Type": MIME_TYPES[extname(staticFile).toLowerCase()] || "application/octet-stream",
        "Cache-Control": staticFile.endsWith(".html")
          ? "public, max-age=300"
          : "public, max-age=31536000, immutable",
      });
      return;
    }

    send(res, 200, readFileSync(resolve(DIST_DIR, "index.html")), {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "public, max-age=300",
    });
  } catch (error) {
    console.error("[seo-server] Request failed:", error);
    send(res, 500, "Internal Server Error", {
      "Content-Type": "text/plain; charset=utf-8",
    });
  }
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`GaonGram SEO server running at http://localhost:${PORT}`);
  console.log(`Site URL: ${getSiteUrl()}`);
  console.log(`API URL: ${getApiBaseUrl()}`);
});
