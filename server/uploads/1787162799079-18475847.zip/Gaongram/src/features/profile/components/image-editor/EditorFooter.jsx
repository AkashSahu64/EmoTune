import React from 'react';
import Button from '../../../../components/common/Button';
import { Check, Loader2 } from 'lucide-react';

const EditorFooter = ({ onCancel, onSubmit, isUpdating, isDisabled, config }) => (
  <div className="mt-2 pt-2 border-t -mb-4">
    <div className="flex justify-end gap-3">
      <Button
        type="button"
        variant="outline"
        onClick={onCancel}
        disabled={isUpdating}
        className="border-gray-300 hover:bg-gray-50 rounded-lg px-4"
      >
        Cancel
      </Button>
      <Button
        onClick={onSubmit}
        loading={isUpdating}
        disabled={isDisabled}
        className="bg-gaon-green-gradient hover:opacity-90 rounded-lg px-4 shadow-md min-w-[140px]"
      >
        {isUpdating ? (
          <span className="flex items-center justify-center gap-2">
            <Loader2 size={18} className="animate-spin" />
            Uploading...
          </span>
        ) : (
          <span className="flex items-center justify-center gap-2">
            <Check size={18} />
            Update {config.type === 'profile' ? 'Profile' : 'Cover'}
          </span>
        )}
      </Button>
    </div>
  </div>
);

export default EditorFooter;