// src/features/blogs/components/BlogMetaInfo.jsx
import React from "react";
import { format } from "date-fns";

const BlogMetaInfo = ({ blog }) => {
  const {
    views,
    created_at,
    updated_at,
    is_published,
    admin_approved,
    rejected,
    allow_comments,
    is_featured,
    is_staff_post,
    category,
    author,
    approved_by,
  } = blog;

  return (
    <div className="space-y-4">
      <div className="bg-card dark:bg-card-dark rounded-xl p-5 shadow-soft border border-border dark:border-border-dark">
        <h4 className="text-sm font-semibold uppercase tracking-wider text-mutedForeground dark:text-mutedForeground-dark mb-3">
          Blog Info
        </h4>
        <dl className="space-y-2 text-sm">
          <div className="flex justify-between">
            <dt className="text-mutedForeground dark:text-mutedForeground-dark">Views</dt>
            <dd className="font-medium text-foreground dark:text-foreground-dark">{views}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-mutedForeground dark:text-mutedForeground-dark">Created</dt>
            <dd className="font-medium text-foreground dark:text-foreground-dark">
              {format(new Date(created_at), "MMM d, yyyy")}
            </dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-mutedForeground dark:text-mutedForeground-dark">Last Updated</dt>
            <dd className="font-medium text-foreground dark:text-foreground-dark">
              {format(new Date(updated_at), "MMM d, yyyy")}
            </dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-mutedForeground dark:text-mutedForeground-dark">Category</dt>
            <dd className="font-medium text-foreground dark:text-foreground-dark">
              {category?.name || "—"}
            </dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-mutedForeground dark:text-mutedForeground-dark">Author</dt>
            <dd className="font-medium text-foreground dark:text-foreground-dark">
              {author?.username || `User ${author}`}
            </dd>
          </div>
        </dl>
      </div>

      <div className="bg-card dark:bg-card-dark rounded-xl p-5 shadow-soft border border-border dark:border-border-dark">
        <h4 className="text-sm font-semibold uppercase tracking-wider text-mutedForeground dark:text-mutedForeground-dark mb-3">
          Status
        </h4>
        <div className="space-y-2">
          <StatusBadge label="Published" value={is_published} />
          <StatusBadge label="Admin Approved" value={admin_approved} />
          <StatusBadge label="Rejected" value={rejected} negative />
          <StatusBadge label="Comments Allowed" value={allow_comments} />
          <StatusBadge label="Featured" value={is_featured} highlight />
          <StatusBadge label="Staff Post" value={is_staff_post} />
        </div>
      </div>
    </div>
  );
};

const StatusBadge = ({ label, value, negative = false, highlight = false }) => {
  const isTrue = value;
  return (
    <div className="flex items-center justify-between">
      <span className="text-sm text-mutedForeground dark:text-mutedForeground-dark">{label}</span>
      <span
        className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
          isTrue
            ? negative
              ? "bg-danger/10 text-danger"
              : highlight
              ? "bg-accent/10 text-accent"
              : "bg-success/10 text-success"
            : "bg-muted dark:bg-muted-dark text-mutedForeground dark:text-mutedForeground-dark"
        }`}
      >
        {isTrue ? (negative ? "Yes" : "Yes") : "No"}
      </span>
    </div>
  );
};

export default BlogMetaInfo;