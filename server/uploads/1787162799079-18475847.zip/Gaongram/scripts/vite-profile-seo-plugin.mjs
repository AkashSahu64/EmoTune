/* eslint-env node */
/* global console, URL */
import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";
import {
  buildEntitySeo,
  buildPlaceholderProfile,
  buildSeoHtml,
  buildProfileHtml,
  fetchEntityById,
  fetchProfileByIdentifier,
  getApiBaseUrl,
  getSiteUrl,
  readProfileSnapshot,
} from "./profile-seo.mjs";
import { buildProfileOgImagePayload } from "../seo/og/images.mjs";
import { renderOgPng } from "../seo/og/png.mjs";
import { renderRobotsTxt } from "../seo/robots/index.mjs";
import {
  endpointForSitemapSection,
  normalizeSitemapItems,
  renderSitemapIndex,
  renderStaticSitemap,
  renderUrlSet,
  SITEMAP_SECTIONS,
} from "../seo/sitemap/index.mjs";
import { fetchJson, apiUrl, normalizeProfile } from "./profile-seo.mjs";

const HTML_ACCEPT_RE = /\btext\/html\b|\*\/\*|\btext\/\*/i;
const PROFILE_ROUTE_RE = /^\/profile\/([^/?#]+)\/?$/i;
const PROFILE_POST_ROUTE_RE = /^\/profile\/([^/?#]+)\/post\/([^/?#]+)\/?$/i;
const ENTITY_ROUTE_PATTERNS = [
  { entity: "post", re: /^\/posts\/([^/?#]+)\/?$/i },
  { entity: "reel", re: /^\/reels\/([^/?#]+)\/?$/i },
  { entity: "audio", re: /^\/audio\/([^/?#]+)\/?$/i },
  { entity: "blog", re: /^\/blogs\/([^/?#]+)\/?$/i },
  { entity: "playlist", re: /^\/playlists\/([^/?#]+)\/?$/i },
  { entity: "hashtag", re: /^\/hashtags\/([^/?#]+)\/?$/i },
  { entity: "story", re: /^\/story\/([^/?#]+)\/?$/i },
];

const isHtmlRequest = (req) => {
  if (req.method !== "GET" && req.method !== "HEAD") return false;

  const accept = req.headers.accept || "";
  const userAgent = req.headers["user-agent"] || "";

  return HTML_ACCEPT_RE.test(accept) || /bot|crawler|spider|facebookexternalhit|twitterbot|whatsapp|telegrambot|linkedinbot|slackbot/i.test(userAgent);
};

const getProfileIdentifier = (requestUrl = "/") => {
  const pathname = requestUrl.split("?")[0].split("#")[0];
  const match = pathname.match(PROFILE_ROUTE_RE);
  if (!match) return "";

  try {
    return decodeURIComponent(match[1]);
  } catch {
    return match[1];
  }
};

const getEntityRoute = (requestUrl = "/") => {
  const url = new URL(requestUrl, "http://localhost");
  const profilePostMatch = url.pathname.match(PROFILE_POST_ROUTE_RE);
  if (profilePostMatch) {
    return {
      entity: "post",
      identifier: decodeURIComponent(profilePostMatch[2]),
      path: url.pathname,
    };
  }

  for (const pattern of ENTITY_ROUTE_PATTERNS) {
    const match = url.pathname.match(pattern.re);
    if (match) {
      return {
        entity: pattern.entity,
        identifier: decodeURIComponent(match[1]),
        path: url.pathname,
      };
    }
  }

  const startId = url.searchParams.get("start") || url.searchParams.get("single");
  if (url.pathname === "/audio" && startId) {
    return { entity: "audio", identifier: startId, path: `${url.pathname}${url.search}` };
  }
  if (url.pathname === "/reels" && startId) {
    return { entity: "reel", identifier: startId, path: `${url.pathname}${url.search}` };
  }

  return null;
};

const sendHtml = (res, html) => {
  res.statusCode = 200;
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.setHeader("Cache-Control", "public, max-age=300, stale-while-revalidate=86400");
  res.end(html);
};

const sendText = (res, body, contentType) => {
  res.statusCode = 200;
  res.setHeader("Content-Type", contentType);
  res.setHeader("Cache-Control", "public, max-age=300, stale-while-revalidate=86400");
  res.end(body);
};

const createUtilityMiddleware = () => async (req, res, next) => {
  const requestUrl = new URL(req.url || "/", "http://localhost");

  if (requestUrl.pathname === "/robots.txt") {
    sendText(res, renderRobotsTxt(), "text/plain; charset=utf-8");
    return;
  }

  if (requestUrl.pathname === "/sitemap.xml") {
    sendText(res, renderSitemapIndex(), "application/xml; charset=utf-8");
    return;
  }

  const sitemapMatch = requestUrl.pathname.match(/^\/sitemap-([a-z]+)\.xml$/i);
  if (sitemapMatch && SITEMAP_SECTIONS.includes(sitemapMatch[1].toLowerCase())) {
    const section = sitemapMatch[1].toLowerCase();
    try {
      const endpoint = endpointForSitemapSection(section);
      const entries = normalizeSitemapItems(
        section,
        endpoint ? await fetchJson(apiUrl(endpoint)) : null,
      );
      sendText(res, renderUrlSet(entries), "application/xml; charset=utf-8");
    } catch {
      sendText(res, renderStaticSitemap(), "application/xml; charset=utf-8");
    }
    return;
  }

  const ogMatch = requestUrl.pathname.match(/^\/api\/og\/([^/]+)\/([^/]+)\/?$/i);
  if (ogMatch) {
    const entity = decodeURIComponent(ogMatch[1]);
    const identifier = decodeURIComponent(ogMatch[2]);
    let payload = {};

    try {
      payload =
        entity === "profile"
          ? normalizeProfile(await fetchProfileByIdentifier(identifier), identifier)
          : await fetchEntityById(entity, identifier);
    } catch {
      payload =
        entity === "profile"
          ? normalizeProfile(buildPlaceholderProfile(identifier), identifier)
          : {};
    }

    const png =
      entity === "profile"
        ? renderOgPng(
            buildProfileOgImagePayload({
              ...payload,
              profileImage: payload.profileImage,
            }),
          )
        : renderOgPng({
            entity,
            title: payload.title || payload.caption || payload.name || `${entity} on GaonGram`,
            description: payload.description || payload.excerpt || payload.content || "Shared from GaonGram",
            image: payload.image || payload.cover_image || payload.thumbnail || payload.profile_image,
          });
    sendText(res, png, "image/png");
    return;
  }

  next();
};

const createProfileMiddleware = ({ mode, server } = {}) => async (req, res, next) => {
  if (!isHtmlRequest(req)) return next();

  const identifier = getProfileIdentifier(req.url || "/");
  const entityRoute = getEntityRoute(req.url || "/");
  if (!identifier && !entityRoute) return next();

  try {
    const templatePath = mode === "preview" ? resolve("dist", "index.html") : resolve("index.html");
    const templateHtml = readFileSync(templatePath, "utf8");
    let html;

    if (identifier) {
      try {
        const profile = await fetchProfileByIdentifier(identifier);
        html = buildProfileHtml(templateHtml, profile, identifier);
      } catch (error) {
        const snapshotHtml =
          mode === "preview" ? readProfileSnapshot(identifier, resolve("dist")) : "";
        const profile = buildPlaceholderProfile(identifier);
        html = snapshotHtml || buildProfileHtml(templateHtml, profile, identifier);
        console.warn(
          `[profile-seo] Using fallback metadata for /profile/${identifier}: ${error.message}`,
        );
      }
    } else {
      try {
        const payload = await fetchEntityById(entityRoute.entity, entityRoute.identifier);
        html = buildSeoHtml(
          templateHtml,
          buildEntitySeo(
            entityRoute.entity,
            payload,
            entityRoute.identifier,
            entityRoute.path,
          ),
          entityRoute.path,
        );
      } catch (error) {
        html = buildSeoHtml(
          templateHtml,
          buildEntitySeo(entityRoute.entity, {}, entityRoute.identifier, entityRoute.path),
          entityRoute.path,
        );
        console.warn(
          `[profile-seo] Using fallback metadata for ${entityRoute.path}: ${error.message}`,
        );
      }
    }

    const transformed =
      mode === "dev" && server
        ? await server.transformIndexHtml(req.url, html)
        : html;

    sendHtml(res, transformed);
  } catch (error) {
    console.error(`[profile-seo] ${mode || "server"} error:`, error);
    next();
  }
};

export default function viteProfileSeoPlugin() {
  return {
    name: "gaongram-profile-seo",
    configureServer(server) {
      console.log(`[profile-seo] dev middleware enabled (${getSiteUrl()}, ${getApiBaseUrl()})`);
      server.middlewares.use(createUtilityMiddleware());
      server.middlewares.use(createProfileMiddleware({ mode: "dev", server }));
    },
    configurePreviewServer(server) {
      console.log(`[profile-seo] preview middleware enabled (${getSiteUrl()}, ${getApiBaseUrl()})`);
      server.middlewares.use(createUtilityMiddleware());
      server.middlewares.use(createProfileMiddleware({ mode: "preview" }));
    },
    closeBundle() {
      const indexPath = resolve("dist", "index.html");
      if (!existsSync(indexPath)) return;
      console.log("[profile-seo] build complete. Profile snapshots are generated by scripts/build.mjs.");
    },
  };
}
