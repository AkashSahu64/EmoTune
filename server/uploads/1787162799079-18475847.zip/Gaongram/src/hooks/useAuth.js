import { useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuthStore } from "../store/authStore.js";

export const useAuth = () => {
  const user = useAuthStore((state) => state.user);
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const loading = useAuthStore((state) => state.loading);
  const error = useAuthStore((state) => state.error);
  const clearError = useAuthStore((state) => state.clearError);
  const logout = useAuthStore((state) => state.logout);
  const navigate = useNavigate();

  useEffect(() => {
    return () => {
      clearError();
    };
  }, [clearError]);

  const requireAuth = useCallback(
    (redirectTo = "/login") => {
      if (!isAuthenticated && !loading) {
        navigate(redirectTo, { replace: true });
        return false;
      }
      return true;
    },
    [isAuthenticated, loading, navigate],
  );

  const requireGuest = useCallback(
    (redirectTo = "/") => {
      if (isAuthenticated && !loading) {
        navigate(redirectTo, { replace: true });
        return false;
      }
      return true;
    },
    [isAuthenticated, loading, navigate],
  );

  const handleLogout = useCallback(async () => {
    await logout();
    navigate("/login", { replace: true });
  }, [logout, navigate]);

  return {
    user,
    isAuthenticated,
    loading,
    error,
    clearError,
    logout: handleLogout,
    requireAuth,
    requireGuest,
  };
};