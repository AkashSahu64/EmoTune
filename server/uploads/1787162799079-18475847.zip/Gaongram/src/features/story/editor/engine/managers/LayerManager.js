import { sortLayers } from "../helpers/layerUtils.js";

export class LayerManager {
  constructor(engine) {
    this.engine = engine;
  }

  syncObjectStack() {
    const { canvas, store } = this.engine;
    if (!canvas) return;
    const state = store.getState();
    sortLayers(state.layers).forEach((layer) => {
      const object = this.engine.objectMap.get(layer.id);
      if (object) canvas.bringToFront(object);
    });
    const vignette = this.engine.decorationManager?.vignetteObject;
    const frame = this.engine.decorationManager?.frameObject;

    if (vignette) canvas.bringToFront(vignette);
    if (frame) canvas.bringToFront(frame);
    this.engine.requestRender?.({ preview: true });
  }

  updateLayerTransform(layerId, transform, recordHistory = false) {
    this.engine.store.getState().updateLayer(layerId, transform, { recordHistory });
  }

  removeLayer(layerId, options = {}) {
    const object = this.engine.objectMap.get(layerId);
    if (object) {
      this.engine.canvas.remove(object);
      this.engine.objectMap.delete(layerId);
    }
    const video = this.engine.videoElements.get(layerId);
    if (video) {
      this.engine.videoFrameDisposers.get(layerId)?.();
      this.engine.videoFrameDisposers.delete(layerId);
      this.engine.nativeVideoContainers?.get(layerId)?.remove();
      this.engine.nativeVideoContainers?.delete(layerId);
      video.pause();
      video.removeAttribute("src");
      video.load();
      this.engine.videoElements.delete(layerId);
    }
    const url = this.engine.sourceUrls.get(layerId);
    if (url) {
      this.engine.revokeSourceUrl(url);
      this.engine.sourceUrls.delete(layerId);
    }
    this.engine.store.getState().removeLayer(layerId, options);
    this.engine.requestRender?.({ preview: true });
  }
}
