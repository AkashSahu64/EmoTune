export const createObjectUrl = (fileOrUrl) => {
  if (!fileOrUrl || typeof fileOrUrl === "string") return fileOrUrl || "";
  return URL.createObjectURL(fileOrUrl);
};

export const revokeObjectUrl = (url) => {
  if (url?.startsWith("blob:")) URL.revokeObjectURL(url);
};

export const resolveMediaType = (fileOrUrl, fallback = "image") => {
  const type = fileOrUrl?.type || "";
  if (type.startsWith("video/")) return "video";
  if (type.startsWith("image/")) return "image";
  return fallback;
};
