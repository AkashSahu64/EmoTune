// src/features/blogs/hooks/useBlog.js
import { useState, useEffect, useCallback } from "react";
import blogService from "../services/blogService";
import { showToast } from "../utils/toast";
import { shouldSkipLiveSeoFetch } from "../seo/seoUtils";

export const useBlog = (id) => {
  const [blog, setBlog] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchBlog = useCallback(async () => {
    if (!id) return;
    if (shouldSkipLiveSeoFetch({ allowConfiguredApi: true })) {
      setBlog(null);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const response = await blogService.getBlogById(id);
      if (response.success) {
        setBlog(response.data);
      } else {
        throw new Error(response.message || "Failed to fetch blog");
      }
    } catch (err) {
      setError(err);
      showToast(err.message || "Failed to load blog", "error");
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchBlog();
  }, [fetchBlog]);

  return { blog, loading, error, refetch: fetchBlog };
};
