import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AlertCircle, Loader2, Pause, Play } from "lucide-react";
import { useCanvasStore } from "../useCanvasStore.js";
import {
  isCorsSafeAudioUrl,
  normalizeStoryMediaUrl,
  storyAudioManager,
} from "../../audio/storyAudioManager.js";

const WAVEFORM_HEIGHT = 50;
const MAX_SEGMENT_DURATION = 15;
const MIN_SEGMENT_DURATION = 1;
const HANDLE_WIDTH = 4; // increased for larger touch target
const HANDLE_HIT_TOLERANCE = 8; // extra area around handle considered hover
const waveformPeakCache = new Map();
const MAX_WAVEFORM_CACHE_ENTRIES = 24;
const TARGET_VISIBLE_RATIO = 0.7; // clip occupies ~70% of canvas width

const clamp = (value, min, max) => Math.min(Math.max(value, min), max);

const formatTime = (seconds) => {
  const safeSeconds = Math.max(0, Number(seconds) || 0);
  const minutes = Math.floor(safeSeconds / 60);
  const secs = Math.floor(safeSeconds % 60);
  return `${minutes}:${secs.toString().padStart(2, "0")}`;
};

const createPeaks = (buffer, barCount) => {
  const channelData = buffer.getChannelData(0);
  const samplesPerBar = Math.max(1, Math.floor(channelData.length / barCount));
  const peaks = [];

  for (let index = 0; index < barCount; index += 1) {
    const start = index * samplesPerBar;
    const end = Math.min(start + samplesPerBar, channelData.length);
    let peak = 0;

    for (let sampleIndex = start; sampleIndex < end; sampleIndex += 1) {
      peak = Math.max(peak, Math.abs(channelData[sampleIndex] || 0));
    }

    peaks.push(peak);
  }

  const maxPeak = Math.max(...peaks, 0.01);
  return peaks.map((peak) => peak / maxPeak);
};

const createFallbackPeaks = (barCount) =>
  Array.from({ length: barCount }, (_, index) => {
    const wave = Math.sin(index * 0.42) * 0.35 + Math.sin(index * 0.11) * 0.25;
    return clamp(0.45 + wave, 0.12, 0.95);
  });

const readCachedWaveform = (key) => waveformPeakCache.get(key) || null;

const writeCachedWaveform = (key, value) => {
  if (!key || !value) return;
  waveformPeakCache.set(key, value);
  if (waveformPeakCache.size > MAX_WAVEFORM_CACHE_ENTRIES) {
    const oldestKey = waveformPeakCache.keys().next().value;
    waveformPeakCache.delete(oldestKey);
  }
};

const fetchArrayBufferWithRetry = async (url, signal, attempts = 2) => {
  let lastError = null;
  for (let attempt = 0; attempt <= attempts; attempt += 1) {
    try {
      const response = await fetch(url, { cache: "no-store", mode: "cors", signal });
      if (!response.ok) throw new Error("Unable to load audio");
      return response.arrayBuffer();
    } catch (error) {
      lastError = error;
      if (error.name === "AbortError" || attempt === attempts) throw error;
      await new Promise((resolve) => window.setTimeout(resolve, 180 * (attempt + 1)));
    }
  }
  throw lastError || new Error("Unable to load audio");
};

const getPlayableAudioDuration = (audioUrl) =>
  new Promise((resolve) => {
    if (!audioUrl) {
      resolve(0);
      return;
    }

    const audio = new Audio();
    let settled = false;
    const cleanup = () => {
      audio.removeEventListener("loadedmetadata", onReady);
      audio.removeEventListener("durationchange", onReady);
      audio.removeEventListener("error", onError);
      audio.removeAttribute("src");
      audio.load();
    };
    const settle = (value) => {
      if (settled) return;
      settled = true;
      window.clearTimeout(timeoutId);
      cleanup();
      resolve(Number.isFinite(value) && value > 0 ? value : 0);
    };
    const onReady = () => settle(audio.duration);
    const onError = () => settle(0);
    const timeoutId = window.setTimeout(() => settle(0), 6000);

    audio.preload = "metadata";
    audio.addEventListener("loadedmetadata", onReady);
    audio.addEventListener("durationchange", onReady);
    audio.addEventListener("error", onError);
    audio.src = audioUrl;
    audio.load();
  });

const getPointerX = (event, canvas) => {
  const rect = canvas.getBoundingClientRect();
  return clamp(event.clientX - rect.left, 0, rect.width);
};

const CustomWaveform = ({ audioUrl, onTrimChange }) => {
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  const peaksRef = useRef([]);
  const durationRef = useRef(0);
  const progressRef = useRef(0);
  const rafRef = useRef(null);
  const sizeRafRef = useRef(null);
  const sizeDebounceRef = useRef(null);
  const dragRef = useRef(null);
  const audioContextRef = useRef(null);
  const abortRef = useRef(null);
  const musicRef = useRef(null);
  const applyLoadedDurationRef = useRef(null);
  const scheduleDrawRef = useRef(null);
  const windowStartRef = useRef(0);
  const windowDurationRef = useRef(0);
  const isPlayingRef = useRef(false);
  const hoveredHandleRef = useRef(null);
  const isDraggingRef = useRef(false);

  const music = useCanvasStore((state) => state.music);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [canvasWidth, setCanvasWidth] = useState(0);
  const safeAudioUrl = useMemo(() => normalizeStoryMediaUrl(audioUrl), [audioUrl]);

  useEffect(() => {
    musicRef.current = music;
  }, [music]);

  const clipDuration = useMemo(() => {
    const availableDuration = duration || music?.sourceDuration || 0;
    if (!availableDuration) return MAX_SEGMENT_DURATION;
    return Math.max(
      MIN_SEGMENT_DURATION,
      Math.min(MAX_SEGMENT_DURATION, availableDuration),
    );
  }, [duration, music?.sourceDuration]);
  const maxTrimStart = Math.max(0, (duration || music?.sourceDuration || clipDuration) - clipDuration);
  const trimStart = clamp(music?.startTime ?? 0, 0, maxTrimStart);
  const trimEnd = trimStart + clipDuration;

  const selectedMusic = useMemo(
    () =>
      music
        ? {
            ...music,
            startTime: trimStart,
            duration: clipDuration,
          }
        : null,
    [clipDuration, music, trimStart],
  );

  const applyLoadedDuration = useCallback(
    (nextDuration) => {
      if (!music || !nextDuration) return;
      const segmentDuration = Math.max(
        MIN_SEGMENT_DURATION,
        Math.min(MAX_SEGMENT_DURATION, nextDuration),
      );
      const maxStart = Math.max(0, nextDuration - segmentDuration);
      const nextStart = clamp(music.startTime ?? 0, 0, maxStart);

      if (nextStart !== music.startTime || segmentDuration !== music.duration) {
        onTrimChange?.(
          {
            startTime: nextStart,
            duration: Math.max(MIN_SEGMENT_DURATION, segmentDuration),
          },
          { recordHistory: false },
        );
      }
    },
    [music, onTrimChange],
  );

  useEffect(() => {
    applyLoadedDurationRef.current = applyLoadedDuration;
  }, [applyLoadedDuration]);

  // time ↔ x conversion using window refs
  const timeToX = useCallback(
    (time) => {
      if (!canvasWidth || !durationRef.current || !windowDurationRef.current) return 0;
      const wd = windowDurationRef.current || durationRef.current;
      const ws = windowStartRef.current || 0;
      return ((time - ws) / wd) * canvasWidth;
    },
    [canvasWidth],
  );

  const xToTime = useCallback(
    (x) => {
      if (!canvasWidth || !durationRef.current || !windowDurationRef.current) return 0;
      const wd = windowDurationRef.current || durationRef.current;
      const ws = windowStartRef.current || 0;
      return ws + (x / canvasWidth) * wd;
    },
    [canvasWidth],
  );

  const scheduleDraw = useCallback(() => {
    if (rafRef.current) return;
    rafRef.current = requestAnimationFrame(() => {
      rafRef.current = null;
      const canvas = canvasRef.current;
      if (!canvas) return;

      const ctx = canvas.getContext("2d");
      const pixelRatio = window.devicePixelRatio || 1;
      const cssWidth = Math.max(1, Math.round(canvas.clientWidth || canvasWidth || 0));
      if (!cssWidth) return;
      const peaks = peaksRef.current;
      if (!peaks.length) {
        const fallbackCount = clamp(Math.round(cssWidth / 4), 200, 400);
        peaksRef.current = createFallbackPeaks(fallbackCount);
      }
      const totalDuration = durationRef.current || 0;
      if (!totalDuration) return;

      const cssHeight = WAVEFORM_HEIGHT;
      const currentProgress = progressRef.current;
      const playing = isPlayingRef.current;
      const currentClipDuration = clipDuration;
      const currentTrimStart = trimStart;
      const currentTrimEnd = trimEnd;

      // compute window based on clip duration and playback state
      const targetWindowDuration = Math.max(
        currentClipDuration * 1.1,
        currentClipDuration / TARGET_VISIBLE_RATIO,
      );
      const windowDuration = Math.min(totalDuration, targetWindowDuration);
      const centerTime = playing
        ? currentTrimStart + currentProgress * currentClipDuration
        : currentTrimStart + currentClipDuration / 2;
      const windowStart = centerTime - windowDuration / 2;

      // store for drag and conversion
      windowStartRef.current = windowStart;
      windowDurationRef.current = windowDuration;

      // compute pixel positions
      const selectedLeftX = ((currentTrimStart - windowStart) / windowDuration) * cssWidth;
      const selectedRightX = ((currentTrimEnd - windowStart) / windowDuration) * cssWidth;
      const playheadTime = playing
        ? currentTrimStart + currentProgress * currentClipDuration
        : currentTrimStart; // when paused, playhead at start of segment
      const playheadX = ((playheadTime - windowStart) / windowDuration) * cssWidth;

      // ensure canvas size matches container (retina)
      if (canvas.width !== Math.round(cssWidth * pixelRatio)) {
        canvas.width = Math.round(cssWidth * pixelRatio);
        canvas.height = Math.round(cssHeight * pixelRatio);
      }

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.save();
      ctx.scale(pixelRatio, pixelRatio);

      // background
      ctx.fillStyle = "rgba(255,255,255,0.08)";
      ctx.fillRect(0, 0, cssWidth, cssHeight);

      // draw waveform bars within visible window
      const peakCount = peaks.length;
      const barCountVisible = Math.max(2, Math.ceil((windowDuration / totalDuration) * peakCount));
      const barWidth = Math.max(2, cssWidth / barCountVisible - 1);
      const gap = Math.max(0, barWidth > 3 ? 1 : 0);
      const actualBarWidth = barWidth - gap;

      // map indices
      const startIndex = Math.floor(
        ((windowStart / totalDuration) * (peakCount - 1)),
      );
      const endIndex = Math.ceil(
        (((windowStart + windowDuration) / totalDuration) * (peakCount - 1)),
      );
      const visibleIndices = [];
      for (let i = startIndex; i <= endIndex; i++) {
        if (i >= 0 && i < peakCount) visibleIndices.push(i);
      }

      visibleIndices.forEach((peakIndex, visualIndex) => {
        const time = (peakIndex / (peakCount - 1)) * totalDuration;
        const x = ((time - windowStart) / windowDuration) * cssWidth;
        const peak = peaks[peakIndex] || 0.1;
        const height = Math.max(3, peak * (cssHeight - 16));
        const y = (cssHeight - height) / 2;
        const centerX = x + actualBarWidth / 2;
        const isSelected = centerX >= selectedLeftX && centerX <= selectedRightX;

        ctx.fillStyle = isSelected ? "#4ade80" : "#166534";
        ctx.fillRect(x, y, actualBarWidth, height);
      });

      // selection region overlay
      const isDragging = isDraggingRef.current;
      ctx.fillStyle = isDragging
        ? "rgba(74,222,128,0.25)"
        : "rgba(74,222,128,0.12)";
      ctx.fillRect(
        selectedLeftX,
        0,
        Math.max(0, selectedRightX - selectedLeftX),
        cssHeight,
      );

      // selection border
      ctx.strokeStyle = "rgba(255,255,255,0.88)";
      ctx.lineWidth = 1;
      ctx.strokeRect(
        selectedLeftX + 0.5,
        0.5,
        Math.max(0, selectedRightX - selectedLeftX - 1),
        cssHeight - 1,
      );

      // draw handles with hover/drag feedback
      const drawHandle = (x, side) => {
        const handleWidth = HANDLE_WIDTH;
        const isHovered = hoveredHandleRef.current === side;
        const color = isDragging
          ? "#ffffff"
          : isHovered
          ? "#a7f3d0"
          : "#4ade80";
        ctx.fillStyle = color;
        ctx.fillRect(x - handleWidth / 2, 0, handleWidth, cssHeight);
        // subtle grip lines
        ctx.fillStyle = "rgba(0,0,0,0.2)";
        ctx.fillRect(x - 2, cssHeight * 0.25, 4, cssHeight * 0.5);
      };

      drawHandle(selectedLeftX, "left");
      drawHandle(selectedRightX, "right");

      // playhead line
      if (playing || playheadX >= 0) {
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(playheadX, 0);
        ctx.lineTo(playheadX, cssHeight);
        ctx.stroke();
      }

      ctx.restore();
    });
  }, [canvasWidth, clipDuration, trimStart, trimEnd]);

  useEffect(() => {
    scheduleDrawRef.current = scheduleDraw;
  }, [scheduleDraw]);

  // resize observer
  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return undefined;

    const updateSize = (attempt = 0) => {
      const rawWidth = Math.round(container.getBoundingClientRect().width || container.clientWidth || 0);
      if (rawWidth <= 0 && attempt < 12) {
        sizeRafRef.current = requestAnimationFrame(() => updateSize(attempt + 1));
        return;
      }
      const nextWidth = Math.max(1, rawWidth || 280);
      const pixelRatio = window.devicePixelRatio || 1;
      canvas.width = Math.round(nextWidth * pixelRatio);
      canvas.height = Math.round(WAVEFORM_HEIGHT * pixelRatio);
      canvas.style.width = "100%";
      canvas.style.height = `${WAVEFORM_HEIGHT}px`;
      setCanvasWidth(nextWidth);
      requestAnimationFrame(scheduleDraw);
    };

    updateSize();
    const observer = new ResizeObserver(() => {
      window.clearTimeout(sizeDebounceRef.current);
      sizeDebounceRef.current = window.setTimeout(() => updateSize(), 32);
    });
    observer.observe(container);
    return () => {
      observer.disconnect();
      window.clearTimeout(sizeDebounceRef.current);
      if (sizeRafRef.current) {
        cancelAnimationFrame(sizeRafRef.current);
        sizeRafRef.current = null;
      }
    };
  }, [scheduleDraw]);

  // waveform loading
  useEffect(() => {
    if (!safeAudioUrl) return undefined;

    let cancelled = false;
    abortRef.current?.abort();
    const abortController = new AbortController();
    abortRef.current = abortController;
    let localAudioContext = null;

    const loadWaveform = async () => {
      setIsLoading(true);
      setError("");
      const initialFallbackCount = 400;
      const fallbackDuration = Math.max(
        musicRef.current?.sourceDuration || 0,
        musicRef.current?.duration || MAX_SEGMENT_DURATION,
        (musicRef.current?.startTime || 0) + (musicRef.current?.duration || MAX_SEGMENT_DURATION),
      );
      peaksRef.current = createFallbackPeaks(initialFallbackCount);
      durationRef.current = fallbackDuration;
      setDuration(fallbackDuration);
      scheduleDrawRef.current?.();

      try {
        const cacheKey = safeAudioUrl; // high‑density peaks keyed only by URL
        const cached = readCachedWaveform(cacheKey);
        if (cached) {
          peaksRef.current = cached.peaks;
          durationRef.current = cached.duration;
          setDuration(cached.duration);
          applyLoadedDurationRef.current?.(cached.duration);
          scheduleDrawRef.current?.();
          setIsLoading(false);
          return;
        }

        if (!isCorsSafeAudioUrl(safeAudioUrl)) {
          const metadataDuration = await getPlayableAudioDuration(safeAudioUrl);
          const resolvedDuration = Math.max(
            metadataDuration,
            musicRef.current?.sourceDuration || 0,
            musicRef.current?.duration || MAX_SEGMENT_DURATION,
            (musicRef.current?.startTime || 0) + (musicRef.current?.duration || MAX_SEGMENT_DURATION),
          );
          const barCount = Math.max(200, Math.ceil(resolvedDuration * 100));
          peaksRef.current = createFallbackPeaks(barCount);
          durationRef.current = resolvedDuration;
          setDuration(resolvedDuration);
          writeCachedWaveform(cacheKey, { peaks: peaksRef.current, duration: resolvedDuration });
          applyLoadedDurationRef.current?.(resolvedDuration);
          scheduleDrawRef.current?.();
          setIsLoading(false);
          return;
        }

        const data = await fetchArrayBufferWithRetry(safeAudioUrl, abortController.signal);

        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        if (!AudioContextClass) throw new Error("Web Audio is not supported");
        const audioContext = new AudioContextClass();
        localAudioContext = audioContext;
        audioContextRef.current = audioContext;
        const buffer = await audioContext.decodeAudioData(data.slice(0));
        if (cancelled) return;

        const nextDuration = buffer.duration || 0;
        const barCount = Math.max(200, Math.ceil(nextDuration * 100));
        peaksRef.current = createPeaks(buffer, barCount);
        durationRef.current = nextDuration;
        setDuration(nextDuration);
        writeCachedWaveform(cacheKey, { peaks: peaksRef.current, duration: nextDuration });

        applyLoadedDurationRef.current?.(nextDuration);
        scheduleDrawRef.current?.();
      } catch (loadError) {
        if (loadError.name !== "AbortError" && !cancelled) {
          const fallbackDuration = Math.max(
            musicRef.current?.sourceDuration || 0,
            musicRef.current?.duration || MAX_SEGMENT_DURATION,
            (musicRef.current?.startTime || 0) + (musicRef.current?.duration || MAX_SEGMENT_DURATION),
          );
          const barCount = Math.max(200, Math.ceil(fallbackDuration * 100));
          peaksRef.current = createFallbackPeaks(barCount);
          durationRef.current = fallbackDuration;
          setDuration(fallbackDuration);
          writeCachedWaveform(safeAudioUrl, {
            peaks: peaksRef.current,
            duration: fallbackDuration,
          });
          setError("");
          applyLoadedDurationRef.current?.(fallbackDuration);
          scheduleDrawRef.current?.();
        }
      } finally {
        if (!cancelled) setIsLoading(false);
        if (localAudioContext) {
          localAudioContext.close?.().catch(() => undefined);
        }
        if (audioContextRef.current === localAudioContext) {
          audioContextRef.current = null;
        }
      }
    };

    loadWaveform();

    return () => {
      cancelled = true;
      abortController.abort();
    };
  }, [safeAudioUrl]);

  // audio progress subscriptions
  useEffect(() => {
    let prevIsPlaying = isPlayingRef.current;
    const unsubscribeProgress = storyAudioManager.subscribe("progress", (event) => {
      if (normalizeStoryMediaUrl(event.detail.music?.audio) !== safeAudioUrl) return;
      progressRef.current = event.detail.progress || 0;
      const newIsPlaying = event.detail.isPlaying;
      if (prevIsPlaying !== newIsPlaying) {
        prevIsPlaying = newIsPlaying;
        isPlayingRef.current = newIsPlaying;
        setIsPlaying(newIsPlaying);
      }
      scheduleDraw();
    });
    const unsubscribeState = storyAudioManager.subscribe("statechange", (event) => {
      if (normalizeStoryMediaUrl(event.detail.music?.audio) !== safeAudioUrl) return;
      const newIsPlaying = event.detail.isPlaying;
      if (isPlayingRef.current !== newIsPlaying) {
        isPlayingRef.current = newIsPlaying;
        setIsPlaying(newIsPlaying);
        prevIsPlaying = newIsPlaying;
      }
      scheduleDraw();
    });

    return () => {
      unsubscribeProgress();
      unsubscribeState();
    };
  }, [safeAudioUrl, scheduleDraw]);

  // redraw on relevant changes
  useEffect(() => {
    scheduleDraw();
  }, [duration, isPlaying, scheduleDraw, trimEnd, trimStart]);

  // visibility / orientation handlers
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (!document.hidden) {
        scheduleDraw();
      }
    };
    document.addEventListener("visibilitychange", handleVisibilityChange);
    window.addEventListener("orientationchange", scheduleDraw, { passive: true });
    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      window.removeEventListener("orientationchange", scheduleDraw);
      if (rafRef.current) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
    };
  }, [scheduleDraw]);

  // hover / cursor tracking (does not affect drag)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const handleMouseMove = (e) => {
      const x = getPointerX(e, canvas);
      const selLeft = timeToX(trimStart);
      const selRight = timeToX(trimEnd);
      const nearLeft = Math.abs(x - selLeft) < HANDLE_WIDTH / 2 + HANDLE_HIT_TOLERANCE;
      const nearRight = Math.abs(x - selRight) < HANDLE_WIDTH / 2 + HANDLE_HIT_TOLERANCE;
      if (nearLeft) {
        hoveredHandleRef.current = "left";
        canvas.style.cursor = "ew-resize";
      } else if (nearRight) {
        hoveredHandleRef.current = "right";
        canvas.style.cursor = "ew-resize";
      } else {
        hoveredHandleRef.current = null;
        canvas.style.cursor = isDraggingRef.current ? "grabbing" : "grab";
      }
      scheduleDraw();
    };
    canvas.addEventListener("mousemove", handleMouseMove, { passive: true });
    return () => {
      canvas.removeEventListener("mousemove", handleMouseMove);
    };
  }, [scheduleDraw, timeToX, trimStart, trimEnd]);

  // trim commit
  const commitTrim = useCallback(
    (startTime, options = {}) => {
      const safeDuration = clipDuration;
      const safeStart = clamp(
        startTime,
        0,
        Math.max(0, (duration || music?.sourceDuration || safeDuration) - safeDuration),
      );
      onTrimChange?.({ startTime: safeStart, duration: safeDuration }, options);
      if (dragRef.current) {
        dragRef.current.latestStart = safeStart;
      }

      if (selectedMusic) {
        storyAudioManager.setSegment(
          { ...selectedMusic, startTime: safeStart, duration: safeDuration },
          { seekToStart: false, keepPlaying: true },
        );
      }
    },
    [clipDuration, duration, music?.sourceDuration, onTrimChange, selectedMusic],
  );

  // pointer event handlers for dragging selection
  const handlePointerDown = useCallback(
    (event) => {
      const canvas = canvasRef.current;
      if (!canvas || !durationRef.current) return;
      const x = getPointerX(event, canvas);
      const pointerTime = xToTime(x);
      const startX = timeToX(trimStart);
      const endX = timeToX(trimEnd);
      const pointerOffset = x >= startX && x <= endX
        ? pointerTime - trimStart
        : clipDuration / 2;
      const nextStart = clamp(
        pointerTime - pointerOffset,
        0,
        Math.max(0, durationRef.current - clipDuration),
      );

      if (nextStart !== trimStart) {
        commitTrim(nextStart, { recordHistory: false, seekToStart: false });
      }

      dragRef.current = {
        pointerId: event.pointerId,
        pointerOffset,
        latestStart: nextStart,
      };
      isDraggingRef.current = true;
      canvas.setPointerCapture?.(event.pointerId);
      event.preventDefault();
    },
    [clipDuration, commitTrim, timeToX, trimStart, trimEnd, xToTime],
  );

  const handlePointerMove = useCallback(
    (event) => {
      const canvas = canvasRef.current;
      const drag = dragRef.current;
      if (!canvas || !drag || !durationRef.current) return;

      const x = getPointerX(event, canvas);
      const nextStart = clamp(
        xToTime(x) - drag.pointerOffset,
        0,
        Math.max(0, durationRef.current - clipDuration),
      );

      commitTrim(nextStart, { recordHistory: false, seekToStart: false });
      scheduleDraw();
      event.preventDefault();
    },
    [clipDuration, commitTrim, scheduleDraw, xToTime],
  );

  const handlePointerUp = useCallback(
    (event) => {
      if (!dragRef.current) return;
      const latestStart = dragRef.current.latestStart ?? trimStart;
      dragRef.current = null;
      isDraggingRef.current = false;
      canvasRef.current?.releasePointerCapture?.(event.pointerId);
      commitTrim(latestStart, { recordHistory: true, seekToStart: false });
      scheduleDraw();
    },
    [commitTrim, trimStart, scheduleDraw],
  );

  const togglePlayback = useCallback(async () => {
    if (!selectedMusic || isLoading || error) return;

    if (isPlaying) {
      storyAudioManager.pause();
      return;
    }

    progressRef.current = 0;
    await storyAudioManager.playSegment(selectedMusic, {
      loop: true,
      seek: true,
      volume: 0.8,
    });
  }, [error, isLoading, isPlaying, selectedMusic]);

  if (!music) return null;

  return (
    <div className="space-y-2 rounded-lg border border-border bg-card p-3 dark:border-border-dark dark:bg-card-dark">
      {isLoading && (
        <div className="flex h-16 items-center justify-center">
          <Loader2 className="animate-spin text-mutedForeground dark:text-mutedForeground-dark" size={20} />
        </div>
      )}

      {error && (
        <div className="flex items-center gap-2 rounded-lg bg-red-500/10 px-3 py-2 text-sm text-red-300">
          <AlertCircle size={16} />
          {error}
        </div>
      )}

      <div ref={containerRef} className="relative overflow-hidden rounded-md">
        <canvas
          ref={canvasRef}
          className="block w-full touch-none"
          style={{ cursor: isDraggingRef.current ? "grabbing" : "grab" }}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
        />
      </div>

      <div className="flex items-center justify-between gap-3">
        <span className="min-w-0 truncate text-xs text-mutedForeground dark:text-mutedForeground-dark">
          {formatTime(trimStart)} - {formatTime(trimEnd)}
        </span>
        <button
          type="button"
          onClick={togglePlayback}
          disabled={isLoading || !!error || !duration}
          className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-white transition hover:bg-primary-light disabled:opacity-40"
          aria-label={isPlaying ? "Pause selected clip" : "Play selected clip"}
          title={isPlaying ? "Pause" : "Play"}
        >
          {isPlaying ? <Pause size={15} /> : <Play size={15} fill="currentColor" />}
        </button>
      </div>
    </div>
  );
};

export default React.memo(CustomWaveform);