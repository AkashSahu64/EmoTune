import React, { useState } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import Avatar from "../../components/common/Avatar.jsx";
import { formatTime } from "../../utils/formatTime.js";
import { notificationService } from "../../services/notification.service.js";
import NotificationActions from "./NotificationActions";
import { useFollow } from "../../hooks/useFollow";
import { useFollowStore } from "../../store/useFollowStore";

const NotificationCard = ({
  notification,
  onClick,
  onUpdateNotification,
  onRemoveNotification,
  onUnreadCountChange,
}) => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const {
    id,
    sender_username,
    sender_photo,
    sender,          // Must be provided by backend
    message,
    data,
    is_read,
    created_at,
    notification_type,
    is_following,
    is_followed_by,
    is_following_requested,
  } = notification;

  const requestId = data?.request_id;

  // Use global follow hook – syncs with Zustand store automatically
  const {
    isFollowing,
    isFollowingRequested,
    isLoading: followLoading,
    toggleFollow,
  } = useFollow(sender, false); // privacy flag not needed here, toggleFollow handles it

  const handleMainClick = async (e) => {
    if (e.target.closest("button")) return;
    if (onClick) {
      onClick(notification);
    } else {
      if (
        notification_type === "follow" ||
        notification_type === "follow_request"
      ) {
        navigate(`/profile/${sender_username}`);
      } else if (
        ["like", "comment", "post"].includes(notification_type) &&
        data?.post_id
      ) {
        navigate(`/vibe-feed/${data.post_id}`);
      }
    }
  };

  const thumbnailUrl =
    data?.image && data.image !== "http://gaongram.com/media/"
      ? data.image
      : null;

  const showThumbnail =
    ["like", "comment", "post"].includes(notification_type) && thumbnailUrl;

  const rowClasses = `
    flex items-center gap-3 px-4 py-3
    hover:bg-gray-50 dark:hover:bg-gray-900
    transition-colors duration-200 cursor-pointer
    ${!is_read ? "bg-blue-50/50 dark:bg-blue-900/20" : ""}
  `;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.2 }}
      onClick={handleMainClick}
      className={rowClasses}
    >
      <Avatar
        src={sender_photo}
        alt={sender_username}
        size="medium"
        className="w-10 h-10"
      />

      <div className="flex-1 min-w-0 max-w-[65%]">
        <div className="text-sm text-gray-700 dark:text-gray-300 leading-snug">
          <span className="font-semibold text-foreground dark:text-foreground-dark mr-1">
            {sender_username}
          </span>

          {!is_read && (
            <span className="inline-block w-2 h-2 bg-blue-500 rounded-full mr-1 align-middle" />
          )}

          <span>{message.replace(sender_username, "").trim()}</span>
        </div>
        <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
          {formatTime(created_at)}
        </p>
      </div>

      <div className="flex-shrink-0 ml-auto flex items-center gap-2">
        {/* Follow Request Actions */}
        {notification_type === "follow_request" && (
          <NotificationActions
            type="follow_request"
            is_followed_by={is_followed_by}
            loading={loading}
            requestId={requestId}
            onAccept={async (reqId) => {
              if (!reqId) {
                console.error("No request_id for accept");
                return;
              }
              setLoading(true);
              // Optimistic update
              const originalNotification = { ...notification };
              onUpdateNotification?.({
                ...notification,
                is_followed_by: true,
                is_following: false,
                is_following_requested: false,
                is_read: true,
              });
              onUnreadCountChange?.(!is_read ? -1 : 0);
              try {
                await notificationService.acceptFollowRequest(reqId);
                // Update global follow store
                useFollowStore.getState().setFollowState(sender, {
                  isFollowing: true,
                  isRequested: false,
                });
              } catch (err) {
                // Rollback
                onUpdateNotification?.(originalNotification);
                onUnreadCountChange?.(!is_read ? 1 : 0);
                console.error("Accept failed", err);
              } finally {
                setLoading(false);
              }
            }}
            onReject={async (reqId) => {
              if (!reqId) {
                console.error("No request_id for reject");
                return;
              }
              setLoading(true);
              // Optimistically remove the notification
              onRemoveNotification?.(id);
              if (!is_read) onUnreadCountChange?.(-1);
              try {
                await notificationService.rejectFollowRequest(reqId);
                // Update global store – request is gone
                useFollowStore.getState().setFollowState(sender, {
                  isRequested: false,
                });
              } catch (err) {
                // Rollback: add notification back
                onUpdateNotification?.(notification);
                if (!is_read) onUnreadCountChange?.(1);
                console.error("Reject failed", err);
              } finally {
                setLoading(false);
              }
            }}
          />
        )}

        {/* Follow Type Notification – uses global follow hook */}
        {notification_type === "follow" && (
          <div onClick={(e) => e.stopPropagation()}>
            <button
              onClick={toggleFollow}
              disabled={followLoading}
              className={`
                px-3 py-1.5 text-sm font-medium rounded-lg transition
                ${isFollowing
                  ? "bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 hover:bg-gray-300 dark:hover:bg-gray-600"
                  : isFollowingRequested
                    ? "bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 hover:bg-gray-300"
                    : "bg-primary text-white hover:bg-primary-light"
                }
                disabled:opacity-50
              `}
            >
              {isFollowing
                ? "Following"
                : isFollowingRequested
                  ? "Requested"
                  : "Follow"}
            </button>
          </div>
        )}

        {/* Thumbnail for posts */}
        {showThumbnail && (
          <img
            src={thumbnailUrl}
            alt=""
            className="w-10 h-10 md:w-12 md:h-12 rounded-lg object-cover border border-border dark:border-border-dark"
          />
        )}
      </div>
    </motion.div>
  );
};

export default React.memo(NotificationCard);