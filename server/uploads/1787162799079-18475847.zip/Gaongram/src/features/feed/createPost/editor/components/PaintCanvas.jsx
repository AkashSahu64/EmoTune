import React, {
  useRef,
  useEffect,
  useCallback,
  forwardRef,
  useImperativeHandle,
} from "react";

import { useCanvasHistory } from "../../../../../hooks/useCanvasHistory";

import {
  hitTestShape,
  drawShape,
  getShapeBounds,
} from "../../../../../utils/shapeUtils";

const PaintCanvas = forwardRef(function PaintCanvas(
  {
    imageSrc,
    filters = { brightness: 100, contrast: 100, saturation: 100 },
    brushColor = "#ff0000",
    brushSize = 8,
    paintTool = "draw",
    fillColor = null,
    lineDash = [],
    opacity = 1,
    selectedShapeId,
    setSelectedShapeId,
    shapeProperties,
    // current shape props for drawing
  },
  ref
) {
  const canvasRef = useRef(null);
  const bgCanvas = useRef(document.createElement("canvas"));
  const paintCanvas = useRef(document.createElement("canvas"));
  const shapesCanvas = useRef(document.createElement("canvas"));
  const previewCanvas = useRef(document.createElement("canvas"));

  const isDrawing = useRef(false);
  const lastPoint = useRef(null);
  const startPoint = useRef(null);
  const shapes = useRef([]);               // vector shapes array
  const selectedShape = useRef(null);     // currently selected shape object

  const { push, undo, redo, clear: clearHistory } = useCanvasHistory();

  // Expose undo/redo to parent
  useImperativeHandle(ref, () => ({
    undo: () => undo(applyState),

    redo: () => redo(applyState),

    clearHistory,

    exportImage: () => {

      redrawShapesCanvas();

      redrawComposite();

      const exportCanvas =
        document.createElement("canvas");

      exportCanvas.width =
        canvasRef.current.width;

      exportCanvas.height =
        canvasRef.current.height;

      const exportCtx =
        exportCanvas.getContext("2d");

      exportCtx.drawImage(
        bgCanvas.current,
        0,
        0
      );

      exportCtx.drawImage(
        paintCanvas.current,
        0,
        0
      );

      exportCtx.drawImage(
        shapesCanvas.current,
        0,
        0
      );

      return exportCanvas.toDataURL(
        "image/png"
      );
    },
  }));

  // ─── Apply state (raster + vectors) ─────────────────────
  const applyState = useCallback((paintData, newShapes) => {
    const w = canvasRef.current.width;
    const h = canvasRef.current.height;
    if (!paintData) {
      paintCanvas.current.getContext("2d").clearRect(0, 0, w, h);
    } else {
      paintCanvas.current.getContext("2d").putImageData(paintData, 0, 0);
    }
    shapes.current =
      JSON.parse(
        JSON.stringify(newShapes || [])
      );
    redrawShapesCanvas();
    redrawComposite();
  }, []);

  // ─── Initialise layers when image loads ────────────────
  useEffect(() => {

    const img = new Image();

    img.crossOrigin = "anonymous";

    img.src = imageSrc;

    img.onload = () => {

      const w = img.naturalWidth;

      const h = img.naturalHeight;

      [
        bgCanvas.current,
        paintCanvas.current,
        shapesCanvas.current,
        previewCanvas.current,
        canvasRef.current,
      ].forEach((c) => {

        if (c) {

          c.width = w;

          c.height = h;

        }

      });

      const bgCtx =
        bgCanvas.current.getContext("2d");

      bgCtx.clearRect(0, 0, w, h);

      bgCtx.filter = `
      brightness(${filters.brightness}%)
      contrast(${filters.contrast}%)
      saturate(${filters.saturation}%)
    `;

      bgCtx.drawImage(img, 0, 0);

      bgCtx.filter = "none";

      redrawComposite();

    };

  }, [imageSrc]);
  useEffect(() => {

    const img = new Image();

    img.crossOrigin = "anonymous";

    img.src = imageSrc;

    img.onload = () => {

      const bgCtx =
        bgCanvas.current.getContext("2d");

      bgCtx.clearRect(
        0,
        0,
        bgCanvas.current.width,
        bgCanvas.current.height
      );

      bgCtx.filter = `
      brightness(${filters.brightness}%)
      contrast(${filters.contrast}%)
      saturate(${filters.saturation}%)
    `;

      bgCtx.drawImage(img, 0, 0);

      bgCtx.filter = "none";

      redrawComposite();

    };

  }, [filters]);

  // ─── Composite all layers ──────────────────────────────
  const redrawComposite = useCallback(() => {
    const compCtx = canvasRef.current?.getContext("2d");
    if (!compCtx) return;
    compCtx.clearRect(0, 0, compCtx.canvas.width, compCtx.canvas.height);
    compCtx.drawImage(bgCanvas.current, 0, 0);
    compCtx.drawImage(paintCanvas.current, 0, 0);
    compCtx.drawImage(shapesCanvas.current, 0, 0);
    compCtx.drawImage(previewCanvas.current, 0, 0);
  }, []);

  const redrawShapesCanvas = useCallback(() => {
    const ctx = shapesCanvas.current.getContext("2d");
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    shapes.current.forEach((shape) => {

      ctx.save();

      ctx.globalAlpha =
        shape.opacity ?? 1;

      drawShape(ctx, shape);

      ctx.restore();

    });
    // Highlight selected shape
    if (selectedShape.current) {
      const b = getShapeBounds(selectedShape.current);
      ctx.save();
      ctx.strokeStyle = "#00BFFF";
      ctx.lineWidth = 2;
      ctx.setLineDash([4, 2]);
      ctx.strokeRect(b.x, b.y, b.w, b.h);
      ctx.restore();
    }
    redrawComposite();
  }, [redrawComposite]);

  // ─── Coordinate helper ─────────────────────────────────
  const getCanvasPoint = (e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    return {
      x: ((e.touches ? e.touches[0].clientX : e.clientX) - rect.left) * (canvasRef.current.width / rect.width),
      y: ((e.touches ? e.touches[0].clientY : e.clientY) - rect.top) * (canvasRef.current.height / rect.height),
    };
  };

  const drawRasterLine = (
    ctx,
    from,
    to,
    width,
    color,
    compositeOp = "source-over",
    options = {}
  ) => {

    ctx.save();

    ctx.globalCompositeOperation =
      compositeOp;

    ctx.globalAlpha =
      options.opacity ?? 1;

    ctx.lineWidth = width;

    ctx.lineCap = "round";

    ctx.lineJoin = "round";

    ctx.strokeStyle = color;

    if (options.glow) {

      ctx.shadowColor = color;

      ctx.shadowBlur =
        options.shadowBlur || width * 2;

    }

    if (options.soft) {

      ctx.shadowColor = color;

      ctx.shadowBlur =
        options.shadowBlur || width * 1.5;

    }

    if (options.lineDash) {

      ctx.setLineDash(options.lineDash);

    }

    ctx.beginPath();

    ctx.moveTo(from.x, from.y);

    ctx.lineTo(to.x, to.y);

    ctx.stroke();

    ctx.restore();

  };

  // ─── Pointer events ────────────────────────────────────
  const handlePointerDown = (e) => {
    e.preventDefault();
    const point = getCanvasPoint(e);
    isDrawing.current = true;
    startPoint.current = { ...point };
    lastPoint.current = { ...point };

    // If a shape is selected and we click inside it, start move
    if (selectedShape.current && hitTestShape(selectedShape.current, point)) {
      // Will implement move on mousemove
      return;
    }

    // Deselect if clicking outside
    if (selectedShape.current && !hitTestShape(selectedShape.current, point)) {
      selectedShape.current = null;
      setSelectedShapeId?.(null);
      redrawShapesCanvas();
      return;
    }

    // For shape tools, start preview
    if (
      [
        "line",
        "arrow",
        "dashed",
        "dot",
        "rect",
        "circle",
        "triangle",
        "hexagon",
      ].includes(paintTool)
    ) {
      previewCanvas.current.getContext("2d").clearRect(0, 0, previewCanvas.current.width, previewCanvas.current.height);
    }
  };

  const handlePointerMove = (e) => {
    if (!isDrawing.current) return;
    e.preventDefault();
    const point = getCanvasPoint(e);
    const paintCtx = paintCanvas.current.getContext("2d");
    const bgCtx = bgCanvas.current.getContext("2d");
    const previewCtx = previewCanvas.current.getContext("2d");

    // If moving a selected shape
    if (selectedShape.current && startPoint.current) {
      const dx = point.x - startPoint.current.x;
      const dy = point.y - startPoint.current.y;
      selectedShape.current.start.x += dx;
      selectedShape.current.start.y += dy;
      selectedShape.current.end.x += dx;
      selectedShape.current.end.y += dy;
      startPoint.current = point;
      redrawShapesCanvas();
      return;
    }

    switch (paintTool) {
      case "draw":

        drawRasterLine(
          paintCtx,
          lastPoint.current,
          point,
          brushSize,
          brushColor,
          "source-over",
          {
            opacity,
          }
        );

        lastPoint.current = { ...point };

        redrawComposite();

        break;
      case "paint":

        drawRasterLine(
          paintCtx,
          lastPoint.current,
          point,
          brushSize,
          brushColor,
          "source-over",
          {
            opacity,
          }
        );

        lastPoint.current = { ...point };

        redrawComposite();

        break;
      case "soft":

        drawRasterLine(
          paintCtx,
          lastPoint.current,
          point,
          brushSize,
          brushColor,
          "source-over",
          {
            opacity,
            soft: true,
            shadowBlur: brushSize * 5
          }
        );

        lastPoint.current = { ...point };

        redrawComposite();

        break;
      case "watercolor":

        for (let i = 0; i < 8; i++) {

          drawRasterLine(
            paintCtx,

            {
              x:
                lastPoint.current.x +
                (Math.random() - 0.5) *
                brushSize,

              y:
                lastPoint.current.y +
                (Math.random() - 0.5) *
                brushSize,
            },

            {
              x:
                point.x +
                (Math.random() - 0.5) *
                brushSize,

              y:
                point.y +
                (Math.random() - 0.5) *
                brushSize,
            },

            brushSize,

            brushColor,

            "source-over",

            {
              opacity:
                opacity * 0.45,

              glow: true,

              shadowBlur:
                brushSize,
            }
          );

        }

        lastPoint.current = { ...point };

        redrawComposite();

        break;
      case "eraser":
        drawRasterLine(paintCtx, lastPoint.current, point, brushSize, "#fff", "destination-out");
        lastPoint.current = { ...point };
        redrawComposite();
        break;
      case "blur":
        bgCtx.save();
        bgCtx.filter = `blur(${brushSize / 2}px)`;
        bgCtx.beginPath();
        bgCtx.arc(point.x, point.y, brushSize, 0, 2 * Math.PI);
        bgCtx.clip();
        bgCtx.drawImage(bgCanvas.current, 0, 0);
        bgCtx.filter = "none";
        bgCtx.restore();
        redrawComposite();
        break;
      case "pixel":
        const s = brushSize * 2;
        const x = Math.max(0, point.x - s / 2);
        const y = Math.max(0, point.y - s / 2);
        const w = Math.min(s, bgCanvas.current.width - x);
        const h = Math.min(s, bgCanvas.current.height - y);
        if (w > 0 && h > 0) {
          const imgData = bgCtx.getImageData(x, y, w, h);
          const temp = document.createElement("canvas");
          temp.width = w; temp.height = h;
          temp.getContext("2d").putImageData(imgData, 0, 0);
          bgCtx.save();
          bgCtx.imageSmoothingEnabled = false;
          bgCtx.drawImage(temp, 0, 0, w / Math.max(1, Math.floor(s / 5)), h / Math.max(1, Math.floor(s / 5)), x, y, w, h);
          bgCtx.restore();
          redrawComposite();
        }
        break;
      case "glow":
        drawRasterLine(paintCtx, lastPoint.current, point, brushSize, brushColor, "source-over", { glow: true });
        lastPoint.current = { ...point };
        redrawComposite();
        break;
      case "neon":
        drawRasterLine(paintCtx, lastPoint.current, point, brushSize * 2, brushColor, "source-over", { glow: true });
        lastPoint.current = { ...point };
        redrawComposite();
        break;
      case "marker":
        drawRasterLine(paintCtx, lastPoint.current, point, brushSize * 2, brushColor, "source-over", { glow: false });
        lastPoint.current = { ...point };
        redrawComposite();
        break;
      case "spray":
        // Simple spray: draw random dots around point
        paintCtx.save();
        paintCtx.fillStyle = brushColor;
        for (let i = 0; i < 20; i++) {
          const rad = brushSize * Math.random();
          const ang = Math.random() * 2 * Math.PI;
          paintCtx.fillRect(point.x + rad * Math.cos(ang), point.y + rad * Math.sin(ang), 1, 1);
        }
        paintCtx.restore();
        lastPoint.current = { ...point };
        redrawComposite();
        break;
      case "mosaic":
        // Pixelate larger blocks
        const bs = brushSize;
        const mx = Math.floor(point.x / bs) * bs;
        const my = Math.floor(point.y / bs) * bs;
        if (mx + bs <= bgCanvas.current.width && my + bs <= bgCanvas.current.height) {
          const mosaicData = bgCtx.getImageData(mx, my, bs, bs);
          const avgR = mosaicData.data.reduce((a, v, i) => i % 4 === 0 ? a + v : a, 0) / (bs * bs);
          const avgG = mosaicData.data.reduce((a, v, i) => i % 4 === 1 ? a + v : a, 0) / (bs * bs);
          const avgB = mosaicData.data.reduce((a, v, i) => i % 4 === 2 ? a + v : a, 0) / (bs * bs);
          bgCtx.fillStyle = `rgb(${avgR},${avgG},${avgB})`;
          bgCtx.fillRect(mx, my, bs, bs);
          redrawComposite();
        }
        break;
      case "smudge":
        // Not perfectly implemented; for now, copy a small area and paste offset
        if (lastPoint.current) {
          const dx = point.x - lastPoint.current.x;
          const dy = point.y - lastPoint.current.y;
          const imgData = bgCtx.getImageData(point.x - brushSize / 2, point.y - brushSize / 2, brushSize, brushSize);
          bgCtx.putImageData(imgData, point.x - brushSize / 2 + dx, point.y - brushSize / 2 + dy);
          redrawComposite();
        }
        lastPoint.current = { ...point };
        break;
      // Shape previews
      default:
        previewCtx.clearRect(0, 0, previewCanvas.current.width, previewCanvas.current.height);
        const shape = {
          type: paintTool,
          start: { ...startPoint.current },
          end: point,
          strokeColor: brushColor,
          strokeWidth: brushSize,
          fillColor: fillColor,
          opacity,
          lineDash:
            paintTool === "dashed"
              ? [20, 10]
              : [],

        };
        drawShape(previewCtx, shape);
        redrawComposite();
        break;
    }
  };

  const handlePointerUp = (e) => {
    if (!isDrawing.current) return;
    e.preventDefault();
    isDrawing.current = false;

    // If we were moving a shape
    if (selectedShape.current && startPoint.current) {
      pushHistory();
      startPoint.current = null;
      return;
    }

    // If drawing a shape, finalise it
    if (["line", "arrow", "dashed", "dot", "rect", "circle", "triangle", "hexagon"].includes(paintTool)) {
      const newShape = {
        id: Date.now().toString(36) + Math.random().toString(36),
        type: paintTool,
        start: { ...startPoint.current },
        end: getCanvasPoint(e),
        strokeColor: brushColor,
        strokeWidth: brushSize,
        fillColor: fillColor,
        opacity,
        lineDash:
          paintTool === "dashed"
            ? [20, 10]
            : [],

      };
      shapes.current.push(newShape);
      previewCanvas.current.getContext("2d").clearRect(0, 0, previewCanvas.current.width, previewCanvas.current.height);
      redrawShapesCanvas();
      pushHistory();
    } else {
      pushHistory(); // raster stroke
    }
  };

  const pushHistory = () => {
    const w = canvasRef.current.width;
    const h = canvasRef.current.height;
    const paintData = paintCanvas.current.getContext("2d").getImageData(0, 0, w, h);
    push(paintData, shapes.current);
  };

  // Shape selection on click (separate from drawing)
  const handleCanvasClick = (e) => {
    if (isDrawing.current) return;
    const point = getCanvasPoint(e);
    // Find shape under cursor
    const hit = shapes.current.find(s => hitTestShape(s, point));
    if (hit) {
      selectedShape.current = hit;
      setSelectedShapeId?.(hit.id);
    } else {
      selectedShape.current = null;
      setSelectedShapeId?.(null);
    }
    redrawShapesCanvas();
  };

  // Attach events
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.addEventListener("mousedown", handlePointerDown);
    canvas.addEventListener("mousemove", handlePointerMove);
    canvas.addEventListener("mouseup", handlePointerUp);
    canvas.addEventListener("mouseleave", handlePointerUp);
    canvas.addEventListener("click", handleCanvasClick);
    canvas.addEventListener("touchstart", handlePointerDown, { passive: false });
    canvas.addEventListener("touchmove", handlePointerMove, { passive: false });
    canvas.addEventListener("touchend", handlePointerUp);
    canvas.addEventListener("touchcancel", handlePointerUp);

    return () => {
      canvas.removeEventListener("mousedown", handlePointerDown);
      canvas.removeEventListener("mousemove", handlePointerMove);
      canvas.removeEventListener("mouseup", handlePointerUp);
      canvas.removeEventListener("mouseleave", handlePointerUp);
      canvas.removeEventListener("click", handleCanvasClick);
      canvas.removeEventListener("touchstart", handlePointerDown);
      canvas.removeEventListener("touchmove", handlePointerMove);
      canvas.removeEventListener("touchend", handlePointerUp);
      canvas.removeEventListener("touchcancel", handlePointerUp);
    };
  }, [paintTool, brushColor, brushSize, fillColor, lineDash, opacity, filters]);

  return (
    <canvas
      ref={canvasRef}
      style={{
        width: "100%",
        height: "100%",
        objectFit: "contain",
        touchAction: "none",
        cursor: "crosshair",
      }}
    />
  );
});

export default PaintCanvas;