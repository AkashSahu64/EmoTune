export { default } from "../../story/editor/tools/TextTool.jsx";
