// src/utils/AudioManager.js
class chatAudioManager {
  constructor() {
    this.currentAudio = null;
  }

  play(audioElement) {
    if (this.currentAudio && this.currentAudio !== audioElement) {
      this.currentAudio.pause();
      this.currentAudio.currentTime = 0;
    }
    this.currentAudio = audioElement;
    audioElement.play();
  }

  pause() {
    if (this.currentAudio) {
      this.currentAudio.pause();
      this.currentAudio = null;
    }
  }
}

export const audioManager = new chatAudioManager();