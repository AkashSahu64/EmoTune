// hooks/useInteractionTracker.js
import { useEffect, useRef, useCallback } from "react";
import { interactionService } from "../services/interaction.service.js";

const DEBUG = true;
// const log = (...args) => {
//   if (DEBUG) console.log("[USE_INTERACTION_TRACKER]:", ...args);
// };

export const useInteractionTracker = ({
  postId,
  isVisible,
  mediaType,
  mediaRef,         // must be a stable ref object (useRef), not a callback
  duration = 0,      // fallback if element.duration is unavailable
}) => {
  const visibilityStartTimeRef = useRef(null);
  const dwellTimeRef = useRef(0);
  const totalWatchTimeRef = useRef(0);
  const interactionFinalizedRef = useRef(false);
  const mediaElementRef = useRef(null);

  // Sync the passed ref into our internal ref (avoids stale closures)
  useEffect(() => {
    mediaElementRef.current = mediaRef?.current ?? null;
  }, [mediaRef]);

  const finalizeAndSendInteraction = useCallback(() => {
    if (interactionFinalizedRef.current) return;
    if (!postId) return;

    interactionFinalizedRef.current = true;

    const dwellTime = dwellTimeRef.current;
    const watchTime = Math.max(totalWatchTimeRef.current, 0);
    const el = mediaElementRef.current;
    const actualDuration = el && !isNaN(el.duration) && el.duration > 0
      ? el.duration
      : duration;

    const completionPercent =
      actualDuration > 0
        ? `${Math.min(100, Math.round((watchTime / actualDuration) * 100))}%`
        : "0%";

    const interaction = {
      post: postId,
      interaction_type: "view",
      dwell_time: Math.round(dwellTime),
      watch_time: Math.round(watchTime),
      completion_percent:
        mediaType === "video" || mediaType === "audio" ? completionPercent : "0%",
    };

    // log("finalize interaction", interaction);
    // log("  watch_time:", watchTime, "duration:", actualDuration, "completion:", completionPercent);
    interactionService.trackInteraction(interaction);
  }, [postId, duration, mediaType]);

  // Dwell time tracking (visibility)
  useEffect(() => {
    if (!postId) return;

    if (isVisible) {
      visibilityStartTimeRef.current = Date.now();
      interactionFinalizedRef.current = false;
      // log(`post ${postId} visible – start dwell timer`);
    } else {
      if (visibilityStartTimeRef.current) {
        const elapsed = (Date.now() - visibilityStartTimeRef.current) / 1000;
        dwellTimeRef.current += elapsed;
        visibilityStartTimeRef.current = null;
        // log(`post ${postId} hidden – dwell accumulated: ${dwellTimeRef.current.toFixed(2)}s`);
      }
      if (dwellTimeRef.current > 0) {
        finalizeAndSendInteraction();
      }
    }

    return () => {
      if (visibilityStartTimeRef.current) {
        const elapsed = (Date.now() - visibilityStartTimeRef.current) / 1000;
        dwellTimeRef.current += elapsed;
        visibilityStartTimeRef.current = null;
      }
    };
  }, [isVisible, postId, finalizeAndSendInteraction]);

  // Media watch time tracking (timeupdate)
  useEffect(() => {
    const el = mediaElementRef.current;
    if (!el || (mediaType !== "video" && mediaType !== "audio")) return;

    const handleTimeUpdate = () => {
      totalWatchTimeRef.current = el.currentTime;
    //   log(`timeupdate – watch_time: ${totalWatchTimeRef.current.toFixed(2)}s`);
    };

    el.addEventListener("timeupdate", handleTimeUpdate);
    return () => {
      el.removeEventListener("timeupdate", handleTimeUpdate);
    };
  }, [mediaType, postId]);

  // Unmount finalization
  useEffect(() => {
    return () => {
      if (visibilityStartTimeRef.current) {
        const elapsed = (Date.now() - visibilityStartTimeRef.current) / 1000;
        dwellTimeRef.current += elapsed;
      }
      // Ensure final interaction is sent if not already sent
      if (dwellTimeRef.current > 0 && !interactionFinalizedRef.current) {
        finalizeAndSendInteraction();
      }
    };
  }, [finalizeAndSendInteraction, postId]);
};