import { useEffect, useRef, useState, useCallback } from 'react';
import { mediaController } from '../media/MediaController.js';
import { useMediaStore } from '../store/mediaStore.js';
import { ensureAudioElement } from '../utils/audioManager.js';

const sameId = (a, b) => String(a ?? '') === String(b ?? '');

export const useGlobalMedia = (mediaId, mediaType, src) => {
  const elementRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [progress, setProgress] = useState({ current: 0, duration: 0 });
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);

  const {
    isMuted: globalMuted,
    userInteracted,
    setUserInteracted: setGlobalUserInteracted,
  } = useMediaStore();

  useEffect(() => {
    if (!mediaId) return undefined;

    const audio = ensureAudioElement(mediaId, src, mediaType);
    if (!audio) return undefined;

    elementRef.current = audio;
    setIsPlaying(!audio.paused);
    setIsMuted(audio.muted);
    setIsLoading(audio.readyState < 2);
    setHasError(false);
    setProgress({
      current: audio.currentTime || 0,
      duration: audio.duration || 0,
    });

    const handleTimeUpdate = () => {
      setProgress({
        current: audio.currentTime || 0,
        duration: audio.duration || 0,
      });
    };
    const handleLoadStart = () => setIsLoading(true);
    const handleCanPlay = () => setIsLoading(false);
    const handleLoadedMetadata = () => {
      setProgress({
        current: audio.currentTime || 0,
        duration: audio.duration || 0,
      });
    };
    const handleError = () => {
      setHasError(true);
      setIsLoading(false);
    };

    const handlePlay = ({ mediaId: playedId }) => {
      if (sameId(playedId, mediaId)) {
        setIsPlaying(true);
        setHasError(false);
      }
    };
    const handlePause = ({ mediaId: pausedId }) => {
      if (sameId(pausedId, mediaId)) {
        setIsPlaying(false);
      }
    };
    const handleStop = ({ mediaId: stoppedId }) => {
      if (sameId(stoppedId, mediaId)) {
        setIsPlaying(false);
        setProgress((prev) => ({ ...prev, current: 0 }));
      }
    };
    const handleMute = ({ mediaId: mutedId, muted }) => {
      if (sameId(mutedId, mediaId)) setIsMuted(muted);
    };
    const handleGlobalMute = (muted) => setIsMuted(muted);
    const handleMediaError = ({ mediaId: errorId }) => {
      if (sameId(errorId, mediaId)) {
        setHasError(true);
        setIsLoading(false);
      }
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadstart', handleLoadStart);
    audio.addEventListener('canplay', handleCanPlay);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('error', handleError);

    mediaController.on('play', handlePlay);
    mediaController.on('pause', handlePause);
    mediaController.on('mediaPlay', handlePlay);
    mediaController.on('mediaPause', handlePause);
    mediaController.on('stop', handleStop);
    mediaController.on('mute', handleMute);
    mediaController.on('globalMute', handleGlobalMute);
    mediaController.on('mediaError', handleMediaError);

    audio.muted = globalMuted || !userInteracted;
    setIsMuted(audio.muted);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadstart', handleLoadStart);
      audio.removeEventListener('canplay', handleCanPlay);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('error', handleError);

      mediaController.off('play', handlePlay);
      mediaController.off('pause', handlePause);
      mediaController.off('mediaPlay', handlePlay);
      mediaController.off('mediaPause', handlePause);
      mediaController.off('stop', handleStop);
      mediaController.off('mute', handleMute);
      mediaController.off('globalMute', handleGlobalMute);
      mediaController.off('mediaError', handleMediaError);
    };
  }, [mediaId, mediaType, src, globalMuted, userInteracted]);

  useEffect(() => {
    if (elementRef.current && mediaId) {
      elementRef.current.muted = globalMuted || !userInteracted;
      setIsMuted(elementRef.current.muted);
    }
  }, [globalMuted, userInteracted, mediaId]);

  const play = useCallback(async () => {
    setGlobalUserInteracted();
    await mediaController.play(mediaId, { manual: true });
  }, [mediaId, setGlobalUserInteracted]);

  const pause = useCallback(() => {
    mediaController.pause(mediaId);
  }, [mediaId]);

  const togglePlay = useCallback(async () => {
    if (isPlaying) pause();
    else await play();
  }, [isPlaying, play, pause]);

  const seek = useCallback((time) => {
    mediaController.seek(mediaId, time);
  }, [mediaId]);

  const toggleMute = useCallback(() => {
    setGlobalUserInteracted();
    mediaController.toggleMediaMute(mediaId);
  }, [mediaId, setGlobalUserInteracted]);

  const skipForward = useCallback((seconds = 5) => {
    mediaController.skipForward(mediaId, seconds);
  }, [mediaId]);

  const skipBackward = useCallback((seconds = 5) => {
    mediaController.skipBackward(mediaId, seconds);
  }, [mediaId]);

  const setVolume = useCallback((volume) => {
    if (elementRef.current) {
      elementRef.current.volume = Math.max(0, Math.min(1, volume));
    }
  }, []);

  const handleProgressClick = useCallback((e) => {
    if (!progress.duration || hasError) return;
    const rect = e.currentTarget.getBoundingClientRect();
    seek(((e.clientX - rect.left) / rect.width) * progress.duration);
  }, [progress.duration, seek, hasError]);

  const formatTime = useCallback((seconds) => {
    if (!seconds || isNaN(seconds)) return '0:00';
    const minutes = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  }, []);

  const progressPercentage =
    progress.duration > 0 ? (progress.current / progress.duration) * 100 : 0;

  return {
    elementRef,
    isPlaying,
    isMuted,
    progress,
    isLoading,
    hasError,
    play,
    pause,
    togglePlay,
    seek,
    toggleMute,
    skipForward,
    skipBackward,
    setVolume,
    handleProgressClick,
    mediaId,
    mediaType,
    formatTime,
    progressPercentage,
  };
};
