import { EDITOR_CONFIGS, EDITOR_MODES } from "../core/editorConfig.js";

export const storyEditorConfig = {
  ...EDITOR_CONFIGS[EDITOR_MODES.story],
  aspectRatios: ["free", "1:1", "4:5", "16:9", "9:16"],
  video: {
    allowCanvasFilters: false,
    allowOverlayCanvas: true,
    allowMusic: true,
    allowText: true,
    allowStickers: true,
    allowDrawing: true,
  },
};

export default storyEditorConfig;
