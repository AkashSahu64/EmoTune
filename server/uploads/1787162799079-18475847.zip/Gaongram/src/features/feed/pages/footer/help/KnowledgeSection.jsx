// src/components/help/KnowledgeSection.jsx
import React from 'react';
import { motion } from 'framer-motion';
import { helpArticles } from './helpData';

// This component would render the full knowledge base content structured into sections.
// We can group articles by category and display as expandable sections or static content.
// For brevity, I'll show a simplified version that lists all articles under category headings.

const KnowledgeSection = () => {
  const grouped = helpArticles.reduce((acc, article) => {
    if (!acc[article.category]) acc[article.category] = [];
    acc[article.category].push(article);
    return acc;
  }, {});

  return (
    <div className="mt-20 space-y-16">
      {Object.entries(grouped).map(([catId, articles]) => (
        <motion.section
          key={catId}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, margin: '-100px' }}
        >
          <h2 className="text-2xl font-bold text-foreground dark:text-foreground-dark mb-6 capitalize">
            {catId} Support
          </h2>
          <div className="space-y-6">
            {articles.map(article => (
              <div key={article.id} className="border-b border-border dark:border-border-dark pb-4">
                <h3 className="font-semibold text-lg mb-2">{article.question}</h3>
                <p className="text-mutedForeground whitespace-pre-line">{article.answer}</p>
              </div>
            ))}
          </div>
        </motion.section>
      ))}
    </div>
  );
};

export default KnowledgeSection;