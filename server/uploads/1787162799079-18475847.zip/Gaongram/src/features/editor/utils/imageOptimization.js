import imageCompression from "browser-image-compression";

export const optimizeImageFile = async (
  file,
  {
    maxSizeMB = 2,
    maxWidthOrHeight = 1920,
    initialQuality = 0.9,
    useWebWorker = true,
  } = {},
) => {
  if (!file?.type?.startsWith("image/")) return file;
  return imageCompression(file, {
    maxSizeMB,
    maxWidthOrHeight,
    initialQuality,
    useWebWorker,
    alwaysKeepResolution: false,
  });
};

export const createImageBitmapSafe = async (blob) => {
  if ("createImageBitmap" in window) {
    return createImageBitmap(blob);
  }
  return null;
};
