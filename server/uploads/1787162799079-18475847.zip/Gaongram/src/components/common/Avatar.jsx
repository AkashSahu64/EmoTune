import React from "react";
import { motion } from "framer-motion";
import defaultAvatar from "../../assets/default-avatar.png"; // Ensure you have a default avatar image at this path

const Avatar = ({
  src,
  alt = "Avatar",
  size = "medium",
  className = "",
  onClick,
  showStatus = false,
  status = "offline",
  isStory = false,
  borderColor = "instagram-pink",
  fallbackText,
  ...rest
}) => {
  // Sizes
  const sizes = {
    xs: "w-6 h-6",
    sm: "w-8 h-8",
    medium: "w-10 h-10",
    large: "w-14 h-14",
    xl: "w-20 h-20",
    "2xl": "w-28 h-28",
  };

  // Status colors
  const statusColors = {
    online: "bg-green-500",
    offline: "bg-gray-400",
    away: "bg-yellow-500",
    busy: "bg-red-500",
  };

  const baseClasses = "rounded-full object-cover flex-shrink-0";
  const sizeClass = sizes[size] || sizes.medium;
  const borderClass = isStory ? `border-1 border-${borderColor}` : "";

  // ✅ Helper to validate src
  const isValid = (val) => {
    return (
      val &&
      typeof val === "string" &&
      val.trim() !== "" &&
      val !== "null" &&
      val !== "undefined"
    );
  };

  // ✅ Random avatar (final fallback)
  const randomAvatar = `https://api.dicebear.com/7.x/initials/svg?seed=${
    alt || "User"
  }`;

  // ✅ Final source selection
  const finalSrc = isValid(src)
    ? src
    : isValid(defaultAvatar)
      ? defaultAvatar
      : randomAvatar;

  return (
    <motion.div
      className="relative inline-block"
      whileHover={{ scale: onClick ? 1.05 : 1 }}
      onClick={onClick}
      style={{ cursor: onClick ? "pointer" : "default" }}
    >
      {/* Avatar Image */}
      <img
        src={finalSrc}
        alt={alt}
        loading="lazy"
        referrerPolicy="no-referrer"
        className={`${baseClasses} ${sizeClass} ${borderClass} ${className}`}
        onError={(e) => {
          e.currentTarget.src = randomAvatar;
        }}
      />

      {/* Status Indicator */}
      {showStatus && (
        <span
          className={`absolute bottom-0 right-0 w-3 h-3 ${
            statusColors[status]
          } border-2 border-white rounded-full`}
        />
      )}
    </motion.div>
  );
};

export default Avatar;
