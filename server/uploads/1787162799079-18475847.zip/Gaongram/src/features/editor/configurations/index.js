export { default as storyEditorConfig } from "./story.config.js";
export { default as postEditorConfig } from "./post.config.js";
export { default as profileEditorConfig } from "./profile.config.js";
