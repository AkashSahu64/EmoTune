import api from '../../lib/axios';

export const hashtagsApi = {
  // Get trending hashtags
  getTrending: (params) => api.get('/api/hashtags/trending', { params }),
  
  // Search hashtags
  search: (query) => api.get('/api/hashtags/search', { params: { q: query } }),
  
  // Get hashtag details
  getHashtag: (tag) => api.get(`/api/hashtags/${tag}`),
  
  // Get posts by hashtag
  getPostsByHashtag: (tag, params) => api.get(`/api/hashtags/${tag}/posts`, { params }),
  
  // Get tracks by hashtag
  getTracksByHashtag: (tag, params) => api.get(`/api/hashtags/${tag}/tracks`, { params }),
  
  // Follow hashtag
  followHashtag: (tag) => api.post(`/api/hashtags/${tag}/follow`),
  
  // Unfollow hashtag
  unfollowHashtag: (tag) => api.delete(`/api/hashtags/${tag}/follow`),
  
  // Get followed hashtags
  getFollowed: () => api.get('/api/hashtags/followed'),
  
  // Get hashtag suggestions
  getSuggestions: () => api.get('/api/hashtags/suggestions'),
  
  // Get hashtag analytics (for business accounts)
  getAnalytics: (tag) => api.get(`/api/hashtags/${tag}/analytics`),
  
  // Get hashtag stats
  getStats: (tag) => api.get(`/api/hashtags/${tag}/stats`)
};

// Hook-friendly functions
export const getTrendingHashtags = async ({ queryKey }) => {
  const [, params] = queryKey;
  const response = await hashtagsApi.getTrending(params);
  return response.data;
};

export const searchHashtags = async ({ queryKey }) => {
  const [, query] = queryKey;
  const response = await hashtagsApi.search(query);
  return response.data;
};

export const getHashtag = async ({ queryKey }) => {
  const [, tag] = queryKey;
  const response = await hashtagsApi.getHashtag(tag);
  return response.data;
};

export const getPostsByHashtag = async ({ queryKey }) => {
  const [, tag, params] = queryKey;
  const response = await hashtagsApi.getPostsByHashtag(tag, params);
  return response.data;
};

export const getTracksByHashtag = async ({ queryKey }) => {
  const [, tag, params] = queryKey;
  const response = await hashtagsApi.getTracksByHashtag(tag, params);
  return response.data;
};

export const followHashtag = async (tag) => {
  const response = await hashtagsApi.followHashtag(tag);
  return response.data;
};

export const unfollowHashtag = async (tag) => {
  const response = await hashtagsApi.unfollowHashtag(tag);
  return response.data;
};

export const getFollowedHashtags = async () => {
  const response = await hashtagsApi.getFollowed();
  return response.data;
};

export const getHashtagSuggestions = async () => {
  const response = await hashtagsApi.getSuggestions();
  return response.data;
};

export const getHashtagAnalytics = async ({ queryKey }) => {
  const [, tag] = queryKey;
  const response = await hashtagsApi.getAnalytics(tag);
  return response.data;
};

export const getHashtagStats = async ({ queryKey }) => {
  const [, tag] = queryKey;
  const response = await hashtagsApi.getStats(tag);
  return response.data;
};

// Helper functions for hashtag processing
export const extractHashtags = (text) => {
  if (!text) return [];
  const hashtagRegex = /#([\w가-힣]+)/g;
  const matches = text.match(hashtagRegex);
  return matches ? matches.map(tag => tag.substring(1)) : [];
};

export const formatHashtag = (tag) => {
  return `#${tag.replace(/\s+/g, '')}`;
};

export const isValidHashtag = (tag) => {
  const trimmed = tag.trim();
  if (!trimmed) return false;
  if (trimmed.length > 30) return false;
  const regex = /^[\w가-힣]+$/;
  return regex.test(trimmed);
};

// Hashtag categories for organization
export const HASHTAG_CATEGORIES = {
  GENRE: [
    'kpop', 'hiphop', 'rnb', 'ballad', 'rock', 'electronic',
    'indie', 'trot', 'ost', 'jazz', 'classical'
  ],
  MOOD: [
    'chill', 'energetic', 'romantic', 'sad', 'happy',
    'nostalgic', 'motivational', 'relaxing'
  ],
  ACTIVITY: [
    'workout', 'study', 'party', 'driving', 'travel',
    'work', 'sleep', 'meditation'
  ],
  LANGUAGE: [
    'korean', 'english', 'japanese', 'chinese',
    'spanish', 'instrumental'
  ],
  ERA: [
    'oldschool', 'newschool', '90s', '2000s', '2010s',
    '2020s', 'retro', 'modern'
  ]
};

// Trending algorithm constants
export const TRENDING_PARAMS = {
  WEIGHTS: {
    RECENCY: 0.35,
    ENGAGEMENT: 0.40,
    VELOCITY: 0.25
  },
  TIME_WINDOWS: {
    HOURLY: '1h',
    DAILY: '24h',
    WEEKLY: '7d',
    MONTHLY: '30d'
  }
};