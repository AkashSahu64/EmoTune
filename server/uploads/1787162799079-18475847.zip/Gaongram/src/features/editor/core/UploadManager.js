export class UploadManager {
  constructor({ retries = 2, chunkSize = 5 * 1024 * 1024 } = {}) {
    this.retries = retries;
    this.chunkSize = chunkSize;
  }

  async runWithRetry(task, { onRetry } = {}) {
    let lastError;
    for (let attempt = 0; attempt <= this.retries; attempt += 1) {
      try {
        return await task(attempt);
      } catch (error) {
        lastError = error;
        if (attempt >= this.retries) break;
        onRetry?.(attempt + 1, error);
        await new Promise((resolve) => window.setTimeout(resolve, 400 * (attempt + 1)));
      }
    }
    throw lastError;
  }

  createChunks(file) {
    if (!file || file.size <= this.chunkSize) return [file].filter(Boolean);
    const chunks = [];
    for (let start = 0; start < file.size; start += this.chunkSize) {
      chunks.push(file.slice(start, Math.min(start + this.chunkSize, file.size), file.type));
    }
    return chunks;
  }
}

export default UploadManager;
