// components/vibe/VibeFooter.jsx
import React from "react";
import PostActionButtons from "../../../components/common/PostActionButtons.jsx";

const VibeFooter = ({
  post,
  isOwner,
  isPoll,
  isAudio,
  onUpdate,
}) => {
  return (
    <div className="px-4 py-2">
      <PostActionButtons
        postId={post.id}
        post={post}
        postType="vibe"
        isLiked={post.is_liked}
        likeCount={post.likes_count || 0}
        commentCount={post.comments_count || 0}
        viewCount={post.views_count || 0}
        pollVotes={post.poll?.total_votes || 0}
        isOwner={isOwner}
        isPoll={isPoll}
        isAudio={isAudio}
        shareUrl={`/post/${post.id}`}
        shareTitle={`Post by @${post.user?.username || "gaongram"}`}
        shareText={post.caption || "Check this post on GaonGram"}
        size="medium"
        onUpdate={(updates) => onUpdate?.(post.id, updates)}
        showViewCount={false}
        showPollStats={isPoll}
        showCommentsCount={true}
        className="mb-1"
      />
    </div>
  );
};

export default VibeFooter;
