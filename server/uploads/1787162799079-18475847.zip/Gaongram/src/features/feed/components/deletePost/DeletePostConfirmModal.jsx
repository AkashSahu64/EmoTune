// src/features/feed/deletePost/DeletePostConfirmModal.jsx
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, X } from 'lucide-react';
import { useUIStore } from '../../../../store/uiStore.js';
import { postEditService } from '../../../../services/postEdit.service.js';
import { showSuccess, showError } from '../../../../utils/toast.js';
import { FEED_EVENTS, publishFeedEvent } from '../../../../utils/feedEvents.js';
import Button from '../../../../components/common/Button.jsx';

const DeletePostConfirmModal = ({ postId, postTitle = 'this post' }) => {
  const { closeModal } = useUIStore();
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      await postEditService.deletePost(postId);
      showSuccess('Post deleted successfully');
      closeModal();
      publishFeedEvent({ type: FEED_EVENTS.DELETED, postId });
    } catch (error) {
      showError('Failed to delete post. Please try again.');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
      className="relative bg-white dark:bg-gray-900 rounded-2xl shadow-xl w-full max-w-md mx-auto overflow-hidden"
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Delete Post</h2>
        <button
          onClick={closeModal}
          className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition"
        >
          <X className="w-5 h-5 text-gray-500 dark:text-gray-400" />
        </button>
      </div>

      {/* Body */}
      <div className="p-6 text-center">
        <div className="mx-auto w-16 h-16 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center mb-4">
          <AlertTriangle className="w-8 h-8 text-red-600 dark:text-red-400" />
        </div>
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
          Are you absolutely sure?
        </h3>
        <p className="text-gray-500 dark:text-gray-400 text-sm mb-6">
          This action cannot be undone. This will permanently delete {postTitle} and remove it from our servers.
        </p>
        <div className="flex flex-col sm:flex-row gap-3">
          <Button
            variant="outline"
            fullWidth
            onClick={closeModal}
            disabled={isDeleting}
          >
            Cancel
          </Button>
          <Button
            variant="danger"
            fullWidth
            onClick={handleDelete}
            loading={isDeleting}
          >
            Delete
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

export default DeletePostConfirmModal;
