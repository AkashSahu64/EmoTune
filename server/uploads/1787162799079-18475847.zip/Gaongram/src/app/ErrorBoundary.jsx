import React from 'react';
import { 
  AlertTriangle, 
  RefreshCw, 
  Home, 
  FileText, 
  Code,
  XCircle,
  AlertCircle,
  Info,
  Copy,
  Check
} from 'lucide-react';
import Button from '../components/common/Button.jsx';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { 
      hasError: false, 
      error: null, 
      errorInfo: null,
      copied: false,
      showDetails: false 
    };
    this.errorDetailsRef = React.createRef();
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({
      error: error,
      errorInfo: errorInfo,
    });
    
    // Log error to console for debugging
    console.error('=== ERROR BOUNDARY CAUGHT ===');
    console.error('Error:', error);
    console.error('Error Name:', error.name);
    console.error('Error Message:', error.message);
    console.error('Error Stack:', error.stack);
    console.error('Component Stack:', errorInfo.componentStack);
    console.error('===========================');
    
    // Send to error tracking service (if available)
    this.reportErrorToService(error, errorInfo);
  }

  reportErrorToService = (error, errorInfo) => {
    // Example: Send to your error tracking service
    if (window.Sentry) {
      window.Sentry.captureException(error);
    }
    
    // Or send to your API endpoint
    try {
      const errorData = {
        error: {
          name: error.name,
          message: error.message,
          stack: error.stack,
          url: window.location.href,
          userAgent: navigator.userAgent,
          timestamp: new Date().toISOString(),
        },
        componentStack: errorInfo.componentStack,
      };
      
      // Uncomment to send to your backend
      // fetch('/api/log-error', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify(errorData),
      // });
    } catch (e) {
      console.warn('Failed to report error:', e);
    }
  };

  handleRefresh = () => {
    // Clear any cached data that might be causing the error
    localStorage.removeItem('error-retry-count');
    sessionStorage.removeItem('error-retry-count');
    window.location.reload();
  };

  handleGoHome = () => {
    window.location.href = '/';
  };

  copyErrorDetails = () => {
    const errorDetails = this.getFormattedErrorDetails();
    navigator.clipboard.writeText(errorDetails)
      .then(() => {
        this.setState({ copied: true });
        setTimeout(() => this.setState({ copied: false }), 2000);
      })
      .catch(err => {
        console.error('Failed to copy:', err);
      });
  };

  getFormattedErrorDetails = () => {
    const { error, errorInfo } = this.state;
    
    let details = `=== ERROR DETAILS ===\n`;
    details += `URL: ${window.location.href}\n`;
    details += `Timestamp: ${new Date().toLocaleString()}\n`;
    details += `User Agent: ${navigator.userAgent}\n\n`;
    
    if (error) {
      details += `ERROR NAME: ${error.name}\n`;
      details += `ERROR MESSAGE: ${error.message}\n\n`;
      details += `ERROR STACK:\n${error.stack || 'No stack trace available'}\n\n`;
    }
    
    if (errorInfo && errorInfo.componentStack) {
      details += `COMPONENT STACK:\n${errorInfo.componentStack}\n`;
    }
    
    return details;
  };

  getErrorSeverity = () => {
    const { error } = this.state;
    if (!error) return 'unknown';
    
    const errorName = error.name || '';
    const errorMessage = error.message || '';
    
    if (errorName.includes('Network') || errorMessage.includes('network') || errorMessage.includes('fetch')) {
      return 'network';
    }
    if (errorName.includes('Type') || errorName.includes('Syntax')) {
      return 'syntax';
    }
    if (errorName.includes('Range') || errorName.includes('Reference')) {
      return 'runtime';
    }
    if (errorMessage.includes('loading') || errorMessage.includes('chunk')) {
      return 'chunk';
    }
    
    return 'unknown';
  };

  getErrorRecommendation = () => {
    const severity = this.getErrorSeverity();
    const recommendations = {
      network: [
        'Check your internet connection',
        'The server might be temporarily unavailable',
        'Try refreshing the page'
      ],
      syntax: [
        'There might be a bug in the code',
        'Try clearing your browser cache',
        'Try accessing in incognito mode'
      ],
      runtime: [
        'An unexpected error occurred',
        'Try refreshing the page',
        'Clear browser cache and cookies'
      ],
      chunk: [
        'The application failed to load properly',
        'Try clearing browser cache',
        'Try a hard refresh (Ctrl + F5)'
      ],
      unknown: [
        'An unexpected error occurred',
        'Try refreshing the page',
        'Clear browser cache and cookies'
      ]
    };
    
    return recommendations[severity] || recommendations.unknown;
  };

  getErrorIcon = () => {
    const severity = this.getErrorSeverity();
    const icons = {
      network: <XCircle className="w-10 h-10 text-orange-500" />,
      syntax: <Code className="w-10 h-10 text-red-500" />,
      runtime: <AlertCircle className="w-10 h-10 text-yellow-500" />,
      chunk: <FileText className="w-10 h-10 text-blue-500" />,
      unknown: <AlertTriangle className="w-10 h-10 text-red-500" />
    };
    
    return icons[severity] || icons.unknown;
  };

  getErrorTitle = () => {
    const severity = this.getErrorSeverity();
    const titles = {
      network: 'Network Error',
      syntax: 'Syntax Error',
      runtime: 'Runtime Error',
      chunk: 'Loading Error',
      unknown: 'Something Went Wrong'
    };
    
    return titles[severity] || titles.unknown;
  };

  toggleDetails = () => {
    this.setState(prevState => ({ showDetails: !prevState.showDetails }));
  };

  renderErrorDetails = () => {
    const { error, errorInfo } = this.state;
    
    if (!error && !errorInfo) {
      return <p className="text-gray-600">No additional error details available.</p>;
    }

    return (
      <div className="space-y-4">
        {/* Basic Error Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <h4 className="font-semibold text-gray-700">Error Type</h4>
            <div className="p-3 bg-gray-50 rounded-lg">
              <code className="text-red-600 font-mono">{error?.name || 'Unknown Error'}</code>
            </div>
          </div>
          
          <div className="space-y-2">
            <h4 className="font-semibold text-gray-700">Location</h4>
            <div className="p-3 bg-gray-50 rounded-lg">
              <code className="text-blue-600 font-mono text-sm break-all">
                {window.location.href}
              </code>
            </div>
          </div>
        </div>

        {/* Error Message */}
        <div className="space-y-2">
          <h4 className="font-semibold text-gray-700">Error Message</h4>
          <div className="p-3 bg-red-50 rounded-lg border border-red-100">
            <p className="text-red-700 font-mono whitespace-pre-wrap break-words">
              {error?.message || 'No error message available'}
            </p>
          </div>
        </div>

        {/* Stack Traces */}
        <div className="space-y-4">
          {error?.stack && (
            <div className="space-y-2">
              <h4 className="font-semibold text-gray-700">JavaScript Stack Trace</h4>
              <div className="p-3 bg-gray-800 rounded-lg overflow-auto max-h-60">
                <pre className="text-gray-200 text-xs font-mono whitespace-pre-wrap">
                  {error.stack}
                </pre>
              </div>
            </div>
          )}

          {errorInfo?.componentStack && (
            <div className="space-y-2">
              <h4 className="font-semibold text-gray-700">React Component Stack</h4>
              <div className="p-3 bg-gray-800 rounded-lg overflow-auto max-h-60">
                <pre className="text-gray-200 text-xs font-mono whitespace-pre-wrap">
                  {errorInfo.componentStack}
                </pre>
              </div>
            </div>
          )}
        </div>

        {/* Browser & Environment Info */}
        <div className="p-3 bg-blue-50 rounded-lg border border-blue-100">
          <h4 className="font-semibold text-blue-700 mb-2">Environment Details</h4>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <span className="text-gray-600">Browser:</span>
              <span className="ml-2 font-medium">{navigator.userAgent.split(' ')[0]}</span>
            </div>
            <div>
              <span className="text-gray-600">Platform:</span>
              <span className="ml-2 font-medium">{navigator.platform}</span>
            </div>
            <div>
              <span className="text-gray-600">Online:</span>
              <span className={`ml-2 font-medium ${navigator.onLine ? 'text-green-600' : 'text-red-600'}`}>
                {navigator.onLine ? 'Yes' : 'No'}
              </span>
            </div>
            <div>
              <span className="text-gray-600">Time:</span>
              <span className="ml-2 font-medium">{new Date().toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  render() {
    if (this.state.hasError) {
      const { copied, showDetails } = this.state;
      const recommendations = this.getErrorRecommendation();
      const errorTitle = this.getErrorTitle();
      
      return (
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex items-center justify-center p-4">
          <div className="max-w-4xl w-full bg-white rounded-2xl shadow-xl overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-red-50 to-orange-50 p-6 border-b">
              <div className="flex items-center space-x-4">
                <div className="flex-shrink-0">
                  {this.getErrorIcon()}
                </div>
                <div className="flex-1">
                  <h1 className="text-2xl font-bold text-gray-900 mb-1">
                    {errorTitle}
                  </h1>
                  <p className="text-gray-600">
                    We're sorry for the inconvenience. Here's what you can do next.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-6 md:p-8">
              {/* Error Summary */}
              <div className="mb-8 p-4 bg-yellow-50 border border-yellow-100 rounded-lg">
                <div className="flex items-start">
                  <Info className="w-5 h-5 text-yellow-600 mt-0.5 mr-3 flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold text-yellow-800 mb-2">What happened?</h3>
                    <p className="text-yellow-700">
                      {this.state.error?.message || 'An unexpected error occurred while rendering this page.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Recommended Actions */}
              <div className="mb-8">
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                  <AlertCircle className="w-5 h-5 mr-2 text-blue-500" />
                  Recommended Actions
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {recommendations.map((action, index) => (
                    <div 
                      key={index} 
                      className="p-4 bg-blue-50 rounded-lg border border-blue-100 hover:bg-blue-100 transition-colors"
                    >
                      <div className="flex items-center">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-3">
                          <span className="text-blue-600 font-semibold">{index + 1}</span>
                        </div>
                        <p className="text-blue-800">{action}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quick Actions */}
              <div className="mb-8">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Fixes</h3>
                <div className="flex flex-wrap gap-3">
                  <Button
                    variant="primary"
                    onClick={this.handleRefresh}
                    startIcon={<RefreshCw className="w-4 h-4" />}
                    className="flex-1 min-w-[200px]"
                  >
                    Refresh Page
                  </Button>
                  
                  <Button
                    variant="outline"
                    onClick={this.handleGoHome}
                    startIcon={<Home className="w-4 h-4" />}
                    className="flex-1 min-w-[200px]"
                  >
                    Go to Homepage
                  </Button>
                  
                  <Button
                    variant="secondary"
                    onClick={this.copyErrorDetails}
                    startIcon={copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    className="flex-1 min-w-[200px]"
                  >
                    {copied ? 'Copied!' : 'Copy Error Details'}
                  </Button>
                </div>
              </div>

              {/* Error Details Toggle */}
              <div className="mb-6">
                <button
                  onClick={this.toggleDetails}
                  className="flex items-center justify-between w-full p-4 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <div className="flex items-center">
                    <FileText className="w-5 h-5 mr-3 text-gray-600" />
                    <span className="font-semibold text-gray-900">
                      {showDetails ? 'Hide Technical Details' : 'Show Technical Details'}
                    </span>
                  </div>
                  <svg 
                    className={`w-5 h-5 text-gray-500 transform transition-transform ${showDetails ? 'rotate-180' : ''}`}
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </div>

              {/* Detailed Error Information */}
              {showDetails && (
                <div 
                  ref={this.errorDetailsRef}
                  className="mt-6 p-6 bg-gray-50 rounded-xl border border-gray-200"
                >
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                      <Code className="w-5 h-5 mr-2 text-gray-600" />
                      Technical Error Details
                    </h3>
                    <button
                      onClick={this.copyErrorDetails}
                      className="flex items-center text-sm text-blue-600 hover:text-blue-800"
                    >
                      {copied ? (
                        <>
                          <Check className="w-4 h-4 mr-1" />
                          Copied
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-1" />
                          Copy All
                        </>
                      )}
                    </button>
                  </div>
                  
                  {this.renderErrorDetails()}
                  
                  {/* Note for developers */}
                  <div className="mt-6 p-3 bg-purple-50 rounded-lg border border-purple-100">
                    <div className="flex items-start">
                      <Info className="w-5 h-5 text-purple-600 mt-0.5 mr-2 flex-shrink-0" />
                      <div>
                        <p className="text-sm text-purple-800">
                          <strong>For Developers:</strong> This information can help debug the issue. 
                          Include these details when reporting the bug.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Support Section */}
              <div className="mt-8 pt-6 border-t">
                <div className="flex flex-col md:flex-row justify-between items-center">
                  <div className="mb-4 md:mb-0">
                    <h4 className="font-semibold text-gray-900 mb-2">Need More Help?</h4>
                    <p className="text-gray-600 text-sm">
                      Our support team is ready to assist you with this issue.
                    </p>
                  </div>
                  <div className="flex space-x-3">
                    <Button
                      variant="ghost"
                      onClick={() => window.open('mailto:support@gaongram.com', '_blank')}
                      className="whitespace-nowrap"
                    >
                      Email Support
                    </Button>
                    <Button
                      variant="ghost"
                      onClick={() => window.open('https://status.gaongram.com', '_blank')}
                      className="whitespace-nowrap"
                    >
                      System Status
                    </Button>
                  </div>
                </div>
                
                {/* Retry Counter */}
                <div className="mt-4 text-center">
                  <p className="text-xs text-gray-500">
                    If you continue experiencing issues, try clearing your browser cache or 
                    <button 
                      onClick={() => window.open('https://gaongram.com/help/troubleshooting', '_blank')}
                      className="text-blue-600 hover:text-blue-800 ml-1"
                    >
                      visit our troubleshooting guide
                    </button>
                  </p>
                </div>
              </div>
            </div>
            
            {/* Footer */}
            <div className="bg-gray-50 px-6 py-4 border-t">
              <div className="flex justify-between items-center text-xs text-gray-500">
                <span>Error ID: {Math.random().toString(36).substr(2, 9).toUpperCase()}</span>
                <span>GaonGram v{import.meta.env.VITE_APP_VERSION || '1.0.0'}</span>
              </div>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

// Higher Order Component for easy usage
export const withErrorBoundary = (Component) => {
  return (props) => (
    <ErrorBoundary>
      <Component {...props} />
    </ErrorBoundary>
  );
};

export default ErrorBoundary;