import { useNavigate } from 'react-router-dom';

export const useStoryNavigation = (stories, currentIndex) => {
  const navigate = useNavigate();

  const goToNext = () => {
    if (currentIndex < stories.length - 1) {
      navigate(`/story/${stories[currentIndex + 1].id}`, { replace: true });
    } else {
      navigate(-1); // close viewer
    }
  };

  const goToPrevious = () => {
    if (currentIndex > 0) {
      navigate(`/story/${stories[currentIndex - 1].id}`, { replace: true });
    } else {
      navigate(-1);
    }
  };

  return { goToNext, goToPrevious };
};