import React, { useRef, useState } from "react";
import { Image, ImagePlus, RefreshCw, Trash2, Upload, Video } from "lucide-react";
import { selectActiveLayer, useCanvasStore } from "../useCanvasStore.js";

const MAX_IMAGE_SIZE = 20 * 1024 * 1024;
const MAX_VIDEO_SIZE = 100 * 1024 * 1024;

const MediaTool = ({ engine }) => {
  const fileInputRef = useRef(null);
  const imageInputRef = useRef(null);
  const videoInputRef = useRef(null);
  const replaceInputRef = useRef(null);
  const activeLayer = useCanvasStore(selectActiveLayer);
  const removeLayer = useCanvasStore((state) => state.removeLayer);
  const [error, setError] = useState("");

  const validateFile = (file, expectedType = "media") => {
    if (!file) return false;
    const isImage = file.type.startsWith("image/");
    const isVideo = file.type.startsWith("video/");
    if (!isImage && !isVideo) {
      setError("Only image and video files allowed.");
      return false;
    }
    if (expectedType === "image" && !isImage) {
      setError("Please choose an image file.");
      return false;
    }
    if (expectedType === "video" && !isVideo) {
      setError("Please choose a video file.");
      return false;
    }
    if (file.size > (isVideo ? MAX_VIDEO_SIZE : MAX_IMAGE_SIZE)) {
      setError(`Max size: ${isVideo ? "100MB" : "20MB"}.`);
      return false;
    }
    setError("");
    return true;
  };

  const addMediaFile = async (file) => {
    if (file.type.startsWith("video/")) {
      await engine?.addVideoLayer({
        file,
        name: file.name || "Video",
        type: "media",
        source: "upload",
      });
      return;
    }

    await engine?.addImageLayer({
      file,
      name: file.name || "Media",
      type: "media",
      source: "upload",
    });
  };

  const handleAdd = async (event, expectedType = "media") => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!validateFile(file, expectedType)) return;
    await addMediaFile(file);
  };

  const handleReplace = async (event) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!activeLayer || !validateFile(file)) return;

    if (file.type.startsWith("video/")) {
      await addMediaFile(file);
      removeLayer(activeLayer.id);
      return;
    }

    await engine?.replaceImageLayer(activeLayer.id, file);
  };

  const canReplace = activeLayer?.type === "media" || activeLayer?.type === "emoji";

  return (
    <div className="space-y-4">
      {error && (
        <div className="rounded-xl border border-red-400/30 bg-red-500/10 px-3 py-2 text-xs text-red-300">
          {error}
        </div>
      )}

      <div className="grid grid-cols-3 gap-2">
        <button
          type="button"
          onClick={() => imageInputRef.current?.click()}
          className="flex h-12 items-center justify-center gap-2 rounded-lg bg-muted text-sm font-semibold transition hover:bg-primary hover:text-white dark:bg-muted-dark"
        >
          <ImagePlus size={17} />
          Image
        </button>
        <button
          type="button"
          onClick={() => videoInputRef.current?.click()}
          className="flex h-12 items-center justify-center gap-2 rounded-lg bg-muted text-sm font-semibold transition hover:bg-primary hover:text-white dark:bg-muted-dark"
        >
          <Video size={17} />
          Video
        </button>
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="flex h-12 items-center justify-center gap-2 rounded-lg bg-primary text-sm font-semibold text-white shadow-lg transition hover:bg-primary-light"
        >
          <Upload size={17} />
          File
        </button>
      </div>

      <input ref={fileInputRef} type="file" accept="image/*,video/*" className="hidden" onChange={(event) => handleAdd(event)} />
      <input ref={imageInputRef} type="file" accept="image/*" className="hidden" onChange={(event) => handleAdd(event, "image")} />
      <input ref={videoInputRef} type="file" accept="video/*" className="hidden" onChange={(event) => handleAdd(event, "video")} />
      <input ref={replaceInputRef} type="file" accept="image/*,video/*" className="hidden" onChange={handleReplace} />

      <div className="flex items-center justify-center rounded-lg border border-dashed border-border bg-muted/40 p-4 text-center transition hover:border-primary dark:border-border-dark dark:bg-muted-dark/30">
        <button type="button" onClick={() => fileInputRef.current?.click()} className="flex flex-col items-center justify-center gap-2">
          <div className="flex h-11 w-11 items-center justify-center rounded-full bg-primary/10">
            <Upload size={18} className="text-primary" />
          </div>
          <p className="text-sm font-semibold">Upload overlay media</p>
          <p className="text-xs text-mutedForeground">PNG, JPG, WEBP, MP4 - max 100MB</p>
        </button>
      </div>

      <div className="rounded-lg border border-border bg-card px-4 py-2 dark:border-border-dark dark:bg-card-dark">
        <div className="mb-3 flex items-center gap-2">
          <Image size={16} className="text-primary" />
          <p className="text-sm font-semibold">Selected Layer</p>
        </div>

        {canReplace ? (
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => replaceInputRef.current?.click()}
              className="flex h-11 items-center justify-center gap-2 rounded-lg bg-muted text-sm font-medium transition hover:bg-primary hover:text-white dark:bg-muted-dark"
            >
              <RefreshCw size={16} />
              Replace
            </button>
            <button
              type="button"
              onClick={() => removeLayer(activeLayer.id)}
              className="flex h-11 items-center justify-center gap-2 rounded-lg bg-red-500/10 text-sm font-medium text-red-400 transition hover:bg-red-500 hover:text-white"
            >
              <Trash2 size={16} />
              Delete
            </button>
          </div>
        ) : (
          <div className="py-3 text-center text-xs text-mutedForeground">
            No media selected
            <br />
            <span className="text-[11px] opacity-70">Select a media layer to edit</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default React.memo(MediaTool);
