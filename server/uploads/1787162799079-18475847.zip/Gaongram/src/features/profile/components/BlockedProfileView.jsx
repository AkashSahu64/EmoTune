import React from "react";
import { motion as Motion } from "framer-motion";
import { Ban } from "lucide-react";
import Button from "../../../components/common/Button";

const BlockedProfileView = ({ username, onUnblock, isLoading }) => (
  <Motion.section
    initial={{ opacity: 0, y: 18 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.28, ease: "easeOut" }}
    className="mx-auto flex w-full max-w-xl flex-col items-center rounded-[32px] border border-border/70 bg-white/80 px-6 py-10 text-center shadow-[0_20px_60px_rgba(15,23,42,0.08)] backdrop-blur dark:border-white/10 dark:bg-[#111418]/80 dark:shadow-[0_20px_60px_rgba(0,0,0,0.28)] sm:px-10"
  >
    <Motion.div
      initial={{ scale: 0.94, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ delay: 0.08, duration: 0.22 }}
      className="flex h-14 w-14 items-center justify-center rounded-full border border-foreground/10 bg-muted/70 text-foreground dark:border-white/10 dark:bg-white/5"
    >
      <Ban className="h-6 w-6" strokeWidth={1.9} />
    </Motion.div>

    <h2 className="mt-5 text-[22px] font-semibold tracking-[-0.03em] text-foreground sm:text-2xl">
      You've blocked this profile
    </h2>

    <p className="mt-3 max-w-md text-sm leading-6 text-mutedForeground sm:text-[15px]">
      {username ? `@${username}` : "This account"} is blocked. Unblock this
      profile to view their posts, videos, audios, and message them again.
    </p>

    <Button
      onClick={onUnblock}
      loading={isLoading}
      variant="outline"
      className="mt-7 rounded-full border-border bg-white px-6 py-2.5 text-sm font-semibold text-foreground hover:bg-muted dark:bg-transparent dark:hover:bg-white/5"
    >
      Unblock Profile
    </Button>
  </Motion.section>
);

export default React.memo(BlockedProfileView);
