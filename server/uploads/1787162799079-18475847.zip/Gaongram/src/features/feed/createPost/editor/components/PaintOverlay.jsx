// src/features/feed/createPost/components/editor/components/PaintOverlay.jsx
import React from "react";
import { Undo2, Redo2, Brush, Minus, MoveRight, Square, Circle, Triangle, Hexagon, Eraser, Droplets, Grid2X2, Star, PenTool, Highlighter, SprayCan, Grid3X3, Blend } from "lucide-react";
import ToolButton from "./ToolButton";

const PaintOverlay = ({
  paintTool, setPaintTool,
  brushColor, setBrushColor,
  brushSize, setBrushSize,
  fillColor, setFillColor,
  lineDash, setLineDash,
  opacity, setOpacity,
  undoPaint, redoPaint,
}) => {
  const tools = [
    { id: "draw", icon: Brush, label: "Draw" },
    { id: "line", icon: Minus, label: "Line" },
    { id: "arrow", icon: MoveRight, label: "Arrow" },
    { id: "dashed", icon: Minus, label: "Dash" },
    { id: "dashdot", icon: Minus, label: "Dot-dash" },
    { id: "rect", icon: Square, label: "Rect" },
    { id: "circle", icon: Circle, label: "Circle" },
    { id: "triangle", icon: Triangle, label: "Tri" },
    { id: "hexagon", icon: Hexagon, label: "Hex" },
    { id: "eraser", icon: Eraser, label: "Erase" },
    { id: "blur", icon: Droplets, label: "Blur" },
    { id: "pixel", icon: Grid2X2, label: "Pixel" },
    { id: "glow", icon: Star, label: "Glow" },
    { id: "neon", icon: PenTool, label: "Neon" },
    { id: "marker", icon: Highlighter, label: "Marker" },
    { id: "spray", icon: SprayCan, label: "Spray" },
    { id: "mosaic", icon: Grid3X3, label: "Mosaic" },
    { id: "smudge", icon: Blend, label: "Smudge" },
  ];

  return (
    <div className="absolute inset-0 pointer-events-none">
      {/* Undo / Redo */}
      

      {/* Vertical Color Bar */}
      <div className="absolute right-2 top-10 bottom-10 flex flex-col items-center gap-2 pointer-events-auto">
        <div className="w-6 h-32 rounded-full bg-gradient-to-b from-red-500 via-yellow-500 via-green-500 via-blue-500 to-purple-500 relative cursor-pointer">
          <div
            className="absolute left-full ml-1 w-4 h-4 rounded-full border-2 border-white shadow"
            style={{ top: `${((1 - parseInt(brushColor.slice(1,3), 16) / 255) * 100) /* approximate */}%` }}
          />
          <input
            type="color"
            value={brushColor}
            onChange={(e) => setBrushColor(e.target.value)}
            className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
          />
        </div>
        {/* Recent colors (simplified) */}
        <div className="flex flex-col gap-1">
          {["#FF3B30","#FF9500","#FFCC00","#34C759","#007AFF","#AF52DE"].map(c => (
            <button key={c} className="w-5 h-5 rounded-full border" style={{ background: c }} onClick={() => setBrushColor(c)} />
          ))}
        </div>
        {/* Opacity slider */}
        <input
          type="range"
          min="0"
          max="1"
          step="0.05"
          value={opacity}
          onChange={(e) => setOpacity(Number(e.target.value))}
          className="w-20 -rotate-90 origin-center"
          style={{ marginTop: '80px' }}
        />
      </div>

      {/* Floating Toolbar at bottom */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1 bg-black/40 backdrop-blur rounded-full px-2 py-1.5 overflow-x-auto pointer-events-auto">
        {tools.slice(0, 8).map(tool => (
          <ToolButton
            key={tool.id}
            active={paintTool === tool.id}
            onClick={() => setPaintTool(tool.id)}
            icon={tool.icon}
            label={tool.label}
            small
          />
        ))}
      </div>
      {/* Second row for more tools */}
      <div className="absolute bottom-14 left-1/2 -translate-x-1/2 flex gap-1 bg-black/40 backdrop-blur rounded-full px-2 py-1.5 pointer-events-auto">
        {tools.slice(8).map(tool => (
          <ToolButton
            key={tool.id}
            active={paintTool === tool.id}
            onClick={() => setPaintTool(tool.id)}
            icon={tool.icon}
            label={tool.label}
            small
          />
        ))}
      </div>

      {/* Brush size */}
      <div className="absolute bottom-28 left-2 flex items-center gap-1 bg-black/40 backdrop-blur rounded-full px-3 py-1 pointer-events-auto">
        <input
          type="range"
          min={1}
          max={60}
          value={brushSize}
          onChange={(e) => setBrushSize(Number(e.target.value))}
          className="w-20 h-1 accent-white"
        />
        <span className="text-white text-xs w-6">{brushSize}px</span>
      </div>

      {/* Fill / Dash toggles (when shape tool active) */}
      {["rect","circle","triangle","hexagon","line","arrow","dashed","dashdot"].includes(paintTool) && (
        <div className="absolute bottom-3 right-2 flex gap-2 pointer-events-auto bg-black/40 backdrop-blur rounded-full px-3 py-1">
          <button
            onClick={() => setFillColor(fillColor ? null : "#ffffff")}
            className={`w-6 h-6 rounded border ${fillColor ? 'bg-white' : 'border-white'}`}
          />
          <select
            value={lineDash.join(',')}
            onChange={(e) => setLineDash(e.target.value ? e.target.value.split(',').map(Number) : [])}
            className="text-white bg-transparent text-xs"
          >
            <option value="">Solid</option>
            <option value="5,5">Dashed</option>
            <option value="10,5,2,5">Dot-dash</option>
          </select>
        </div>
      )}
    </div>
  );
};

export default PaintOverlay;