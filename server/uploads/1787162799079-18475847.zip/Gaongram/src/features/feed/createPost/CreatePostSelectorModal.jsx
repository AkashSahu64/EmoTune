import React from "react";
import { motion } from "framer-motion";
import {
  X,
  Image as ImageIcon,
  Video,
  Music,
  Type,
  BarChart3,
  ChevronRight,
  Sparkles,
} from "lucide-react";

import { useUIStore } from "../../../store/uiStore.js";

const postTypes = [
  {
    id: "image",
    label: "Image Post",
    desc: "Share photos and memories",
    icon: ImageIcon,
    color: "from-emerald-500 to-green-400",
  },
  {
    id: "video",
    label: "Video Post",
    desc: "Upload reels and clips",
    icon: Video,
    color: "from-rose-500 to-pink-400",
  },
  {
    id: "audio",
    label: "Audio Post",
    desc: "Share music and sounds",
    icon: Music,
    color: "from-violet-500 to-purple-400",
  },
  {
    id: "text",
    label: "Text Post",
    desc: "Write your thoughts",
    icon: Type,
    color: "from-sky-500 to-cyan-400",
  },
  {
    id: "poll",
    label: "Poll",
    desc: "Ask your audience",
    icon: BarChart3,
    color: "from-amber-500 to-orange-400",
  },
];

const CreatePostSelectorModal = () => {
  const { closeModal, openModal } = useUIStore();

  const handleSelect = (type) => {
    const modalMap = {
      image: "create-image-post",
      video: "create-video-post",
      audio: "create-audio-post",
      text: "create-text-post",
      poll: "create-poll-post",
    };

    closeModal();

    setTimeout(() => {
      openModal(modalMap[type]);
    }, 150);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 25, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 15 }}
      transition={{ duration: 0.25 }}
      className="w-full overflow-hidden rounded-xl border border-border dark:border-border-dark bg-card dark:bg-card-dark text-foreground dark:text-foreground-dark shadow-lg"
    >
      {/* Header */}
      <div
        className="relative overflow-hidden px-4 py-2 border-b border-border dark:border-border-dark"
      >
        <div
          className=" absolute inset-0 bg-muted dark:bg-muted-dark opacity-10"
        />

        <div className="relative flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Sparkles size={18} className="text-primary" />

              <h2 className="text-base font-semibold">Create Something</h2>
            </div>

            <p
              className="text-xs text-mutedForeground dark:text-mutedForeground-dark ml-7"
            >
              Share your moment with everyone
            </p>
          </div>

          <button
            onClick={closeModal}
            className="p-2 rounded-full hover:bg-muted dark:hover:bg-muted-dark transition"
          >
            <X size={20} />
          </button>
        </div>
      </div>

      {/* Body */}
      <div className="px-4 py-2 space-y-1">
        {postTypes.map((type, index) => {
          const Icon = type.icon;

          return (
            <motion.button
              key={type.id}
              onClick={() => handleSelect(type.id)}
              initial={{
                opacity: 0,
                y: 10,
              }}
              animate={{
                opacity: 1,
                y: 0,
              }}
              transition={{
                delay: index * 0.05,
              }}
              whileHover={{
                scale: 1.002,
              }}
              whileTap={{
                scale: 0.98,
              }}
              className="group w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl border border-border dark:border-border-dark hover:border-primary/30 hover:bg-muted/50 dark:hover:bg-muted-dark/50 transition-all"
            >
              <div className="flex items-center gap-4">
                <div
                  className={` w-10 h-10 rounded-xl bg-gradient-to-br ${type.color} flex items-center justify-center shadow-md`}
                >
                  <Icon size={22} className="text-white" />
                </div>

                <div className="text-left leading-tight">
                  <h3 className="text-base font-semibold">{type.label}</h3>

                  <p
                    className=" text-xs text-mutedForeground dark:text-mutedForeground-dark"
                  >
                    {type.desc}
                  </p>
                </div>
              </div>

              <ChevronRight
                size={18}
                className="
                  text-mutedForeground
                  group-hover:translate-x-0.5
                  transition-transform
                "
              />
            </motion.button>
          );
        })}
      </div>
    </motion.div>
  );
};

export default CreatePostSelectorModal;
