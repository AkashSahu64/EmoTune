import React from 'react';
import { motion } from 'framer-motion';
import { Upload, User, Camera as CameraIcon } from 'lucide-react';

const ImageSourceSelector = ({
  imagePreview,
  onFileSelect,
  onCameraSelect,
  config,
}) => {
  const isProfile = config.type === 'profile';

  return (
    <motion.div
      key="select"
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="space-y-8"
    >
      {/* Image Preview */}
      <div className="flex justify-center">
        <div
          className={`relative ${
            isProfile ? 'w-44 h-44 rounded-xl' : 'w-full h-36 rounded-xl'
          } overflow-hidden bg-gray-50 border border-gray-200 shadow-sm`}
        >
          {imagePreview ? (
            <img
              src={imagePreview}
              alt={`${config.type} preview`}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center text-gray-400">
              <User size={isProfile ? 80 : 50} />
              <span className="mt-2 text-sm">
                No {config.type} image
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Camera */}
        <motion.button
          whileHover={{ y: -2 }}
          whileTap={{ scale: 0.97 }}
          onClick={onCameraSelect}
          className="flex items-center gap-4 p-1 rounded-lg border border-gray-200 bg-white hover:border-gray-300 hover:shadow-md transition-all"
        >
          <div className="p-2 rounded-lg bg-gray-100 text-gray-700">
            <CameraIcon size={22} />
          </div>
          <div className="text-left">
            <p className="font-medium text-gray-800">
              Take Photo
            </p>
            <p className="text-sm text-gray-500">
              Use your device camera
            </p>
          </div>
        </motion.button>

        {/* Upload */}
        <motion.button
          whileHover={{ y: -2 }}
          whileTap={{ scale: 0.97 }}
          onClick={onFileSelect}
          className="flex items-center gap-4 p-1 rounded-lg border border-gray-200 bg-white hover:border-gray-300 hover:shadow-md transition-all"
        >
          <div className="p-2 rounded-lg bg-gray-100 text-gray-700">
            <Upload size={22} />
          </div>
          <div className="text-left">
            <p className="font-medium text-gray-800">
              Upload Photo
            </p>
            <p className="text-sm text-gray-500">
              Choose from your device
            </p>
          </div>
        </motion.button>
      </div>
    </motion.div>
  );
};

export default ImageSourceSelector;
