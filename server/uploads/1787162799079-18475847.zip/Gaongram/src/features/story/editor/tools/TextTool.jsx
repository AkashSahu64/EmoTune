// TextTool.jsx
import React, { useMemo } from "react";
import {
  AlignCenter,
  AlignLeft,
  AlignRight,
  AlignJustify,
  Bold,
  Italic,
  Sparkles,
  Type,
} from "lucide-react";
import { selectActiveLayer, useCanvasStore } from "../useCanvasStore.js";
import { getSliderBackground } from "../engine/helpers/math.js";

const FONT_OPTIONS = [
  "Inter",
  "Arial",
  "Georgia",
  "Impact",
  "Trebuchet MS",
  "Times New Roman",
  "Courier New",
];

const effectOptions = [
  { id: "none", label: "None" },
  { id: "shadow", label: "Shadow" },
  { id: "glow", label: "Glow" },
  { id: "neon", label: "Neon" },
];

const TextTool = ({ engine }) => {
  const activeLayer = useCanvasStore(selectActiveLayer);
  const updateLayer = useCanvasStore((state) => state.updateLayer);
  const isTextLayer = activeLayer?.type === "text";

  const style = useMemo(
    () => ({
      fontFamily: "Inter",
      fontSize: 48,
      fontWeight: "700",
      fontStyle: "normal",
      fill: "#ffffff",
      textAlign: "center",
      letterSpacing: 0,
      opacity: 1,
      effect: "shadow",
      glowColor: "#E1306C",
      gradient: {
        enabled: false,
        from: "#E1306C",
        to: "#F77737",
      },
      ...(activeLayer?.style || {}),
    }),
    [activeLayer],
  );

  const [liveValues, setLiveValues] = React.useState({
    fontSize: style.fontSize,
    opacity: style.opacity,
    letterSpacing: style.letterSpacing,
  });

  const prevLayerId = React.useRef(activeLayer?.id);

  React.useEffect(() => {
    if (prevLayerId.current !== activeLayer?.id) {
      setLiveValues({
        fontSize: style.fontSize,
        opacity: style.opacity,
        letterSpacing: style.letterSpacing,
      });

      prevLayerId.current = activeLayer?.id;
    }
  }, [activeLayer?.id, style]);

  const updateStyle = (patch, recordHistory = false) => {
    if (!activeLayer) return;
    updateLayer(
      activeLayer.id,
      {
        style: {
          ...style,
          ...patch,
          gradient: {
            ...style.gradient,
            ...(patch.gradient || {}),
          },
        },
      },
      { recordHistory },
    );
  };

  const handleAddText = () => {
    engine?.addTextLayer({
      fontFamily: style.fontFamily,
      fontSize: style.fontSize,
      fontWeight: style.fontWeight,
      fontStyle: style.fontStyle,
      fill: style.fill,
      textAlign: style.textAlign,
      opacity: style.opacity,
    });
  };

  return (
    <div className="space-y-1">
      <button
        type="button"
        onClick={handleAddText}
        className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary hover:bg-primary-light text-white px-3 py-2 text-md font-semibold shadow-lg transition mb-2"
      >
        <Type size={20} />
        Add text
      </button>

      {!isTextLayer ? (
        <div className="rounded-lg border border-border dark:border-border-dark bg-card dark:bg-card-dark p-4 text-sm text-mutedForeground dark:text-mutedForeground-dark">
          Select a text layer to edit typography, color, effects, and spacing.
        </div>
      ) : (
        <>
          <label className="block">
            <span className="text-xs font-semibold text-mutedForeground dark:text-mutedForeground-dark">
              Text
            </span>
            <textarea
              value={activeLayer.text || ""}
              onChange={(event) =>
                updateLayer(
                  activeLayer.id,
                  { text: event.target.value },
                  { recordHistory: false },
                )
              }
              onBlur={(event) =>
                updateLayer(activeLayer.id, { text: event.target.value })
              }
              rows={3}
              className="mt-0.5 w-full resize-none rounded-lg border border-border dark:border-border-dark bg-gray-100 dark:bg-muted-dark px-2 py-1 text-sm text-foreground dark:text-foreground-dark outline-none transition placeholder:text-mutedForeground dark:placeholder:text-mutedForeground-dark focus:border-primary"
            />
          </label>

          <div className="grid grid-cols-2 gap-3">
            <label className="block">
              <span className="text-xs font-semibold text-mutedForeground dark:text-mutedForeground-dark">
                Font
              </span>
              <select
                value={style.fontFamily}
                onChange={(event) =>
                  updateStyle({ fontFamily: event.target.value }, true)
                }
                className="mt-0.5 h-9 w-full rounded-lg border border-border dark:border-border-dark bg-gray-100 dark:bg-muted-dark px-2 text-sm text-foreground dark:text-foreground-dark outline-none"
              >
                {FONT_OPTIONS.map((font) => (
                  <option key={font} value={font}>
                    {font}
                  </option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="text-xs font-semibold text-mutedForeground dark:text-mutedForeground-dark">
                Weight
              </span>
              <select
                value={style.fontWeight}
                onChange={(event) =>
                  updateStyle({ fontWeight: event.target.value }, true)
                }
                className="mt-0.5 h-9 w-full rounded-lg border border-border dark:border-border-dark bg-gray-100 dark:bg-muted-dark px-2 text-sm text-foreground dark:text-foreground-dark outline-none"
              >
                <option value="400">Regular</option>
                <option value="600">Semi Bold</option>
                <option value="700">Bold</option>
                <option value="800">Extra Bold</option>
              </select>
            </label>
          </div>

          <div className="rounded-lg border border-border dark:border-border-dark bg-card dark:bg-card-dark px-3 py-1">
            <div className="flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() =>
                  updateStyle(
                    {
                      fontWeight: style.fontWeight === "800" ? "400" : "800",
                    },
                    true,
                  )
                }
                className={`flex h-10 w-10 items-center justify-center rounded-lg transition ${
                  style.fontWeight === "800"
                    ? "bg-primary text-white"
                    : "bg-gray-100 dark:bg-muted-dark text-foreground dark:text-foreground-dark hover:bg-border dark:hover:bg-border-dark"
                }`}
                aria-label="Toggle bold"
                title="Bold"
              >
                <Bold size={20} />
              </button>

              <button
                type="button"
                onClick={() =>
                  updateStyle(
                    {
                      fontStyle:
                        style.fontStyle === "italic" ? "normal" : "italic",
                    },
                    true,
                  )
                }
                className={`flex h-10 w-10 items-center justify-center rounded-lg transition ${
                  style.fontStyle === "italic"
                    ? "bg-primary text-white"
                    : "bg-gray-100 dark:bg-muted-dark text-foreground dark:text-foreground-dark hover:bg-border dark:hover:bg-border-dark"
                }`}
                aria-label="Toggle italic"
                title="Italic"
              >
                <Italic size={20} />
              </button>

              {/* 🔥 ALIGNMENT */}
              {["left", "center", "right", "justify"].map((align) => {
                const Icon =
                  align === "left"
                    ? AlignLeft
                    : align === "right"
                      ? AlignRight
                      : align === "center"
                        ? AlignCenter
                        : AlignJustify;

                return (
                  <button
                    key={align}
                    type="button"
                    onClick={() => updateStyle({ textAlign: align }, true)}
                    className={`flex h-10 w-10 items-center justify-center rounded-lg transition ${
                      style.textAlign === align
                        ? "bg-primary text-white"
                        : "bg-gray-100 dark:bg-muted-dark text-foreground dark:text-foreground-dark hover:bg-border dark:hover:bg-border-dark"
                    }`}
                    aria-label={`Align ${align}`}
                    title={`Align ${align}`}
                  >
                    <Icon size={20} />
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-evenly gap-3 rounded-lg border border-border dark:border-border-dark bg-card dark:bg-card-dark px-3 py-1">
            {/* 🎨 COLOR */}
            <div className="flex flex-col">
              <span className="text-[11px] font-semibold text-mutedForeground dark:text-mutedForeground-dark">
                Color
              </span>
              <input
                type="color"
                value={style.fill}
                onChange={(event) =>
                  updateStyle(
                    { fill: event.target.value, gradient: { enabled: false } },
                    false,
                  )
                }
                onBlur={(event) =>
                  updateStyle(
                    { fill: event.target.value, gradient: { enabled: false } },
                    true,
                  )
                }
                className="mt-1 h-9 w-10 rounded-md border border-border dark:border-border-dark bg-gray-100 dark:bg-muted-dark p-1 cursor-pointer"
              />
            </div>

            {/* ✨ GLOW */}
            <div className="flex flex-col">
              <span className="text-[11px] font-semibold text-mutedForeground dark:text-mutedForeground-dark">
                Glow
              </span>
              <input
                type="color"
                value={style.glowColor}
                onChange={(event) =>
                  updateStyle({ glowColor: event.target.value }, false)
                }
                onBlur={(event) =>
                  updateStyle({ glowColor: event.target.value }, true)
                }
                className="mt-1 h-9 w-10 rounded-md border border-border dark:border-border-dark bg-gray-100 dark:bg-muted-dark p-1 cursor-pointer"
              />
            </div>

            {/* 🌈 GRADIENT TOGGLE */}
            <div className="flex flex-col">
              {/* Toggle */}
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-semibold text-mutedForeground dark:text-mutedForeground-dark">
                  Gradient
                </span>
                <input
                  type="checkbox"
                  checked={style.gradient?.enabled || false}
                  onChange={(e) =>
                    updateStyle(
                      { gradient: { enabled: e.target.checked } },
                      true,
                    )
                  }
                  className="h-3 w-3 accent-viral-pink"
                />
              </div>

              {/* Colors (ALWAYS BELOW → no layout shift) */}
              <div className="flex gap-2 mt-1">
                <input
                  type="color"
                  value={style.gradient.from}
                  disabled={!style.gradient?.enabled}
                  onChange={(e) =>
                    updateStyle({ gradient: { from: e.target.value } }, false)
                  }
                  onBlur={(e) =>
                    updateStyle({ gradient: { from: e.target.value } }, true)
                  }
                  className="h-9 w-10 rounded-md border border-border dark:border-border-dark bg-gray-100 dark:bg-muted-dark p-1 disabled:opacity-40 cursor-pointer"
                />

                <input
                  type="color"
                  value={style.gradient.to}
                  disabled={!style.gradient?.enabled}
                  onChange={(e) =>
                    updateStyle({ gradient: { to: e.target.value } }, false)
                  }
                  onBlur={(e) =>
                    updateStyle({ gradient: { to: e.target.value } }, true)
                  }
                  className="h-9 w-10 rounded-md border border-border dark:border-border-dark bg-gray-100 dark:bg-muted-dark p-1 disabled:opacity-40 cursor-pointer"
                />
              </div>
            </div>

            {/* 🎭 EFFECT */}
            <div className="flex flex-col min-w-[110px]">
              <span className="text-[11px] font-semibold text-mutedForeground dark:text-mutedForeground-dark">
                Effect
              </span>
              <select
                value={style.effect}
                onChange={(event) =>
                  updateStyle(
                    {
                      effect: event.target.value,
                      shadow:
                        event.target.value === "shadow"
                          ? "rgba(0,0,0,0.42) 0 5px 16px"
                          : null,
                    },
                    true,
                  )
                }
                className="mt-1 h-9 rounded-md border border-border dark:border-border-dark bg-gray-100 dark:bg-muted-dark px-2 text-xs outline-none"
              >
                {effectOptions.map((effect) => (
                  <option key={effect.id} value={effect.id}>
                    {effect.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="rounded-lg border border-border dark:border-border-dark bg-card dark:bg-card-dark px-3 py-1 space-y-1">
            <label className="block">
              <div className="flex items-center justify-between -mb-2">
                <span className="text-xs font-medium text-mutedForeground dark:text-mutedForeground-dark">
                  Size
                </span>

                <span className="text-xs font-semibold text-mutedForeground dark:text-mutedForeground-dark">
                  {liveValues.fontSize}px
                </span>
              </div>

              <input
                type="range"
                min="18"
                max="132"
                value={liveValues.fontSize}
                onChange={(e) => {
                  const value = Number(e.target.value);
                  setLiveValues((prev) => ({ ...prev, fontSize: value }));
                }}
                onPointerUp={(e) => {
                  const value = Number(e.currentTarget.value);
                  updateStyle({ fontSize: value }, true);
                }}
                className="custom-range w-full"
                style={{
                  background: getSliderBackground(
                    liveValues.fontSize,
                    18,
                    132,
                    document.documentElement.classList.contains("dark"),
                  ),
                }}
              />
            </label>

            {/* 🌫 OPACITY */}
            <label className="block">
              <div className="flex items-center justify-between -mb-2">
                <span className="text-xs font-medium text-mutedForeground dark:text-mutedForeground-dark">
                  Opacity
                </span>

                <span className="text-xs font-semibold text-mutedForeground dark:text-mutedForeground-dark">
                  {Math.round(liveValues.opacity * 100)}%
                </span>
              </div>

              <input
                type="range"
                min="0.1"
                max="1"
                step="0.01"
                value={liveValues.opacity}
                onChange={(e) => {
                  const value = Number(e.target.value);
                  setLiveValues((prev) => ({ ...prev, opacity: value }));
                }}
                onPointerUp={(e) => {
                  const value = Number(e.currentTarget.value);
                  updateStyle({ opacity: value }, true);
                }}
                className="custom-range w-full"
                style={{
                  background: getSliderBackground(
                    liveValues.opacity,
                    0.1,
                    1,
                    document.documentElement.classList.contains("dark"),
                  ),
                }}
              />
            </label>

            <label className="block">
              <div className="flex items-center justify-between -mb-2">
                <span className="text-xs font-medium text-mutedForeground dark:text-mutedForeground-dark">
                  Letter spacing
                </span>

                <span className="text-xs font-semibold text-mutedForeground dark:text-mutedForeground-dark">
                  {liveValues.letterSpacing}
                </span>
              </div>

              <input
                type="range"
                min="-80"
                max="300"
                value={liveValues.letterSpacing}
                onChange={(e) => {
                  const value = Number(e.target.value);
                  setLiveValues((prev) => ({ ...prev, letterSpacing: value }));
                }}
                onPointerUp={(e) => {
                  const value = Number(e.currentTarget.value);
                  updateStyle({ letterSpacing: value }, true);
                }}
                className="custom-range w-full"
                style={{
                  background: getSliderBackground(
                    liveValues.letterSpacing,
                    -80,
                    300,
                    document.documentElement.classList.contains("dark"),
                  ),
                }}
              />
            </label>
          </div>
        </>
      )}
    </div>
  );
};

export default React.memo(TextTool);
