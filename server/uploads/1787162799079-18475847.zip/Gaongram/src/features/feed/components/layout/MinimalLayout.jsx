// src/layouts/MinimalLayout.jsx
import React from "react";
import AppFooter from "./AppFooter";

const MinimalLayout = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col">
      
      {/* Content */}
      <main className="flex-1">{children}</main>

      {/* Footer */}
      <AppFooter />
    </div>
  );
};

export default MinimalLayout;