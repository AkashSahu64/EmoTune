import { useUIStore } from '../store/uiStore.js';

export const showToast = (message, type = 'info', duration = 3000) => {
  const { addToast, removeToast } = useUIStore.getState();
  
  const id = Date.now();
  addToast({ id, message, type });
  
  setTimeout(() => {
    removeToast(id);
  }, duration);
  
  return id;
};

export const showSuccess = (message, duration = 3000) => {
  return showToast(message, 'success', duration);
};

export const showError = (message, duration = 3000) => {
  return showToast(message, 'error', duration);
};

export const showWarning = (message, duration = 3000) => {
  return showToast(message, 'warning', duration);
};

export const showInfo = (message, duration = 3000) => {
  return showToast(message, 'info', duration);
};