import { createObjectUrl } from "../helpers/dom.js";
import { transformFromObject } from "./TransformUtils.js";
import { DEFAULT_FILTERS } from "../../utils/filterPresets.js";

export class MediaLoader {
  constructor(engine) {
    this.engine = engine;
  }

  async loadBaseMedia(file, aspectRatio) {
    const { canvas, store, objectFactory } = this.engine;
    if (!file || !canvas || this.engine.isDisposed) return null;

    const isVideo = file.type.startsWith("video/");
    const sourceUrl = createObjectUrl(file);
    const layerId = store.getState().createLayerId("base");
    this.engine.sourceUrls.set(layerId, sourceUrl);

    try {
      const layer = {
        id: layerId,
        type: "base",
        mediaType: isVideo ? "video" : "image",
        name: file.name || "Base media",
        src: sourceUrl,
        originalName: file.name,
        originalType: file.type,
        locked: true,
        filters: { ...DEFAULT_FILTERS },
      };

      let object;
      if (isVideo) {
        object = await objectFactory.createVideoObject(sourceUrl, layerId);
      } else {
        object = await objectFactory.createImageObject(sourceUrl, layerId);
      }
      if (!object || !canvas || this.engine.isDisposed) return null;

      const canvasWidth = canvas.getWidth();
      const canvasHeight = canvas.getHeight();
      const objWidth = object.width || canvasWidth;
      const objHeight = object.height || canvasHeight;
      const scale = Math.min(canvasWidth / objWidth, canvasHeight / objHeight);

      object.set({
        left: canvasWidth / 2,
        top: canvasHeight / 2,
        originX: "center",
        originY: "center",
        scaleX: scale,
        scaleY: scale,
        selectable: false,
        evented: false,
        __storyLayerType: "base",
        storyLayerType: "base",
      });

      canvas.add(object);
      this.engine.objectMap.set(layerId, object);
      if (this.engine.backgroundObject) {
        canvas.sendToBack(this.engine.backgroundObject);
      }

      store.getState().addLayer(
        { ...layer, ...transformFromObject(object), zIndex: 0 },
        { recordHistory: false, select: false }
      );
      this.engine.applyFiltersToLayer(store.getState().layers.find((item) => item.id === layerId), {
        preview: false,
        immediate: true,
      });
      this.engine.resizeToAspectRatio(aspectRatio);
      this.engine.requestRender({ preview: true });
      return layerId;
    } catch (error) {
      if (!this.engine.isDisposed) this.engine.onError?.(error);
      return null;
    }
  }

  async addImageLayer({ file, url, name = "Media", type = "media", source = "upload" }) {
    const { canvas, store, objectFactory } = this.engine;
    if (!canvas || this.engine.isDisposed) return null;
    const src = file ? createObjectUrl(file) : url;
    const layerId = store.getState().createLayerId(type);
    if (file) this.engine.sourceUrls.set(layerId, src);

    try {
      let object;
      if (src.startsWith("data:image/svg+xml")) {
        const decoded = decodeURIComponent(src.split(",")[1]);
        object = await objectFactory.createSVGObject(decoded, layerId);
      } else {
        object = await objectFactory.createImageObject(src, layerId);
      }
      if (!object || !canvas || this.engine.isDisposed) return null;
      const center = canvas.getCenter();
      object.set({ left: center.left, top: center.top, originX: "center", originY: "center" });
      object.set({ __storyLayerType: type, storyLayerType: type });
      object.scaleToWidth(canvas.getWidth() * 0.4);
      object.setCoords();
      canvas.add(object);
      canvas.setActiveObject(object);
      this.engine.objectMap.set(layerId, object);

      store.getState().addLayer({
        id: layerId,
        type,
        mediaType: "image",
        name,
        src,
        source,
        ...transformFromObject(object),
      });
      this.engine.layerManager.syncObjectStack();
      this.engine.requestRender({ preview: true });
      return layerId;
    } catch (error) {
      if (!this.engine.isDisposed) this.engine.onError?.(error);
      return null;
    }
  }

  async addVideoLayer({ file, url, name = "Video", type = "media", source = "upload" }) {
    const { canvas, store, objectFactory } = this.engine;
    if (!canvas || this.engine.isDisposed) return null;

    const src = file ? createObjectUrl(file) : url;
    const layerId = store.getState().createLayerId(type);
    if (file) this.engine.sourceUrls.set(layerId, src);

    try {
      const object = await objectFactory.createVideoObject(src, layerId);
      if (!object || !canvas || this.engine.isDisposed) return null;

      const center = canvas.getCenter();
      object.set({
        left: center.left,
        top: center.top,
        originX: "center",
        originY: "center",
        selectable: true,
        evented: true,
        hasControls: true,
        __storyLayerType: type,
        storyLayerType: type,
      });
      object.scaleToWidth(canvas.getWidth() * 0.55);
      object.setCoords();
      canvas.add(object);
      canvas.setActiveObject(object);
      this.engine.objectMap.set(layerId, object);

      store.getState().addLayer({
        id: layerId,
        type,
        mediaType: "video",
        name,
        src,
        source,
        ...transformFromObject(object),
      });
      this.engine.layerManager.syncObjectStack();
      this.engine.requestRender({ preview: true });
      return layerId;
    } catch (error) {
      if (!this.engine.isDisposed) this.engine.onError?.(error);
      return null;
    }
  }

  async addGifLayer({ url, name }) {
    const { canvas, store, objectFactory, layerManager } = this.engine;
    if (!canvas || this.engine.isDisposed) return null;

    const layerId = store.getState().createLayerId("gif");
    const gifObject = await objectFactory.createGifObject(url, layerId);
    if (!gifObject) return null;

    const center = canvas.getCenter();
    gifObject.set({ left: center.left, top: center.top });
    canvas.add(gifObject);
    canvas.setActiveObject(gifObject);
    this.engine.objectMap.set(layerId, gifObject);

    store.getState().addLayer({
      id: layerId,
      type: "gif",
      name,
      src: url,
      ...transformFromObject(gifObject),
    });
    layerManager.syncObjectStack();
    this.engine.requestRender({ preview: true });
    return layerId;
  }

  async replaceImageLayer(layerId, file) {
    const oldObject = this.engine.objectMap.get(layerId);
    if (!oldObject || !file) return Promise.resolve(null);
    const newLayerId = await this.addImageLayer({ file, name: file.name || "Media" });
    if (!newLayerId) return null;
    const transform = transformFromObject(oldObject);
    this.engine.store.getState().updateLayer(newLayerId, transform);
    this.engine.layerManager.removeLayer(layerId);
    return newLayerId;
  }
}
