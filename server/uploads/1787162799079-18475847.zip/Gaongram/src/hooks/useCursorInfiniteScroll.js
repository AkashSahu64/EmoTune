// hooks/useCursorInfiniteScroll.js
import { useState, useRef, useCallback } from 'react';

export const useCursorInfiniteScroll = (fetchFn) => {
  const [data, setData] = useState([]);
  const [cursor, setCursor] = useState(null);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);

  const idSetRef = useRef(new Set());

  const loadMore = useCallback(async () => {
    if (loading || !hasMore) return;

    setLoading(true);

    try {
      const res = await fetchFn(cursor);

      if (!res || !Array.isArray(res.data)) {
        setHasMore(false);
        return;
      }

      const newItems = [];
      for (const item of res.data) {
        if (!idSetRef.current.has(item.id)) {
          idSetRef.current.add(item.id);
          newItems.push(item);
        }
      }

      setData(prev => [...prev, ...newItems]);

      // Stop if no new items were added (prevents infinite loop on empty pages)
      if (newItems.length === 0) {
        setHasMore(false);
      } else if (res.nextCursor) {
        setCursor(res.nextCursor);
        setHasMore(true);
      } else {
        setHasMore(false);
      }
    } catch (err) {
      console.error('Infinite scroll error:', err);
      setHasMore(false);
    } finally {
      setLoading(false);
    }
  }, [cursor, loading, hasMore, fetchFn]);

  const refresh = async () => {
    setLoading(true);
    try {
      idSetRef.current.clear();
      const res = await fetchFn(null);

      const freshData = Array.isArray(res?.data) ? res.data : [];
      freshData.forEach(item => idSetRef.current.add(item.id));

      setData(freshData);
      setCursor(res?.nextCursor || null);
      setHasMore(Boolean(res?.nextCursor));
    } catch (err) {
      console.error('Refresh error:', err);
    } finally {
      setLoading(false);
    }
  };

  return {
    data,
    loading,
    hasMore,
    loadMore,
    refresh,
  };
};