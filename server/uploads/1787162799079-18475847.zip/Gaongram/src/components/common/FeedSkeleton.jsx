// components/common/FeedSkeleton.jsx
import React from 'react';

const FeedSkeleton = ({ count = 3 }) => {
  return (
    <>
      {Array(count).fill(0).map((_, i) => (
        <div key={i} className="bg-card dark:bg-card-dark rounded-lg overflow-hidden animate-pulse">
          {/* Header skeleton */}
          <div className="px-4 pt-3 pb-1 flex items-start justify-between">
            <div className="flex items-start space-x-3">
              <div className="w-10 h-10 bg-gray-300 dark:bg-gray-700 rounded-full" />
              <div className="flex flex-col space-y-2">
                <div className="w-28 h-4 bg-gray-300 dark:bg-gray-700 rounded" />
                <div className="w-16 h-3 bg-gray-300 dark:bg-gray-700 rounded" />
              </div>
            </div>
            <div className="w-16 h-8 bg-gray-300 dark:bg-gray-700 rounded-full" />
          </div>

          {/* Media skeleton */}
          <div className="w-full aspect-video bg-gray-300 dark:bg-gray-700" />

          {/* Footer skeleton */}
          <div className="px-4 py-3 flex justify-between items-center">
            <div className="flex space-x-4">
              <div className="w-8 h-8 bg-gray-300 dark:bg-gray-700 rounded-full" />
              <div className="w-8 h-8 bg-gray-300 dark:bg-gray-700 rounded-full" />
              <div className="w-8 h-8 bg-gray-300 dark:bg-gray-700 rounded-full" />
            </div>
            <div className="w-12 h-6 bg-gray-300 dark:bg-gray-700 rounded" />
          </div>
        </div>
      ))}
    </>
  );
};

export default FeedSkeleton;