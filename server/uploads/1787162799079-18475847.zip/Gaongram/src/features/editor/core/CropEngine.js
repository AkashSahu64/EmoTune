const ASPECT_RATIO_KEYS = {
  free: undefined,
  "1:1": "1:1",
  "4:5": "4:5",
  "16:9": "16:9",
  "9:16": "9:16",
};

const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

export class CropEngine {
  constructor({ engine, store }) {
    this.engine = engine;
    this.store = store;
    this.freeCrop = false;
  }

  getBaseObject() {
    const state = this.store.getState();
    const baseLayer = state.layers.find((layer) => layer.type === "base");
    return baseLayer ? this.engine?.objectMap?.get(baseLayer.id) : null;
  }

  getState() {
    const state = this.store.getState();
    const object = this.getBaseObject();
    return {
      aspectRatio: this.freeCrop ? null : state.aspectRatio,
      isFreeCrop: this.freeCrop,
      zoom: object?.scaleX || 1,
      rotation: object?.angle || 0,
      flipX: Boolean(object?.flipX),
      flipY: Boolean(object?.flipY),
    };
  }

  setAspectRatio(value) {
    const aspectRatio = Object.prototype.hasOwnProperty.call(ASPECT_RATIO_KEYS, value)
      ? ASPECT_RATIO_KEYS[value]
      : value;
    this.freeCrop = aspectRatio == null;
    const object = this.getBaseObject();
    const canvas = this.engine?.canvas;

    if (aspectRatio) {
      if (object) {
        object.set({
          lockUniScaling: true,
          selectable: false,
          evented: false,
        });
      }
      const baseLayer = this.store.getState().layers.find((layer) => layer.type === "base");
      if (baseLayer?.id) {
        this.store.getState().updateLayer(baseLayer.id, { locked: true }, { recordHistory: false });
      }
      this.store.getState().setAspectRatio(aspectRatio);
      this.engine?.resizeToAspectRatio(aspectRatio);
      return;
    }

    if (!object || !canvas) return;
    object.set({
      lockUniScaling: false,
      selectable: true,
      evented: true,
      lockMovementX: false,
      lockMovementY: false,
    });
    const baseLayer = this.store.getState().layers.find((layer) => layer.type === "base");
    if (baseLayer?.id) {
      this.store.getState().updateLayer(baseLayer.id, { locked: false }, { recordHistory: false });
    }
    canvas.setActiveObject(object);
    this.engine.requestRender({ preview: true });
  }

  setZoom(value) {
    const object = this.getBaseObject();
    if (!object) return;
    const next = clamp(Number(value) || 1, 0.2, 8);
    object.scaleX = object.flipX ? -Math.abs(next) : Math.abs(next);
    object.scaleY = object.flipY ? -Math.abs(next) : Math.abs(next);
    this.engine?.constrainToBounds?.(object);
    object.setCoords();
    this.syncLayer(object);
  }

  zoomBy(delta) {
    const object = this.getBaseObject();
    this.setZoom((Math.abs(object?.scaleX || 1) + delta).toFixed(2));
  }

  rotate(degrees = 90) {
    const object = this.getBaseObject();
    if (!object) return;
    object.rotate(((object.angle || 0) + degrees) % 360);
    this.engine?.constrainToBounds?.(object);
    object.setCoords();
    this.syncLayer(object);
  }

  setRotation(degrees) {
    const object = this.getBaseObject();
    if (!object) return;
    object.rotate(Number(degrees) || 0);
    this.engine?.constrainToBounds?.(object);
    object.setCoords();
    this.syncLayer(object);
  }

  flip(axis) {
    const object = this.getBaseObject();
    if (!object) return;
    if (axis === "x") object.set("flipX", !object.flipX);
    if (axis === "y") object.set("flipY", !object.flipY);
    object.setCoords();
    this.syncLayer(object);
  }

  reset() {
    const object = this.getBaseObject();
    const canvas = this.engine?.canvas;
    if (!object || !canvas) return;
    const scale = Math.min(canvas.getWidth() / (object.width || 1), canvas.getHeight() / (object.height || 1));
    object.set({
      left: canvas.getWidth() / 2,
      top: canvas.getHeight() / 2,
      angle: 0,
      flipX: false,
      flipY: false,
      scaleX: scale,
      scaleY: scale,
    });
    object.setCoords();
    this.syncLayer(object);
  }

  syncLayer(object) {
    const state = this.store.getState();
    const baseLayer = state.layers.find((layer) => layer.type === "base");
    if (baseLayer?.id) {
      state.updateLayer(
        baseLayer.id,
        {
          left: Math.round(object.left || 0),
          top: Math.round(object.top || 0),
          scaleX: Number(Math.abs(object.scaleX || 1).toFixed(4)),
          scaleY: Number(Math.abs(object.scaleY || 1).toFixed(4)),
          rotation: Math.round(object.angle || 0),
          flipX: Boolean(object.flipX),
          flipY: Boolean(object.flipY),
        },
        { recordHistory: false },
      );
    }
    this.engine?.requestRender({ preview: true });
  }
}

export default CropEngine;
