export { LayerManager as default, LayerManager } from "../../story/editor/engine/managers/LayerManager.js";
