import React from 'react';
import { motion } from 'framer-motion';

const Loader = ({ size = 'medium', color = 'instagram-pink', fullScreen = false, text }) => {
  const sizes = {
    small: 'w-6 h-6',
    medium: 'w-10 h-10',
    large: 'w-16 h-16',
  };
  
  const colorClasses = {
    'instagram-pink': 'text-instagram-pink',
    'white': 'text-white',
    'gray': 'text-gray-400',
  };
  
  const spinner = (
    <div className="flex flex-col items-center justify-center">
      <svg
        className={`animate-spin ${sizes[size]} ${colorClasses[color] || colorClasses['instagram-pink']}`}
        fill="none"
        viewBox="0 0 24 24"
      >
        <circle
          className="opacity-25"
          cx="12"
          cy="12"
          r="10"
          stroke="currentColor"
          strokeWidth="4"
        />
        <path
          className="opacity-75"
          fill="currentColor"
          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
        />
      </svg>
      {text && <p className="mt-3 text-sm text-gray-500">{text}</p>}
    </div>
  );
  
  if (fullScreen) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-white/80 backdrop-blur-sm z-50">
        {spinner}
      </div>
    );
  }
  
  return spinner;
};

export const SkeletonLoader = ({ count = 1, type = 'card' }) => {
  const skeletons = Array(count).fill(0);
  
  if (type === 'card') {
    return (
      <>
        {skeletons.map((_, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0.5 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, repeat: Infinity, repeatType: 'reverse' }}
            className="bg-white rounded-xl shadow-sm border p-4"
          >
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 rounded-full shimmer" />
              <div className="flex-1">
                <div className="w-24 h-4 shimmer rounded mb-2" />
                <div className="w-16 h-3 shimmer rounded" />
              </div>
            </div>
            <div className="w-full h-64 shimmer rounded-lg mb-4" />
            <div className="space-y-2">
              <div className="w-3/4 h-4 shimmer rounded" />
              <div className="w-1/2 h-4 shimmer rounded" />
            </div>
          </motion.div>
        ))}
      </>
    );
  }
  
  if (type === 'text') {
    return (
      <div className="space-y-2">
        {skeletons.map((_, index) => (
          <div key={index} className="w-full h-4 shimmer rounded" />
        ))}
      </div>
    );
  }
  
  return null;
};

export default Loader;  