// components/ProfileInformationModal.jsx
import React from "react";
import { X, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";
import Button from "../../../components/common/Button";

const InfoRow = ({ label, value }) => (
  <div className="flex justify-between py-2 border-b border-border dark:border-border-dark last:border-0">
    <span className="text-sm font-medium text-mutedForeground dark:text-mutedForeground-dark">
      {label}
    </span>
    <span className="text-sm text-foreground dark:text-foreground-dark text-right break-words max-w-[60%]">
      {value || "—"}
    </span>
  </div>
);

const ProfileInformationModal = ({ isOpen, onClose, profile, onEdit }) => {
  if (!isOpen || !profile) return null;

  const formatDate = (dateString) => {
    if (!dateString) return "—";
    return new Date(dateString).toLocaleDateString();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-6">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm"
          onClick={onClose}
        />

        {/* Modal */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative bg-white dark:bg-card-dark rounded-xl shadow-xl w-full max-w-md overflow-hidden"
        >
          {/* Header */}
          <div className="px-6 py-3 border-b border-border dark:border-border-dark bg-gradient-to-r from-gaon-cream to-white dark:from-gray-800 dark:to-card-dark">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-foreground dark:text-foreground-dark">
                Personal Information
              </h3>
              <button
                onClick={onClose}
                className="p-1.5 text-gray-400 hover:text-foreground dark:hover:text-foreground-dark hover:bg-gray-100 dark:hover:bg-muted-dark rounded-lg transition-colors"
              >
                <X size={20} />
              </button>
            </div>
          </div>

          {/* Body */}
          <div className="max-h-[60vh] md:max-h-[70vh] overflow-y-auto p-6 space-y-1 hide-scrollbar">
            <InfoRow label="First Name" value={profile.first_name} />
            <InfoRow label="Last Name" value={profile.last_name} />
            <InfoRow label="Username" value={`@${profile.username}`} />
            <InfoRow label="Email" value={profile.email} />
            <InfoRow label="Phone" value={profile.phone} />
            <InfoRow label="Bio" value={profile.bio} />
            <InfoRow label="Website" value={profile.external_link} />
            <InfoRow label="Date of Birth" value={formatDate(profile.dob)} />
            <InfoRow label="Gender" value={profile.gender} />
            <InfoRow label="Address" value={profile.address} />
            <InfoRow label="City" value={profile.city} />
            <InfoRow label="State" value={profile.state} />
            <InfoRow label="Country" value={profile.country} />
            <InfoRow label="Pin Code" value={profile.pin_code} />
            <InfoRow
              label="Privacy"
              value={profile.is_private ? "Private" : "Public"}
            />
            <InfoRow label="Followers" value={profile.followers_count} />
            <InfoRow label="Following" value={profile.following_count} />
            <InfoRow label="Posts" value={profile.posts_count} />
          </div>

          {/* Footer */}
          <div className="sticky bottom-0 bg-white dark:bg-card-dark border-t border-border dark:border-border-dark px-6 py-3">
            <div className="flex justify-end gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="border-gray-300 dark:border-border-dark text-foreground dark:text-foreground-dark hover:bg-gray-50 dark:hover:bg-muted-dark rounded-lg px-4"
              >
                Close
              </Button>
              <Button
                type="button"
                onClick={() => {
                  if (onEdit) onEdit();
                }}
                className="bg-primary hover:bg-primary-light rounded-lg px-4 shadow-md text-white"
              >
                Edit Profile
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default ProfileInformationModal;
