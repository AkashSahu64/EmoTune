import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { authAPI } from './api.js';
import { showSuccess, showError } from '../../../utils/toast.js';
import { useAuthStore } from '../../../store/authStore.js';

export const useRegister = () => {
  return useMutation({
    mutationFn: authAPI.register,
    onSuccess: (data) => {
      showSuccess('Registration successful! Please verify your email.');
    },
    onError: (error) => {
      showError(error.response?.data?.message || 'Registration failed');
    },
  });
};

export const useVerifyOtp = () => {
  const { setUser } = useAuthStore();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: authAPI.verifyOtp,
    onSuccess: (data) => {
      setUser(data.user);
      localStorage.setItem('access_token', data.access);
      localStorage.setItem('refresh_token', data.refresh);
      showSuccess('Email verified successfully!');
      queryClient.invalidateQueries(['auth']);
    },
    onError: (error) => {
      showError(error.response?.data?.message || 'OTP verification failed');
    },
  });
};

export const useLogin = () => {
  const { setUser } = useAuthStore();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: authAPI.login,
    onSuccess: (data) => {
      setUser(data.user);
      localStorage.setItem('access_token', data.access);
      localStorage.setItem('refresh_token', data.refresh);
      showSuccess('Login successful!');
      queryClient.invalidateQueries(['auth']);
    },
    onError: (error) => {
      showError(error.response?.data?.message || 'Login failed');
    },
  });
};

export const useLogout = () => {
  const { clearUser } = useAuthStore();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: authAPI.logout,
    onSuccess: () => {
      clearUser();
      localStorage.removeItem('access_token');
      localStorage.removeItem('refresh_token');
      showSuccess('Logged out successfully');
      queryClient.clear();
    },
    onError: (error) => {
      console.error('Logout error:', error);
      // Still clear local state even if API fails
      clearUser();
      localStorage.removeItem('access_token');
      localStorage.removeItem('refresh_token');
      queryClient.clear();
    },
  });
};

export const useProfile = () => {
  return useQuery({
    queryKey: ['profile'],
    queryFn: authAPI.getProfile,
    enabled: !!localStorage.getItem('access_token'),
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
};

export const useUpdateProfile = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: authAPI.updateProfile,
    onSuccess: (data) => {
      showSuccess('Profile updated successfully!');
      queryClient.invalidateQueries(['profile']);
    },
    onError: (error) => {
      showError(error.response?.data?.message || 'Profile update failed');
    },
  });
};

export const useCheckAuth = () => {
  return useQuery({
    queryKey: ['auth', 'check'],
    queryFn: async () => {
      const token = localStorage.getItem('access_token');
      if (!token) throw new Error('No token found');
      
      try {
        await authAPI.verifyToken(token);
        const profile = await authAPI.getProfile();
        return { isAuthenticated: true, user: profile };
      } catch (error) {
        // Try to refresh token
        const refreshToken = localStorage.getItem('refresh_token');
        if (refreshToken) {
          try {
            const { access } = await authAPI.refreshToken(refreshToken);
            localStorage.setItem('access_token', access);
            const profile = await authAPI.getProfile();
            return { isAuthenticated: true, user: profile };
          } catch (refreshError) {
            localStorage.removeItem('access_token');
            localStorage.removeItem('refresh_token');
            return { isAuthenticated: false, user: null };
          }
        }
        return { isAuthenticated: false, user: null };
      }
    },
    retry: 1,
    staleTime: 10 * 60 * 1000, // 10 minutes
  });
};