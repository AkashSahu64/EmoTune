export const validateEmail = (email) => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
};

export const validatePassword = (password) => {
  // At least 8 characters, 1 uppercase, 1 lowercase, 1 number
  const re = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{8,}$/;
  return re.test(password);
};

export const validateUsername = (username) => {
  // Alphanumeric, underscores, 3-30 characters
  const re = /^[a-zA-Z0-9_]{3,30}$/;
  return re.test(username);
};

export const validatePhone = (phone) => {
  // Simple phone validation
  const re = /^[\+]?[1-9][\d]{0,15}$/;
  return re.test(phone);
};

export const validateFile = (file, allowedTypes, maxSize) => {
  const errors = [];
  
  if (!file) {
    errors.push('File is required');
    return { isValid: false, errors };
  }
  
  if (maxSize && file.size > maxSize) {
    const sizeInMB = maxSize / (1024 * 1024);
    errors.push(`File size must be less than ${sizeInMB}MB`);
  }
  
  if (allowedTypes && !allowedTypes.includes(file.type)) {
    errors.push(`File type not supported. Allowed: ${allowedTypes.join(', ')}`);
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
};

export const validateRequired = (value, fieldName) => {
  if (!value || value.trim() === '') {
    return `${fieldName} is required`;
  }
  return '';
};