export { SEO_CONFIG } from "../../seo/metadata/config.mjs";
