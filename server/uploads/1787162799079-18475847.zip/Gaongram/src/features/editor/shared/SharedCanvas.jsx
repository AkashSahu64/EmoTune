export { default } from "../components/SharedCanvas.jsx";
