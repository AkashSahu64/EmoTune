import PostEditor from "../../editor/editors/PostEditor.jsx";

export default PostEditor;
