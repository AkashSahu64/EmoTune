// store/mediaStore.js - UPDATED
import { create } from 'zustand';
import { mediaController } from '../media/MediaController.js';

const sameId = (a, b) => String(a ?? '') === String(b ?? '');

export const useMediaStore = create((set, get) => {
  // Initialize media controller listeners
  mediaController.on('globalMute', (muted) => {
    set({ isMuted: muted });
  });
  
  mediaController.on('play', ({ mediaId }) => {
    set({ activePostId: mediaId });
  });
  
  mediaController.on('pause', ({ mediaId }) => {
    const state = get();
    if (sameId(state.activePostId, mediaId)) {
      set({ lastActivePostId: mediaId });
    }
  });
  
  mediaController.on('stop', ({ mediaId }) => {
    const state = get();
    if (state.activePostId === mediaId) {
      set({ activePostId: null });
    }
  });

  return {
    // State
    activePostId: null,
    lastActivePostId: null,
    manuallyControlledPostId: null,
    manualControlUntil: 0,
    isMuted: true,
    userInteracted: false,
    canAutoplay: false,

    // Actions
    setActivePost: (postId) => {
      const current = get().activePostId;
      
      if (!postId || sameId(current, postId)) return;
      
      set({
        activePostId: String(postId),
        lastActivePostId: current,
      });
    },

    clearActivePost: () => {
      const current = get().activePostId;
      set({
        activePostId: null,
        lastActivePostId: current,
      });
    },

    markManualControl: (postId, ttlMs = 12000) => {
      set({
        manuallyControlledPostId: String(postId),
        manualControlUntil: Date.now() + ttlMs,
      });
    },

    clearManualControl: () => {
      set({ manuallyControlledPostId: null, manualControlUntil: 0 });
    },

    toggleMute: () => {
      mediaController.toggleGlobalMute();
    },

    setUserInteracted: () => {
      mediaController.setUserInteracted();
      set({ userInteracted: true });
    },

    shouldPlay: (postId) => {
      const { activePostId, userInteracted } = get();
      return userInteracted && sameId(activePostId, postId);
    },

    shouldMute: (postId) => {
      const { activePostId, isMuted, userInteracted } = get();
      return isMuted || !userInteracted || !sameId(activePostId, postId);
    },

    canAutoplayPost: (postId) => {
      const { manuallyControlledPostId, manualControlUntil } = get();
      if (!manuallyControlledPostId) return true;
      if (Date.now() > manualControlUntil) return true;
      return sameId(manuallyControlledPostId, postId);
    },
  };
});
