import { useNavigate } from "react-router-dom";
import { useUIStore } from "../../../store/uiStore.js";
import { useFollow } from "../../../hooks/useFollow.js";
import Avatar from "../../../components/common/Avatar.jsx";
import Button from "../../../components/common/Button.jsx";
import { useTranslation } from "react-i18next";

const SuggestedUserItem = ({ user }) => {
  const navigate = useNavigate();
  const { t } = useTranslation(); 

  const { toggleFollow, isFollowing, isFollowingRequested, isLoading } =
    useFollow(user.user_id || user.id, user.is_private);

  const handleProfileClick = () => {
    navigate(`/profile/${user.username || user.id || user.user_id}`);
  };

  const handleFollowClick = (e) => {
    e.stopPropagation();
    toggleFollow();
  };

  // ✅ FIX: use translation keys instead of hardcoded strings
  let labelKey = "follow";
  let variant = "primary";
  let disabled = isLoading;

  if (isFollowingRequested) {
    labelKey = "requested";
    variant = "outline";
    disabled = true;
  } else if (isFollowing) {
    labelKey = "following";
    variant = "outline";
  }

  return (
    <div
      onClick={handleProfileClick}
      className="flex items-center gap-2 py-1 rounded-lg cursor-pointer hover:bg-muted dark:hover:bg-muted-dark transition"
    >
      <div className="flex-shrink-0">
        <Avatar src={user.avatar} alt={user.username} size="medium" />
      </div>

      <div className="flex-1 min-w-0">
        <p
          className="text-sm font-medium truncate text-foreground dark:text-foreground-dark"
          title={user.username}
        >
          {user.username}
        </p>

        <p className="text-xs text-mutedForeground dark:text-mutedForeground-dark truncate">
          {user.full_name || user.name}
        </p>
      </div>

      <div className="flex-shrink-0">
        <Button
          size="small"
          variant={variant}
          onClick={handleFollowClick}
          disabled={disabled}
          className="w-[80px] justify-center"
        >
          {t(labelKey)} 
        </Button>
      </div>
    </div>
  );
};

const SuggestedUsersFeedCard = ({ users = [], allUsers }) => {
  const { openModal } = useUIStore();
  const { t } = useTranslation(); 

  if (!users.length) return null;

  const handleSeeAll = () => {
    openModal("suggested-users-modal", {
      users: Array.isArray(allUsers) && allUsers.length > 0 ? allUsers : users,
    });
  };

  return (
    <div className="bg-card dark:bg-card-dark rounded-xl border border-border dark:border-border-dark shadow-soft p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-foreground dark:text-foreground-dark">
          {t("suggested_for_you")} 
        </h3>

        <button
          onClick={handleSeeAll}
          className="text-sm font-medium text-primary"
        >
          {t("see_all")} 
        </button>
      </div>

      <div className="space-y-2">
        {users.map((user, index) => (
          <SuggestedUserItem key={index} user={user} />
        ))}
      </div>
    </div>
  );
};

export default SuggestedUsersFeedCard;