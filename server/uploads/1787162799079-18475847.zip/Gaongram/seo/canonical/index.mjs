/* global URL */
import { getSiteUrl } from "../metadata/config.mjs";
import { toAbsoluteUrl } from "../metadata/utils.mjs";

export const getCanonicalUrl = (value = "/") => {
  const absoluteUrl = toAbsoluteUrl(value, "/");

  try {
    const url = new URL(absoluteUrl);
    url.hash = "";
    url.searchParams.sort();
    return url.href;
  } catch {
    return getSiteUrl();
  }
};

export const getContentUrl = (path) => getCanonicalUrl(path || "/");

export const canonicalProfilePath = (profileOrIdentifier = {}) => {
  const username =
    typeof profileOrIdentifier === "string"
      ? profileOrIdentifier
      : profileOrIdentifier.username ||
        profileOrIdentifier.user_name ||
        profileOrIdentifier.slug ||
        profileOrIdentifier.id ||
        "";
  return `/profile/${encodeURIComponent(String(username || "user"))}`;
};

export const canonicalProfileUrl = (profileOrIdentifier) =>
  getContentUrl(canonicalProfilePath(profileOrIdentifier));
