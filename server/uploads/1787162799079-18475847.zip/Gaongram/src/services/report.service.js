import api from '../config/axios.js';

export const reportService = {
  /**
   * Get available report reasons
   */
  getReportReasons: async () => {
    try {
      const response = await api.get('/report/reasons/');
      return response.data || [];
    } catch (error) {
      console.error('Error fetching report reasons:', error);
      throw error;
    }
  },

  /**
   * Submit a report
   * @param {Object} reportData - Report details
   * @param {string} reportData.modelType - 'user', 'post', or 'comment'
   * @param {string|number} reportData.objectId - ID of the object being reported
   * @param {string} reportData.reason - Reason key from getReportReasons
   * @param {string|null} reportData.description - Optional description
   */
  submitReport: async ({ modelType, objectId, reason, description = null }) => {
    if (!['user', 'post', 'comment'].includes(modelType)) {
      throw new Error(`Invalid model type: ${modelType}. Must be 'user', 'post', or 'comment'.`);
    }

    try {
      const response = await api.post(`/report/${modelType}/${objectId}/`, {
        reason,
        description
      });
      return response.data;
    } catch (error) {
      console.error(`Error reporting ${modelType} ${objectId}:`, error);
      throw error;
    }
  },

  /**
   * Get user's reports (for admin/moderation)
   */
  getUserReports: async (params = {}) => {
    try {
      const response = await api.get('/reports/', { params });
      return response.data;
    } catch (error) {
      console.error('Error fetching user reports:', error);
      throw error;
    }
  },

  /**
   * Update report status (admin only)
   */
  updateReportStatus: async (reportId, status) => {
    try {
      const response = await api.patch(`/reports/${reportId}/status/`, { status });
      return response.data;
    } catch (error) {
      console.error(`Error updating report ${reportId}:`, error);
      throw error;
    }
  }
};

export const blockService = {
  /**
   * Toggle block/unblock for a user.
   * POST /block-user-toggle/{userId}/
   */
  toggleBlockUser: async (userId) => {
    const response = await api.post(`/block-user-toggle/${userId}/`);
    return response.data;
  },
};