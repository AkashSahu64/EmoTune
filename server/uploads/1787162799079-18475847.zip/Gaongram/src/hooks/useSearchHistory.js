import { useState, useEffect } from "react";

const STORAGE_KEY =
  "gaongram_search_history";

const MAX_ITEMS = 10;

export function useSearchHistory() {

  const [history, setHistory] =
    useState([]);

  // ======================
  // LOAD HISTORY
  // ======================

  const loadHistory = () => {

    try {

      const stored =
        localStorage.getItem(
          STORAGE_KEY
        );

      if (stored) {

        const parsed =
          JSON.parse(stored);

        if (
          Array.isArray(parsed)
        ) {

          setHistory(parsed);
        }
      }

    } catch (error) {

      console.error(
        "Search history parse error:",
        error
      );
    }
  };

  // Initial load
  useEffect(() => {

    loadHistory();

  }, []);

  // Listen custom update event
  useEffect(() => {

    window.addEventListener(
      "search-history-updated",
      loadHistory
    );

    return () => {

      window.removeEventListener(
        "search-history-updated",
        loadHistory
      );
    };

  }, []);

  // ======================
  // ADD TO HISTORY
  // ======================

  const addToHistory = (
    user
  ) => {

    if (
      !user ||
      !user.username
    ) return;

    try {

      const stored =
        localStorage.getItem(
          STORAGE_KEY
        );

      const prev = stored
        ? JSON.parse(stored)
        : [];

      // remove duplicate
      const filtered =
        prev.filter(
          (item) =>

            item.username !==
            user.username
        );

      const updated = [

        user,

        ...filtered,

      ].slice(0, MAX_ITEMS);

      localStorage.setItem(

        STORAGE_KEY,

        JSON.stringify(updated)

      );

      setHistory(updated);

      // notify all components
      window.dispatchEvent(

        new Event(
          "search-history-updated"
        )

      );

    } catch (error) {

      console.error(
        "Failed to save history",
        error
      );
    }
  };

  // ======================
  // REMOVE
  // ======================

  const removeFromHistory =
    (username) => {

      const updated =
        history.filter(

          (item) =>

            item.username !==
            username

        );

      localStorage.setItem(

        STORAGE_KEY,

        JSON.stringify(updated)

      );

      setHistory(updated);

      window.dispatchEvent(

        new Event(
          "search-history-updated"
        )

      );
    };

  // ======================
  // CLEAR
  // ======================

  const clearHistory = () => {

    localStorage.removeItem(
      STORAGE_KEY
    );

    setHistory([]);

    window.dispatchEvent(

      new Event(
        "search-history-updated"
      )

    );
  };

  return {

    history,

    addToHistory,

    removeFromHistory,

    clearHistory,

  };
}