import React from "react";

const Timeline = ({ items = [], currentIndex = 0, progress = 0, onSeek }) => {
  if (!items.length) return null;

  return (
    <div className="flex w-full gap-1">
      {items.map((item, index) => (
        <button
          key={item?.id || index}
          type="button"
          onClick={() => onSeek?.(index)}
          className="h-1 flex-1 overflow-hidden rounded-full bg-white/30"
          aria-label={`Go to item ${index + 1}`}
        >
          <span
            className="block h-full rounded-full bg-white transition-[width] duration-75 ease-linear"
            style={{
              width: index === currentIndex ? `${progress}%` : index < currentIndex ? "100%" : "0%",
            }}
          />
        </button>
      ))}
    </div>
  );
};

export default React.memo(Timeline);
