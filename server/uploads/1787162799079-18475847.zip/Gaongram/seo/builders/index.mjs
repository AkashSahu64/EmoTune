﻿import {
  INDEX_ROBOTS,
  NOINDEX_ROBOTS,
  SEO_CONFIG,
} from "../metadata/config.mjs";
import {
  addCacheVersion,
  cleanText,
  compactObject,
  firstPresentNumber,
  formatCount,
  getSocialImage,
  toAbsoluteUrl,
  truncateText,
} from "../metadata/utils.mjs";
import { getContentUrl, canonicalProfileUrl } from "../canonical/index.mjs";
import {
  createOrganizationSchema,
  createWebPageSchema,
  createWebsiteSchema,
} from "../schemas/index.mjs";
import { ogImageUrl } from "../og/images.mjs";

export { createOrganizationSchema, createWebsiteSchema };

export const STATIC_PAGE_SEO = {
  home: {
    title: "GaonGram Home",
    description:
      "Explore your GaonGram feed with posts, stories, creators, reels, audio, and conversations from across Bharat.",
    path: "/feed",
  },
  login: {
    title: "Login to GaonGram",
    description:
      "Log in to GaonGram to share posts, watch reels, listen to audio, message friends, and discover creators.",
    path: "/login",
    noindex: true,
  },
  register: {
    title: "Create a GaonGram Account",
    description:
      "Join GaonGram to connect with people, share moments, follow creators, and discover local communities.",
    path: "/register",
    noindex: true,
  },
  forgotPassword: {
    title: "Forgot Password",
    description: "Reset your GaonGram password securely.",
    path: "/forgot-password",
    noindex: true,
  },
  resetPassword: {
    title: "Reset Password",
    description: "Create a new secure password for your GaonGram account.",
    path: "/reset-password",
    noindex: true,
  },
  verifyOtp: {
    title: "Verify Your GaonGram Account",
    description: "Verify your GaonGram account with a one-time password.",
    path: "/verify-otp",
    noindex: true,
  },
  googleAuth: {
    title: "Google Authentication",
    description: "Complete Google sign-in for your GaonGram account.",
    path: "/auth/google",
    noindex: true,
  },
  changePassword: {
    title: "Change Password",
    description: "Change your GaonGram account password securely.",
    path: "/change-password",
    noindex: true,
  },
  notifications: {
    title: "Notifications",
    description: "View your GaonGram account notifications.",
    path: "/notifications",
    noindex: true,
  },
  messages: {
    title: "Messages",
    description: "Open your GaonGram private messages.",
    path: "/messages",
    noindex: true,
  },
  about: {
    title: "About GaonGram",
    description:
      "Learn how GaonGram connects Bharat through local communities, creators, reels, stories, audio, and real-time conversations.",
    path: "/about",
  },
  privacy: {
    title: "Privacy Policy",
    description:
      "Read GaonGram's privacy policy, data protection practices, user rights, and security commitments.",
    path: "/privacy",
  },
  terms: {
    title: "Terms and Conditions",
    description:
      "Review the GaonGram terms and conditions for account use, content ownership, safety, and platform rules.",
    path: "/terms",
  },
  help: {
    title: "GaonGram Help Center",
    description:
      "Find help articles and support answers for your GaonGram account, posts, messages, privacy, and safety tools.",
    path: "/help-center",
  },
  contact: {
    title: "Contact GaonGram",
    description:
      "Contact the GaonGram support team for account help, safety reports, feedback, and business inquiries.",
    path: "/contact",
  },
  safety: {
    title: "GaonGram Safety",
    description:
      "Explore GaonGram safety tools, reporting systems, privacy controls, moderation policies, and user protections.",
    path: "/safety",
  },
  guidelines: {
    title: "Community Guidelines",
    description:
      "Read GaonGram's community guidelines for respectful, authentic, and safe participation.",
    path: "/community-guidelines",
  },
  language: {
    title: "Choose Language",
    description: "Choose your preferred language on GaonGram.",
    path: "/language",
  },
  search: {
    title: "Search GaonGram",
    description:
      "Search GaonGram for accounts, posts, hashtags, creators, and conversations.",
    path: "/search",
  },
  trending: {
    title: "Trending on GaonGram",
    description:
      "Discover trending hashtags, topics, creators, posts, and conversations on GaonGram.",
    path: "/trending",
  },
  reels: {
    title: "GaonGram Reels",
    description: "Watch short videos, reels, and creator clips on GaonGram.",
    path: "/reels",
  },
  audio: {
    title: "GaonGram Audio",
    description:
      "Listen to audio posts, music, voice clips, and creator audio on GaonGram.",
    path: "/audio",
  },
  blogs: {
    title: "GaonGram Blogs",
    description:
      "Read blogs, stories, updates, and long-form posts from GaonGram creators and communities.",
    path: "/blogs",
  },
  playlists: {
    title: "GaonGram Playlists",
    description: "Create, save, and listen to audio playlists on GaonGram.",
    path: "/playlists",
  },
  stories: {
    title: "GaonGram Stories",
    description: "Watch short-lived stories and creator updates on GaonGram.",
    path: "/stories",
    noindex: true,
  },
};

const titleIncludesSiteName = (value) =>
  String(value || "").toLowerCase().includes(SEO_CONFIG.siteName.toLowerCase());

export const formatSeoTitle = (title) => {
  const cleanTitle = cleanText(title || SEO_CONFIG.defaultTitle);
  if (!cleanTitle || titleIncludesSiteName(cleanTitle)) return cleanTitle;
  return `${cleanTitle} | ${SEO_CONFIG.siteName}`;
};

const defaultSocialImage = () => getSocialImage(SEO_CONFIG.defaultImage);

const hasEntityImage = (image) =>
  Boolean(image) && getSocialImage(image) !== defaultSocialImage();

const preferEntityImage = (image, fallback) =>
  hasEntityImage(image) ? getSocialImage(image) : fallback;

export const normalizeProfile = (profile = {}, identifier = "") => {
  const user = profile.user || profile.account || {};
  const stats =
    profile.stats || profile.counts || profile.metrics || profile.profile_stats || {};
  const username = cleanText(
    profile.username ||
      profile.user_name ||
      profile.slug ||
      user.username ||
      user.user_name ||
      identifier,
  );
  const fullName = cleanText(
    profile.fullName ||
      profile.full_name ||
      profile.displayName ||
      profile.name ||
      user.fullName ||
      user.full_name ||
      user.displayName ||
      user.name ||
      [profile.firstName || profile.first_name, profile.lastName || profile.last_name]
        .filter(Boolean)
        .join(" ") ||
      [user.firstName || user.first_name, user.lastName || user.last_name]
        .filter(Boolean)
        .join(" ") ||
      username ||
      "GaonGram user",
  );
  const nameParts = fullName.split(/\s+/).filter(Boolean);

  return {
    id: profile.id || profile.profile_id || user.profile_id,
    userId:
      profile.userId ||
      profile.user_id ||
      user.userId ||
      user.user_id ||
      user.id ||
      profile.id,
    username,
    fullName,
    firstName: cleanText(
      profile.firstName ||
        profile.first_name ||
        user.firstName ||
        user.first_name ||
        nameParts[0],
    ),
    lastName: cleanText(
      profile.lastName ||
        profile.last_name ||
        user.lastName ||
        user.last_name ||
        nameParts.slice(1).join(" "),
    ),
    bio: cleanText(profile.bio || profile.bio_display || profile.about || user.bio || ""),
    profileImage: getSocialImage(
      profile.profileImage ||
        profile.profile_image ||
        profile.photo ||
        profile.avatar ||
        profile.image ||
        profile.picture ||
        user.profileImage ||
        user.profile_image ||
        user.photo ||
        user.avatar ||
        profile.user?.profile_image ||
        profile.user?.photo,
    ),
    followers: firstPresentNumber(
      stats.followers,
      stats.followersCount,
      stats.followers_count,
      profile.followers_count,
      profile.follower_count,
      profile.followersCount,
      profile.followerCount,
      profile.followers,
      profile.total_followers,
      user.followers_count,
      user.followersCount,
    ),
    following: firstPresentNumber(
      stats.following,
      stats.followingCount,
      stats.following_count,
      profile.following_count,
      profile.followingCount,
      profile.following,
      profile.total_following,
      user.following_count,
      user.followingCount,
    ),
    posts: firstPresentNumber(
      stats.posts,
      stats.postsCount,
      stats.posts_count,
      profile.posts_count,
      profile.post_count,
      profile.postsCount,
      profile.postCount,
      profile.posts,
      profile.total_posts,
      user.posts_count,
      user.postsCount,
    ),
    externalLink: profile.externalLink || profile.external_link,
    updatedAt: profile.updatedAt || profile.updated_at,
  };
};

export const buildStaticPageSeo = (key, overrides = {}) => {
  const page = STATIC_PAGE_SEO[key] || {};
  const title = overrides.title || page.title || SEO_CONFIG.defaultTitle;
  const description =
    overrides.description || page.description || SEO_CONFIG.defaultDescription;
  const canonical = getContentUrl(
    overrides.canonical || overrides.path || page.path || "/",
  );
  const noindex = overrides.noindex ?? page.noindex ?? false;

  return {
    title: formatSeoTitle(title),
    description,
    keywords: overrides.keywords || SEO_CONFIG.defaultKeywords,
    canonical,
    ogUrl: canonical,
    ogImage: addCacheVersion(
      overrides.ogImage || page.ogImage || SEO_CONFIG.defaultImage,
      overrides.imageVersion,
    ),
    ogImageAlt: overrides.ogImageAlt || SEO_CONFIG.defaultImageAlt,
    ogType: overrides.ogType || "website",
    noindex,
    robots: noindex ? NOINDEX_ROBOTS : INDEX_ROBOTS,
    schema: [
      createWebPageSchema({
        title: formatSeoTitle(title),
        description,
        url: canonical,
        type: overrides.schemaType || "WebPage",
      }),
    ],
  };
};

export const buildProfileSeo = (profile = {}, options = {}) => {
  const normalized = normalizeProfile(profile, options.identifier);
  const canonical = canonicalProfileUrl(normalized);
  const usernameLabel = normalized.username ? `@${normalized.username}` : "@user";
  const title = `${normalized.fullName} (${usernameLabel})`;
  const statsLine = `${formatCount(normalized.followers)} Followers \u2022 ${formatCount(
    normalized.following,
  )} Following \u2022 ${formatCount(normalized.posts)} Posts`;
  const description = truncateText(
    [
      `${statsLine}.`,
      normalized.bio,
      `See ${normalized.fullName}'s photos, videos, and posts on ${SEO_CONFIG.siteName}.`,
    ]
      .filter(Boolean)
      .join(" | "),
    300,
  );
  const generatedImage = ogImageUrl(
    "profile",
    normalized.username || normalized.userId || options.identifier,
    normalized.updatedAt || options.imageVersion,
  );
  const image = preferEntityImage(normalized.profileImage, generatedImage);

  const personSchema = compactObject({
    "@context": "https://schema.org",
    "@type": "Person",
    name: normalized.fullName,
    alternateName: usernameLabel,
    description: normalized.bio || description,
    image: normalized.profileImage,
    url: canonical,
    sameAs: normalized.externalLink,
    interactionStatistic: [
      {
        "@type": "InteractionCounter",
        interactionType: { "@type": "FollowAction" },
        userInteractionCount: normalized.followers,
      },
      {
        "@type": "InteractionCounter",
        interactionType: { "@type": "WriteAction" },
        userInteractionCount: normalized.posts,
      },
    ],
  });

  return {
    title,
    appendSiteName: false,
    description,
    canonical,
    ogUrl: canonical,
    ogImage: image,
    ogImageSecureUrl: image,
    ogImageAlt: `${normalized.fullName} profile preview on ${SEO_CONFIG.siteName}`,
    ogType: "profile",
    image: normalized.profileImage,
    profile: {
      username: normalized.username,
      firstName: normalized.firstName,
      lastName: normalized.lastName,
    },
    schema: [
      personSchema,
      compactObject({
        "@context": "https://schema.org",
        "@type": "ProfilePage",
        name: title,
        description,
        url: canonical,
        mainEntity: personSchema,
      }),
    ],
  };
};

export const getProfileUsername = (profile = {}) =>
  cleanText(profile.username || profile.user_name || profile.slug || "");

export const getProfileDisplayName = (profile = {}) =>
  cleanText(
    profile.fullName ||
      profile.full_name ||
      profile.displayName ||
      profile.name ||
      [profile.firstName || profile.first_name, profile.lastName || profile.last_name]
        .filter(Boolean)
        .join(" ") ||
      getProfileUsername(profile) ||
      "GaonGram creator",
  );

export const getProfileImage = (profile = {}) =>
  getSocialImage(
    profile.profileImage ||
      profile.profile_image ||
      profile.photo ||
      profile.avatar ||
      profile.image,
  );

export const getPostAuthor = (post = {}, profile = {}) => {
  const user = post.user || post.author || {};
  const username =
    getProfileUsername(user) ||
    post.user_name ||
    post.username ||
    getProfileUsername(profile);
  const name =
    user.fullName ||
    user.full_name ||
    user.displayName ||
    user.name ||
    post.author_name ||
    post.full_name ||
    profile.fullName ||
    profile.full_name ||
    username ||
    "GaonGram creator";

  return {
    id: user.id || post.user_id || post.author_id || profile.userId || profile.id,
    name: cleanText(name),
    username: cleanText(username),
    image: getProfileImage(user.profile_image || user.photo ? user : profile),
  };
};

export const getPostMediaType = (post = {}) => {
  const raw = post.media_type || post.type || post.post_type;
  if (raw) return String(raw).toLowerCase();
  if (post.videos?.length || post.video || post.hls_playlist) return "video";
  if (post.audio || post.audio_url) return "audio";
  if (post.images?.length || post.image || post.media_url) return "image";
  if (post.poll || post.poll_question) return "poll";
  return "text";
};

export const getPostCaption = (post = {}) =>
  cleanText(post.caption || post.content || post.text || post.description || "");

export const getPostImage = (post = {}, fallback = "") => {
  const video = post.videos?.[0] || post.video || {};
  const audio = post.audio || {};
  const media = Array.isArray(post.media) ? post.media[0] : post.media || {};
  const file = Array.isArray(post.files) ? post.files[0] : post.files || {};
  const image =
    post.images?.[0]?.image ||
    post.images?.[0]?.url ||
    post.images?.[0]?.media_url ||
    video.thumbnail ||
    video.thumbnail_url ||
    video.preview_frame ||
    video.cover_image ||
    video.poster ||
    video.poster_url ||
    audio.cover_image ||
    audio.cover ||
    audio.thumbnail ||
    audio.image ||
    post.cover_image ||
    post.cover ||
    post.thumbnail ||
    post.thumbnail_url ||
    post.image ||
    post.image_url ||
    media.thumbnail ||
    media.thumbnail_url ||
    media.cover_image ||
    media.poster ||
    media.image ||
    media.url ||
    file.thumbnail ||
    file.cover_image ||
    file.image ||
    file.url ||
    (getPostMediaType(post) === "image" ? post.media_url : "") ||
    fallback;

  return getSocialImage(image);
};

export const getPostVideoUrl = (post = {}) => {
  const video = post.videos?.[0] || post.video || {};
  const videoUrl =
    video.hls_playlist || video.video || post.hls_playlist || post.video || "";
  return videoUrl ? toAbsoluteUrl(videoUrl) : "";
};

export const buildPostSeo = (post = {}, profile = {}, options = {}) => {
  const author = getPostAuthor(post, profile);
  const caption = getPostCaption(post);
  const mediaType = options.mediaType || getPostMediaType(post);
  const postId = post.id || options.postId || options.id;
  const username = author.username || getProfileUsername(profile);
  const canonical = getContentUrl(
    options.path ||
      (username
        ? `/profile/${username}/post/${postId || ""}`
        : `/posts/${postId || ""}`),
  );
  const generatedImage = ogImageUrl(
    mediaType === "video" ? "reel" : mediaType === "audio" ? "audio" : "post",
    postId,
    options.imageVersion || post.updated_at || post.updatedAt,
  );
  const contentImage = getPostImage(post, "");
  const primaryImage = preferEntityImage(contentImage, generatedImage);
  const videoUrl = getPostVideoUrl(post);
  const firstVideo = post.videos?.[0] || post.video || {};
  const typeLabel = mediaType === "video" ? "video" : mediaType;
  const title = caption
    ? `${author.name} on ${SEO_CONFIG.siteName}: ${truncateText(caption, 78)}`
    : `${typeLabel.charAt(0).toUpperCase()}${typeLabel.slice(1)} post by ${
        author.name
      }${username ? ` (@${username})` : ""}`;
  const postCta =
    mediaType === "video"
      ? `Watch this video, reactions, and comments on ${SEO_CONFIG.siteName}.`
      : mediaType === "audio"
        ? `Listen to this audio and discover reactions and comments on ${SEO_CONFIG.siteName}.`
        : `Explore this post, reactions, and comments on ${SEO_CONFIG.siteName}.`;
  const description = truncateText([caption, postCta].filter(Boolean).join("\n\n"), 300);

  return {
    title,
    description,
    canonical,
    ogUrl: canonical,
    ogImage: primaryImage,
    ogImageSecureUrl: primaryImage,
    ogImageAlt: `${typeLabel} post by ${author.name} on ${SEO_CONFIG.siteName}`,
    ogType: mediaType === "video" ? "video.other" : "article",
    image: primaryImage,
    article: {
      publishedTime: post.created_at || post.createdAt,
      modifiedTime: post.updated_at || post.updatedAt,
      author: author.name,
      section: typeLabel,
      tags: post.tags || post.hashtags,
    },
    video: videoUrl
      ? {
          url: videoUrl,
          secureUrl: videoUrl,
          type: videoUrl.includes(".m3u8")
            ? "application/x-mpegURL"
            : "video/mp4",
          width: firstVideo.width || post.video_width,
          height: firstVideo.height || post.video_height,
        }
      : null,
    schema: [
      compactObject({
        "@context": "https://schema.org",
        "@type": "SocialMediaPosting",
        headline: title,
        articleBody: caption || description,
        image: primaryImage,
        url: canonical,
        datePublished: post.created_at || post.createdAt,
        dateModified: post.updated_at || post.updatedAt,
        author: {
          "@type": "Person",
          name: author.name,
          alternateName: username ? `@${username}` : undefined,
          image: author.image,
          url: username ? getContentUrl(`/profile/${username}`) : undefined,
        },
        publisher: createOrganizationSchema(),
      }),
    ],
  };
};

export const buildReelSeo = (reel = {}, options = {}) => {
  const base = buildPostSeo(reel, options.profile, {
    path: options.path || `/reels/${reel.id || options.reelId || options.id || ""}`,
    mediaType: "video",
    postId: reel.id || options.reelId || options.id,
    imageVersion: options.imageVersion,
  });
  const author = getPostAuthor(reel, options.profile);
  const caption = getPostCaption(reel);
  const description = truncateText(
    [
      caption,
      `Watch this reel, reactions, and comments on ${SEO_CONFIG.siteName}.`,
    ]
      .filter(Boolean)
      .join("\n\n"),
    300,
  );

  return {
    ...base,
    title: caption
      ? `Reel by ${author.name}: ${truncateText(caption, 78)}`
      : `Reel by ${author.name}${author.username ? ` (@${author.username})` : ""}`,
    description,
    ogType: "video.other",
  };
};

export const buildAudioSeo = (audioPost = {}, options = {}) => {
  const audio = audioPost.audio || audioPost;
  const author = getPostAuthor(audioPost, options.profile);
  const id = audioPost.id || audio.id || options.audioId || options.id;
  const titleText = cleanText(
    audio.title || audioPost.caption || audioPost.title || "Audio on GaonGram",
  );
  const canonical = getContentUrl(options.path || `/audio?start=${id || ""}`);
  const contentImage = getSocialImage(
    audio.cover_image || audioPost.cover_image || getPostImage(audioPost),
  );
  const generatedImage = ogImageUrl("audio", id, options.imageVersion || audioPost.updated_at);
  const image = preferEntityImage(contentImage, generatedImage);
  const description = truncateText(
    [
      audioPost.caption || audio.description || titleText,
      `Listen to this audio and discover reactions and comments on ${SEO_CONFIG.siteName}.`,
    ]
      .filter(Boolean)
      .join("\n\n"),
    300,
  );

  return {
    title: `${titleText} | ${SEO_CONFIG.siteName} Audio`,
    description,
    canonical,
    ogUrl: canonical,
    ogImage: image,
    ogImageSecureUrl: image,
    ogImageAlt: `${titleText} audio preview on ${SEO_CONFIG.siteName}`,
    ogType: "music.song",
    image,
    schema: [
      compactObject({
        "@context": "https://schema.org",
        "@type": "AudioObject",
        name: titleText,
        description,
        contentUrl: audio.audio || audio.url ? toAbsoluteUrl(audio.audio || audio.url) : undefined,
        thumbnailUrl: image,
        uploadDate: audioPost.created_at || audioPost.createdAt,
        author: {
          "@type": "Person",
          name: author.name,
          alternateName: author.username ? `@${author.username}` : undefined,
        },
      }),
    ],
  };
};

export const buildBlogSeo = (blog = {}, options = {}) => {
  const id = blog.slug || blog.id || options.blogId || options.id;
  const title = cleanText(blog.title || "GaonGram Blog");
  const canonical = getContentUrl(options.path || `/blogs/${id || ""}`);
  const contentImage = getSocialImage(
    blog.image ||
      blog.cover_image ||
      blog.cover ||
      blog.thumbnail ||
      blog.thumbnail_url ||
      blog.banner_image,
  );
  const generatedImage = ogImageUrl("blog", id, options.imageVersion || blog.updated_at);
  const image = preferEntityImage(contentImage, generatedImage);
  const author = blog.author || {};
  const description = truncateText(
    [
      blog.excerpt || blog.description || blog.summary || blog.content,
      `Read the full article and discussion on ${SEO_CONFIG.siteName}.`,
    ]
      .filter(Boolean)
      .join("\n\n") || `Read the full article and discussion on ${SEO_CONFIG.siteName}.`,
    300,
  );

  return {
    title: `${title} | ${SEO_CONFIG.siteName} Blogs`,
    description,
    canonical,
    ogUrl: canonical,
    ogImage: image,
    ogImageSecureUrl: image,
    ogImageAlt: cleanText(blog.image_alt_text || title),
    ogType: "article",
    image,
    article: {
      publishedTime: blog.created_at || blog.published_at,
      modifiedTime: blog.updated_at,
      author: author.username || author.name || author.full_name || blog.author_name,
      section: blog.category?.name || blog.category || "Blog",
      tags: blog.tags,
    },
    schema: [
      compactObject({
        "@context": "https://schema.org",
        "@type": "Article",
        headline: title,
        description,
        image,
        datePublished: blog.created_at || blog.published_at,
        dateModified: blog.updated_at,
        author: {
          "@type": "Person",
          name:
            author.full_name ||
            author.name ||
            author.username ||
            blog.author_name ||
            "GaonGram creator",
        },
        publisher: createOrganizationSchema(),
        mainEntityOfPage: canonical,
      }),
    ],
  };
};

export const buildPlaylistSeo = (playlist = {}, options = {}) => {
  const id = playlist.id || options.id;
  const title = cleanText(playlist.title || playlist.name || "GaonGram Playlist");
  const itemCount = firstPresentNumber(
    playlist.items?.length,
    playlist.items_count,
    playlist.tracks_count,
  );
  const canonical = getContentUrl(options.path || `/playlists/${id || ""}`);
  const contentImage = getSocialImage(
    playlist.cover_image ||
      playlist.cover ||
      playlist.image ||
      playlist.thumbnail ||
      playlist.artwork,
  );
  const generatedImage = ogImageUrl(
    "playlist",
    id,
    options.imageVersion || playlist.updated_at,
  );
  const image = preferEntityImage(contentImage, generatedImage);
  const description = truncateText(
    `${title} is a ${itemCount ? `${formatCount(itemCount)} track ` : ""}playlist on ${
      SEO_CONFIG.siteName
    }. Listen to saved audio and creator clips.`,
    220,
  );

  return {
    title: `${title} | ${SEO_CONFIG.siteName} Playlist`,
    description,
    canonical,
    ogUrl: canonical,
    ogImage: image,
    ogImageSecureUrl: image,
    ogImageAlt: `${title} playlist preview on ${SEO_CONFIG.siteName}`,
    ogType: "music.playlist",
    image,
    schema: [
      compactObject({
        "@context": "https://schema.org",
        "@type": "MusicPlaylist",
        name: title,
        description,
        image,
        url: canonical,
        numTracks: itemCount,
      }),
    ],
  };
};

export const buildHashtagSeo = (hashtag = {}, options = {}) => {
  const rawName = cleanText(
    hashtag.name || hashtag.display_name || options.tag || options.id || "",
  );
  const tagName = rawName.replace(/^#/, "");
  const displayName = tagName ? `#${tagName}` : "#GaonGram";
  const postCount = firstPresentNumber(
    hashtag.posts_count,
    hashtag.postCount,
    hashtag.count,
  );
  const canonical = getContentUrl(options.path || `/hashtags/${encodeURIComponent(tagName)}`);
  const description = truncateText(
    `Explore ${displayName} on ${SEO_CONFIG.siteName}${
      postCount ? ` with ${formatCount(postCount)} posts` : ""
    }. Discover related posts, reels, creators, and conversations.`,
    220,
  );
  const generatedImage = ogImageUrl("hashtag", tagName || "gaongram", options.imageVersion);
  const contentImage = getSocialImage(
    hashtag.image || hashtag.cover_image || hashtag.thumbnail || hashtag.preview_image,
  );
  const image = preferEntityImage(contentImage, generatedImage);

  return {
    title: `${displayName} posts, reels, and creators | ${SEO_CONFIG.siteName}`,
    description,
    canonical,
    ogUrl: canonical,
    ogImage: image,
    ogImageSecureUrl: image,
    ogImageAlt: `${displayName} on ${SEO_CONFIG.siteName}`,
    ogType: "website",
    schema: [
      compactObject({
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        name: `${displayName} on ${SEO_CONFIG.siteName}`,
        description,
        url: canonical,
      }),
    ],
  };
};

export const buildStorySeo = (story = {}, options = {}) => {
  const author = getPostAuthor(story, options.profile);
  const storyId = story.id || options.storyId || options.id || "";
  const canonical = getContentUrl(options.path || `/story/${storyId}`);
  const caption = getPostCaption(story);
  const image = getPostImage(story, author.image);
  const generatedImage = ogImageUrl("story", storyId, options.imageVersion || story.updated_at);
  const primaryImage = preferEntityImage(image, generatedImage);
  const description = truncateText(
    caption ||
      `View this story by ${author.name}${
        author.username ? ` (@${author.username})` : ""
      } on ${SEO_CONFIG.siteName}.`,
    220,
  );

  return {
    title: `Story by ${author.name} | ${SEO_CONFIG.siteName}`,
    description,
    canonical,
    ogUrl: canonical,
    ogImage: primaryImage,
    ogImageSecureUrl: primaryImage,
    ogImageAlt: `Story by ${author.name} on ${SEO_CONFIG.siteName}`,
    ogType: "article",
    image,
    noindex: options.noindex ?? true,
    robots: NOINDEX_ROBOTS,
    schema: [
      compactObject({
        "@context": "https://schema.org",
        "@type": "SocialMediaPosting",
        headline: `Story by ${author.name}`,
        articleBody: description,
        image: primaryImage,
        url: canonical,
        datePublished: story.created_at || story.createdAt,
        author: {
          "@type": "Person",
          name: author.name,
          alternateName: author.username ? `@${author.username}` : undefined,
        },
      }),
    ],
  };
};
