import { fabric } from "fabric";

const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
const DRAWING_TOOLS = new Set(["draw", "soft", "dashed", "dot", "watercolor", "watermark", "neon", "marker"]);
const PROCESSING_TOOLS = new Set(["blur", "pixel"]);
const ERASER_TOOLS = new Set(["eraser"]);
const SHAPE_TOOLS = new Set(["line", "arrow", "rectangle", "circle", "triangle", "hexagon", "dashedLine", "dottedLine"]);

const rgbaFromHex = (hex, alpha = 1) => {
  const value = String(hex || "#ffffff").replace("#", "");
  const normalized = value.length === 3
    ? value.split("").map((char) => char + char).join("")
    : value.padEnd(6, "f").slice(0, 6);
  const number = Number.parseInt(normalized, 16);
  return `rgba(${(number >> 16) & 255}, ${(number >> 8) & 255}, ${number & 255}, ${clamp(alpha, 0, 1)})`;
};

const pointerFromEvent = (canvas, event) => canvas.getPointer(event.e, false);

const rectIntersectsCircle = (rect, point, radius) => {
  const closestX = clamp(point.x, rect.left, rect.left + rect.width);
  const closestY = clamp(point.y, rect.top, rect.top + rect.height);
  return Math.hypot(point.x - closestX, point.y - closestY) <= radius;
};

export class PaintEngine {
  constructor({ engine, store }) {
    this.engine = engine;
    this.store = store;
    this.options = {
      color: "#ffffff",
      size: 12,
      opacity: 1,
      tool: "draw",
      fill: "transparent",
      strokeWidth: 4,
      blur: 8,
    };
    this.shapeState = null;
    this.rasterState = null;
    this.eraserState = null;
    this.cursorPreview = null;
    this.boundCanvas = null;
    this.lastTargetFind = null;
  }

  configure(options = {}) {
    this.options = { ...this.options, ...options };
    this.applyBrush();
  }

  enable(tool = this.options.tool) {
    this.configure({ tool });
    const canvas = this.engine?.canvas;
    if (!canvas) return;

    canvas.getElement().style.touchAction = "none";
    canvas.defaultCursor = "crosshair";
    canvas.hoverCursor = "crosshair";
    canvas.isDrawingMode = this.isDrawingTool(tool);
    canvas.selection = !this.isProcessingTool(tool) && !this.isEraserTool(tool);
    canvas.skipTargetFind = this.isProcessingTool(tool) || this.isEraserTool(tool);
    this.bindPointerEvents(canvas);

    if (this.isDrawingTool(tool)) {
      this.applyBrush();
    }
  }

  disable() {
    const canvas = this.engine?.canvas;
    if (!canvas) return;
    canvas.isDrawingMode = false;
    canvas.selection = true;
    canvas.skipTargetFind = false;
    this.removeShapePreview();
    this.removeCursorPreview();
    this.unbindPointerEvents(canvas);
  }

  isDrawingTool(tool) {
    return DRAWING_TOOLS.has(tool);
  }

  isProcessingTool(tool) {
    return PROCESSING_TOOLS.has(tool);
  }

  isEraserTool(tool) {
    return ERASER_TOOLS.has(tool);
  }

  isShapeTool(tool) {
    return SHAPE_TOOLS.has(tool);
  }

  isBrushTool(tool) {
    return this.isDrawingTool(tool) || this.isProcessingTool(tool) || this.isEraserTool(tool);
  }

  applyBrush() {
    const canvas = this.engine?.canvas;
    if (!canvas || !this.isDrawingTool(this.options.tool)) return;

    const { color, size, opacity, tool } = this.options;
    const width = clamp(size, 1, 140);
    const brush = new fabric.PencilBrush(canvas);
    brush.width = width;
    brush.color = color;
    brush.strokeLineCap = "round";
    brush.strokeLineJoin = "round";

    if (tool === "dashed") brush.strokeDashArray = [width * 2.2, width * 1.15];
    if (tool === "dot") brush.strokeDashArray = [0.1, width * 1.5];
    if (tool === "soft") {
      brush.color = rgbaFromHex(color, opacity * 0.46);
      brush.shadow = new fabric.Shadow({ color: rgbaFromHex(color, 0.8), blur: width * 2.25 });
    }
    if (tool === "watercolor" || tool === "watermark") {
      brush.width = width * 1.45;
      brush.color = rgbaFromHex(color, opacity * 0.26);
      brush.shadow = new fabric.Shadow({ color: rgbaFromHex(color, 0.34), blur: width * 0.8 });
    }
    if (tool === "neon") {
      brush.width = width * 0.75;
      brush.color = rgbaFromHex(color, 1);
      brush.shadow = new fabric.Shadow({ color, blur: width * 3.5 });
    }
    if (tool === "marker") {
      brush.width = width * 1.8;
      brush.color = rgbaFromHex(color, opacity * 0.38);
    }

    canvas.freeDrawingBrush = brush;
    canvas.off("path:created", this.handlePathCreated);
    canvas.on("path:created", this.handlePathCreated);
  }

  handlePathCreated = (event) => {
    const path = event.path;
    if (!path) return;
    const { color, opacity, tool, size } = this.options;

    path.set({
      opacity: tool === "soft" || tool === "watercolor" || tool === "watermark" || tool === "marker" ? 1 : opacity,
      objectCaching: false,
      name: "Drawing",
      selectable: true,
      evented: true,
    });

    if (tool === "neon") {
      path.clone((glow) => {
        glow.set({
          stroke: rgbaFromHex(color, 0.42),
          strokeWidth: (path.strokeWidth || size) * 2.6,
          shadow: new fabric.Shadow({ color, blur: size * 4 }),
          selectable: false,
          evented: false,
        });
        this.engine.canvas.insertAt(glow, Math.max(1, this.engine.canvas.getObjects().indexOf(path)), false);
        this.commitObject(glow, "neon glow", { recordHistory: false });
        this.engine.requestRender({ preview: true });
      });
    }

    this.commitObject(path, `${tool} brush`);
  };

  bindPointerEvents(canvas) {
    if (this.boundCanvas === canvas) return;
    this.boundCanvas = canvas;
    canvas.on("mouse:down", this.handlePointerDown);
    canvas.on("mouse:move", this.handlePointerMove);
    canvas.on("mouse:up", this.handlePointerUp);
  }

  unbindPointerEvents(canvas) {
    if (!canvas || this.boundCanvas !== canvas) return;
    canvas.off("mouse:down", this.handlePointerDown);
    canvas.off("mouse:move", this.handlePointerMove);
    canvas.off("mouse:up", this.handlePointerUp);
    this.boundCanvas = null;
  }

  armShape(type) {
    this.configure({ tool: type });
    const canvas = this.engine?.canvas;
    if (!canvas) return;
    canvas.isDrawingMode = false;
    canvas.selection = false;
    canvas.skipTargetFind = true;
    canvas.discardActiveObject();
    this.engine.requestRender({ preview: false });
  }

  addShape(type) {
    this.armShape(type);
    return null;
  }

  handlePointerDown = (event) => {
    const canvas = this.engine?.canvas;
    if (!canvas) return;

    if (this.isShapeTool(this.options.tool)) {
      this.beginShape(event);
      return;
    }

    if (this.isProcessingTool(this.options.tool)) {
      const point = pointerFromEvent(canvas, event);
      this.rasterState = { objects: [], lastPoint: null };
      this.addProcessingPatch(point, true);
      return;
    }

    if (this.isEraserTool(this.options.tool)) {
      const point = pointerFromEvent(canvas, event);
      this.eraserState = { didErase: false };
      this.eraseAt(point);
      this.updateCursorPreview(point);
    }
  };

  handlePointerMove = (event) => {
    const canvas = this.engine?.canvas;
    if (!canvas) return;

    if (this.isShapeTool(this.options.tool)) {
      this.updateShape(event);
      return;
    }

    if (this.isProcessingTool(this.options.tool) && this.rasterState) {
      this.addProcessingPatch(pointerFromEvent(canvas, event));
      return;
    }

    if (this.isEraserTool(this.options.tool)) {
      const point = pointerFromEvent(canvas, event);
      this.updateCursorPreview(point);
      if (this.eraserState) this.eraseAt(point);
    }
  };

  handlePointerUp = (event) => {
    if (this.isShapeTool(this.options.tool)) {
      this.finishShape(event);
      return;
    }

    if (this.isProcessingTool(this.options.tool)) {
      this.finishProcessingStroke();
      return;
    }

    if (this.isEraserTool(this.options.tool)) {
      this.eraserState = null;
      this.removeCursorPreview();
      this.engine?.requestRender({ preview: true });
    }
  };

  beginShape(event) {
    const canvas = this.engine?.canvas;
    if (!canvas) return;
    const start = pointerFromEvent(canvas, event);
    this.shapeState = {
      start,
      preview: this.createShapeObject(this.options.tool, start, start, true),
    };
    if (this.shapeState.preview) {
      canvas.add(this.shapeState.preview);
      canvas.setActiveObject(this.shapeState.preview);
      this.engine.requestRender({ preview: false });
    }
  }

  updateShape(event) {
    const canvas = this.engine?.canvas;
    if (!canvas || !this.shapeState?.preview) return;
    const end = pointerFromEvent(canvas, event);
    const replacement = this.createShapeObject(this.options.tool, this.shapeState.start, end, true);
    canvas.remove(this.shapeState.preview);
    this.shapeState.preview = replacement;
    if (replacement) {
      canvas.add(replacement);
      canvas.setActiveObject(replacement);
    }
    this.engine.requestRender({ preview: false });
  }

  finishShape(event) {
    const canvas = this.engine?.canvas;
    if (!canvas || !this.shapeState?.preview) return;
    const end = pointerFromEvent(canvas, event);
    const distance = Math.hypot(end.x - this.shapeState.start.x, end.y - this.shapeState.start.y);
    canvas.remove(this.shapeState.preview);
    this.shapeState.preview = null;

    if (distance >= 3) {
      const object = this.createShapeObject(this.options.tool, this.shapeState.start, end, false);
      if (object) {
        canvas.add(object);
        canvas.setActiveObject(object);
        this.commitObject(object, this.options.tool);
      }
    }

    this.shapeState = null;
    this.engine.requestRender({ preview: true });
  }

  addProcessingPatch(point, force = false) {
    const canvas = this.engine?.canvas;
    if (!canvas || !this.rasterState) return;

    const radius = clamp(this.options.size * 1.25, 6, 90);
    const lastPoint = this.rasterState.lastPoint;
    if (!force && lastPoint && Math.hypot(point.x - lastPoint.x, point.y - lastPoint.y) < radius * 0.42) return;

    const patch = this.createProcessedPatch(point, radius, this.options.tool);
    if (!patch) return;

    patch.set({
      selectable: false,
      evented: false,
      objectCaching: false,
      opacity: clamp(this.options.opacity, 0.1, 1),
      storyLayerType: "paint",
      __storyLayerType: "paint",
    });
    canvas.add(patch);
    this.rasterState.objects.push(patch);
    this.rasterState.lastPoint = point;
    this.engine.requestRender({ preview: false });
  }

  createProcessedPatch(point, radius, tool) {
    const sourceCanvas = this.createCompositeSnapshot();
    if (!sourceCanvas) return null;

    const size = Math.max(8, Math.round(radius * 2));
    const sourceX = clamp(Math.round(point.x - radius), 0, Math.max(0, sourceCanvas.width - size));
    const sourceY = clamp(Math.round(point.y - radius), 0, Math.max(0, sourceCanvas.height - size));
    const patchCanvas = document.createElement("canvas");
    patchCanvas.width = size;
    patchCanvas.height = size;
    const ctx = patchCanvas.getContext("2d");
    if (!ctx) return null;

    if (tool === "blur") {
      const blurRadius = clamp(this.options.size / 2, 3, 34);
      ctx.filter = `blur(${blurRadius}px)`;
      ctx.drawImage(sourceCanvas, sourceX, sourceY, size, size, 0, 0, size, size);
      ctx.filter = "none";
    } else {
      const blockSize = clamp(Math.round(this.options.size / 3), 3, 28);
      const lowWidth = Math.max(1, Math.ceil(size / blockSize));
      const lowHeight = Math.max(1, Math.ceil(size / blockSize));
      const lowCanvas = document.createElement("canvas");
      lowCanvas.width = lowWidth;
      lowCanvas.height = lowHeight;
      const lowCtx = lowCanvas.getContext("2d");
      lowCtx.imageSmoothingEnabled = false;
      lowCtx.drawImage(sourceCanvas, sourceX, sourceY, size, size, 0, 0, lowWidth, lowHeight);
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(lowCanvas, 0, 0, lowWidth, lowHeight, 0, 0, size, size);
    }

    ctx.globalCompositeOperation = "destination-in";
    ctx.beginPath();
    ctx.arc(size / 2, size / 2, radius, 0, Math.PI * 2);
    ctx.fillStyle = "#000";
    ctx.fill();
    ctx.globalCompositeOperation = "source-over";

    return new fabric.Image(patchCanvas, {
      left: sourceX,
      top: sourceY,
      originX: "left",
      originY: "top",
      width: size,
      height: size,
    });
  }

  createCompositeSnapshot() {
    const canvas = this.engine?.canvas;
    if (!canvas) return null;

    const snapshot = document.createElement("canvas");
    snapshot.width = canvas.getWidth();
    snapshot.height = canvas.getHeight();
    if (this.engine.getPrimaryVideoElement?.()) {
      this.engine.renderVideoCompositeFrame?.(snapshot);
      return snapshot;
    }

    canvas.discardActiveObject();
    canvas.renderAll();
    snapshot.getContext("2d")?.drawImage(canvas.getElement(), 0, 0, snapshot.width, snapshot.height);
    return snapshot;
  }

  finishProcessingStroke() {
    const canvas = this.engine?.canvas;
    const objects = this.rasterState?.objects || [];
    this.rasterState = null;
    if (!canvas || !objects.length) return;

    let object = objects[0];
    if (objects.length > 1) {
      objects.forEach((item) => canvas.remove(item));
      object = new fabric.Group(objects, {
        objectCaching: false,
        selectable: true,
        evented: true,
      });
      canvas.add(object);
    } else {
      object.set({ selectable: true, evented: true });
    }

    canvas.setActiveObject(object);
    this.commitObject(object, `${this.options.tool} brush`);
  }

  eraseAt(point) {
    const canvas = this.engine?.canvas;
    if (!canvas) return;
    const radius = clamp(this.options.size, 4, 120);
    const candidates = canvas.getObjects().filter((object) =>
      object !== this.cursorPreview &&
      object.storyLayerType === "paint" &&
      object.visible !== false,
    );

    candidates.forEach((object) => {
      const rect = object.getBoundingRect(true, true);
      if (!rectIntersectsCircle(rect, point, radius)) return;
      if (object.layerId) {
        this.engine.objectMap.delete(object.layerId);
        this.store.getState().removeLayer(object.layerId, { recordHistory: true, force: true });
      }
      canvas.remove(object);
      this.eraserState = { ...(this.eraserState || {}), didErase: true };
    });
    this.engine.requestRender({ preview: true });
  }

  updateCursorPreview(point) {
    const canvas = this.engine?.canvas;
    if (!canvas) return;
    const radius = clamp(this.options.size, 4, 120);
    if (!this.cursorPreview) {
      this.cursorPreview = new fabric.Circle({
        radius,
        fill: "rgba(255,255,255,0.08)",
        stroke: "rgba(255,255,255,0.82)",
        strokeWidth: 1,
        selectable: false,
        evented: false,
        excludeFromExport: true,
        objectCaching: false,
      });
      canvas.add(this.cursorPreview);
    }
    this.cursorPreview.set({
      left: point.x - radius,
      top: point.y - radius,
      radius,
    });
    canvas.bringToFront(this.cursorPreview);
    this.engine.requestRender({ preview: false });
  }

  removeCursorPreview() {
    const canvas = this.engine?.canvas;
    if (canvas && this.cursorPreview) {
      canvas.remove(this.cursorPreview);
    }
    this.cursorPreview = null;
  }

  removeShapePreview() {
    const canvas = this.engine?.canvas;
    if (canvas && this.shapeState?.preview) {
      canvas.remove(this.shapeState.preview);
    }
    this.shapeState = null;
  }

  createShapeObject(type, start, end, preview = false) {
    const common = {
      fill: this.options.fill === "transparent" ? "rgba(255,255,255,0)" : this.options.fill,
      stroke: this.options.color,
      strokeWidth: clamp(this.options.strokeWidth, 1, 80),
      opacity: preview ? Math.min(0.72, this.options.opacity) : this.options.opacity,
      objectCaching: false,
      selectable: !preview,
      evented: !preview,
      strokeLineCap: "round",
      strokeLineJoin: "round",
    };
    const left = Math.min(start.x, end.x);
    const top = Math.min(start.y, end.y);
    const width = Math.abs(end.x - start.x);
    const height = Math.abs(end.y - start.y);

    if (type === "line" || type === "dashedLine" || type === "dottedLine") {
      return new fabric.Line([start.x, start.y, end.x, end.y], {
        ...common,
        fill: undefined,
        strokeDashArray: type === "dashedLine" ? [common.strokeWidth * 4, common.strokeWidth * 2] : type === "dottedLine" ? [0.1, common.strokeWidth * 2] : undefined,
      });
    }
    if (type === "arrow") return this.createArrow(start, end, common, preview);
    if (type === "rectangle") {
      return new fabric.Rect({ ...common, left, top, width: Math.max(1, width), height: Math.max(1, height), rx: 8, ry: 8 });
    }
    if (type === "circle") {
      return new fabric.Ellipse({ ...common, left, top, rx: Math.max(1, width / 2), ry: Math.max(1, height / 2) });
    }
    if (type === "triangle") {
      return new fabric.Triangle({ ...common, left, top, width: Math.max(1, width), height: Math.max(1, height) });
    }
    if (type === "hexagon") {
      return new fabric.Polygon(this.createPolygonPoints(6, Math.max(1, width / 2), Math.max(1, height / 2)), {
        ...common,
        left: left + width / 2,
        top: top + height / 2,
        originX: "center",
        originY: "center",
      });
    }
    return null;
  }

  createArrow(start, end, common, preview) {
    const angle = Math.atan2(end.y - start.y, end.x - start.x);
    const length = Math.max(1, Math.hypot(end.x - start.x, end.y - start.y));
    const line = new fabric.Line([0, 0, length, 0], {
      stroke: common.stroke,
      strokeWidth: common.strokeWidth,
      strokeLineCap: "round",
    });
    const head = new fabric.Triangle({
      left: length,
      top: 0,
      width: common.strokeWidth * 4.5,
      height: common.strokeWidth * 4.5,
      fill: common.stroke,
      angle: 90,
      originX: "center",
      originY: "center",
    });
    return new fabric.Group([line, head], {
      left: start.x,
      top: start.y,
      angle: (angle * 180) / Math.PI,
      originX: "left",
      originY: "center",
      opacity: common.opacity,
      objectCaching: false,
      selectable: !preview,
      evented: !preview,
    });
  }

  createPolygonPoints(sides, radiusX, radiusY = radiusX) {
    return Array.from({ length: sides }, (_, index) => {
      const angle = (Math.PI * 2 * index) / sides - Math.PI / 2;
      return {
        x: Math.cos(angle) * radiusX,
        y: Math.sin(angle) * radiusY,
      };
    });
  }

  commitObject(object, name = "Paint", options = {}) {
    if (!object) return;
    const layerId = object.layerId || this.store.getState().createLayerId("paint");
    object.set({
      layerId,
      storyLayerType: "paint",
      __storyLayerType: "paint",
      name,
      selectable: object.selectable !== false,
      evented: object.evented !== false,
    });
    object.setCoords();
    this.engine.objectMap.set(layerId, object);
    this.store.getState().addLayer(
      {
        id: layerId,
        type: "paint",
        name,
        left: object.left,
        top: object.top,
        scaleX: object.scaleX,
        scaleY: object.scaleY,
        rotation: object.angle || 0,
        opacity: object.opacity,
      },
      { recordHistory: options.recordHistory !== false },
    );
    this.engine.requestRender({ preview: true });
  }
}

export default PaintEngine;
