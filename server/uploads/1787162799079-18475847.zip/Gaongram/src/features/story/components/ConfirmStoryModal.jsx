import React, { useState } from "react";
import { useUIStore } from "../../../store/uiStore";

const ConfirmStoryModal = ({
  title,
  message,
  confirmText = "Confirm",
  cancelText = "Cancel",
  onConfirm,
  type = "default",
}) => {
  const { closeModal } = useUIStore();
  const [loading, setLoading] = useState(false);

  const handleConfirm = async () => {
    try {
      setLoading(true);
      await onConfirm?.();
      closeModal(); 
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-900 rounded-xl p-6 w-full max-w-md shadow-xl">
      <h2 className="text-lg font-semibold mb-2">{title}</h2>
      <p className="text-sm text-gray-500 mb-6">{message}</p>

      <div className="flex justify-end gap-3">
        <button
          onClick={closeModal}
          className="px-4 py-2 rounded-lg bg-gray-200 dark:bg-gray-700"
        >
          {cancelText}
        </button>

        <button
          onClick={handleConfirm}
          disabled={loading}
          className={`px-4 py-2 rounded-lg text-white ${
            type === "danger" ? "bg-red-600" : "bg-primary"
          }`}
        >
          {loading ? "Deleting..." : confirmText}
        </button>
      </div>
    </div>
  );
};

export default ConfirmStoryModal;