// FrameTool.jsx
import React from "react";
import { Check, Crop, Square } from "lucide-react";
import { useCanvasStore } from "../useCanvasStore.js";
import { ASPECT_RATIOS, FRAME_OPTIONS } from "../utils/filterPresets.js";

const FrameTool = () => {
  const aspectRatio = useCanvasStore((state) => state.aspectRatio);
  const frame = useCanvasStore((state) => state.frame);
  const setAspectRatio = useCanvasStore((state) => state.setAspectRatio);
  const setFrame = useCanvasStore((state) => state.setFrame);

  return (
    <div className="space-y-2">
      <div className="rounded-lg border border-border dark:border-border-dark bg-card dark:bg-card-dark px-3 py-1">
        <p className="flex items-center gap-2 text-sm font-semibold text-foreground dark:text-foreground-dark">
          <Crop size={18} />
          Aspect ratio
        </p>
        <div className="mt-2 grid grid-cols-5 gap-2">
          {Object.values(ASPECT_RATIOS).map((item) => (
            <button
              key={item.label}
              type="button"
              onClick={() => setAspectRatio(item.label)}
              className={`rounded-lg border px-3 py-2 text-sm font-semibold transition ${
                aspectRatio === item.label
                  ? "border-primary bg-primary text-white"
                  : "border-border dark:border-border-dark bg-gray-100 dark:bg-muted-dark text-foreground dark:text-foreground-dark hover:bg-background dark:hover:bg-background-dark"
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-lg border border-border dark:border-border-dark bg-card dark:bg-card-dark px-3 py-2">
        <p className="flex items-center gap-2 text-sm font-semibold text-foreground dark:text-foreground-dark">
          <Square size={16} />
          Frame overlay
        </p>
        <div className="mt-2 grid grid-cols-3 gap-2">
          {FRAME_OPTIONS.map((option) => {
            const selected = (frame || "none") === option.id;
            return (
              <button
                key={option.id}
                type="button"
                onClick={() =>
                  setFrame(option.id === "none" ? null : option.id)
                }
                className={`relative overflow-hidden rounded-lg border px-2 py-1 text-left transition ${
                  selected
                    ? "border-primary bg-primary/10 dark:bg-primary/20"
                    : "border-border dark:border-border-dark bg-gray-100 dark:bg-muted-dark text-foreground dark:text-foreground-dark hover:bg-background dark:hover:bg-background-dark"
                }`}
              >
                <span className="block text-xs font-semibold">
                  {option.label}
                </span>
                <span
                  className="mt-1 block h-10 rounded-lg border"
                  style={{
                    borderColor: option.stroke || "rgba(255,255,255,0.18)",
                    borderWidth: option.id === "film" ? 2 : 2,
                    boxShadow: option.shadow
                      ? "0 0 18px rgba(225,48,108,0.55)"
                      : "none",
                  }}
                />
                {selected && (
                  <span className="absolute right-2 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-white">
                    <Check size={12} />
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default React.memo(FrameTool);
