import React, { useState, useEffect, useCallback, useRef } from "react";
import { AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { notificationService } from "../../services/notification.service.js";
import NotificationCard from "./NotificationCard";
import Loader from "../../components/common/Loader.jsx";
import EmptyState from "../../components/common/EmptyState.jsx";
import { showToast } from "../../utils/toast.js";
import Seo from "../../components/seo/Seo.jsx";
import { buildStaticPageSeo } from "../../seo/seoBuilders.js";

const NotificationList = () => {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState([]);
  const [nextUrl, setNextUrl] = useState(null);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [error, setError] = useState(null);

  const sentinelRef = useRef(null);

  const updateNotification = useCallback((updatedNotification) => {
    setNotifications((prev) =>
      prev.map((n) =>
        n.id === updatedNotification.id ? updatedNotification : n,
      ),
    );
  }, []);

  const removeNotification = useCallback((id) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const adjustUnreadCount = useCallback((delta) => {
    setUnreadCount((prev) => Math.max(0, prev + delta));
  }, []);

  useEffect(() => {
    const fetchInitial = async () => {
      setLoading(true);
      setError(null);
      try {
        const count = await notificationService.getUnreadCount();
        setUnreadCount(count);

        const data = await notificationService.getNotifications();
        setNotifications(data.results || []);
        setNextUrl(data.next);
        setHasMore(!!data.next);

        const unreadIds = data.results
          .filter((n) => !n.is_read)
          .map((n) => n.id);

        if (unreadIds.length > 0) {
          await notificationService.markAsRead(unreadIds);

          // instantly update UI
          setNotifications((prev) =>
            prev.map((n) => ({
              ...n,
              is_read: true,
            })),
          );

          setUnreadCount(0);

          window.dispatchEvent(new CustomEvent("notifications-read"));
        }
      } catch (err) {
        console.error("Failed to load notifications:", err);
        setError(err.message || "Failed to load notifications");
        showToast("Failed to load notifications", "error");
      } finally {
        setLoading(false);
      }
    };

    fetchInitial();
  }, []);

  const fetchMore = useCallback(async () => {
    if (!nextUrl || loadingMore) return;

    try {
      setLoadingMore(true);

      const data = await notificationService.getNotifications(nextUrl);

      setNotifications((prev) => {
        const existingIds = new Set(prev.map((n) => n.id));

        const uniqueNew = (data.results || []).filter(
          (n) => !existingIds.has(n.id),
        );

        return [...prev, ...uniqueNew];
      });

      setNextUrl(data.next || null);

      setHasMore(Boolean(data.next));
    } catch (err) {
      console.error("Failed to load more notifications:", err);

      showToast("Failed to load more notifications", "error");
    } finally {
      setLoadingMore(false);
    }
  }, [nextUrl, loadingMore]);

  useEffect(() => {
    const current = sentinelRef.current;

    if (!current) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const first = entries[0];

        if (first.isIntersecting && hasMore && !loadingMore && nextUrl) {
          fetchMore();
        }
      },
      {
        root: null,
        rootMargin: "300px",
        threshold: 0,
      },
    );

    observer.observe(current);

    return () => {
      observer.disconnect();
    };
  }, [fetchMore, hasMore, loadingMore, nextUrl]);

  const handleNotificationClick = (notification) => {
    if (
      notification.notification_type === "follow" ||
      notification.notification_type === "follow_request"
    ) {
      navigate(`/profile/${notification.sender_username}`);
    } else if (
      ["like", "comment", "post"].includes(notification.notification_type)
    ) {
      const postId = notification.data?.post_id;

      if (postId) {
        navigate(`/vibe-feed/${postId}`);
      }
    }
  };

  if (loading) {
    return (
      <>
        <Seo {...buildStaticPageSeo("notifications")} />
        <div className="min-h-screen bg-gray-50 dark:bg-background-dark pt-20">
          <div className="max-w-3xl mx-auto px-4">
            <Loader fullScreen={false} text="Loading notifications..." />
          </div>
        </div>
      </>
    );
  }

  if (error) {
    return (
      <>
        <Seo {...buildStaticPageSeo("notifications")} />
        <div className="min-h-screen bg-gray-50 dark:bg-background-dark pt-20">
          <div className="max-w-3xl mx-auto px-4">
            <EmptyState
              icon="alert-circle"
              title="Error loading notifications"
              description={error}
              action={
                <button
                  onClick={() => window.location.reload()}
                  className="px-4 py-2 bg-instagram-pink text-white rounded-lg"
                >
                  Retry
                </button>
              }
            />
          </div>
        </div>
      </>
    );
  }

  if (notifications.length === 0) {
    return (
      <>
        <Seo {...buildStaticPageSeo("notifications")} />
        <div className="min-h-screen bg-gray-50 dark:bg-background-dark pt-20">
          <div className="max-w-3xl mx-auto px-4">
            <EmptyState
              icon="bell"
              title="No notifications"
              description="You don't have any notifications yet."
            />
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Seo {...buildStaticPageSeo("notifications")} />
      <div className="min-h-screen bg-gray-50 dark:bg-background-dark">
        <div className="max-w-3xl mx-auto lg:px-4 lg:py-4">
          {/* Simple header */}
          <div className="mb-6 px-4">
            <h1 className="text-2xl font-bold text-foreground dark:text-foreground-dark">
              Notifications
            </h1>
            <p className="text-mutedForeground dark:text-mutedForeground-dark">
              {unreadCount > 0 ? `${unreadCount} unread` : "All caught up!"}
            </p>
          </div>

          {/* Flat list with dividers */}
          <div className="divide-y divide-gray-100 dark:divide-gray-800">
            <AnimatePresence>
              {notifications.map((notification) => (
                <NotificationCard
                  key={notification.id}
                  notification={notification}
                  onClick={handleNotificationClick}
                  onUpdateNotification={updateNotification}
                  onRemoveNotification={removeNotification}
                  onUnreadCountChange={adjustUnreadCount}
                />
              ))}
            </AnimatePresence>
          </div>

          {hasMore && (
            <div
              ref={sentinelRef}
              className=" h-24 flex items-center justify-center"
            >
              {loadingMore && <Loader size="small" />}
            </div>
          )}

          {!hasMore && notifications.length > 0 && (
            <p className="text-center text-mutedForeground dark:text-mutedForeground-dark text-sm py-8">
              You've seen all notifications
            </p>
          )}
        </div>
      </div>
    </>
  );
};

export default NotificationList;
