import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion as Motion } from "framer-motion";
import { Check, Download, Eye, Loader2, RotateCcw, Save, Undo2, X } from "lucide-react";
import { useCanvasStore } from "../../story/editor/useCanvasStore.js";
import EditorSidebar from "../../story/editor/components/EditorSidebar.jsx";
import { storyAudioManager } from "../../story/audio/storyAudioManager.js";
import { downloadExportedStory } from "../../story/editor/utils/exportStory.js";
import {
  createPreviewUnavailableDataUrl,
  validateCanvasExportSafety,
} from "../../story/editor/engine/helpers/dom.js";
import { getEditorConfig } from "../core/editorConfig.js";
import ExportManager from "../core/ExportManager.js";
import SharedCanvas from "../components/SharedCanvas.jsx";
import SharedToolbar from "../components/SharedToolbar.jsx";
import ExportLoader from "../components/ExportLoader.jsx";
import useCanvas from "../hooks/useCanvas.js";
import MusicMarquee from "../../../components/music/MusicMarquee.jsx";

const isTypingTarget = (target) => {
  const tagName = target?.tagName?.toLowerCase();
  return tagName === "input" || tagName === "textarea" || target?.isContentEditable;
};

const StoryPreview = ({ imageUrl, music, onClose }) => {
  const previewDuration = music?.duration || 7;

  useEffect(() => {
    if (!music?.audio) return undefined;
    storyAudioManager.playSegment(music, { loop: true, volume: 0.85 });
    return () => storyAudioManager.pause();
  }, [music]);

  return (
    <Motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[70] overflow-hidden bg-black">
      <div className="absolute left-3 right-3 top-[calc(env(safe-area-inset-top)+0.75rem)] z-10 flex gap-1 sm:left-4 sm:right-4">
        <div className="h-1 flex-1 overflow-hidden rounded-full bg-white/25">
          <Motion.div className="h-full rounded-full bg-white" initial={{ width: "0%" }} animate={{ width: "100%" }} transition={{ duration: previewDuration, ease: "linear" }} />
        </div>
      </div>
      <button type="button" onClick={onClose} className="absolute right-3 top-[calc(env(safe-area-inset-top)+1.25rem)] z-20 flex h-11 w-11 items-center justify-center rounded-full bg-black/35 text-white backdrop-blur-xl transition hover:bg-white/10 sm:right-4" aria-label="Close preview">
        <X size={22} />
      </button>
      <div className="flex h-[100dvh] min-h-[100svh] items-center justify-center">
        <div className="relative h-full w-full max-w-[430px] overflow-hidden bg-black shadow-2xl landscape:max-w-none">
          {imageUrl && <img src={imageUrl} alt="" className="h-full w-full object-contain" />}
          {music && (
            <div className="absolute bottom-[calc(env(safe-area-inset-bottom)+1rem)] left-3 right-3 flex items-center gap-3 rounded-[18px] border border-white/20 bg-black/45 px-3 py-2.5 text-white shadow-2xl backdrop-blur-xl sm:left-4 sm:right-4">
              <div className="h-12 w-12 shrink-0 overflow-hidden rounded-full bg-white/15">
                {music.cover_image ? <img src={music.cover_image} alt="" className="h-full w-full object-cover" /> : <div className="h-full w-full rounded-full bg-gradient-to-br from-viral-pink to-viral-purple" />}
              </div>
              <MusicMarquee
                title={music.title}
                artist={music.artist}
                className="min-w-0 flex-1 text-white"
                textClassName="text-sm font-semibold"
              />
            </div>
          )}
        </div>
      </div>
    </Motion.div>
  );
};

const getExtension = (file, fallback = "jpg") => {
  if (file?.type?.includes("video")) return "webm";
  if (file?.type?.includes("png")) return "png";
  return fallback;
};

const UnifiedCanvasEditor = ({
  file,
  mode = "story",
  config: configProp,
  onCancel,
  onExport,
  isUploading = false,
  uploadProgress = 0,
  error = "",
}) => {
  const config = useMemo(() => getEditorConfig({ mode, ...configProp }), [configProp, mode]);
  const exportLockRef = useRef(false);
  const [engineError, setEngineError] = useState("");
  const [activeTool, setActiveTool] = useState(config.defaultTool || "text");
  const [previewUrl, setPreviewUrl] = useState(null);
  const [previewMode, setPreviewMode] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [exportMessage, setExportMessage] = useState("");

  const revision = useCanvasStore((state) => state.revision);
  const activeLayerId = useCanvasStore((state) => state.activeLayerId);
  const aspectRatio = useCanvasStore((state) => state.aspectRatio);
  const layers = useCanvasStore((state) => state.layers);
  const music = useCanvasStore((state) => state.music);
  const past = useCanvasStore((state) => state.past);
  const future = useCanvasStore((state) => state.future);
  const undo = useCanvasStore((state) => state.undo);
  const redo = useCanvasStore((state) => state.redo);

  const handlePreviewChange = useCallback((url) => setPreviewUrl(url), []);
  const handleCanvasError = useCallback((err) => setEngineError(err?.message || "Canvas error"), []);
  const { canvasRef, engine, isReady } = useCanvas({
    file,
    store: useCanvasStore,
    config,
    aspectRatio: config.aspectRatio,
    onPreviewChange: handlePreviewChange,
    onError: handleCanvasError,
  });

  const activeLayerName = useMemo(
    () => layers.find((layer) => layer.id === activeLayerId)?.name || "Canvas",
    [activeLayerId, layers],
  );

  useEffect(() => {
    engine?.syncFromStore();
  }, [engine, revision]);

  useEffect(() => {
    const handler = (event) => {
      if (isTypingTarget(event.target)) return;
      const isModifier = event.ctrlKey || event.metaKey;
      if (event.key === "Delete" || event.key === "Backspace") {
        event.preventDefault();
        engine?.deleteActiveLayer();
      }
      if (isModifier && event.key.toLowerCase() === "z") {
        event.preventDefault();
        if (event.shiftKey) redo();
        else undo();
      }
    };

    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [engine, redo, undo]);

  useEffect(() => () => storyAudioManager.stop(), []);

  const capturePreview = () => {
    const canvas = engine?.canvas;
    if (!canvas) return;
    canvas.discardActiveObject();
    engine.applyFiltersToAll({ preview: false, immediate: true, rebuild: true });
    engine.requestRender({ preview: false, immediate: true });
    try {
      const safety = validateCanvasExportSafety(canvas);
      if (!safety.safe) throw safety.error || new Error("Preview canvas is not export-safe");
      setPreviewUrl(canvas.toDataURL({ format: "jpeg", quality: 0.86, multiplier: 1 }));
    } catch (error) {
      console.error("[StoryEditor] Preview export failed", error);
      setPreviewUrl(createPreviewUnavailableDataUrl(canvas.getWidth(), canvas.getHeight()));
    }
    setPreviewMode(true);
  };

  const buildFileName = (extension = getExtension(file)) => {
    const baseName = (file?.name || config.outputType || "media").replace(/\.[^.]+$/, "").slice(0, 80);
    return `${baseName}-edited.${extension}`;
  };

  const handleExport = async (exportMode) => {
    if (!engine?.canvas || exportLockRef.current || isExporting || isUploading) return;

    exportLockRef.current = true;
    setIsExporting(true);
    setExportProgress(4);
    setExportMessage("Preparing media...");
    setEngineError("");

    try {
      const manager = new ExportManager({ engine, store: useCanvasStore, config });
      const state = useCanvasStore.getState();
      const baseLayer = state.layers.find((layer) => layer.type === "base");
      const extension = baseLayer?.mediaType === "video" || state.music?.audio ? "mp4" : "jpg";
      const exported = await manager.export({
        fileName: buildFileName(extension),
        onProgress: ({ progress, message }) => {
          setExportProgress(progress);
          if (message) setExportMessage(message);
        },
      });

      if (exportMode === "download") {
        downloadExportedStory({ blob: exported.blob, fileName: exported.file.name });
        if (exported.previewUrl?.startsWith("blob:")) URL.revokeObjectURL(exported.previewUrl);
      } else {
        storyAudioManager.stop();
        setExportProgress(85);
        setExportMessage(config.mode === "post" ? "Saving..." : "Uploading...");
        await onExport?.({
          file: exported.file,
          previewUrl: exported.previewUrl || exported.dataUrl,
          storyType: exported.storyType || (exported.file.type.startsWith("video/") ? "video" : "image"),
          metadata: {
            aspectRatio,
            frame: state.frame,
            filters: state.filters,
            music: state.music
              ? {
                  id: state.music.id,
                  title: state.music.title,
                  artist: state.music.artist,
                  cover_image: state.music.cover_image,
                  audio: state.music.audio,
                  startTime: state.music.startTime,
                  duration: state.music.duration,
                  sourceDuration: state.music.sourceDuration,
                }
              : null,
            layers: state.layers.map(({ id, type, name, text, style, filters, zIndex }) => ({
              id,
              type,
              name,
              text,
              style,
              filters,
              zIndex,
            })),
          },
        });
      }
    } catch (err) {
      setEngineError(err?.message || "Export failed");
    } finally {
      exportLockRef.current = false;
      setIsExporting(false);
      setExportProgress(0);
      setExportMessage("");
    }
  };

  const isBusy = isExporting || isUploading;
  const progress = isUploading ? 85 + uploadProgress * 0.15 : exportProgress;
  const title = config.title || (config.mode === "post" ? "Edit post media" : "Create story");

  return (
    <AnimatePresence>
      <Motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[60] h-[100dvh] min-h-[100svh] overflow-hidden overscroll-none bg-background text-foreground dark:bg-background-dark dark:text-foreground-dark">
        <div className="relative flex h-full min-h-0 flex-col">
          <header className="shrink-0 border-b border-border px-2 py-2 pt-[calc(env(safe-area-inset-top)+0.5rem)] backdrop-blur-xl dark:border-border-dark sm:px-4">
            <div className="flex min-h-12 items-center justify-between gap-2">
            <div className="flex min-w-0 items-center gap-2 sm:gap-3">
              <button type="button" onClick={onCancel} disabled={isBusy} className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-muted text-foreground transition hover:bg-border disabled:opacity-50 dark:bg-muted-dark dark:text-foreground-dark dark:hover:bg-muted-dark" aria-label="Close editor">
                <X size={20} />
              </button>
              <div className="min-w-0 max-w-[28vw] min-[380px]:max-w-[38vw] sm:max-w-[18rem]">
                <h1 className="truncate text-base font-semibold">{title}</h1>
                <p className="truncate text-xs text-mutedForeground dark:text-mutedForeground-dark">{activeLayerName}</p>
              </div>
            </div>

            <div className="flex shrink-0 items-center gap-1 sm:gap-2">
              <button type="button" onClick={undo} disabled={!past.length || isBusy} className="hidden h-10 w-10 items-center justify-center rounded-full bg-muted text-foreground transition hover:bg-border disabled:opacity-35 dark:bg-muted-dark dark:text-foreground-dark sm:flex" aria-label="Undo" title="Undo">
                <Undo2 size={20} />
              </button>
              <button type="button" onClick={redo} disabled={!future.length || isBusy} className="hidden h-10 w-10 items-center justify-center rounded-full bg-muted text-foreground transition hover:bg-border disabled:opacity-35 dark:bg-muted-dark dark:text-foreground-dark sm:flex" aria-label="Redo" title="Redo">
                <RotateCcw size={20} />
              </button>
              {config.mode === "story" && (
                <>
                  <button type="button" onClick={capturePreview} disabled={!isReady || isBusy} className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-muted text-foreground transition hover:bg-border disabled:opacity-35 dark:bg-muted-dark dark:text-foreground-dark sm:w-auto sm:px-3" aria-label="Preview" title="Preview">
                    <Eye size={20} />
                    <span className="ml-2 hidden text-md font-semibold sm:inline">Preview</span>
                  </button>
                  <button type="button" onClick={() => handleExport("download")} disabled={!isReady || isBusy} className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-muted text-foreground transition hover:bg-border disabled:opacity-35 dark:bg-muted-dark dark:text-foreground-dark sm:w-auto sm:px-3" aria-label="Download" title="Download">
                    <Download size={20} />
                    <span className="ml-2 hidden text-md font-semibold sm:inline">Download</span>
                  </button>
                </>
              )}
              <button type="button" onClick={() => handleExport("save")} disabled={!isReady || isBusy} className="flex h-10 shrink-0 items-center justify-center gap-2 rounded-full bg-primary px-3 text-sm font-semibold text-white shadow-lg transition hover:bg-primary-light disabled:opacity-50 sm:text-md">
                {isBusy ? <Loader2 size={20} className="animate-spin" /> : <Save size={20} />}
                <span className="hidden min-[380px]:inline">{isUploading ? "Uploading" : config.mode === "post" ? "Save" : "Upload"}</span>
              </button>
            </div>
            </div>
          </header>

          {(engineError || error) && (
            <div className="mx-3 mt-3 rounded-2xl border border-red-400/30 bg-red-500/10 px-4 py-2 text-sm text-red-400 sm:mx-5">
              {engineError || error}
            </div>
          )}

          <ExportLoader visible={isExporting || isUploading} progress={progress} message={isUploading ? "Uploading..." : exportMessage || "Preparing media..."} />

          <main className="grid min-h-0 flex-1 grid-rows-[minmax(0,1fr)_auto_minmax(11rem,38dvh)] gap-2 overflow-hidden p-2 pb-[calc(env(safe-area-inset-bottom)+0.5rem)] sm:gap-3 sm:p-3 md:grid-cols-[4.75rem_minmax(0,1fr)_minmax(19rem,25rem)] md:grid-rows-1 md:p-4 lg:grid-cols-[5rem_minmax(0,1fr)_25rem] xl:grid-cols-[5.25rem_minmax(0,1fr)_26rem]">
            <div className="order-2 min-w-0 md:order-1 md:flex md:min-h-0 md:items-center md:justify-center">
              <SharedToolbar activeTool={activeTool} onToolChange={setActiveTool} features={config.features} />
            </div>

            <SharedCanvas ref={canvasRef} isReady={isReady} className="order-1 h-full md:order-2" />

            <div className="order-3 min-h-0 md:order-3">
              <EditorSidebar activeTool={activeTool} engine={engine} />
            </div>
          </main>

          {isUploading && uploadProgress === 100 && (
            <Motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="absolute bottom-5 left-1/2 flex -translate-x-1/2 items-center gap-2 rounded-full bg-success px-4 py-2 text-sm font-semibold text-white shadow-lg">
              <Check size={17} />
              Upload complete
            </Motion.div>
          )}
        </div>

        <AnimatePresence>
          {previewMode && <StoryPreview imageUrl={previewUrl} music={music} onClose={() => setPreviewMode(false)} />}
        </AnimatePresence>
      </Motion.div>
    </AnimatePresence>
  );
};

export default UnifiedCanvasEditor;
