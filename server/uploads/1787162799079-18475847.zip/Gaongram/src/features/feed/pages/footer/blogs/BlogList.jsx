// src/features/blogs/pages/BlogList.jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import Button from "../../../../../components/common/Button";
import BlogCard from "./BlogCard";
import BlogSkeleton from "./BlogSkeleton";
import { useBlogs } from "../../../../../hooks/useBlogs";
import { showSuccess, showError } from "../../../../../utils/toast";
import blogService from "../../../../../services/blogService";
import PublicLayout from "../../../components/layout/PublicLayout";
import Seo from "../../../../../components/seo/Seo.jsx";
import { buildStaticPageSeo } from "../../../../../seo/seoBuilders.js";

const BlogList = () => {
  const navigate = useNavigate();
  const { blogs, loading, pagination, goToPage, refetch } = useBlogs({ page: 1 });
  const [deletingId, setDeletingId] = useState(null);

  const handleDelete = async (id) => {
    setDeletingId(id);
    try {
      const response = await blogService.deleteBlog(id);
      if (response.success) {
        showSuccess("Blog deleted successfully");
        refetch();
      }
    } catch (error) {
      showError(error.message || "Failed to delete blog");
    } finally {
      setDeletingId(null);
    }
  };

  const handleCreateNew = () => {
    navigate("/blogs/create");
  };

  if (loading) {
    return (
      <>
        <Seo {...buildStaticPageSeo("blogs")} />
        <div className="container mx-auto px-4 py-8 max-w-7xl">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold">Blogs</h1>
            <Button onClick={handleCreateNew}>Create New Blog</Button>
          </div>
          <BlogSkeleton />
        </div>
      </>
    );
  }

  if (!blogs.length) {
    return (
      <PublicLayout>
        <Seo {...buildStaticPageSeo("blogs")} />
        <div className="container mx-auto px-4 py-8 max-w-7xl">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Blogs</h1>
          <Button onClick={handleCreateNew}>Create New Blog</Button>
        </div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-16 bg-card dark:bg-card-dark rounded-xl2 shadow-soft"
        >
          <div className="text-6xl mb-4">📭</div>
          <h3 className="text-xl font-semibold mb-2">No blogs yet</h3>
          <p className="text-mutedForeground dark:text-mutedForeground-dark mb-6">
            Get started by creating your first blog post.
          </p>
          <Button onClick={handleCreateNew}>Create Blog</Button>
        </motion.div>
      </div>
      </PublicLayout>
    );
  }

  return (
    <PublicLayout>
      <Seo {...buildStaticPageSeo("blogs")} />
      <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-viral-pink bg-clip-text text-transparent">
          Blogs
        </h1>
        <Button onClick={handleCreateNew}>+ Create New Blog</Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {blogs.map((blog) => (
          <BlogCard
            key={blog.id}
            blog={blog}
            onDelete={handleDelete}
            isDeleting={deletingId === blog.id}
          />
        ))}
      </div>

      {/* Pagination */}
      {pagination.count > 0 && (
        <div className="flex justify-center mt-10 gap-2">
          <Button
            variant="outline"
            disabled={!pagination.previous}
            onClick={() => goToPage(pagination.previous?.split("page=")[1])}
          >
            Previous
          </Button>
          <span className="px-4 py-2 text-sm">
            Page {pagination.previous ? parseInt(pagination.previous.split("page=")[1]) + 1 : 1} of{" "}
            {Math.ceil(pagination.count / 10)}
          </span>
          <Button
            variant="outline"
            disabled={!pagination.next}
            onClick={() => goToPage(pagination.next?.split("page=")[1])}
          >
            Next
          </Button>
        </div>
      )}
    </div>
    </PublicLayout>
  );
};

export default BlogList;
