import React, {
  useCallback,
  useEffect,
  useRef,
  useState,
  useMemo,
} from "react";
import { motion as Motion, AnimatePresence } from "framer-motion";
import {
  X,
  ChevronLeft,
  ChevronRight,
  LogOut,
  User,
  Mail,
  Phone,
  Lock,
  EyeOff,
  ShieldCheck,
  AlertCircle,
  Moon,
  Sun,
  Globe,
  Ban,
  BadgeCheck,
  AlertTriangle,
} from "lucide-react";
import { useTranslation } from "react-i18next";
import { useTheme } from "../../hooks/useTheme";
import { useAuthStore } from "../../store/authStore";
import EditProfileDetailsModal from "../../features/profile/components/EditProfileDetailsModal";
import ProfileInformationModal from "../../features/profile/components/ProfileInformationModal";
import EmailUpdateModal from "../../features/profile/components/EmailUpdateModal";
import PhoneUpdateModal from "../../features/profile/components/PhoneUpdateModal";
import ReportsModal from "../../features/profile/components/ReportsModal";
import BlockedUsersModal from "../../features/profile/components/BlockedUsersModal";
import LanguageSelectorModal from "../../features/profile/components/LanguageSelectorModal";
import VerificationRequestModal from "../../features/profile/components/VerificationRequestModal";
import { profileAPI } from "../../features/profile/profileApi";
import { showToast } from "../../utils/toast";
import { calculateAge } from "../../utils/calculateAge";

const ACTIVITY_STATUS_KEY = "gaongram_activity_status";

const readActivityStatus = () => {
  if (typeof localStorage === "undefined") return false;
  return localStorage.getItem(ACTIVITY_STATUS_KEY) === "true";
};

const writeActivityStatus = (value) => {
  if (typeof localStorage !== "undefined") {
    localStorage.setItem(ACTIVITY_STATUS_KEY, String(Boolean(value)));
  }
};

const getPrivateValue = (profile, fallbackUser) =>
  Boolean(
    profile?.is_private ??
    profile?.private_account ??
    fallbackUser?.is_private ??
    fallbackUser?.private_account ??
    false,
  );

const getSensitiveValue = (profile, fallbackUser) =>
  (profile?.is_sensitive_allowed ?? fallbackUser?.is_sensitive_allowed) ===
  true;

const ToggleSwitch = ({ enabled, onChange, disabled = false, ariaLabel }) => (
  <button
    type="button"
    role="switch"
    aria-checked={enabled}
    aria-label={ariaLabel}
    disabled={disabled}
    onClick={(event) => {
      event.stopPropagation();
      if (!disabled) onChange(!enabled);
    }}
    className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-primary ${
      enabled ? "bg-primary" : "bg-gray-300 dark:bg-gray-600"
    } ${disabled ? "cursor-not-allowed opacity-60" : ""}`}
  >
    <span
      className={`inline-block h-4 w-4 rounded-full bg-white transition-transform ${
        enabled ? "translate-x-6" : "translate-x-1"
      }`}
    />
  </button>
);

const SettingRow = ({ icon, label, subtitle, rightElement, onClick }) => {
  const Component = onClick ? "button" : "div";

  return (
    <Component
      type={onClick ? "button" : undefined}
      onClick={onClick}
      className="flex w-full items-center justify-between rounded-lg px-4 py-1.5 text-left transition hover:bg-muted dark:hover:bg-muted-dark"
    >
      <div className="flex min-w-0 items-center space-x-3">
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-muted dark:bg-muted-dark">
          {React.createElement(icon, {
            className: "h-4 w-4 text-foreground dark:text-foreground-dark",
          })}
        </div>
        <div className="min-w-0">
          <p className="truncate text-sm font-medium text-foreground dark:text-foreground-dark">
            {label}
          </p>
          <p className="truncate text-xs text-mutedForeground dark:text-mutedForeground-dark">
            {subtitle}
          </p>
        </div>
      </div>
      <div className="ml-3 shrink-0">{rightElement}</div>
    </Component>
  );
};

const SectionTitle = ({ children }) => (
  <h3 className="px-4 pt-3 text-xs font-bold uppercase tracking-wider text-foreground dark:text-foreground-dark">
    {children}
  </h3>
);

const SettingsPopup = ({ onClose }) => {
  const { t } = useTranslation();
  const user = useAuthStore((state) => state.user);
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const logout = useAuthStore((state) => state.logout);
  const setUser = useAuthStore((state) => state.setUser);
  const { theme, setTheme } = useTheme();

  const [isProfileInfoOpen, setIsProfileInfoOpen] = useState(false);
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  const [isPhoneModalOpen, setIsPhoneModalOpen] = useState(false);
  const [isReportsModalOpen, setIsReportsModalOpen] = useState(false);
  const [isBlockedUsersModalOpen, setIsBlockedUsersModalOpen] = useState(false);
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
  const [profileData, setProfileData] = useState(null);
  const [verificationModalOpen, setVerificationModalOpen] = useState(false);
  const [verificationStatus, setVerificationStatus] = useState(null);
  const [isLoadingStatus, setIsLoadingStatus] = useState(false);
  const [updating, setUpdating] = useState({});
  const [settings, setSettings] = useState(() => ({
    privateAccount: getPrivateValue(null, user),
    activityStatus: readActivityStatus(),
    sensitiveContent: getSensitiveValue(null, user),
  }));

  const modalRef = useRef(null);
  const mountedRef = useRef(true);
  const lockRef = useRef(new Set());
  const userRef = useRef(user);

  const isDarkMode = theme === "dark";
  const isUpdating = useMemo(
    () => Object.values(updating).some(Boolean),
    [updating],
  );

  const setLock = useCallback((key, value) => {
    if (value) {
      lockRef.current.add(key);
    } else {
      lockRef.current.delete(key);
    }
    setUpdating((prev) => ({ ...prev, [key]: value }));
  }, []);

  const syncSettingsFromProfile = useCallback(
    (profile) => {
      const currentUser = userRef.current;
      setProfileData(profile);
      setSettings((prev) => ({
        ...prev,
        privateAccount: getPrivateValue(profile, currentUser),
        sensitiveContent: getSensitiveValue(profile, currentUser),
      }));

      if (
        currentUser &&
        profile &&
        (currentUser.is_private !== profile.is_private ||
          currentUser.is_sensitive_allowed !== profile.is_sensitive_allowed)
      ) {
        setUser({
          ...currentUser,
          is_private: profile.is_private,
          is_sensitive_allowed: profile.is_sensitive_allowed,
        });
      }
    },
    [setUser],
  );

  const loadProfile = useCallback(
    async ({ silent = false } = {}) => {
      const currentUser = useAuthStore.getState().user;
      if (!currentUser?.id) return null;

      try {
        const data = await profileAPI.getProfileById(currentUser.id);
        if (
          mountedRef.current &&
          useAuthStore.getState().user?.id === currentUser.id
        ) {
          syncSettingsFromProfile(data);
        }
        return data;
      } catch (error) {
        if (!silent) {
          showToast(t("failed_to_load_profile"), "error");
        }
        return null;
      }
    },
    [syncSettingsFromProfile, t],
  );

  const loadVerificationStatus = useCallback(async () => {
    const currentUser = useAuthStore.getState().user;
    if (!currentUser?.id) return;

    setIsLoadingStatus(true);
    try {
      const data = await profileAPI.getVerificationStatus(currentUser.id);
      if (!mountedRef.current) return;
      setVerificationStatus(data?.status ? data : null);
    } catch (error) {
      console.error("Failed to load verification status:", error);
      if (mountedRef.current) setVerificationStatus(null);
    } finally {
      if (mountedRef.current) setIsLoadingStatus(false);
    }
  }, []);

  const verificationBadge = useMemo(() => {
    const status = verificationStatus?.status;

    switch (status) {
      case "approved":
        return {
          text: t("verified"),
          color:
            "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
        };

      case "rejected":
        return {
          text: t("rejected"),
          color: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
        };

      case "pending":
        return {
          text: t("pending"),
          color:
            "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400",
        };

      default:
        return {
          text: t("apply_for_verification"),
          color:
            "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",
        };
    }
  }, [verificationStatus?.status, t]);

  const updatePrivacySetting = useCallback(
    async (nextValue) => {
      const currentUser = useAuthStore.getState().user;
      if (!currentUser?.id || lockRef.current.has("privacy")) return;

      const previousValue = settings.privateAccount;
      const previousUser = currentUser;

      setLock("privacy", true);
      setSettings((prev) => ({ ...prev, privateAccount: nextValue }));
      setUser({ ...currentUser, is_private: nextValue });

      try {
        const updatedProfile = await profileAPI.updateProfile(currentUser.id, {
          is_private: nextValue,
        });
        syncSettingsFromProfile({
          ...(profileData || {}),
          ...(updatedProfile || {}),
          is_private: nextValue,
        });
        showToast(t("privacy_updated_success"), "success");
      } catch (error) {
        setSettings((prev) => ({ ...prev, privateAccount: previousValue }));
        setUser(previousUser);
        showToast(
          error.response?.data?.message || t("privacy_update_failed"),
          "error",
        );
      } finally {
        setLock("privacy", false);
      }
    },
    [
      profileData,
      setLock,
      setUser,
      settings.privateAccount,
      syncSettingsFromProfile,
      t,
    ],
  );

  const toggleSensitiveContent = useCallback(
    async (nextValue) => {
      const currentUser = useAuthStore.getState().user;
      if (!currentUser?.id || lockRef.current.has("sensitive")) return;

      const dob = profileData?.dob || currentUser?.dob;
      if (nextValue) {
        if (!dob || calculateAge(dob) === null) {
          showToast("Please add your date of birth first.", "error");
          return;
        }

        if (calculateAge(dob) < 18) {
          showToast("You must be 18+ to enable sensitive content.", "error");
          return;
        }
      }

      const previousValue = settings.sensitiveContent;
      const previousUser = currentUser;

      setLock("sensitive", true);
      setSettings((prev) => ({ ...prev, sensitiveContent: nextValue }));
      setUser({ ...currentUser, is_sensitive_allowed: nextValue });

      try {
        const updatedProfile = await profileAPI.updateProfile(currentUser.id, {
          is_sensitive_allowed: nextValue,
        });
        syncSettingsFromProfile({
          ...(profileData || {}),
          ...(updatedProfile || {}),
          is_sensitive_allowed: nextValue,
        });
        showToast("Sensitive content setting updated.", "success");
      } catch (error) {
        setSettings((prev) => ({ ...prev, sensitiveContent: previousValue }));
        setUser(previousUser);
        showToast(
          error.response?.data?.message ||
            "Failed to update sensitive content setting.",
          "error",
        );
      } finally {
        setLock("sensitive", false);
      }
    },
    [
      profileData,
      setLock,
      setUser,
      settings.sensitiveContent,
      syncSettingsFromProfile,
    ],
  );

  const toggleDarkMode = useCallback(
    (nextValue) => {
      setTheme(nextValue ? "dark" : "light");
    },
    [setTheme],
  );

  const toggleActivityStatus = useCallback((nextValue) => {
    writeActivityStatus(nextValue);
    setSettings((prev) => ({ ...prev, activityStatus: nextValue }));
  }, []);

  const handleUpdateProfile = useCallback(
    async ({ data }) => {
      const currentUser = useAuthStore.getState().user;
      if (!currentUser?.id || lockRef.current.has("profile")) return;

      setLock("profile", true);
      try {
        const updatedProfile = await profileAPI.updateProfile(
          currentUser.id,
          data,
        );
        syncSettingsFromProfile({
          ...(profileData || {}),
          ...(updatedProfile || {}),
        });
        showToast(t("profile_updated_success"), "success");
      } catch (error) {
        showToast(error.response?.data?.message || t("update_failed"), "error");
        throw error;
      } finally {
        setLock("profile", false);
      }
    },
    [profileData, setLock, syncSettingsFromProfile, t],
  );

  const handleLogout = useCallback(() => {
    onClose?.();
    logout();
  }, [logout, onClose]);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  useEffect(() => {
    userRef.current = user;
  }, [user]);

  useEffect(() => {
    setSettings((prev) => ({
      ...prev,
      privateAccount: getPrivateValue(profileData, user),
      sensitiveContent: getSensitiveValue(profileData, user),
    }));
  }, [profileData, user]);

  const hasInitializedRef = useRef(false);

  useEffect(() => {
    if (!isAuthenticated || !user?.id) {
      onClose?.();
      return;
    }

    if (hasInitializedRef.current) return;

    hasInitializedRef.current = true;

    loadProfile({ silent: true });
    loadVerificationStatus();
  }, [isAuthenticated, user?.id]);

  useEffect(() => {
    const esc = (event) => {
      if (event.key === "Escape") onClose?.();
    };

    window.addEventListener("keydown", esc);
    return () => window.removeEventListener("keydown", esc);
  }, [onClose]);

  const verificationRightElement = useMemo(() => {
    if (isLoadingStatus) {
      return <div className="h-5 w-16 rounded bg-gray-200 dark:bg-gray-700" />;
    }

    return (
      <span
        className={`rounded-full px-2 py-1 text-xs font-medium ${verificationBadge.color}`}
      >
        {verificationBadge.text}
      </span>
    );
  }, [isLoadingStatus, verificationBadge]);

  const handleOverlayClick = (event) => {
    if (modalRef.current && !modalRef.current.contains(event.target)) {
      onClose?.();
    }
  };

  return (
    <>
      <AnimatePresence>
        <Motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4 backdrop-blur-sm"
          onClick={handleOverlayClick}
        >
          <Motion.div
            ref={modalRef}
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="flex max-h-[85vh] w-full max-w-md flex-col rounded-2xl border border-border bg-card shadow-2xl dark:border-border-dark dark:bg-card-dark"
          >
            <div className="sticky top-0 z-10 flex items-center justify-between rounded-t-2xl border-b border-border bg-card px-4 py-3 text-foreground dark:border-border-dark dark:bg-card-dark dark:text-foreground-dark">
              <button
                type="button"
                onClick={onClose}
                className="rounded-full p-2 hover:bg-muted dark:hover:bg-muted-dark"
              >
                <ChevronLeft className="h-5 w-5" />
              </button>
              <h2 className="text-lg font-semibold">{t("settings")}</h2>
              <button
                type="button"
                onClick={onClose}
                className="rounded-full p-2 hover:bg-muted dark:hover:bg-muted-dark"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="hide-scrollbar flex-1 overflow-y-auto">
              <SectionTitle>{t("accounts")}</SectionTitle>
              <SettingRow
                icon={User}
                label={t("personal_information")}
                subtitle={t("name_username_bio")}
                onClick={async () => {
                  await loadProfile({ silent: true });
                  setIsProfileInfoOpen(true);
                }}
                rightElement={<ChevronRight className="h-4 w-4" />}
              />
              <SettingRow
                icon={Mail}
                label={t("email")}
                subtitle={user?.email || t("email_address")}
                onClick={async () => {
                  await loadProfile({ silent: true });
                  setIsEmailModalOpen(true);
                }}
                rightElement={<ChevronRight className="h-4 w-4" />}
              />
              <SettingRow
                icon={Phone}
                label={t("phone_number")}
                subtitle={t("add_phone_number")}
                onClick={async () => {
                  await loadProfile({ silent: true });
                  setIsPhoneModalOpen(true);
                }}
                rightElement={<ChevronRight className="h-4 w-4" />}
              />

              <SectionTitle>{t("privacy_security")}</SectionTitle>
              <SettingRow
                icon={Lock}
                label={t("private_account")}
                subtitle={t("only_approved_followers")}
                rightElement={
                  <ToggleSwitch
                    enabled={settings.privateAccount}
                    disabled={updating.privacy}
                    ariaLabel="Toggle private account"
                    onChange={updatePrivacySetting}
                  />
                }
              />
              <SettingRow
                icon={AlertTriangle}
                label="Sensitive Content"
                subtitle="Show 18+ media"
                rightElement={
                  <ToggleSwitch
                    enabled={settings.sensitiveContent}
                    disabled={updating.sensitive}
                    ariaLabel="Toggle sensitive content"
                    onChange={toggleSensitiveContent}
                  />
                }
              />
              {/* <SettingRow
                icon={EyeOff}
                label={t("activity_status")}
                subtitle={t("hide_when_active")}
                rightElement={
                  <ToggleSwitch
                    enabled={settings.activityStatus}
                    ariaLabel="Toggle activity status"
                    onChange={toggleActivityStatus}
                  />
                }
              />
              <SettingRow
                icon={ShieldCheck}
                label={t("two_factor_auth")}
                subtitle={t("add_extra_security")}
                rightElement={<ChevronRight className="h-4 w-4" />}
              />*/}
              <SettingRow
                icon={AlertCircle}
                label={t("view_reports")}
                subtitle={t("view_all_reports")}
                onClick={() => setIsReportsModalOpen(true)}
                rightElement={<ChevronRight className="h-4 w-4" />}
              />
              <SettingRow
                icon={Ban}
                label={t("block")}
                subtitle={t("all_block_user")}
                onClick={() => setIsBlockedUsersModalOpen(true)}
                rightElement={<ChevronRight className="h-4 w-4" />}
              />
              <SettingRow
                icon={BadgeCheck}
                label={t("verification")}
                subtitle={t("get_blue_tick")}
                onClick={() => setVerificationModalOpen(true)}
                rightElement={verificationRightElement}
              />

              <SectionTitle>{t("appearance")}</SectionTitle>
              <SettingRow
                icon={isDarkMode ? Sun : Moon}
                label={t("dark_mode")}
                subtitle={t("easier_on_eyes")}
                rightElement={
                  <ToggleSwitch
                    enabled={isDarkMode}
                    ariaLabel="Toggle dark mode"
                    onChange={toggleDarkMode}
                  />
                }
              />

              <SectionTitle>{t("language_region")}</SectionTitle>
              <SettingRow
                icon={Globe}
                label={t("app_language")}
                subtitle={t("choose_language")}
                onClick={() => setIsLanguageModalOpen(true)}
                rightElement={<ChevronRight className="h-4 w-4" />}
              />

              <div className="mt-4 border-t border-border px-4 py-2 dark:border-border-dark">
                <button
                  type="button"
                  onClick={handleLogout}
                  className="flex w-full items-center justify-center gap-2 rounded-lg border border-red-300 py-2 text-red-500 transition hover:bg-red-50 dark:hover:bg-red-900/20"
                >
                  <LogOut className="h-5 w-5" />
                  {t("logout")}
                </button>
              </div>
            </div>
          </Motion.div>
        </Motion.div>
      </AnimatePresence>

      <ProfileInformationModal
        isOpen={isProfileInfoOpen}
        onClose={() => setIsProfileInfoOpen(false)}
        profile={profileData || user}
        onEdit={() => {
          setIsProfileInfoOpen(false);
          setIsEditProfileOpen(true);
        }}
      />
      <EditProfileDetailsModal
        isOpen={isEditProfileOpen}
        onClose={() => setIsEditProfileOpen(false)}
        profile={profileData || user}
        onUpdate={handleUpdateProfile}
        isUpdating={isUpdating}
      />
      <EmailUpdateModal
        isOpen={isEmailModalOpen}
        onClose={() => setIsEmailModalOpen(false)}
        profile={profileData || user}
        onUpdate={handleUpdateProfile}
        isUpdating={isUpdating}
      />
      <PhoneUpdateModal
        isOpen={isPhoneModalOpen}
        onClose={() => setIsPhoneModalOpen(false)}
        profile={profileData || user}
        onUpdate={handleUpdateProfile}
        isUpdating={isUpdating}
      />
      <ReportsModal
        isOpen={isReportsModalOpen}
        onClose={() => setIsReportsModalOpen(false)}
        onNavigateAway={() => {
          setIsReportsModalOpen(false);
          onClose();
        }}
      />
      <BlockedUsersModal
        isOpen={isBlockedUsersModalOpen}
        onClose={() => setIsBlockedUsersModalOpen(false)}
      />
      <LanguageSelectorModal
        isOpen={isLanguageModalOpen}
        onClose={() => setIsLanguageModalOpen(false)}
      />
      <VerificationRequestModal
        isOpen={verificationModalOpen}
        onClose={() => setVerificationModalOpen(false)}
        onSuccess={loadVerificationStatus}
      />
    </>
  );
};

export default SettingsPopup;