import React, { useState } from "react";
import { Heart } from "lucide-react";
import { motion as Motion, AnimatePresence } from "framer-motion";

const StoryLikeButton = ({ isLiked, onLike, disabled }) => {
  const [hearts, setHearts] = useState([]);

  const handleClick = (e) => {
    e.stopPropagation();
    if (disabled) return;

    onLike();

    if (!isLiked) {
      const newHearts = Array.from({ length: 8 }).map((_, i) => {
        const spread = (Math.random() - 0.5) * 100;
        const height = 180 + Math.random() * 80;

        return {
          id: Date.now() + i,
          x: spread,
          y: -height,
          rotate: Math.random() * 90 - 45,
          scale: 0.8 + Math.random() * 0.6,
        };
      });

      setHearts(newHearts);

      setTimeout(() => {
        setHearts([]);
      }, 1600);
    }
  };

  return (
    <div className="relative">

      <button
        onClick={handleClick}
        disabled={disabled}
        className="flex h-11 w-11 items-center justify-center rounded-full bg-black/20 backdrop-blur-xl transition hover:bg-black/35 disabled:opacity-50"
        aria-label={isLiked ? "Unlike story" : "Like story"}
        aria-pressed={isLiked}
      >
        <Heart
          size={26}
          className={isLiked ? "text-red-500 fill-red-500" : "text-white"}
        />
      </button>

      <AnimatePresence>
        {hearts.map((heart, i) => (
          <Motion.div
            key={heart.id}
            initial={{ opacity: 0, y: 0, x: 0, scale: 0.5 }}
            animate={{
              opacity: [1, 1, 0],
              y: heart.y,
              x: heart.x,
              scale: heart.scale,
              rotate: heart.rotate,
            }}
            transition={{
              duration: 1.6,
              ease: [0.22, 1, 0.36, 1],
              delay: i * 0.05,
            }}
            className="absolute bottom-3 right-3 pointer-events-none"
          >
            <Heart size={22} className="text-red-500 fill-red-500" />
          </Motion.div>
        ))}
      </AnimatePresence>

    </div>
  );
};

export default React.memo(StoryLikeButton);
