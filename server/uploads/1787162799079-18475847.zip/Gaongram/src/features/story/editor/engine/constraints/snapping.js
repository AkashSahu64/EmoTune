import { fabric } from "fabric";

const SNAP_THRESHOLD = 10;

export function snapObject(object, canvasWidth, canvasHeight) {
  if (!object) return;
  const center = object.getCenterPoint();
  const canvasCenterX = canvasWidth / 2;
  const canvasCenterY = canvasHeight / 2;

  if (Math.abs(center.x - canvasCenterX) < SNAP_THRESHOLD) {
    object.setPositionByOrigin(new fabric.Point(canvasCenterX, center.y), "center", "center");
  }
  if (Math.abs(center.y - canvasCenterY) < SNAP_THRESHOLD) {
    object.setPositionByOrigin(new fabric.Point(center.x, canvasCenterY), "center", "center");
  }

  const edges = {
    left: object.left,
    top: object.top,
    right: (object.left || 0) + object.getScaledWidth(),
    bottom: (object.top || 0) + object.getScaledHeight(),
  };
  if (Math.abs(edges.left) < SNAP_THRESHOLD) object.set({ left: 0 });
  if (Math.abs(edges.top) < SNAP_THRESHOLD) object.set({ top: 0 });
  if (Math.abs(canvasWidth - edges.right) < SNAP_THRESHOLD) {
    object.set({ left: canvasWidth - object.getScaledWidth() });
  }
  if (Math.abs(canvasHeight - edges.bottom) < SNAP_THRESHOLD) {
    object.set({ top: canvasHeight - object.getScaledHeight() });
  }
}
