// CanvasEngine.js (FULL FILE)
import { fabric } from "fabric";
import { ASPECT_RATIOS } from "../../utils/filterPresets.js";
import { ObjectFactory } from "../managers/ObjectFactory.js";
import { FilterManager } from "../managers/FilterManager.js";
import { DecorationManager } from "../managers/DecorationManager.js";
import { PreviewManager } from "../managers/PreviewManager.js";
import { LayerManager } from "../managers/LayerManager.js";
import { EventManager } from "../managers/EventManager.js";
import { MediaLoader } from "../managers/MediaLoader.js";
import { transformFromObject, readTextStyle, applyTextStyle } from "../managers/TransformUtils.js";
import { constrainToBounds } from "../constraints/boundary.js";
import { isFilterableObject, isLayerSelectable } from "../helpers/layerUtils.js";
import { isLocalObjectUrl, revokeObjectUrl } from "../helpers/dom.js";
import { mergeFilters } from "../../utils/filterPresets.js";

export default class CanvasEngine {
    constructor({ canvasEl, store, onReady, onError, onPreviewChange }) {
        this.instanceId = Date.now() + Math.random();
        this.canvasEl = canvasEl;
        this.store = store;
        this.onReady = onReady;
        this.onError = onError;
        this.onPreviewChange = onPreviewChange;
        this.canvas = null;
        this.objectMap = new Map();
        this.sourceUrls = new Map();
        this.loadingSourceUrls = new Set();
        this.revokeAfterLoadUrls = new Set();
        this.videoElements = new Map();
        this.videoFrameDisposers = new Map();
        this.nativeVideoContainers = new Map();
        this.lastSyncedRevision = -1;
        this.hydratingIds = new Set();
        this.isDisposed = false;
        this.renderRaf = null;
        this.videoRenderRaf = null;
        this.pendingPreview = false;
        this.lastVideoFrameTime = 0;
        this.pendingMusicLayer = false;
        this.musicStickerRaf = null;
        this.lastMusicStickerTime = 0;

        // Instantiate managers
        this.objectFactory = new ObjectFactory(this);
        this.filterManager = new FilterManager(this);
        this.decorationManager = new DecorationManager(this);
        this.previewManager = new PreviewManager(this);
        this.layerManager = new LayerManager(this);
        this.eventManager = new EventManager(this);
        this.mediaLoader = new MediaLoader(this);
    }

    // --- Public API (unchanged except new music methods) ---
    init(aspectRatio = "9:16") {
        if (!this.canvasEl) throw new Error("Missing canvas element");
        this.isDisposed = false;
        const dimensions = this.getCanvasDimensions(aspectRatio);
        this.canvas = new fabric.Canvas(this.canvasEl, {
            width: dimensions.width,
            height: dimensions.height,
            backgroundColor: "#050505",
            preserveObjectStacking: true,
            fireRightClick: false,
            stopContextMenu: true,
            selection: true,
            enableRetinaScaling: true,
        });
        this.canvas.set({ storyAspectRatio: aspectRatio });
        this.configureControls();
        this.eventManager.bind();
        this._addBackground();
        this.onReady?.(this.canvas);
        return this.canvas;
    }

    dispose() {
        this.isDisposed = true;
        if (this.renderRaf) {
            cancelAnimationFrame(this.renderRaf);
            this.renderRaf = null;
        }
        if (this.videoRenderRaf) {
            cancelAnimationFrame(this.videoRenderRaf);
            this.videoRenderRaf = null;
        }
        if (this.musicStickerRaf) {
            cancelAnimationFrame(this.musicStickerRaf);
            this.musicStickerRaf = null;
        }
        this.previewManager.dispose?.();
        this.eventManager.unbind();
        this.videoFrameDisposers.forEach((dispose) => dispose());
        this.videoFrameDisposers.clear();
        this.videoElements.forEach((video) => {
            video.pause();
            video.removeAttribute("src");
            video.load();
        });
        this.nativeVideoContainers.forEach((element) => element.remove());
        this.nativeVideoContainers.clear();
        this.sourceUrls.forEach((url) => {
            if (isLocalObjectUrl(url)) {
                setTimeout(() => {
                    try {
                        URL.revokeObjectURL(url);
                    } catch {
                        // Ignore revoke races for blob URLs that the browser already released.
                    }
                }, 3000);
            }
        });
        this.sourceUrls.clear();
        this.videoElements.clear();
        this.objectMap.clear();
        this.canvas?.dispose();
        this.canvas = null;
    }

    resizeToAspectRatio(aspectRatio) {
        if (!this.canvas) return;
        const previousWidth = this.canvas.getWidth();
        const previousHeight = this.canvas.getHeight();
        if (!previousWidth || !previousHeight) return;
        const dimensions = this.getCanvasDimensions(aspectRatio);
        const scaleX = dimensions.width / previousWidth;
        const scaleY = dimensions.height / previousHeight;

        this.canvas.setDimensions(dimensions);
        if (this.backgroundObject) {
            this.backgroundObject.set({
                width: dimensions.width,
                height: dimensions.height,
                left: 0,
                top: 0,
                scaleX: 1,
                scaleY: 1,
            });
        }
        this.canvas.getObjects().forEach((object) => {
            if (object.excludeFromLayoutScale) return;
            object.set({
                left: (object.left || 0) * scaleX,
                top: (object.top || 0) * scaleY,
                scaleX: (object.scaleX || 1) * scaleX,
                scaleY: (object.scaleY || 1) * scaleY,
            });
            object.setCoords();
            if (object.layerId && this.objectMap.has(object.layerId)) {
                this.store.getState().updateLayer(object.layerId, transformFromObject(object), { recordHistory: false });
            }
        });
        this.canvas.set({ storyAspectRatio: aspectRatio });
        this.applyFiltersToAll({ preview: true, rebuild: true });
    }

    getCanvasDimensions(aspectRatio) {
        const ratio = ASPECT_RATIOS[aspectRatio] || ASPECT_RATIOS["9:16"];
        const viewportWidth = window.visualViewport?.width || window.innerWidth;
        const viewportHeight = window.visualViewport?.height || window.innerHeight;
        const isNarrow = viewportWidth < 768;
        const isShort = viewportHeight < 560;
        const reservedHeight = isNarrow ? (isShort ? 190 : 310) : 150;
        const maxHeight = Math.min(
            Math.max(220, viewportHeight - reservedHeight),
            isNarrow ? 520 : 760,
        );
        const maxWidth = Math.min(Math.max(240, viewportWidth - (isNarrow ? 28 : 48)), isNarrow ? 390 : 430);
        let height = maxHeight;
        let width = height * ratio.ratio;
        if (width > maxWidth) {
            width = maxWidth;
            height = width / ratio.ratio;
        }
        return { width: Math.round(width), height: Math.round(height) };
    }

    getBaseBounds() {
        const baseLayer = this.store.getState().layers.find((l) => l.type === "base");
        if (!baseLayer) return null;
        const obj = this.objectMap.get(baseLayer.id);
        if (!obj) return null;
        return obj.getBoundingRect();
    }

    constrainToBounds(object) {
        if (!object || !this.canvas) return;
        constrainToBounds(object, this.canvas.getWidth(), this.canvas.getHeight());
    }

    configureControls() {
        fabric.Object.prototype.transparentCorners = false;
        fabric.Object.prototype.cornerColor = "#ffffff";
        fabric.Object.prototype.cornerStrokeColor = "#111827";
        fabric.Object.prototype.cornerStyle = "circle";
        fabric.Object.prototype.borderColor = "rgba(255,255,255,0.86)";
        fabric.Object.prototype.borderScaleFactor = 1.5;
        fabric.Object.prototype.padding = 6;
        fabric.Object.prototype.controls.mtr.offsetY = -36;
        fabric.Object.prototype.centeredScaling = true;
        fabric.Object.prototype.centeredRotation = true;
    }

    requestRender({ preview = true, immediate = false } = {}) {
        if (!this.canvas || this.isDisposed) return;
        this.pendingPreview = this.pendingPreview || preview;

        const flush = () => {
            this.renderRaf = null;
            if (!this.canvas || this.isDisposed) return;
            this.canvas.renderAll();
            this.syncNativeVideoLayers();
            if (this.pendingPreview) {
                this.previewManager.emitPreview();
                this.pendingPreview = false;
            }
        };

        if (immediate) {
            if (this.renderRaf) {
                cancelAnimationFrame(this.renderRaf);
                this.renderRaf = null;
            }
            flush();
            return;
        }

        if (!this.renderRaf) {
            this.renderRaf = requestAnimationFrame(flush);
        }
    }

    applyFiltersToLayer(layer, { preview = true, immediate = false, rebuild = false } = {}) {
        const object = this.objectMap.get(layer?.id);
        if (layer?.type !== "base") return false;
        if (layer?.mediaType === "video") {
            this.applyVideoFilters(layer?.id, mergeFilters(this.store.getState().filters, layer.filters));
            this.syncDecorations(this.store.getState().filters, this.store.getState().frame);
            this.requestRender({ preview, immediate });
            return true;
        }
        if (!object || !isFilterableObject(object)) return false;

        const applied = this.filterManager.applyFiltersToObject(
            object,
            mergeFilters(this.store.getState().filters, layer.filters),
            { rebuild },
        );
        if (applied) {
            this.requestRender({ preview, immediate });
        }
        return applied;
    }

    applyFiltersToAll({ preview = true, immediate = false, rebuild = false } = {}) {
        if (!this.canvas || this.isDisposed) return false;

        const state = this.store.getState();
        let didApply = false;
        state.layers.forEach((layer) => {
            if (layer.type !== "base") return;
            if (layer.mediaType === "video") {
                this.applyVideoFilters(layer.id, mergeFilters(state.filters, layer.filters));
                didApply = true;
                return;
            }
            const object = this.objectMap.get(layer.id);
            if (!object || !isFilterableObject(object)) return;
            didApply = this.filterManager.applyFiltersToObject(
                object,
                mergeFilters(state.filters, layer.filters),
                { rebuild },
            ) || didApply;
        });

        this.syncDecorations(state.filters, state.frame);
        if (didApply || state.filters?.vignette || state.frame) {
            this.requestRender({ preview, immediate });
        }
        return didApply;
    }

    applyTransientFilters({ scope = "global", layerId = null, filters = {} } = {}) {
        if (!this.canvas || this.isDisposed) return;

        const state = this.store.getState();
        if (scope === "layer" && layerId) {
            const layer = state.layers.find((item) => item.id === layerId);
            const object = this.objectMap.get(layerId);
            if (layer?.mediaType === "video") {
                this.applyVideoFilters(layerId, mergeFilters(state.filters, filters));
                this.requestRender({ preview: true });
                return;
            }
            if (layer?.type === "base" && object && isFilterableObject(object)) {
                this.filterManager.applyFiltersToObject(
                    object,
                    mergeFilters(state.filters, filters),
                );
                this.requestRender({ preview: true });
            }
            return;
        }

        state.layers.forEach((layer) => {
            if (layer.type !== "base") return;
            if (layer.mediaType === "video") {
                this.applyVideoFilters(layer.id, mergeFilters(filters, layer.filters));
                return;
            }
            const object = this.objectMap.get(layer.id);
            if (!object || !isFilterableObject(object)) return;
            this.filterManager.applyFiltersToObject(
                object,
                mergeFilters(filters, layer.filters),
            );
        });
        this.syncDecorations(filters, state.frame);
        this.requestRender({ preview: true });
    }

    registerVideoElement(layerId, video, object) {
        if (!layerId || !video) return;

        this.videoFrameDisposers.get(layerId)?.();
        this.videoElements.set(layerId, video);
        this.mountNativeVideoElement(layerId, video);
        this.syncNativeVideoLayer(layerId);

        const startLoop = () => this.startVideoRenderLoop();
        const renderOnce = () => this.renderVideoFrame(layerId, performance.now());
        video.addEventListener("play", startLoop);
        video.addEventListener("playing", startLoop);
        video.addEventListener("seeked", renderOnce);
        video.addEventListener("loadeddata", renderOnce);
        video.addEventListener("timeupdate", renderOnce);

        this.videoFrameDisposers.set(layerId, () => {
            video.removeEventListener("play", startLoop);
            video.removeEventListener("playing", startLoop);
            video.removeEventListener("seeked", renderOnce);
            video.removeEventListener("loadeddata", renderOnce);
            video.removeEventListener("timeupdate", renderOnce);
            this.nativeVideoContainers.get(layerId)?.remove();
            this.nativeVideoContainers.delete(layerId);
        });

        if (object) {
            object.__storyVideoElement = video;
        }
        this.startVideoRenderLoop();
    }

    mountNativeVideoElement(layerId, video) {
        const container = this.canvas?.lowerCanvasEl?.parentElement;
        if (!container || this.nativeVideoContainers.get(layerId) === video) return;

        container.style.position = "relative";
        container.style.overflow = "hidden";
        video.classList.add("story-editor-native-video");
        video.setAttribute("playsinline", "");
        video.setAttribute("webkit-playsinline", "");
        Object.assign(video.style, {
            position: "absolute",
            left: "50%",
            top: "50%",
            width: "1px",
            height: "1px",
            objectFit: "fill",
            pointerEvents: "none",
            zIndex: "0",
            willChange: "transform, filter",
            background: "#050505",
            transformOrigin: "center center",
        });

        [this.canvas.lowerCanvasEl, this.canvas.upperCanvasEl].forEach((canvasEl, index) => {
            if (!canvasEl) return;
            canvasEl.style.position = "absolute";
            canvasEl.style.left = "0";
            canvasEl.style.top = "0";
            canvasEl.style.zIndex = String(index + 2);
        });

        container.insertBefore(video, container.firstChild);
        this.nativeVideoContainers.set(layerId, video);
    }

    setTransparentOverlayMode(enabled) {
        if (!this.canvas) return;
        this.canvas.backgroundColor = enabled ? "rgba(0,0,0,0)" : "#050505";
        this.backgroundObject?.set({ visible: !enabled });
        this.canvas.getElement().style.background = enabled ? "transparent" : "#050505";
    }

    syncNativeVideoLayers() {
        for (const layerId of this.videoElements.keys()) {
            this.syncNativeVideoLayer(layerId);
        }
        const hasBaseVideo = this.store.getState().layers.some((layer) => layer.type === "base" && layer.mediaType === "video");
        this.setTransparentOverlayMode(hasBaseVideo);
    }

    syncNativeVideoLayer(layerId) {
        const video = this.videoElements.get(layerId);
        const object = this.objectMap.get(layerId);
        const layer = this.store.getState().layers.find((item) => item.id === layerId);
        if (!video || !object || !this.canvas) return;

        const visible = layer?.visible !== false && object.visible !== false;
        const width = Math.max(2, object.getScaledWidth?.() || object.width || video.videoWidth || this.canvas.getWidth());
        const height = Math.max(2, object.getScaledHeight?.() || object.height || video.videoHeight || this.canvas.getHeight());
        const flipX = object.flipX ? -1 : 1;
        const flipY = object.flipY ? -1 : 1;

        Object.assign(video.style, {
            display: visible ? "block" : "none",
            width: `${width}px`,
            height: `${height}px`,
            left: `${object.left || this.canvas.getWidth() / 2}px`,
            top: `${object.top || this.canvas.getHeight() / 2}px`,
            transform: `translate(-50%, -50%) rotate(${object.angle || 0}deg) scale(${flipX}, ${flipY})`,
        });
        this.applyVideoFilters(layerId, mergeFilters(this.store.getState().filters, layer?.filters));
    }

    applyVideoFilters(layerId, filters = {}) {
        const video = this.videoElements.get(layerId);
        if (!video) return false;
        video.style.filter = this.filterManager.buildCssFilter(filters);
        video.dataset.storyFilter = video.style.filter;
        return true;
    }

    renderVideoFrame(layerId, now = performance.now()) {
        if (!this.canvas || this.isDisposed) return false;
        const video = this.videoElements.get(layerId);
        const object = this.objectMap.get(layerId);
        if (!video || !object || object.visible === false || video.readyState < 2) return false;

        const layer = this.store.getState().layers.find((item) => item.id === layerId);
        if (!layer) return false;
        const mergedFilters = mergeFilters(this.store.getState().filters, layer?.filters);
        this.applyVideoFilters(layerId, mergedFilters);
        this.syncNativeVideoLayer(layerId);

        object.__storyLastVideoFrame = now;
        return true;
    }

    startVideoRenderLoop() {
        if (this.videoRenderRaf || !this.canvas || this.isDisposed) return;

        const tick = (now) => {
            if (!this.canvas || this.isDisposed) {
                this.videoRenderRaf = null;
                return;
            }

            const shouldThrottle = now - this.lastVideoFrameTime < 33;
            let hasPlayingVideo = false;
            let renderedFrame = false;

            for (const [layerId, video] of this.videoElements.entries()) {
                if (!video.paused && !video.ended && video.readyState >= 2) {
                    hasPlayingVideo = true;
                    if (!shouldThrottle) {
                        renderedFrame = this.renderVideoFrame(layerId, now) || renderedFrame;
                    }
                }
            }

            if (renderedFrame) {
                this.lastVideoFrameTime = now;
                this.canvas.requestRenderAll();
                if (this.pendingPreview) {
                    this.previewManager.emitPreview();
                    this.pendingPreview = false;
                }
            }

            if (hasPlayingVideo) {
                this.videoRenderRaf = requestAnimationFrame(tick);
            } else {
                this.videoRenderRaf = null;
            }
        };

        this.videoRenderRaf = requestAnimationFrame(tick);
    }

    startMusicStickerLoop(group) {
        if (this.musicStickerRaf || !group?.__storyEqualizerBars?.length) return;

        const tick = (now) => {
            if (!this.canvas || this.isDisposed || !this.objectMap.has(group.layerId)) {
                this.musicStickerRaf = null;
                return;
            }

            if (now - this.lastMusicStickerTime > 90) {
                this.lastMusicStickerTime = now;
                group.__storyEqualizerBars.forEach((bar, index) => {
                  const height = 7 + Math.abs(Math.sin(now / 220 + index * 1.35)) * 12;
                  bar.set({
                    height,
                    top: 67 - height,
                  });
                });
                group.dirty = true;
                this.requestRender({ preview: false });
            }
            this.musicStickerRaf = requestAnimationFrame(tick);
        };

        this.musicStickerRaf = requestAnimationFrame(tick);
    }

    updateLayerFilters(layerId) {
        const object = this.objectMap.get(layerId);
        const state = this.store.getState();
        const layer = state.layers.find(l => l.id === layerId);
        if (layer?.type !== "base") return;
        if (layer.mediaType === "video") {
            this.applyVideoFilters(layerId, mergeFilters(state.filters, layer.filters));
            this.requestRender({ preview: true, immediate: true });
            return;
        }
        if (!object || !isFilterableObject(object)) return;

        const finalFilters = mergeFilters(state.filters, layer.filters);
        this.filterManager.applyFiltersToObject(object, finalFilters);
        this.requestRender({ preview: true, immediate: true });
    }

    syncFromStore() {
        const state = this.store.getState();
        if (!this.canvas || this.lastSyncedRevision === state.revision) return;
        if (this.canvas.storyAspectRatio !== state.aspectRatio) {
            this.resizeToAspectRatio(state.aspectRatio);
        }

        const currentIds = new Set(state.layers.map((l) => l.id));
        // Remove objects that are no longer in the layer list
        for (const [id, object] of this.objectMap.entries()) {
            if (!currentIds.has(id)) {
                this.canvas.remove(object);
                this.objectMap.delete(id);
                this.videoFrameDisposers.get(id)?.();
                this.videoFrameDisposers.delete(id);
                const video = this.videoElements.get(id);
                if (video) {
                    video.pause();
                    video.removeAttribute("src");
                    video.load();
                    this.videoElements.delete(id);
                }
                this.nativeVideoContainers.get(id)?.remove();
                this.nativeVideoContainers.delete(id);
            }
        }

        // Process each layer
        state.layers.forEach((layer) => {
            const object = this.objectMap.get(layer.id);
            if (layer.type === "gif") return;

            // Special handling for music layer
            if (layer.type === "music") {
                // Music layer is re-created directly from store.music data, not hydrated
                if (!object && state.music) {
                    this.addMusicLayer(state.music);
                } else if (object) {
                    object.set({
                        visible: layer.visible !== false,
                        left: layer.left ?? object.left,
                        top: layer.top ?? object.top,
                        scaleX: layer.scaleX ?? object.scaleX,
                        scaleY: layer.scaleY ?? object.scaleY,
                        angle: layer.rotation ?? object.angle,
                        opacity: layer.opacity ?? object.opacity,
                        selectable: isLayerSelectable(layer),
                        evented: isLayerSelectable(layer),
                    });
                    object.musicData = {
                        ...(object.musicData || {}),
                        id: state.music?.id,
                        title: state.music?.title,
                        artist: state.music?.artist,
                        cover_image: state.music?.cover_image,
                        audio: state.music?.audio,
                        startTime: state.music?.startTime,
                        duration: state.music?.duration,
                        sourceDuration: state.music?.sourceDuration,
                    };
                    object.setCoords();
                }
                return;
            }

            if (object) {
                const selectable = isLayerSelectable(layer);
                object.set({
                    visible: layer.visible !== false,
                    left: layer.left ?? object.left,
                    top: layer.top ?? object.top,
                    scaleX: layer.scaleX ?? object.scaleX,
                    scaleY: layer.scaleY ?? object.scaleY,
                    angle: layer.rotation ?? object.angle,
                    opacity: layer.opacity ?? object.opacity,
                    selectable,
                    evented: selectable,
                });
                if (layer.type === "text") {
                    object.set("text", layer.text ?? object.text);
                    applyTextStyle(object, layer.style || {});
                }
                if (isFilterableObject(object)) {
                    this.applyFiltersToLayer(layer, { preview: false });
                }
                object.setCoords();
                if (layer.mediaType === "video") {
                    this.syncNativeVideoLayer(layer.id);
                }
            } else if (!this.hydratingIds.has(layer.id)) {
                this.hydrateLayer(layer);
            }
        });

        if (state.music && !state.layers.some((layer) => layer.type === "music") && !this.pendingMusicLayer) {
            this.pendingMusicLayer = true;
            this.addMusicLayer(state.music).finally(() => {
                this.pendingMusicLayer = false;
            });
        }

        // Remove any music layers on canvas that are not in the store anymore
        for (const [id, obj] of this.objectMap.entries()) {
            if (obj.layerId && obj.layerId.startsWith("music-") && !state.layers.some(l => l.id === id)) {
                this.canvas.remove(obj);
                this.objectMap.delete(id);
            }
        }

        this.syncDecorations(state.filters, state.frame);
        this.syncNativeVideoLayers();
        this.layerManager.syncObjectStack();

        const active = this.objectMap.get(state.activeLayerId);
        if (active && active.selectable) {
            this.canvas.setActiveObject(active);
        } else if (!state.activeLayerId) {
            this.canvas.discardActiveObject();
        } else {
            this.canvas.discardActiveObject();
            this.store.getState().setActiveLayerId(null);
        }
        this.lastSyncedRevision = state.revision;
        this.applyFiltersToAll({ preview: false });
        this.requestRender({ preview: true });
    }

    syncDecorations(filters, frame) {
        this.decorationManager.syncVignette(filters?.vignette || 0);
        this.decorationManager.syncFrame(frame);
    }

    applyLayerPatch(layerId, patch) {
        const object = this.objectMap.get(layerId);
        if (!object || !this.canvas) return;

        if (patch.text !== undefined && object.type === "i-text") {
            object.set("text", patch.text);
        }
        if (patch.style && object.type === "i-text") {
            applyTextStyle(object, patch.style);
        }

        const transformPatch = {};
        ["left", "top", "scaleX", "scaleY", "rotation", "opacity"].forEach((key) => {
            if (patch[key] !== undefined) transformPatch[key] = patch[key];
        });
        if (Object.keys(transformPatch).length) {
            object.set(transformPatch);
        }

        if (patch.filters) {
            this.updateLayerFilters(layerId);
        }

        object.setCoords();
        this.requestRender({ preview: true });
    }

    addTextLayer(options = {}) {
        if (!this.canvas) return null;
        const layerId = this.store.getState().createLayerId("text");
        const bounds = this.getBaseBounds();
        const centerX = bounds ? bounds.left + bounds.width / 2 : this.canvas.getWidth() / 2;
        const centerY = bounds ? bounds.top + bounds.height / 2 : this.canvas.getHeight() / 2;
        const maxWidth = bounds ? bounds.width * 0.9 : this.canvas.getWidth() * 0.8;

        const text = new fabric.Textbox(options.text || "Tap to edit", {
            left: centerX,
            top: centerY,
            originX: "center",
            originY: "center",
            splitByGrapheme: true,
            breakWords: true,
            fontFamily: options.fontFamily || "Inter, Arial, sans-serif",
            fontSize: options.fontSize || 48,
            fontWeight: options.fontWeight || "700",
            fontStyle: options.fontStyle || "normal",
            fill: options.fill || "#ffffff",
            textAlign: options.textAlign || "center",
            charSpacing: options.charSpacing ?? 0,
            opacity: options.opacity ?? 1,
            shadow: options.shadow || new fabric.Shadow("rgba(0,0,0,0.35) 0 4px 12px"),
            editable: true,
            layerId,
            objectCaching: false,
            selectable: true,
            evented: true,
            width: maxWidth,
        });
        text.setControlsVisibility({ mb: false, ml: false, mr: false, mt: false });
        text.initDimensions();
        text.setCoords();
        this.canvas.add(text);
        this.canvas.setActiveObject(text);
        this.objectMap.set(layerId, text);

        this.store.getState().addLayer({
            id: layerId,
            type: "text",
            name: "Text",
            text: text.text,
            style: readTextStyle(text),
            ...transformFromObject(text),
        });
        this.layerManager.syncObjectStack();
        text.enterEditing();
        text.selectAll();
        this.requestRender({ preview: true });
        return layerId;
    }

    deleteActiveLayer() {
        const active = this.canvas?.getActiveObject();
        if (!active?.layerId) return;
        this.layerManager.removeLayer(active.layerId);
    }

    getPrimaryVideoElement() {
        const baseLayer = this.store.getState().layers.find((l) => l.type === "base" && l.mediaType === "video");
        if (!baseLayer) return null;
        return this.videoElements.get(baseLayer.id) || null;
    }

    getPrimaryVideoLayer() {
        const baseLayer = this.store.getState().layers.find((l) => l.type === "base" && l.mediaType === "video");
        if (!baseLayer) return null;
        return {
            layer: baseLayer,
            video: this.videoElements.get(baseLayer.id) || null,
            object: this.objectMap.get(baseLayer.id) || null,
        };
    }

    renderVideoCompositeFrame(targetCanvas) {
        const primary = this.getPrimaryVideoLayer();
        const video = primary?.video;
        const object = primary?.object;
        if (!targetCanvas || !video || !object || video.readyState < 2 || !this.canvas) return false;

        const ctx = targetCanvas.getContext("2d");
        const scaleX = targetCanvas.width / this.canvas.getWidth();
        const scaleY = targetCanvas.height / this.canvas.getHeight();
        ctx.save();
        ctx.clearRect(0, 0, targetCanvas.width, targetCanvas.height);
        ctx.fillStyle = "#050505";
        ctx.fillRect(0, 0, targetCanvas.width, targetCanvas.height);
        ctx.scale(scaleX, scaleY);
        ctx.translate(object.left || this.canvas.getWidth() / 2, object.top || this.canvas.getHeight() / 2);
        ctx.rotate(((object.angle || 0) * Math.PI) / 180);
        ctx.scale(object.flipX ? -1 : 1, object.flipY ? -1 : 1);
        ctx.filter = video.dataset.storyFilter || video.style.filter || "none";
        const renderedWidth = Math.max(2, object.getScaledWidth?.() || object.width || video.videoWidth);
        const renderedHeight = Math.max(2, object.getScaledHeight?.() || object.height || video.videoHeight);
        ctx.drawImage(
            video,
            -renderedWidth / 2,
            -renderedHeight / 2,
            renderedWidth,
            renderedHeight,
        );
        ctx.restore();
        ctx.drawImage(this.canvas.getElement(), 0, 0, targetCanvas.width, targetCanvas.height);
        return true;
    }

    selectLayer(id) {
        const object = this.objectMap.get(id);
        const layer = this.store.getState().layers.find((item) => item.id === id);
        if (!object || !this.canvas || !object.selectable || !isLayerSelectable(layer)) return;
        this.canvas.setActiveObject(object);
        this.store.getState().setActiveLayerId(id);
        this.requestRender({ preview: false });
    }

    async addMusicLayer(musicData) {
    if (!this.canvas || !musicData) return null;
    // Remove existing music layer if any
    this.removeMusicLayer();

    const layerId = this.store.getState().createLayerId("music");
    const bounds = this.getBaseBounds();
    const centerX = bounds ? bounds.left + bounds.width / 2 : this.canvas.getWidth() / 2;
    const centerY = bounds ? bounds.top + bounds.height * 0.15 : this.canvas.getHeight() * 0.15;

    // ⚠️ createMusicGroup returns a Promise – await it
    const group = await this.objectFactory.createMusicGroup(musicData, layerId);
    if (!group || this.isDisposed) return null;  // Safeguard

    group.set({
        left: centerX,
        top: centerY,
        originX: "center",
        originY: "top",
        selectable: true,
        evented: true,
        hasControls: true,
        layerId,
    });
    group.setCoords();
    this.canvas.add(group);
    this.canvas.setActiveObject(group);
        this.objectMap.set(layerId, group);
        this.startMusicStickerLoop(group);

        this.store.getState().addLayer({
        id: layerId,
        type: "music",
        name: musicData.title || "Music sticker",
        musicId: musicData.id,
        music: {
            id: musicData.id,
            title: musicData.title,
            artist: musicData.artist,
            cover_image: musicData.cover_image,
                audio: musicData.audio,
                startTime: musicData.startTime,
                duration: musicData.duration,
                sourceDuration: musicData.sourceDuration,
            },
        ...transformFromObject(group),
    }, { recordHistory: false });

    this.layerManager.syncObjectStack();
    this.requestRender({ preview: true, immediate: true });
    return layerId;
}

    removeMusicLayer() {
        const musicLayer = this.store.getState().layers.find(l => l.type === "music");
        if (musicLayer) {
            this.layerManager.removeLayer(musicLayer.id, { recordHistory: false, force: true });
        }
    }
    // ----------------------------------

    loadBaseMedia(file, aspectRatio) {
        return this.mediaLoader.loadBaseMedia(file, aspectRatio);
    }

    addImageLayer(params) {
        return this.mediaLoader.addImageLayer(params);
    }

    addVideoLayer(params) {
        return this.mediaLoader.addVideoLayer(params);
    }

    addGifLayer(params) {
        return this.mediaLoader.addGifLayer(params);
    }

    replaceImageLayer(layerId, file) {
        return this.mediaLoader.replaceImageLayer(layerId, file);
    }

    revokeSourceUrl(url) {
        if (!isLocalObjectUrl(url)) return;
        if (this.loadingSourceUrls.has(url)) {
            this.revokeAfterLoadUrls.add(url);
            return;
        }
        revokeObjectUrl(url);
    }

    trackSourceUrlLoad(url, promise) {
        if (!isLocalObjectUrl(url)) return promise;
        this.loadingSourceUrls.add(url);
        return promise.finally(() => {
            this.loadingSourceUrls.delete(url);
            if (this.revokeAfterLoadUrls.has(url)) {
                this.revokeAfterLoadUrls.delete(url);
                revokeObjectUrl(url);
            }
        });
    }

    _addBackground() {
        const bg = new fabric.Rect({
            left: 0,
            top: 0,
            width: this.canvas.getWidth(),
            height: this.canvas.getHeight(),
            fill: "#050505",
            selectable: false,
            evented: false,
            excludeFromExport: false,
            excludeFromLayoutScale: true,
            objectCaching: false,
        });
        this.canvas.add(bg);
        this.canvas.sendToBack(bg);
        this.backgroundObject = bg;
    }

    hydrateLayer(layer) {
        if (!this.canvas || !layer?.src) return;
        if (layer.type === "gif" || layer.type === "music") return; // skip music layers handled separately
        this.hydratingIds.add(layer.id);
        const onHydrated = (object) => {
            if (!object || this.isDisposed) {
                this.hydratingIds.delete(layer.id);
                return;
            }
            const selectable = isLayerSelectable(layer);
            object.set({
                layerId: layer.id,
                __storyLayerType: layer.type,
                storyLayerType: layer.type,
                left: layer.left ?? this.canvas.getWidth() / 2,
                top: layer.top ?? this.canvas.getHeight() / 2,
                scaleX: layer.scaleX ?? 1,
                scaleY: layer.scaleY ?? 1,
                angle: layer.rotation ?? 0,
                opacity: layer.opacity ?? 1,
                selectable,
                evented: selectable,
                visible: layer.visible !== false,
            });
            this.canvas.add(object);
            this.objectMap.set(layer.id, object);
            if (isFilterableObject(object)) {
                this.filterManager.applyFiltersToObject(object, mergeFilters(this.store.getState().filters, layer.filters));
            }
            object.setCoords();
            this.layerManager.syncObjectStack();
            this.requestRender({ preview: true });
            this.hydratingIds.delete(layer.id);
        };

        if (layer.mediaType === "video") {
            this.objectFactory.createVideoObject(layer.src, layer.id)
                .then(onHydrated)
                .catch((err) => {
                    this.hydratingIds.delete(layer.id);
                    this.onError?.(err);
                });
            return;
        }
        this.objectFactory.createImageObject(layer.src, layer.id)
            .then(onHydrated)
            .catch((err) => {
                this.hydratingIds.delete(layer.id);
                this.onError?.(err);
            });
    }
}
