import api from "../config/axios.js";

export const commentService = {
  createComment: async (data) => {
    const payload =
      data.parent != null
        ? {
            comment: data.comment,
            parent: data.parent,
          }
        : {
            comment: data.comment,
            post: data.postId,
          };

    const response = await api.post("/comments/", payload);
    return response.data;
  },

  getComments: async (postId) => {
    const response = await api.get(`/comments-list/${postId}/`);
    return response.data;
  },

  likeComment: async (id) => {
    if (!id) throw new Error("Invalid comment ID");

    return await api.post(`/comments/${Number(id)}/like/`);
  },

  updateComment: async (id, data) => {
    if (!id) throw new Error("Invalid comment ID");

    const response = await api.patch(`/comments/${Number(id)}/`, data);
    return response.data;
  },

  deleteComment: async (id) => {
    await api.delete(`/comments/${id}/delete/`);
  },
};
