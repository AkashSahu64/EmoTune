import React from "react";
import { useNavigate } from "react-router-dom";
import { Share2 } from "lucide-react";
import Avatar from "../common/Avatar.jsx";

const PlaylistCard = ({ playlist }) => {
  const navigate = useNavigate();

  const handleShare = (e) => {
    e.stopPropagation();

    const url = `${window.location.origin}/playlists/${playlist.id}`;

    if (navigator.share) {
      navigator.share({
        title: playlist.title,
        url,
      });
    } else {
      navigator.clipboard.writeText(url);
    }
  };

  return (
    <div
      onClick={() => navigate(`/playlists/${playlist.id}`)}
      className="
        flex items-center justify-between
        px-2 py-1 mx-4 mb-1
        bg-gray-100
        rounded-lg
        shadow-sm
        hover:shadow-sm
        hover:bg-white
        active:scale-[0.98]
        transition-all duration-200 ease-in-out
        cursor-pointer
      "
    >
      {/* LEFT SIDE */}
      <div className="flex items-center gap-4">
        <Avatar
          src={playlist.cover_image}
          alt={playlist.title}
          size="full"
          className="w-14 h-14 rounded-full object-cover"
        />

        <div>
          <h3 className="text-base font-semibold text-black">
            {playlist.title}
          </h3>

          <p className="text-sm text-gray-500">
            Playlist • {playlist.is_public ? "Public" : "Private"}
          </p>
        </div>
      </div>

      {/* SHARE ICON */}
      {playlist.is_public && (
        <button
          onClick={handleShare}
          className="
            p-2 rounded-full
            hover:bg-gray-200
            transition
          "
        >
          <Share2 className="w-5 h-5 text-gray-500" />
        </button>
      )}
    </div>
  );
};

export default React.memo(PlaylistCard);
