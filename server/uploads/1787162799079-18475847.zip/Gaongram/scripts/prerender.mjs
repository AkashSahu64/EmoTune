/* eslint-env node */
/* global console, process, setTimeout */
import { spawn } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { buildStaticPageSeo, STATIC_PAGE_SEO } from "../seo/builders/index.mjs";
import { injectSeoHead, renderSeoHead } from "../seo/metadata/render.mjs";

const packageJson = JSON.parse(readFileSync("package.json", "utf8"));
const parseRoutes = (value = "") => {
  const trimmed = String(value || "").trim();
  if (!trimmed) return [];

  if (trimmed.startsWith("[")) {
    try {
      return JSON.parse(trimmed);
    } catch {
      return [];
    }
  }

  return trimmed
    .split(/[\n,]/)
    .map((route) => route.trim())
    .filter(Boolean);
};

const readRoutesFile = () => {
  const routeFile = resolve("scripts", "prerender-routes.json");
  if (!existsSync(routeFile)) return [];

  try {
    const parsed = JSON.parse(readFileSync(routeFile, "utf8"));
    return Array.isArray(parsed) ? parsed : parsed.routes || [];
  } catch {
    return [];
  }
};

const normalizeRoute = (route) => {
  const value = String(route || "").trim();
  if (!value) return "";
  return value.startsWith("/") ? value : `/${value}`;
};

const crawlRoutes = Array.from(
  new Set(
    [
      ...(packageJson.reactSnap?.include || []),
      ...parseRoutes(process.env.GAONGRAM_PRERENDER_ROUTES),
      ...readRoutesFile(),
    ]
      .map(normalizeRoute)
      .filter(Boolean),
  ),
);
const routes = Array.from(
  new Set([
    ...crawlRoutes,
    ...((packageJson.seoSnapshots?.include || []).map(normalizeRoute)),
  ]),
).filter(Boolean);

const toSnapshotPath = (route) => {
  const pathname = String(route).split(/[?#]/)[0].replace(/^\/+|\/+$/g, "");
  return pathname ? resolve("dist", pathname, "index.html") : resolve("dist", "index.html");
};

const expectedSnapshots = routes.map(toSnapshotPath);
const reactSnapBin = resolve("scripts", "react-snap-runner.cjs");
const crawlTotal = crawlRoutes.length;

const staticPageKeyForRoute = (route) =>
  Object.entries(STATIC_PAGE_SEO).find(([, page]) => page.path === route)?.[0] ||
  "";

const writeStaticFallbackSnapshots = () => {
  const basePath = resolve("dist", "index.html");
  if (!existsSync(basePath)) return;

  const baseHtml = readFileSync(basePath, "utf8");
  for (const route of routes) {
    const target = toSnapshotPath(route);
    const pageKey = staticPageKeyForRoute(route);
    if (existsSync(target) || !pageKey) continue;

    const html = injectSeoHead(
      baseHtml,
      renderSeoHead(buildStaticPageSeo(pageKey, { path: route }), route),
    );
    mkdirSync(dirname(target), { recursive: true });
    writeFileSync(target, html);
    console.log(`seo snapshot generated for ${route}`);
  }
};

let staticFallbackWritten = false;

const snapshotsExist = () => {
  if (!staticFallbackWritten) {
    writeStaticFallbackSnapshots();
    staticFallbackWritten = true;
  }
  return expectedSnapshots.every((file) => existsSync(file));
};

const child = spawn(process.execPath, [reactSnapBin], {
  cwd: process.cwd(),
  env: {
    ...process.env,
    GAONGRAM_PRERENDER_ROUTES_RESOLVED: JSON.stringify(crawlRoutes),
  },
  windowsHide: true,
});

let completed = false;
let output = "";
let snapshotWaitStarted = false;

const stopChild = () =>
  new Promise((resolveStop) => {
    if (!child.pid || child.exitCode !== null || child.killed) {
      resolveStop();
      return;
    }

    child.kill();
    resolveStop();
  });

const finish = async (code) => {
  if (completed) return;
  completed = true;

  if (snapshotsExist()) {
    await stopChild();
    console.log("react-snap snapshots verified.");
    process.exit(0);
  }

  await stopChild();
  process.exit(code || 1);
};

const waitForSnapshotsThenFinish = () => {
  if (snapshotWaitStarted) return;
  snapshotWaitStarted = true;

  const deadline = Date.now() + 60000;
  const poll = () => {
    if (snapshotsExist()) {
      finish(0);
      return;
    }

    if (Date.now() > deadline) {
      finish(1);
      return;
    }

    setTimeout(poll, 1000).unref();
  };

  poll();
};

const handleOutput = (chunk, stream) => {
  const text = chunk.toString();
  output += text;
  stream.write(text);

  // Detect react-snap completion via multiple possible output patterns
  const completionPatterns = [
    `crawled ${crawlTotal} out of ${crawlTotal}`,
    "snapshot complete",
    "all snapshots complete",
    "finished generating snapshots",
    "react-snap: done",
  ];
  const isComplete = completionPatterns.some((p) => output.includes(p));

  if (isComplete) {
    waitForSnapshotsThenFinish();
  }
};

child.stdout.on("data", (chunk) => handleOutput(chunk, process.stdout));
child.stderr.on("data", (chunk) => handleOutput(chunk, process.stderr));
child.on("error", () => finish(1));
child.on("close", (code) => {
  if (snapshotsExist()) {
    finish(0);
    return;
  }

  if (code === 0 || snapshotWaitStarted) {
    waitForSnapshotsThenFinish();
    return;
  }

  finish(code);
});

setTimeout(() => finish(1), 120000).unref();
