import api from '../../config/axios.js';

export const vibeAPI = {
  // Get all vibe posts
  getVibePosts: async (params = {}) => {
    const response = await api.get('/vibe-posts/', { params });
    return response.data;
  },

  // Get single vibe post
  getVibePost: async (postId) => {
    const response = await api.get(`/vibe-posts/${postId}/`);
    return response.data;
  },

  // Create vibe post
  createVibePost: async (postData) => {
    const response = await api.post('/vibe-posts/', postData);
    return response.data;
  },

  // Update vibe post
  updateVibePost: async (postId, postData) => {
    const response = await api.put(`/vibe-posts/${postId}/`, postData);
    return response.data;
  },

  // Partial update vibe post
  patchVibePost: async (postId, postData) => {
    const response = await api.patch(`/vibe-posts/${postId}/`, postData);
    return response.data;
  },

  // Delete vibe post
  deleteVibePost: async (postId) => {
    const response = await api.delete(`/vibe-posts/${postId}/`);
    return response.data;
  },

  // Add view to post
  addView: async (postId) => {
    const response = await api.post(`/vibe-posts/${postId}/add_view/`);
    return response.data;
  },

  // Like/unlike post
  likePost: async (postId) => {
    const response = await api.post(`/vibe-posts/${postId}/like_post/`);
    return response.data;
  },

  // Unlike post
  unlikePost: async (postId) => {
    const response = await api.delete(`/vibe-posts/${postId}/like_post/`);
    return response.data;
  },

  // Vote on poll
  votePoll: async (postId, optionId) => {
    const response = await api.post(`/vibe-posts/${postId}/vote_poll/`, { 
      option_id: optionId 
    });
    return response.data;
  },

  // Get user posts
  getUserPosts: async (userId, params = {}) => {
    const response = await api.get(`/vibe-posts/${userId}/user_posts/`, { params });
    return response.data;
  },

  // Get user videos
  getUserVideos: async (userId, params = {}) => {
    const response = await api.get(`/vibe-posts/${userId}/user_videos/`, { params });
    return response.data;
  },

  // Save vibe post
  saveVibePost: async (postId) => {
    const response = await api.post(`/vibe-posts/${postId}/save/`);
    return response.data;
  },

  // Unsave vibe post
  unsaveVibePost: async (postId) => {
    const response = await api.delete(`/vibe-posts/${postId}/save/`);
    return response.data;
  },

  // Get trending vibes
  getTrendingVibes: async (params = {}) => {
    const response = await api.get('/vibe-posts/trending/', { params });
    return response.data;
  },

  // Get recommended vibes
  getRecommendedVibes: async (params = {}) => {
    const response = await api.get('/vibe-posts/recommended/', { params });
    return response.data;
  },

  // Share vibe post
  shareVibePost: async (postId, platform) => {
    const response = await api.post(`/vibe-posts/${postId}/share/`, { platform });
    return response.data;
  },

  // Report vibe post
  reportVibePost: async (postId, reason) => {
    const response = await api.post(`/vibe-posts/${postId}/report/`, { reason });
    return response.data;
  },
};