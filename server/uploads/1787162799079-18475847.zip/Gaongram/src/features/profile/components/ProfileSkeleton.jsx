import React from "react";

const ProfileSkeleton = () => (
  <div className="min-h-screen animate-pulse bg-[radial-gradient(circle_at_top,_rgba(198,167,94,0.12),_transparent_30%),linear-gradient(180deg,#fafafb_0%,#f4f6fb_100%)]">
    <div className="sticky top-0 z-20 border-b border-black/5 bg-background/90 backdrop-blur-xl">
      <div className="mx-auto flex h-14 max-w-5xl items-center px-3 sm:h-16 sm:px-4 md:px-6">
        <div className="grid w-full grid-cols-[40px_1fr_40px] items-center">
          <div className="h-10 w-10 rounded-full bg-muted" />
          <div className="mx-auto h-5 w-20 rounded-full bg-muted" />
          <div className="ml-auto h-10 w-10 rounded-full bg-muted" />
        </div>
      </div>
    </div>

    <div className="mx-auto w-full max-w-5xl px-0 sm:px-4 md:px-6">
      <div className="overflow-hidden bg-card sm:mt-4 sm:rounded-[32px] sm:border sm:border-border/70 sm:shadow-soft">
        <div className="relative h-[180px] bg-muted sm:h-[220px] lg:h-[240px]">
          <div className="absolute left-1/2 top-full h-24 w-24 -translate-x-1/2 -translate-y-1/2 rounded-full border-4 border-white bg-background sm:h-28 sm:w-28 lg:h-32 lg:w-32" />
        </div>

        <div className="px-4 pb-8 pt-16 sm:px-6 sm:pb-10 md:px-8">
          <div className="mx-auto h-8 w-48 rounded-full bg-muted" />
          <div className="mx-auto mt-3 h-4 w-28 rounded-full bg-muted" />
          <div className="mx-auto mt-4 h-4 w-64 rounded-full bg-muted" />
          <div className="mx-auto mt-2 h-4 w-52 rounded-full bg-muted" />

          <div className="mx-auto mt-6 flex max-w-md gap-3">
            <div className="h-11 flex-1 rounded-full bg-muted" />
            <div className="h-11 w-28 rounded-full bg-muted" />
          </div>

          <div className="mx-auto mt-6 grid max-w-sm grid-cols-3 divide-x divide-border/70 overflow-hidden rounded-2xl border border-border/80 bg-background/70">
            {[1, 2, 3].map((item) => (
              <div
                key={item}
                className="flex min-h-[84px] flex-col items-center justify-center gap-2 px-3 py-4"
              >
                <div className="h-5 w-12 rounded-full bg-muted" />
                <div className="h-3 w-16 rounded-full bg-muted" />
              </div>
            ))}
          </div>

          <div className="mt-6 border-b border-border/80">
            <div className="mx-auto grid max-w-md grid-cols-3 gap-1">
              {[1, 2, 3].map((item) => (
                <div
                  key={item}
                  className="mx-auto h-12 w-full rounded-2xl bg-muted"
                />
              ))}
            </div>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {Array.from({ length: 6 }).map((_, index) => (
              <div
                key={index}
                className="aspect-square rounded-[22px] bg-muted"
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  </div>
);

export default ProfileSkeleton;
