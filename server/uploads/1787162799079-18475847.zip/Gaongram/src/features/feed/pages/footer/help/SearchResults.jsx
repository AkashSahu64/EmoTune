// src/components/help/SearchResults.jsx
import React from 'react';
import { motion } from 'framer-motion';
import FAQAccordion from './FAQAccordion';
import Highlighter from 'react-highlight-words'; // npm install react-highlight-words

const SearchResults = ({ articles, query, onArticleClick, expandedId, setExpandedId }) => {
  if (articles.length === 0) {
    return (
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }}
        className="text-center py-16"
      >
        <p className="text-lg text-mutedForeground">No results found for "{query}"</p>
        <p className="text-sm mt-2">Try different keywords or browse categories.</p>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <h2 className="text-xl font-semibold mb-4 text-foreground dark:text-foreground-dark">
        Search Results ({articles.length})
      </h2>
      <div className="space-y-3">
        {articles.map(article => (
          <motion.div
            key={article.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="border border-border dark:border-border-dark rounded-xl overflow-hidden bg-card dark:bg-card-dark"
          >
            <button
              onClick={() => onArticleClick(article.id)}
              className="w-full px-5 py-4 text-left hover:bg-muted/50 dark:hover:bg-muted-dark/50 transition"
            >
              <Highlighter
                highlightClassName="bg-yellow-200 dark:bg-yellow-800 px-1 rounded"
                searchWords={query.split(' ')}
                autoEscape={true}
                textToHighlight={article.question}
                className="font-medium text-foreground dark:text-foreground-dark"
              />
              <p className="text-sm text-mutedForeground mt-1 line-clamp-2">
                <Highlighter
                  highlightClassName="bg-yellow-200 dark:bg-yellow-800"
                  searchWords={query.split(' ')}
                  autoEscape={true}
                  textToHighlight={article.answer.substring(0, 150) + '...'}
                />
              </p>
            </button>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default SearchResults;