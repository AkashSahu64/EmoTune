// src/hooks/useSendMessage.js
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { messageService } from "../services/message.service";
import { useChatStore } from "../store/chatStore";
import { useAuthStore } from "../store/authStore";
import { showToast } from "../utils/toast";
import { useSocket } from "../context/SocketProvider";

export const useSendMessage = (receiverId) => {
  const queryClient = useQueryClient();
  const { emit, isConnected } = useSocket();
  const {
    addTempMessage,
    replaceTempMessage,
    markMessageFailed,
    clearFailedMessage,
    updateChatList,
  } = useChatStore();
  const { user } = useAuthStore();

  const sendMessage = useMutation({
    mutationFn: async ({ message, file, file_type, reply_to, retryTempId = null }) => {
      const tempId = retryTempId || `temp_${Date.now()}_${Math.random()}`;

      const tempMessage = {
        tempId,
        id: tempId,
        sender: user?.id,
        receiver: receiverId,
        message: message || "",
        file: file ? URL.createObjectURL(file) : null,
        file_type: file_type || "others",
        created_at: new Date().toISOString(),
        isTemp: true,
        reply_to: reply_to
  ? {
      id: reply_to.id,
      message: reply_to.message,
      sender_name: reply_to.sender_name,
      file_type: reply_to.file_type,
      file: reply_to.file,
    }
  : null,
      };

      addTempMessage(receiverId, tempMessage);

      try {
        // ✅ PRIORITY: WEBSOCKET SEND
        if (isConnected && !file) {
          emit("message", {
            id: tempId,
            message_type: "text",
            message,
            receiver_id: receiverId,
          });
          return;
        }

        // ❗ fallback if socket not connected
        const response = await messageService.sendMessage(receiverId, {
          message,
          files: file ? [file] : [],
          file_type,
          reply_to,
        });

        if (response.success && response.data?.[0]) {
          const realMsg = response.data[0];

          replaceTempMessage(receiverId, tempId, realMsg);

          // 🔥 SEND VIA SOCKET ALSO
          emit("message", {
            id: realMsg.id,
            message_type: "file",
            message: realMsg.message,
            file: realMsg.file,
            file_type: realMsg.file_type,
            receiver_id: receiverId,
            reply_to: tempMessage.reply_to,
          });
        }
      } catch (error) {
        markMessageFailed(tempId, () =>
          sendMessage.mutate({ message, file, file_type, retryTempId: tempId }),
        );
      }
    },
  });

  return {
    sendMessage: sendMessage.mutate,
    isSending: sendMessage.isPending,
  };
};
