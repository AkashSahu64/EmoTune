import React from "react";
import { Plus, Image } from "lucide-react";
import { useUIStore } from "../../../store/uiStore.js";
import Avatar from "../../../components/common/Avatar.jsx";
import { useTranslation } from "react-i18next";

const CreatePostBar = ({ user, variant = "default" }) => {
  const { openModal } = useUIStore();
  const { t } = useTranslation();

  return (
    <div className="flex items-center gap-3">
      <Avatar
        src={user?.avatar || user?.profile_image || user?.photo}
        alt={user?.username}
        size="md"
      />

      <button
        onClick={() => openModal("create-post-selector")}
        className={`flex items-center justify-between flex-1 
        bg-muted dark:bg-muted-dark 
        border border-border dark:border-border-dark 
        rounded-full px-4 py-1
        hover:bg-muted/80 dark:hover:bg-muted-dark/80 
        transition`}
      >
        <span className="text-mutedForeground text-sm">
          {t("what_on_mind")}
        </span>

        {variant === "mobile" ? (
          <Image className="w-5 h-5 text-primary" />
        ) : (
          <div className="w-8 h-8 flex items-center justify-center 
            rounded-full bg-primary text-muted hover:scale-105 transition-all">
            <Plus size={16} />
          </div>
        )}
      </button>
    </div>
  );
};

export default CreatePostBar;