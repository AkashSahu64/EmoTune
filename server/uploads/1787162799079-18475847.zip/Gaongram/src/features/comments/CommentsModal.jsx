import React, { useRef, useState } from "react";
import { X, Heart, MoreVertical } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuthStore } from "../../store/authStore.js";
import { useUIStore } from "../../store/uiStore.js";
import { commentService } from "../../services/comment.service.js";
import { showSuccess, showError } from "../../utils/toast.js";
import { formatTime } from "../../utils/formatTime.js";
import Avatar from "../../components/common/Avatar.jsx";
import Loader from "../../components/common/Loader.jsx";
import Button from "../../components/common/Button.jsx";
import { useTranslation } from "react-i18next";
import { IoIosSend } from "react-icons/io";

const isSameId = (a, b) => String(a) === String(b);

const toBoolean = (value) => {
  if (typeof value === "boolean") return value;
  if (typeof value === "string") return value.toLowerCase() === "true";
  return Boolean(value);
};

const getCreatedComment = (response) => {
  const candidates = [response?.data?.data, response?.data, response];

  return candidates.find(
    (candidate) =>
      candidate &&
      typeof candidate === "object" &&
      !Array.isArray(candidate) &&
      (candidate.id || candidate.comment),
  );
};

const withCommentResults = (old, updateResults, updateCount) => {
  if (!old) return old;

  if (Array.isArray(old)) {
    return updateResults(old);
  }

  if (Array.isArray(old?.data?.results)) {
    return {
      ...old,
      data: {
        ...old.data,
        results: updateResults(old.data.results),
        count: updateCount ? updateCount(old.data.count) : old.data.count,
      },
    };
  }

  if (Array.isArray(old?.data)) {
    return {
      ...old,
      data: updateResults(old.data),
    };
  }

  return old;
};

const insertComment = (comments, commentToInsert, parentId) => {
  if (!parentId) {
    return [
      commentToInsert,
      ...comments.filter(
        (comment) => !isSameId(comment.id, commentToInsert.id),
      ),
    ];
  }

  return comments.map((comment) => {
    if (isSameId(comment.id, parentId)) {
      const existingReplies = Array.isArray(comment.replies)
        ? comment.replies
        : [];

      return {
        ...comment,
        replies: [
          ...existingReplies.filter(
            (reply) => !isSameId(reply.id, commentToInsert.id),
          ),
          commentToInsert,
        ],
      };
    }

    if (Array.isArray(comment.replies) && comment.replies.length > 0) {
      return {
        ...comment,
        replies: insertComment(comment.replies, commentToInsert, parentId),
      };
    }

    return comment;
  });
};

const replaceTempComment = (comments, tempId, realComment, parentId) => {
  let replaced = false;

  const replaceInTree = (items) =>
    items.reduce((next, item) => {
      if (
        realComment.id &&
        isSameId(item.id, realComment.id) &&
        !isSameId(item.id, tempId)
      ) {
        return next;
      }

      if (isSameId(item.id, tempId)) {
        replaced = true;
        next.push({
          ...item,
          ...realComment,
          replies: Array.isArray(realComment.replies)
            ? realComment.replies
            : item.replies || [],
        });
        return next;
      }

      next.push({
        ...item,
        replies: Array.isArray(item.replies)
          ? replaceInTree(item.replies)
          : item.replies,
      });
      return next;
    }, []);

  const withoutTemp = replaceInTree(comments);
  return replaced
    ? withoutTemp
    : insertComment(withoutTemp, realComment, parentId);
};

const removeComment = (comments, commentId) =>
  comments
    .filter((comment) => !isSameId(comment.id, commentId))
    .map((comment) => ({
      ...comment,
      replies: Array.isArray(comment.replies)
        ? removeComment(comment.replies, commentId)
        : [],
    }));

const updateCommentLikes = (comments, commentId, updater) =>
  comments.map((comment) => {
    if (isSameId(comment.id, commentId)) {
      return updater(comment);
    }

    if (Array.isArray(comment.replies) && comment.replies.length > 0) {
      return {
        ...comment,
        replies: updateCommentLikes(comment.replies, commentId, updater),
      };
    }

    return comment;
  });

const getRootComments = (commentsData) => commentsData?.data?.results || [];

const CommentsModal = ({ postId, onCommentAdded, onCommentDeleted }) => {
  const { user, isAuthenticated } = useAuthStore();
  const { closeModal, openModal } = useUIStore();
  const queryClient = useQueryClient();
  const { t } = useTranslation();

  const [newComment, setNewComment] = useState("");
  const [replyText, setReplyText] = useState("");
  const [replyingTo, setReplyingTo] = useState(null);
  const submitLockRef = useRef(false);
  const commentsQueryKey = ["comments", postId];

  const {
    data: commentsData,
    isLoading,
    isError,
  } = useQuery({
    queryKey: commentsQueryKey,
    queryFn: () => commentService.getComments(postId),
    enabled: !!postId,
    staleTime: 2 * 60 * 1000,
  });

  const createCommentMutation = useMutation({
    mutationFn: (commentData) => commentService.createComment(commentData),
    onMutate: async (newCommentData) => {
      await queryClient.cancelQueries({ queryKey: commentsQueryKey });

      const previousComments = queryClient.getQueryData(commentsQueryKey);
      const tempId = `temp-comment-${Date.now()}-${Math.random()
        .toString(36)
        .slice(2)}`;
      const isReply = Boolean(newCommentData.parent);

      const optimisticComment = {
        id: tempId,
        user: user?.id,
        username: user?.username || user?.name || "",
        post: isReply ? undefined : postId,
        parent: newCommentData.parent || null,
        profile_image: user?.profile_image || user?.avatar,
        comment: newCommentData.comment,
        created_at: new Date().toISOString(),
        likes_count: 0,
        is_liked: false,
        replies: [],
        is_verified: Boolean(user?.is_verified),
        is_optimistic: true,
      };

      queryClient.setQueryData(commentsQueryKey, (old) =>
        withCommentResults(
          old,
          (comments) =>
            insertComment(comments, optimisticComment, newCommentData.parent),
          (count = 0) => count + 1,
        ),
      );

      return { previousComments, tempId, optimisticComment };
    },
    onSuccess: (data, variables, context) => {
      const serverComment = getCreatedComment(data);

      const realComment = {
        ...context.optimisticComment,
        ...serverComment,
        id: serverComment?.id ?? context.tempId,
        post: serverComment?.post ?? (variables.parent ? undefined : postId),
        parent: serverComment?.parent ?? variables.parent ?? null,
        comment: serverComment?.comment ?? variables.comment,
        likes_count: serverComment?.likes_count ?? 0,
        is_liked: toBoolean(serverComment?.is_liked),
        replies: Array.isArray(serverComment?.replies)
          ? serverComment.replies
          : [],
        is_optimistic: false,
      };

      queryClient.setQueryData(commentsQueryKey, (old) =>
        withCommentResults(old, (comments) =>
          replaceTempComment(
            comments,
            context.tempId,
            realComment,
            variables.parent,
          ),
        ),
      );

      setReplyText("");
      setNewComment("");
      setReplyingTo(null);

      // ✅ ONLY THIS
      onCommentAdded?.();
    },
    onError: (err, variables, context) => {
      showError(t("comment_failed") || "Failed to add comment");
      if (context?.previousComments) {
        queryClient.setQueryData(commentsQueryKey, context.previousComments);
      }
    },
    onSettled: () => {
      submitLockRef.current = false;
    },
  });

  const toggleLikeMutation = useMutation({
    mutationFn: ({ commentId }) => commentService.likeComment(commentId),
    onMutate: async ({ commentId }) => {
      await queryClient.cancelQueries({ queryKey: commentsQueryKey });

      const previousComments = queryClient.getQueryData(commentsQueryKey);

      queryClient.setQueryData(commentsQueryKey, (old) =>
        withCommentResults(old, (comments) =>
          updateCommentLikes(comments, commentId, (comment) => {
            const alreadyLiked = toBoolean(comment.is_liked);

            return {
              ...comment,
              is_liked: !alreadyLiked,
              likes_count: !alreadyLiked
                ? (comment.likes_count || 0) + 1
                : Math.max(0, (comment.likes_count || 0) - 1),
            };
          }),
        ),
      );

      return { previousComments };
    },
    onSuccess: (data, variables) => {
      const updated = data?.data?.data || data?.data || data;

      if (
        updated &&
        typeof updated === "object" &&
        ("likes_count" in updated || "is_liked" in updated)
      ) {
        queryClient.setQueryData(commentsQueryKey, (old) =>
          withCommentResults(old, (comments) =>
            updateCommentLikes(comments, variables.commentId, (comment) => ({
              ...comment,
              is_liked:
                typeof updated.is_liked === "undefined"
                  ? comment.is_liked
                  : toBoolean(updated.is_liked),
              likes_count: updated.likes_count ?? comment.likes_count,
            })),
          ),
        );
      }
    },
    onError: (err, variables, context) => {
      if (context?.previousComments) {
        queryClient.setQueryData(commentsQueryKey, context.previousComments);
      }

      showError(t("like_failed") || "Failed to update like");
    },
  });

  const deleteCommentMutation = useMutation({
    mutationFn: (commentId) => commentService.deleteComment(commentId),
    onMutate: async (commentId) => {
      await queryClient.cancelQueries({ queryKey: commentsQueryKey });

      const previousComments = queryClient.getQueryData(commentsQueryKey);
      const wasTopLevel = getRootComments(previousComments).some((comment) =>
        isSameId(comment.id, commentId),
      );

      queryClient.setQueryData(commentsQueryKey, (old) =>
        withCommentResults(
          old,
          (comments) => removeComment(comments, commentId),
          (count = 0) => Math.max(0, count - 1),
        ),
      );

      return { previousComments };
    },
    onSuccess: () => {
      const updatedCount =
        queryClient.getQueryData(commentsQueryKey)?.data?.count || 0;

      onCommentDeleted?.();

      onCommentsCountSynced?.(updatedCount);
    },
    onError: (err, variables, context) => {
      if (context?.previousComments) {
        queryClient.setQueryData(commentsQueryKey, context.previousComments);
      }
    },
  });

  const handleSubmit = (event) => {
    event.preventDefault();

    if (submitLockRef.current || createCommentMutation.isPending) return;

    if (!isAuthenticated) {
      showError(t("login_to_comment") || "Please login to comment");
      return;
    }

    const text = replyingTo ? replyText : newComment;
    if (!text.trim()) return;

    submitLockRef.current = true;
    createCommentMutation.mutate({
      comment: text.trim(),
      postId,
      parent: replyingTo,
    });
  };

  const handleLikeComment = (comment) => {
    if (!isAuthenticated) {
      showError(t("login_to_like_comments"));
      return;
    }

    toggleLikeMutation.mutate({
      commentId: comment.id,
      isReply: comment.parent !== null,
    });
  };

  const handleDeleteComment = (commentId) => {
    if (window.confirm(t("confirm_delete_comment"))) {
      deleteCommentMutation.mutate(commentId);
    }
  };

  const renderComment = (comment, depth = 0) => {
    const isOwner = Number(user?.id) === Number(comment.user);
    const isReply = depth > 0;
    const isCreating = createCommentMutation.isPending;

    return (
      <div key={comment.id} className={`py-1 ${isReply ? "ml-1" : ""}`}>
        <div className="flex items-start leading-tight">
          <div className="flex-shrink-0 mr-2">
            <Avatar
              src={comment.profile_image}
              alt={comment.username}
              size="small"
            />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center flex-wrap gap-1 mb-1">
                  <span className="text-sm font-semibold text-foreground dark:text-foreground-dark">
                    {comment.username}
                  </span>
                  <span className="text-sm text-foreground dark:text-foreground-dark break-all">
                    {comment.comment}
                  </span>
                </div>

                <div className="flex items-center space-x-3 text-xs text-mutedForeground dark:text-mutedForeground-dark mt-1">
                  <span>{formatTime(comment.created_at, "relative")}</span>
                  <button
                    type="button"
                    onClick={() => handleLikeComment(comment)}
                    className={`hover:text-foreground dark:hover:text-foreground-dark ${
                      toBoolean(comment.is_liked)
                        ? "text-red-500 font-semibold"
                        : ""
                    }`}
                  >
                    {comment.likes_count > 0
                      ? t("likes_count", { count: comment.likes_count })
                      : t("like")}
                  </button>
                  {!isReply && (
                    <button
                      type="button"
                      onClick={() => {
                        if (!isAuthenticated) {
                          showError(t("login_to_reply"));
                          return;
                        }
                        setReplyingTo(
                          replyingTo === comment.id ? null : comment.id,
                        );
                      }}
                      className="hover:text-foreground dark:hover:text-foreground-dark"
                    >
                      {t("reply")}
                    </button>
                  )}
                  {isOwner && (
                    <button
                      type="button"
                      onClick={() => handleDeleteComment(comment.id)}
                      className="text-red-500 hover:text-red-700"
                    >
                      {t("delete")}
                    </button>
                  )}
                </div>

                {replyingTo === comment.id && (
                  <form
                    onSubmit={handleSubmit}
                    className="mt-2 flex items-center w-[260px] sm:w-[220px]"
                  >
                    <input
                      type="text"
                      placeholder={`Reply to ${comment.username}...`}
                      value={replyText}
                      onChange={(event) => setReplyText(event.target.value)}
                      disabled={isCreating}
                      className="flex-1 px-2 py-1 text-sm border border-border dark:border-border-dark bg-white dark:bg-card-dark rounded-full focus:ring-1 focus:ring-primary focus:border-transparent focus:outline-none"
                      autoFocus
                    />
                    <button
                      type="submit"
                      disabled={!replyText.trim() || isCreating}
                      className={` relative flex items-center justify-center w-8 h-8 rounded-full transition-all duration-300 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed ml-2 ${replyText.trim() ? "bg-primary/80 text-white shadow-xs" : "bg-muted dark:bg-muted-dark text-mutedForeground"}`}
                    >
                      {isCreating ? (
                        <div
                          size={20}
                          className="border-2 border-white/40 border-t-white rounded-full animate-spin"
                        />
                      ) : (
                        <IoIosSend
                          size={22}
                          className={`transition-transform duration-300 ${replyText.trim() ? "translate-x-[1px]" : ""}`}
                        />
                      )}
                    </button>
                  </form>
                )}
              </div>

              <div className="flex items-center ml-2">
                <button
                  type="button"
                  onClick={() => handleLikeComment(comment)}
                  className="p-1"
                >
                  <Heart
                    className={`w-5 h-5 ${
                      toBoolean(comment.is_liked)
                        ? "fill-red-500 text-red-500"
                        : "text-mutedForeground dark:text-mutedForeground-dark"
                    }`}
                  />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    openModal("comment-options", {
                      isOwner,
                      commentId: comment.id,
                      commentData: comment,
                      onDelete: () => handleDeleteComment(comment.id),
                    })
                  }
                  className="text-mutedForeground dark:text-mutedForeground-dark hover:text-foreground dark:hover:text-foreground-dark"
                >
                  <MoreVertical className="w-5 h-5" />
                </button>
              </div>
            </div>

            {Array.isArray(comment.replies) && comment.replies.length > 0 && (
              <div className="mt-1 space-y-1 leadting-tight">
                {comment.replies.map((reply) =>
                  renderComment(reply, depth + 1),
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  const comments = getRootComments(commentsData);
  const totalComments = commentsData?.data?.count || 0;

  return (
    <div className="h-full flex flex-col bg-white dark:bg-card-dark">
      <div className="px-4 py-3 border-b border-border dark:border-border-dark flex items-center justify-between">
        <h2 className="text-lg font-semibold text-foreground dark:text-foreground-dark">
          {t("comments")} {totalComments > 0 && `(${totalComments})`}
        </h2>
        <button
          type="button"
          onClick={closeModal}
          className="p-2 hover:bg-gray-100 dark:hover:bg-muted-dark rounded-full text-foreground dark:text-foreground-dark"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-3 pb-24">
        {isLoading ? (
          <div className="flex justify-center py-8">
            <Loader />
          </div>
        ) : isError ? (
          <div className="text-center py-8">
            <p className="text-mutedForeground dark:text-mutedForeground-dark">
              {t("comment_failed")}
            </p>
          </div>
        ) : comments.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-mutedForeground dark:text-mutedForeground-dark">
              {t("no_comment")}
            </p>
          </div>
        ) : (
          <div className="py-2">
            {comments.map((comment) => renderComment(comment))}
          </div>
        )}
      </div>

      <div className="px-4 py-2 border-t border-border dark:border-border-dark bg-white dark:bg-card-dark sticky bottom-0">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <input
            value={newComment}
            onChange={(event) => setNewComment(event.target.value)}
            disabled={createCommentMutation.isPending}
            placeholder={t("add_a_comment")}
            className="flex-1 px-4 py-2 border border-border dark:border-border-dark bg-white dark:bg-card-dark rounded-full text-foreground dark:text-foreground-dark focus:outline-none focus:ring-2 focus:ring-instagram-pink"
          />
          <button
            type="submit"
            disabled={!newComment.trim() || createCommentMutation.isPending}
            className={`
    relative flex items-center justify-center
    w-10 h-10 rounded-full
    transition-all duration-300
    active:scale-95
    disabled:opacity-50 disabled:cursor-not-allowed
    ${
      newComment.trim()
        ? "bg-primary text-white shadow-lg "
        : "bg-muted dark:bg-muted-dark text-mutedForeground"
    }
  `}
          >
            {createCommentMutation.isPending && !replyingTo ? (
              <div className="w-5 h-5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
            ) : (
              <IoIosSend
                size={28}
                className={`
        transition-transform duration-300
        ${newComment.trim() ? "translate-x-[1px]" : ""}
      `}
              />
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default CommentsModal;
