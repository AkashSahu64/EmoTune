import { useState, useEffect, useRef, useCallback } from "react";

const IMAGE_DURATION = 7000;
const clampProgress = (value) => Math.min(100, Math.max(0, value));

export const useStoryProgress = ({
  isActive,
  storyType,
  videoRef,
  durationMs = IMAGE_DURATION,
  onComplete,
}) => {
  const [progress, setProgress] = useState(0);
  const [isBuffering, setIsBuffering] = useState(false);

  const rafRef = useRef(null);
  const isActiveRef = useRef(isActive);
  const storyTypeRef = useRef(storyType);
  const onCompleteRef = useRef(onComplete);
  const startTimeRef = useRef(0);
  const pausedRef = useRef(false);
  const elapsedBeforePauseRef = useRef(0);
  const durationRef = useRef(durationMs || IMAGE_DURATION);
  const completedRef = useRef(false);
  const lastProgressRef = useRef(0);

  useEffect(() => {
    isActiveRef.current = isActive;
  }, [isActive]);

  useEffect(() => {
    storyTypeRef.current = storyType;
  }, [storyType]);

  useEffect(() => {
    onCompleteRef.current = onComplete;
  }, [onComplete]);

  const commitProgress = useCallback((nextProgress, force = false) => {
    const rounded = clampProgress(nextProgress);
    if (!force && Math.abs(rounded - lastProgressRef.current) < 0.18 && rounded < 100) return;
    lastProgressRef.current = rounded;
    setProgress(rounded);
  }, []);

  const completeOnce = useCallback(() => {
    if (completedRef.current) return;
    completedRef.current = true;
    cancelAnimationFrame(rafRef.current);
    commitProgress(100, true);
    onCompleteRef.current?.();
  }, [commitProgress]);

  const tickImage = useCallback(
    (now) => {
      if (!isActiveRef.current || pausedRef.current) return;
      const elapsed = elapsedBeforePauseRef.current + (now - startTimeRef.current);
      const percent = (elapsed / durationRef.current) * 100;
      commitProgress(percent);
      if (percent >= 100) completeOnce();
      else rafRef.current = requestAnimationFrame(tickImage);
    },
    [commitProgress, completeOnce],
  );

  const tickVideo = useCallback(() => {
    const video = videoRef?.current;
    if (!isActiveRef.current || pausedRef.current || !video) return;
    if (video.duration && Number.isFinite(video.duration)) {
      const percent = (video.currentTime / video.duration) * 100;
      commitProgress(percent);
      if (percent >= 99.9 || video.ended) {
        completeOnce();
        return;
      }
    }
    rafRef.current = requestAnimationFrame(tickVideo);
  }, [commitProgress, completeOnce, videoRef]);

  const start = useCallback((options = {}) => {
    const { resetElapsed = false } = options;
    if (!isActiveRef.current) return;
    cancelAnimationFrame(rafRef.current);
    completedRef.current = false;
    pausedRef.current = false;
    if (resetElapsed) elapsedBeforePauseRef.current = 0;
    startTimeRef.current = performance.now();
    if (storyTypeRef.current === "video") rafRef.current = requestAnimationFrame(tickVideo);
    else rafRef.current = requestAnimationFrame(tickImage);
  }, [tickImage, tickVideo]);

  useEffect(() => {
    durationRef.current = durationMs || IMAGE_DURATION;
  }, [durationMs]);

  useEffect(() => {
    if (!isActive) {
      cancelAnimationFrame(rafRef.current);
      return undefined;
    }
    start();
    return () => cancelAnimationFrame(rafRef.current);
  }, [isActive, start, storyType]);

  useEffect(() => {
    if (storyType !== "video" || !videoRef?.current) return undefined;
    const video = videoRef.current;

    const handleWaiting = () => setIsBuffering(true);
    const handlePlaying = () => {
      setIsBuffering(false);
      if (!pausedRef.current) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = requestAnimationFrame(tickVideo);
      }
    };
    const handleEnded = () => completeOnce();
    const handleSeek = () => {
      if (video.duration) {
        commitProgress((video.currentTime / video.duration) * 100, true);
      }
    };

    video.addEventListener("waiting", handleWaiting);
    video.addEventListener("stalled", handleWaiting);
    video.addEventListener("playing", handlePlaying);
    video.addEventListener("canplay", handlePlaying);
    video.addEventListener("ended", handleEnded);
    video.addEventListener("seeked", handleSeek);
    video.addEventListener("timeupdate", handleSeek);

    return () => {
      video.removeEventListener("waiting", handleWaiting);
      video.removeEventListener("stalled", handleWaiting);
      video.removeEventListener("playing", handlePlaying);
      video.removeEventListener("canplay", handlePlaying);
      video.removeEventListener("ended", handleEnded);
      video.removeEventListener("seeked", handleSeek);
      video.removeEventListener("timeupdate", handleSeek);
    };
  }, [commitProgress, completeOnce, storyType, tickVideo, videoRef]);

  const pause = useCallback(() => {
    if (pausedRef.current) return;
    pausedRef.current = true;
    elapsedBeforePauseRef.current = (lastProgressRef.current / 100) * durationRef.current;
    cancelAnimationFrame(rafRef.current);
    videoRef?.current?.pause?.();
  }, [videoRef]);

  const resume = useCallback(() => {
    if (!isActiveRef.current || completedRef.current) return;
    pausedRef.current = false;
    startTimeRef.current = performance.now();
    cancelAnimationFrame(rafRef.current);

    if (storyTypeRef.current === "video" && videoRef?.current) {
      videoRef.current.play().catch(() => {});
      rafRef.current = requestAnimationFrame(tickVideo);
      return;
    }

    rafRef.current = requestAnimationFrame(tickImage);
  }, [tickImage, tickVideo, videoRef]);

  const seek = useCallback(
    (percent) => {
      const next = clampProgress(percent);
      elapsedBeforePauseRef.current = (next / 100) * durationRef.current;
      startTimeRef.current = performance.now();
      commitProgress(next, true);
      const video = videoRef?.current;
      if (video?.duration) {
        video.currentTime = (next / 100) * video.duration;
      }
    },
    [commitProgress, videoRef],
  );

  const reset = useCallback(() => {
    completedRef.current = false;
    lastProgressRef.current = 0;
    elapsedBeforePauseRef.current = 0;
    pausedRef.current = false;
    setIsBuffering(false);
    commitProgress(0, true);
    cancelAnimationFrame(rafRef.current);
    if (videoRef?.current) {
      videoRef.current.currentTime = 0;
    }
    start({ resetElapsed: true });
  }, [commitProgress, start, videoRef]);

  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        if (isActiveRef.current && !pausedRef.current) {
          pausedRef.current = true;
          elapsedBeforePauseRef.current = (lastProgressRef.current / 100) * durationRef.current;
          cancelAnimationFrame(rafRef.current);
        }
        return;
      }

      if (isActiveRef.current && pausedRef.current) {
        resume();
      }
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => document.removeEventListener("visibilitychange", handleVisibilityChange);
  }, [resume]);

  return {
    progress,
    isBuffering,
    pause,
    resume,
    reset,
    seek,
  };
};
