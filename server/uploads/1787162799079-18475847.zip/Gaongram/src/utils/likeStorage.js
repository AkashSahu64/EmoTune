export const getLikedPosts = () => {
  try {
    return JSON.parse(localStorage.getItem('liked_posts')) || [];
  } catch {
    return [];
  }
};

export const addLikedPost = (id) => {
  const liked = getLikedPosts();
  localStorage.setItem(
    'liked_posts',
    JSON.stringify([...new Set([...liked, id])])
  );
};

export const removeLikedPost = (id) => {
  const liked = getLikedPosts().filter(pid => pid !== id);
  localStorage.setItem('liked_posts', JSON.stringify(liked));
};
