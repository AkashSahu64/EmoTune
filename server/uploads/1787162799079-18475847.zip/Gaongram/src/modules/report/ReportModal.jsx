import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { AlertCircle, CheckCircle, X } from 'lucide-react';
import { useUIStore } from '../../store/uiStore.js';
import Button from '../../components/common/Button.jsx';
import { useTranslation } from "react-i18next";

const ReportModal = ({ modelType, objectId, objectData, reasons = [], onSubmit }) => {
  const { closeModal } = useUIStore();
  const { t } = useTranslation();

  const [selectedReason, setSelectedReason] = useState(null);
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [step, setStep] = useState('select');

  // Get display text based on model type
  const getDisplayText = () => {
    switch (modelType) {
      case 'user':
        return { 
          title: t('report_user'), 
          subtitle: t('report_user_subtitle') 
        };
      case 'post':
        return { 
          title: t('report_post'), 
          subtitle: t('report_post_subtitle') 
        };
      case 'comment':
        return { 
          title: t('report_comment'), 
          subtitle: t('report_comment_subtitle') 
        };
      default:
        return { 
          title: t('report'), 
          subtitle: t('select_reason') 
        };
    }
  };

  const { title, subtitle } = getDisplayText();

  const handleReasonSelect = (reasonKey) => {
    setSelectedReason(reasonKey);

    if (reasonKey === 'other') {
      setStep('details');
      return;
    }

    handleSubmit(reasonKey);
  };

  const handleSubmit = async (customReason = null) => {
    const reasonToSubmit = customReason || selectedReason;
    if (!reasonToSubmit) return;

    setIsSubmitting(true);
    try {
      const res = await onSubmit(
        reasonToSubmit,
        reasonToSubmit === 'other' ? description : null
      );

      if (res?.success) {
        setStep('success');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setSelectedReason(null);
    setDescription('');
    setStep('select');
  };

  if (step === 'success') {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="p-6 max-w-sm mx-auto text-center bg-white dark:bg-card-dark rounded-lg"
      >
        <div className="w-16 h-16 mx-auto mb-4 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center">
          <CheckCircle className="w-8 h-8 text-green-600 dark:text-green-400" />
        </div>
        
        <h3 className="text-xl font-semibold text-foreground dark:text-foreground-dark mb-2">
          {t("report_submitted")}
        </h3>
        
        <p className="text-mutedForeground dark:text-mutedForeground-dark mb-6">
          {t("report_thank_you")}
        </p>
        
        <Button
          fullWidth
          onClick={closeModal}
          className="bg-green-600 hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-800"
        >
          {t("done")}
        </Button>
      </motion.div>
    );
  }

  if (step === 'details') {
    return (
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="px-3 py-2 max-w-sm mx-auto bg-white dark:bg-card-dark rounded-lg"
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground dark:text-foreground-dark">{title}</h3>
            <p className="text-sm text-mutedForeground dark:text-mutedForeground-dark">
              {t("provide_details")}
            </p>
          </div>
          <button
            onClick={handleReset}
            className="p-1 hover:bg-gray-100 dark:hover:bg-muted-dark rounded-full"
          >
            <X className="w-5 h-5 text-mutedForeground dark:text-mutedForeground-dark" />
          </button>
        </div>

        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder={t("describe_issue")}
          className="w-full h-32 p-3 border border-border dark:border-border-dark bg-white dark:bg-card-dark rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent resize-none text-foreground dark:text-foreground-dark outline-none"
          rows={4}
        />

        <div className="flex gap-3 mt-6">
          <Button
            variant="outline"
            fullWidth
            onClick={handleReset}
            disabled={isSubmitting}
            className="bg-white dark:bg-card-dark text-black dark:text-white hover:bg-gray-50 dark:hover:bg-muted-dark/80"
          >
            {t("back")}
          </Button>
          
          <Button
            fullWidth
            loading={isSubmitting}
            onClick={() => handleSubmit()}
            disabled={!description.trim()}
          >
            {t("submit_report")}
          </Button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="px-6 py-3 max-w-sm mx-auto bg-white dark:bg-card-dark rounded-lg"
    >
      <div className="mb-4 text-center">
        <div className="w-12 h-12 mx-auto mb-3 bg-red-100 dark:bg-red-950/30 rounded-full flex items-center justify-center">
          <AlertCircle className="w-6 h-6 text-red-600 dark:text-red-400" />
        </div>
        
        <h3 className="text-lg font-semibold text-foreground dark:text-foreground-dark mb-1">
          {title}
        </h3>
        
        <p className="text-sm text-mutedForeground dark:text-mutedForeground-dark">
          {subtitle}
        </p>
      </div>

      <div className="space-y-1 mb-3">
        {reasons.map((reason) => (
          <button
            key={reason.key}
            onClick={() => handleReasonSelect(reason.key)}
            disabled={isSubmitting}
            className={`
              w-full text-left px-3 py-2 rounded-lg border transition-all duration-200
              ${selectedReason === reason.key
                ? 'border-red-500 bg-red-50 dark:bg-red-950/30'
                : 'border-border dark:border-border-dark hover:bg-gray-50 dark:hover:bg-muted-dark'
              }
              ${isSubmitting ? 'opacity-50 cursor-not-allowed' : ''}
            `}
          >
            <span className={`font-medium ${
              selectedReason === reason.key
                ? 'text-red-700 dark:text-red-400'
                : 'text-foreground dark:text-foreground-dark'
            }`}>
              {t(reason.label)} 
            </span>
          </button>
        ))}
      </div>

      <div className="space-y-0">
        <Button
          variant="ghost"
          fullWidth
          onClick={closeModal}
          disabled={isSubmitting}
          className="mb-2 text-mutedForeground border dark:text-mutedForeground-dark hover:text-foreground dark:hover:text-foreground-dark dark:bg-muted-dark/80 dark:hover:bg-muted-dark"
        >
          {t("cancel")}
        </Button>
        
        <p className="text-xs text-mutedForeground dark:text-mutedForeground-dark text-center">
          {t("report_anonymous")}
        </p>
      </div>
    </motion.div>
  );
};

export default ReportModal;