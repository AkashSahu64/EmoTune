import CanvasEngine from "../../story/editor/engine/core/CanvasEngine.js";
import { getEditorConfig } from "./editorConfig.js";
import { getDeviceProfile } from "../utils/deviceHelpers.js";

export default class EditorEngine extends CanvasEngine {
  constructor(options = {}) {
    super(options);
    this.config = getEditorConfig(options.config);
    this.deviceProfile = getDeviceProfile();
  }

  init(aspectRatio = this.config.aspectRatio) {
    const canvas = super.init(aspectRatio);
    this.applyDeviceProfile();
    return canvas;
  }

  applyDeviceProfile() {
    if (!this.canvas) return;

    this.canvas.selection = this.config.mode !== "profile";
    this.canvas.skipTargetFind = false;
    this.canvas.targetFindTolerance = this.deviceProfile.isTouch ? 16 : 8;
    this.canvas.perPixelTargetFind = !this.deviceProfile.isLowPower;
    this.canvas.renderOnAddRemove = false;
    this.canvas.enableRetinaScaling = true;
    this.canvas.requestRenderAll();
  }

  getCanvasDimensions(aspectRatio = this.config.aspectRatio) {
    const dimensions = super.getCanvasDimensions(aspectRatio);
    if (this.config.mode !== "post") return dimensions;

    const max = Math.min(window.innerWidth - 32, window.innerHeight * 0.68, 720);
    return {
      width: Math.round(Math.min(dimensions.width, max)),
      height: Math.round(Math.min(dimensions.height, max)),
    };
  }
}
