// pages/Home.jsx
import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { useQuery } from "@tanstack/react-query";
import { Sparkles, Users, TrendingUp, Plus } from "lucide-react";

import { vibeService } from "../../../services/vibe.service.js";
import { useAuthStore } from "../../../store/authStore.js";
import { useUIStore } from "../../../store/uiStore.js";
import { useBlockStore } from "../../../store/block.store.js";

import VibeCard from "../../vibe/components/VibeCard.jsx";
import SuggestedUsersFeedCard from "../components/SuggestedUsersFeedCard.jsx";
import RightSidebar from "../components/RightSidebar.jsx";

import Loader from "../../../components/common/Loader.jsx";
import EmptyState from "../../../components/common/EmptyState.jsx";
import Seo from "../../../components/seo/Seo.jsx";
import { buildStaticPageSeo } from "../../../seo/seoBuilders.js";
import { shouldSkipLiveSeoFetch } from "../../../seo/seoUtils.js";
import StoriesCarousel from "../../story/components/StoriesCarousel.jsx";
import { useMediaDebug } from "../../../hooks/useMediaDebug.js";
import Avatar from "../../../components/common/Avatar.jsx";
import { profileService } from "../../../services/profile.service.js";
import FeedSkeleton from "../../../components/common/FeedSkeleton.jsx";
import CreatePostBar from "../components/CreatePostBar.jsx";
import {
  FEED_EVENTS,
  subscribeToFeedEvents,
} from "../../../utils/feedEvents.js";
import { normalizeVibePost } from "../../../utils/normalizeVibePost.js";
import { profileAPI } from "../../profile/profileApi.js";

const Home = () => {
  const { user, isAuthenticated, setUser } = useAuthStore();
  const { openModal } = useUIStore();
  const blockedUsers = useBlockStore((state) => state.blockedUsers);
  const skipLiveFetch = shouldSkipLiveSeoFetch();

  const [activeTab, setActiveTab] = useState("for-you");
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [error, setError] = useState(null);
  const observerRef = useRef(null);

  useMediaDebug();

  useEffect(() => {
    if (!isAuthenticated || !user?.id) return;
    const hasSensitiveProfileFields =
      Object.prototype.hasOwnProperty.call(user, "dob") &&
      Object.prototype.hasOwnProperty.call(user, "is_sensitive_allowed");

    if (hasSensitiveProfileFields) {
      return;
    }

    let isMounted = true;

    profileAPI
      .getProfileById(user.id)
      .then((profile) => {
        if (!isMounted || !profile) return;
        setUser({
          ...user,
          ...profile,
          id: user.id,
          dob: profile.dob,
          is_sensitive_allowed: profile.is_sensitive_allowed === true,
        });
      })
      .catch(() => {});

    return () => {
      isMounted = false;
    };
  }, [isAuthenticated, setUser, user]);

  const normalizeToArray = (res) => {
    if (Array.isArray(res)) return res;
    if (Array.isArray(res?.users)) return res.users;
    if (Array.isArray(res?.data)) return res.data;
    if (Array.isArray(res?.data?.results)) return res.data.results;
    if (Array.isArray(res?.results)) return res.results;
    return [];
  };

  const injectSuggestions = (posts, suggested) => {
    if (
      !Array.isArray(posts) ||
      posts.length < 4 ||
      !suggested ||
      !suggested.random?.length
    ) {
      return posts;
    }

    const cloned = posts.filter((p) => p.__type !== "suggested-users");
    const index = Math.min(3, cloned.length - 1);
    cloned.splice(index, 0, {
      __type: "suggested-users",
      users: suggested.random,
      allUsers: suggested.all || [],
    });

    return cloned;
  };

  const fetchFeed = useCallback(async (pageNum = 1, append = false) => {
    if (skipLiveFetch) {
      setLoading(false);
      setPosts([]);
      setHasMore(false);
      return;
    }

    try {
      if (append) {
        setLoadingMore(true);
      } else {
        setLoading(true);
      }

      setError(null);

      const result = await vibeService.getVibePosts({
        page: pageNum,
        page_size: 10,
      });

      setPosts((prev) => (append ? [...prev, ...result.data] : result.data));

      setHasMore(result.hasMore);
    } catch (err) {
      setError(err.message || "Failed to load feed");
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  }, [skipLiveFetch]);

  useEffect(() => {
    setPage(1);
    fetchFeed(1, false);
  }, [fetchFeed]);

  const loadMore = useCallback(async () => {
    if (loadingMore || !hasMore) return;

    const nextPage = page + 1;

    setPage(nextPage);

    await fetchFeed(nextPage, true);
  }, [page, loadingMore, hasMore, fetchFeed]);

  const lastPostRef = useCallback(
    (node) => {
      if (loadingMore || !hasMore) return;

      if (observerRef.current) {
        observerRef.current.disconnect();
      }

      observerRef.current = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) {
            loadMore();
          }
        },
        {
          threshold: 0.2,
          rootMargin: "400px",
        },
      );

      if (node) {
        observerRef.current.observe(node);
      }
    },
    [loadingMore, hasMore, loadMore],
  );

  useEffect(() => {
    const unsubscribe = subscribeToFeedEvents((event) => {
      if (event.type === FEED_EVENTS.DELETED && event.postId) {
        setPosts((prev) => prev.filter((post) => post.id !== event.postId));
        return;
      }

      if (event.type === FEED_EVENTS.UPDATED && event.post) {
        const updatedPost = normalizeVibePost(event.post);
        if (updatedPost) {
          setPosts((prev) =>
            prev.map((post) => (post.id === updatedPost.id ? updatedPost : post)),
          );
          return;
        }
      }

      if (event.type === FEED_EVENTS.BLOCKED_USER && event.userId) {
        const blockedUserId = String(event.userId);
        setPosts((prev) =>
          prev.filter((post) => String(post.user?.id || post.author) !== blockedUserId),
        );
        return;
      }

      fetchFeed(1, false);
      setPage(1);
    });

    return unsubscribe;
  }, [fetchFeed]);

  // Fetch suggested users
  const { data: suggestedUsers } = useQuery({
    queryKey: ["suggested-users"],
    queryFn: async () => {
      let page = 1;
      let allUsers = [];
      let next = true;

      while (next) {
        const res = await profileService.getProfiles({
          page,
          page_size: 50,
        });
        const usersBatch = normalizeToArray(res);
        allUsers = [...allUsers, ...usersBatch];
        if (!res.next) {
          next = false;
        } else {
          page += 1;
        }
      }

      const shuffled = [...allUsers].sort(() => 0.5 - Math.random());
      return {
        random: shuffled.slice(0, 6),
        all: shuffled,
      };
    },
    enabled: !skipLiveFetch,
  });

  const filteredFeedPosts = posts.filter((post) => {
    if (post.__type) return true;
    return !blockedUsers.has(String(post.user?.id || post.author));
  });

  // Inject suggested users and then loop feed for endless scrolling
  const feedWithSuggestions = useMemo(() => {
    if (!suggestedUsers?.all?.length) return filteredFeedPosts;
    return injectSuggestions(filteredFeedPosts, suggestedUsers);
  }, [filteredFeedPosts, suggestedUsers]);

  const tabs = [
    { id: "for-you", label: "For You", icon: Sparkles },
    { id: "following", label: "Following", icon: Users },
    { id: "trending", label: "Trending", icon: TrendingUp },
  ];

  const handleCreatePost = () => openModal("create-post-selector");

  return (
    <>
      <Seo {...buildStaticPageSeo("home")} />

      <div className="w-full min-h-screen bg-background dark:bg-background-dark">
        <div className="max-w-[760px] lg:max-w-[900px] mx-auto px-0 sm:px-6 pt-2">
          <div className="flex justify-center lg:justify-between items-start gap-6">
            {/* FEED */}
            <div className="w-full max-w-[400px]">
              <div className="mb-3 md:mb-4">
                <CreatePostBar user={user} />
              </div>
              <div className="mb-3">
                <StoriesCarousel />
              </div>
              <div>
                {loading ? (
                  <FeedSkeleton count={3} />
                ) : error ? (
                  <EmptyState title="Error loading feed" description={error} />
                ) : feedWithSuggestions.length === 0 ? (
                  <EmptyState title="No posts yet" />
                ) : (
                  feedWithSuggestions.map((item, index) => {
                    if (item.__type === "suggested-users") {
                      return (
                        <SuggestedUsersFeedCard
                          key={`suggested-${index}`}
                          users={item.users}
                          allUsers={item.allUsers}
                        />
                      );
                    }

                    return (
                      <div
                        key={item.id}
                        ref={
                          index === feedWithSuggestions.length - 3
                            ? lastPostRef
                            : null
                        }
                      >
                        <VibeCard
                          post={item}
                          onUpdate={(postId, updates) => {
                            setPosts((prevPosts) =>
                              prevPosts.map((p) => {
                                if (p.id !== postId) return p;

                                return {
                                  ...p,
                                  ...updates,
                                  // Handle functional updates (important ⚡)
                                  comments_count:
                                    typeof updates?.comments_count ===
                                    "function"
                                      ? updates.comments_count(p.comments_count)
                                      : (updates?.comments_count ??
                                        p.comments_count),

                                  likes_count:
                                    typeof updates?.total_likes === "function"
                                      ? updates.total_likes(p.likes_count)
                                      : (updates?.total_likes ?? p.likes_count),
                                };
                              }),
                            );
                          }}
                        />
                      </div>
                    );
                  })
                )}

                {loadingMore && (
                  <div className="py-6 flex justify-center">
                    <Loader />
                  </div>
                )}
              </div>
            </div>

            {/* SIDEBAR */}
            <div className="hidden lg:block w-[320px] shrink-0">
              <div className="sticky top-20">
                <RightSidebar
                  user={user}
                  suggestedUsers={suggestedUsers?.random}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Home;
