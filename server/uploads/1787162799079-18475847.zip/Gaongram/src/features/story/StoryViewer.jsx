import React, { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import { motion as Motion, AnimatePresence } from "framer-motion";
import { useAuthStore } from "../../store/authStore.js";
import { useStoryViewer } from "../../hooks/useStoryViewer.js";
import { useStoryProgress } from "../../hooks/useStoryProgress.js";
import StoryProgressBars from "./components/StoryProgressBars.jsx";
import StoryHeader from "./components/StoryHeader.jsx";
import StoryLikeButton from "./components/StoryLikeButton.jsx";
import StoryCommentInput from "./components/StoryCommentInput.jsx";
import StoryViewersSheet from "./components/StoryViewersSheet.jsx";
import StoryOptionsMenu from "./components/StoryOptionsMenu.jsx";
import StoryViewersStack from "./components/StoryViewersStack.jsx";
import { storyService } from "../../services/story.service.js";
import { normalizeStoryMusic, storyAudioManager } from "./audio/storyAudioManager.js";

const isStoryInteractiveTarget = (target) =>
  target?.closest?.("button, a, input, textarea, [role='button'], [data-story-interactive='true']");

const StoryViewer = () => {
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const videoRef = useRef(null);
  const containerRef = useRef(null);
  const longPressTimer = useRef(null);
  const pointerStateRef = useRef(null);
  const navigationLockRef = useRef(false);
  const [viewerList, setViewerList] = useState([]);

  // Get stories from location state (passed from carousel) or fallback to single story
  const locationState =
    location.state && typeof location.state === "object"
      ? location.state
      : null;
  const [storyGroup, setStoryGroup] = useState(
    locationState && locationState.stories ? locationState.stories : [],
  );
  const [currentIndex, setCurrentIndex] = useState(
    locationState && typeof locationState.initialIndex === "number"
      ? locationState.initialIndex
      : 0,
  );
  const [showViewers, setShowViewers] = useState(false);
  const [isPausedByUser, setIsPausedByUser] = useState(false);
  const [swipeDownProgress, setSwipeDownProgress] = useState(0);

  // Fetch current story details if not in group (e.g., direct URL)
  const {
    story: fetchedStory,
    likeStory,
    isLiking,
    deleteStory,
    isDeleting,
  } = useStoryViewer(id);

  // If no group from state, build one from fetched story
  useEffect(() => {
    if (fetchedStory && storyGroup.length === 0) {
      setStoryGroup([fetchedStory]);
      setCurrentIndex(0);
    }
  }, [fetchedStory, storyGroup.length]);

  const currentStory = useMemo(
    () => storyGroup[currentIndex],
    [currentIndex, storyGroup],
  );
  const currentMusic = useMemo(
    () => normalizeStoryMusic(currentStory),
    [currentStory],
  );
  const currentStoryId = currentStory?.id;
  const isOwner = currentStory?.user_id === user?.id;

  // Navigation functions
  const goToNext = useCallback(() => {
    if (!storyGroup?.length) return;
    if (navigationLockRef.current) return;
    navigationLockRef.current = true;
    window.setTimeout(() => {
      navigationLockRef.current = false;
    }, 260);

    if (currentIndex < storyGroup.length - 1) {
      const nextIndex = currentIndex + 1;

      setCurrentIndex(nextIndex);
    } else {
      navigate(-1);
    }
  }, [currentIndex, storyGroup, navigate]);

  const goToPrevious = useCallback(() => {
    if (!storyGroup?.length) return;
    if (navigationLockRef.current) return;
    navigationLockRef.current = true;
    window.setTimeout(() => {
      navigationLockRef.current = false;
    }, 260);

    if (currentIndex > 0) {
      const prevIndex = currentIndex - 1;

      setCurrentIndex(prevIndex);
    } else {
      navigate(-1);
    }
  }, [currentIndex, storyGroup, navigate]);

  // Progress hook
  const { progress, pause, resume, reset } = useStoryProgress({
    isActive: !isPausedByUser && !showViewers && !!currentStory,
    storyType: currentStory?.story_type,
    videoRef,
    durationMs: undefined,
    onComplete: goToNext,
  });
  const displayedProgress = progress;

  // Reset progress when story changes
  useEffect(() => {
    reset();

    if (videoRef?.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play?.().catch(() => undefined);
    }

    setIsPausedByUser(false);
  }, [currentIndex, currentStoryId, reset]);

  const handleDeleteStory = useCallback(
    async (storyId = currentStoryId) => {
      if (!storyId) return;

      const previousGroup = storyGroup;
      const previousIndex = currentIndex;
      const nextGroup = previousGroup.filter((story) => String(story.id) !== String(storyId));
      const nextIndex = Math.min(previousIndex, Math.max(nextGroup.length - 1, 0));

      setStoryGroup(nextGroup);
      setShowViewers(false);

      if (nextGroup.length) {
        setCurrentIndex(nextIndex);
      } else {
        navigate(-1);
      }

      try {
        await deleteStory(storyId);
      } catch (error) {
        console.error(error);
        if (nextGroup.length) {
          setStoryGroup(previousGroup);
          setCurrentIndex(previousIndex);
        }
      }
    },
    [currentIndex, currentStoryId, deleteStory, navigate, storyGroup],
  );

  const pauseStory = useCallback(() => {
    pause();
    setIsPausedByUser(true);
  }, [pause]);

  const resumeStory = useCallback(() => {
    setIsPausedByUser(false);
    resume();
  }, [resume]);

  useEffect(() => {
    if (showViewers) {
      pause();
      videoRef.current?.pause?.();
      storyAudioManager.pause();
    } else if (!isPausedByUser) {
      resume();
      if (currentMusic && currentStory?.story_type !== "video") {
        storyAudioManager.resume().catch(() => undefined);
      }
    }
  }, [currentMusic, currentStory?.story_type, isPausedByUser, pause, resume, showViewers]);

  useEffect(() => {
    if (!currentMusic || currentStory?.story_type === "video") {
      storyAudioManager.stop();
      return undefined;
    }

    storyAudioManager.playSegment(currentMusic, {
      loop: true,
      volume: 0.85,
      resumeOnGesture: true,
    });
    return () => storyAudioManager.stop();
  }, [currentMusic, currentStory?.story_type]);

  const handlePointerDown = useCallback(
    (event) => {
      if (event.pointerType === "mouse" && event.button !== 0) return;
      if (isStoryInteractiveTarget(event.target)) return;

      pointerStateRef.current = {
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        lastY: event.clientY,
        startTime: performance.now(),
        didLongPress: false,
        didMove: false,
      };
      containerRef.current?.setPointerCapture?.(event.pointerId);
      window.clearTimeout(longPressTimer.current);
      longPressTimer.current = window.setTimeout(() => {
        if (!pointerStateRef.current) return;
        pointerStateRef.current.didLongPress = true;
        pauseStory();
      }, 260);
    },
    [pauseStory],
  );

  const handlePointerMove = useCallback((event) => {
    const state = pointerStateRef.current;
    if (!state || state.pointerId !== event.pointerId) return;

    const deltaX = event.clientX - state.startX;
    const deltaY = event.clientY - state.startY;
    const absX = Math.abs(deltaX);
    const absY = Math.abs(deltaY);

    if (absX > 8 || absY > 8) {
      state.didMove = true;
      window.clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }

    if (deltaY > 0 && absY > absX) {
      event.preventDefault();
      setSwipeDownProgress(Math.min(deltaY / 220, 1));
    }
  }, []);

  const handlePointerUp = useCallback(
    (event) => {
      const state = pointerStateRef.current;
      if (!state || state.pointerId !== event.pointerId) return;

      window.clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
      pointerStateRef.current = null;
      containerRef.current?.releasePointerCapture?.(event.pointerId);

      const deltaX = event.clientX - state.startX;
      const deltaY = event.clientY - state.startY;
      const absX = Math.abs(deltaX);
      const absY = Math.abs(deltaY);
      const elapsed = performance.now() - state.startTime;

      setSwipeDownProgress(0);

      if (state.didLongPress) {
        resumeStory();
        return;
      }

      if (deltaY > 105 && absY > absX * 1.25) {
        navigate(-1);
        return;
      }

      if (absX > 72 && absX > absY * 1.2) {
        if (deltaX < 0) goToNext();
        else goToPrevious();
        return;
      }

      if (absX <= 12 && absY <= 12 && elapsed < 360) {
        const rect = containerRef.current?.getBoundingClientRect();
        if (!rect) return;
        const tapX = event.clientX - rect.left;
        if (tapX < rect.width * 0.38) {
          goToPrevious();
        } else {
          goToNext();
        }
      } else {
        resumeStory();
      }
    },
    [goToNext, goToPrevious, navigate, resumeStory],
  );

  const handlePointerCancel = useCallback(
    (event) => {
      window.clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
      pointerStateRef.current = null;
      containerRef.current?.releasePointerCapture?.(event.pointerId);
      setSwipeDownProgress(0);
      resumeStory();
    },
    [resumeStory],
  );

  useEffect(() => {
    if (!storyGroup?.length) return;

    const candidates = [storyGroup[currentIndex + 1], storyGroup[currentIndex - 1]].filter(Boolean);

    candidates.forEach((nextStory) => {
      if (nextStory.story_type === "image") {
        const img = new Image();
        img.decoding = "async";
        img.src = nextStory.story;
      }

      if (nextStory.story_type === "video") {
        const video = document.createElement("video");
        video.src = nextStory.story;
        video.preload = "auto";
        video.playsInline = true;
        video.muted = true;
      }
    });
  }, [currentIndex, storyGroup]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "ArrowLeft") goToPrevious();
      if (e.key === "ArrowRight") goToNext();
      if (e.key === "Escape") {
        navigate(-1);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [goToPrevious, goToNext, navigate]);

  useEffect(() => {
    return () => {
      window.clearTimeout(longPressTimer.current);
    };
  }, []);

  useEffect(() => {
    if (!isOwner || !currentStory?.id) return;

    const loadViewers = async () => {
      try {
        const res = await storyService.getStoryViewers(currentStory.id);
        setViewerList(res?.data?.results || []);
      } catch (e) {
        console.error("viewer fetch error", e);
      }
    };

    loadViewers();
  }, [currentStory?.id, isOwner]);

  if (!currentStory) {
    return (
      <div className="fixed inset-0 z-50 bg-black flex items-center justify-center">
        <div className="text-center text-white">
          <p className="text-lg">Story not found</p>
          <button
            onClick={() => navigate(-1)}
            className="mt-4 px-4 py-2 bg-white/10 rounded-lg"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <Motion.div
      ref={containerRef}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 touch-none select-none overflow-hidden overscroll-none bg-black"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerCancel}
    >
      {/* Blurred background */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${currentStory.story})`,
          filter: "blur(50px)",
          transform: "scale(1.1)",
        }}
      />

      {/* Main content container */}
      <div className="relative flex h-[100dvh] min-h-[100svh] items-center justify-center">
        <div
          className="relative h-full w-full max-w-[430px] overflow-hidden bg-black shadow-2xl will-change-transform"
          style={{
            transform: `translateY(${swipeDownProgress * 50}px) scale(${1 - swipeDownProgress * 0.05})`,
            opacity: 1 - swipeDownProgress * 0.5,
          }}
        >
          {/* Progress bars */}
          <StoryProgressBars
            stories={storyGroup}
            currentIndex={currentIndex}
            progress={displayedProgress}
          />

          {/* Header */}
          <StoryHeader
            story={currentStory}
            isOwner={isOwner}
            onClose={() => {
              navigate(-1);
            }}
            onViewersClick={() => setShowViewers(true)}
            onDelete={handleDeleteStory}
            isDeleting={isDeleting}
          />

          {/* Media */}
          <div className="h-full flex items-center justify-center">
            {currentStory.story_type === "video" ? (
              <video
                ref={videoRef}
                src={currentStory.story}
                className="w-full h-full object-contain"
                playsInline
                muted={false}
                autoPlay
                loop={false}
                preload="auto"
                onCanPlay={() => {
                  if (!isPausedByUser) {
                    videoRef.current?.play?.().catch(() => undefined);
                  }
                }}
              />
            ) : (
              <img
                src={currentStory.story}
                alt={currentStory.text || "Story"}
                className="w-full h-full object-contain"
                decoding="async"
              />
            )}
          </div>

          {/* Text overlay */}
          {currentStory.text && (
            <div className="pointer-events-none absolute bottom-[calc(env(safe-area-inset-bottom)+4.25rem)] left-3 right-3 text-center">
              <p className="mx-auto inline-block max-w-full rounded-md bg-black/30 px-3 py-1 text-base text-white backdrop-blur-sm sm:text-lg">
                {currentStory.text}
              </p>
            </div>
          )}

          {isOwner && (
            <StoryViewersStack
              viewers={viewerList}
              viewCount={currentStory.view_count}
              onOpen={() => setShowViewers(true)}
            />
          )}

          {/* Like button */}
          {!isOwner && (
            <>
              <StoryCommentInput
                storyId={currentStory.id}
                rightElement={
                  <StoryLikeButton
                    isLiked={currentStory.is_liked}
                    likesCount={currentStory.likes_count}
                    onLike={async () => {
                      const prevLiked = currentStory.is_liked;
                      const prevLikesCount = currentStory.likes_count || 0;

                      setStoryGroup((prev) =>
                        prev.map((s, i) =>
                          i === currentIndex
                            ? {
                                ...s,
                                is_liked: !prevLiked,
                                likes_count: Math.max(
                                  0,
                                  (s.likes_count || 0) + (prevLiked ? -1 : 1),
                                ),
                              }
                            : s,
                        ),
                      );

                      try {
                        await likeStory(currentStory.id);
                      } catch (e) {
                        console.error(e);
                        setStoryGroup((prev) =>
                          prev.map((s, i) =>
                            i === currentIndex
                              ? {
                                  ...s,
                                  is_liked: prevLiked,
                                  likes_count: prevLikesCount,
                                }
                              : s,
                          ),
                        );
                      }
                    }}
                    disabled={isLiking}
                  />
                }
              />
            </>
          )}

          {/* Options menu (three-dot) */}
          <StoryOptionsMenu
            isOwner={isOwner}
            onDelete={() => handleDeleteStory(currentStory.id)}
            isDeleting={isDeleting}
          />
        </div>
      </div>

      {/* Viewers sheet */}
      <AnimatePresence>
        {showViewers && (
          <StoryViewersSheet
            viewers={viewerList}
            totalViews={currentStory.view_count}
            totalLikes={currentStory.likes_count}
            onClose={() => setShowViewers(false)}
          />
        )}
      </AnimatePresence>
    </Motion.div>
  );
};

export default StoryViewer;
