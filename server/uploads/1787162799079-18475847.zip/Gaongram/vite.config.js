// import { defineConfig } from 'vite'
// import react from '@vitejs/plugin-react'

// export default defineConfig({
//   plugins: [react()],
//   server: {
//     host: '0.0.0.0',
//     port: 3000,
//     proxy: {
//   '/api/v1': {
//     // target: 'http://192.168.18.5:8000',
//     target: 'https://gaongram.com',
//     changeOrigin: true,
//     secure: false,
//   },
// },
//   },
// })

import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import viteProfileSeoPlugin from "./scripts/vite-profile-seo-plugin.mjs";

export default defineConfig({
  plugins: [react(), viteProfileSeoPlugin()],

  server: {
    host: "0.0.0.0",

    port: 3000,

    allowedHosts: true,

    proxy: {
      "/api/v1": {
        // target: "http://192.168.18.5:8000",
        target: "https://gaongram.com",

        changeOrigin: true,

        secure: false,
      },
      '/media': {
    // target: "http://192.168.18.5:8000",
    target: 'https://gaongram.com',
    changeOrigin: true,
    secure: false,
  },
    },
  },

  build: {
    target: "es2015",
  },
});
