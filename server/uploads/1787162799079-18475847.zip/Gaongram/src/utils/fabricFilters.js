// src/utils/fabricFilters.js
import { fabric } from 'fabric';

// Make sure fabric is loaded before defining filters
if (!fabric || !fabric.Image) {
  throw new Error('Fabric.js not loaded properly. Please ensure fabric is installed and imported correctly.');
}

// ===========================
// Custom Brightness filter
// ===========================
fabric.Image.filters.Brightness = fabric.util.createClass(
  fabric.Image.filters.BaseFilter,
  {
    type: 'Brightness',

    applyTo2d: function (options) {
      if (this.brightness === 0) return;
      const data = options.imageData.data;
      const brightness = this.brightness;
      for (let i = 0; i < data.length; i += 4) {
        data[i] = Math.min(255, Math.max(0, data[i] + brightness));
        data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + brightness));
        data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + brightness));
      }
    },

    brightness: 0,
    mainParameter: 'brightness',
  }
);
fabric.Image.filters.Brightness.fromObject =
  fabric.Image.filters.BaseFilter.fromObject;

// ===========================
// Custom Contrast filter
// ===========================
fabric.Image.filters.Contrast = fabric.util.createClass(
  fabric.Image.filters.BaseFilter,
  {
    type: 'Contrast',

    applyTo2d: function (options) {
      const data = options.imageData.data;
      const contrast = (this.contrast + 100) / 100;
      const factor = (259 * (contrast + 255)) / (255 * (259 - contrast));
      for (let i = 0; i < data.length; i += 4) {
        data[i] = factor * (data[i] - 128) + 128;
        data[i + 1] = factor * (data[i + 1] - 128) + 128;
        data[i + 2] = factor * (data[i + 2] - 128) + 128;
      }
    },

    contrast: 0,
    mainParameter: 'contrast',
  }
);
fabric.Image.filters.Contrast.fromObject =
  fabric.Image.filters.BaseFilter.fromObject;

// ===========================
// Custom Saturation filter
// ===========================
fabric.Image.filters.Saturation = fabric.util.createClass(
  fabric.Image.filters.BaseFilter,
  {
    type: 'Saturation',

    applyTo2d: function (options) {
      const data = options.imageData.data;
      const saturation = (this.saturation + 100) / 100;
      for (let i = 0; i < data.length; i += 4) {
        const r = data[i],
          g = data[i + 1],
          b = data[i + 2];
        const gray = 0.2989 * r + 0.587 * g + 0.114 * b;
        data[i] = gray * (1 - saturation) + r * saturation;
        data[i + 1] = gray * (1 - saturation) + g * saturation;
        data[i + 2] = gray * (1 - saturation) + b * saturation;
      }
    },

    saturation: 0,
    mainParameter: 'saturation',
  }
);
fabric.Image.filters.Saturation.fromObject =
  fabric.Image.filters.BaseFilter.fromObject;