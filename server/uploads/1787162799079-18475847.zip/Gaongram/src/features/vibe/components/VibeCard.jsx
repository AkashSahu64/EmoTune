// components/vibe/VibeCard.jsx
import React, { useRef, useEffect, useState, useCallback } from "react";
import { motion } from "framer-motion";
import { useAuthStore } from "../../../store/authStore.js";
import { useUIStore } from "../../../store/uiStore.js";
import { useMediaStore } from "../../../store/mediaStore.js";
import { useVisibility } from "../../../hooks/useVisibility.js";
import { useInteractionTracker } from "../../../hooks/useInteractionTracker.js";
import { formatNumber, formatTime } from "../../../utils/formatTime.js";
import VibeHeader from "./VibeHeader";
import MediaRenderer from "./MediaRenderer";
import VibeFooter from "./VibeFooter";
import { Eye } from "lucide-react";
import { calculateAge } from "../../../utils/calculateAge.js";
import SensitiveContentSettingsModal from "../../../components/modals/SensitiveContentSettingsModal.jsx";
import AgeRestrictedModal from "../../../components/modals/AgeRestrictedModal.jsx";

const VibeCard = ({ post, onUpdate }) => {
  const { user } = useAuthStore();
  const {
    activePostId,
    isMuted,
    toggleMute,
    shouldPlay,
    shouldMute,
    setActivePost,
    clearActivePost,
    setUserInteracted,
    userInteracted,
  } = useMediaStore();

  const videoRef = useRef(null);
  const audioRef = useRef(null);
  const videoProgressBarRef = useRef(null);
  const audioProgressBarRef = useRef(null);

  const [showFullCaption, setShowFullCaption] = useState(false);
  const [audioPlayCount, setAudioPlayCount] = useState(0);
  const [videoPlayCount, setVideoPlayCount] = useState(0);
  const [videoCurrentTime, setVideoCurrentTime] = useState(0);
  const [videoDuration, setVideoDuration] = useState(0);
  const [audioCurrentTime, setAudioCurrentTime] = useState(0);
  const [audioDuration, setAudioDuration] = useState(0);
  const [isVideoSeeking, setIsVideoSeeking] = useState(false);
  const [isAudioSeeking, setIsAudioSeeking] = useState(false);
  const [videoLoading, setVideoLoading] = useState(true);
  const [audioLoading, setAudioLoading] = useState(true);
  const [showSensitiveSettingsModal, setShowSensitiveSettingsModal] =
    useState(false);
  const [showAgeRestrictedModal, setShowAgeRestrictedModal] = useState(false);

  const { elementRef, isVisible } = useVisibility(post.id, {
    threshold: 0.6,
    rootMargin: "50px",
  });

  const isImage = post.media_type === "image" || post.images?.length > 0;
  const isVideo = post.media_type === "video" || post.videos?.length > 0;
  const isAudio = post.media_type === "audio" || post.audio;
  const isPoll =
    post?.poll ||
    post?.poll_question ||
    (Array.isArray(post?.poll_options) && post.poll_options.length > 0);
  const imageUrl = post.images?.[0]?.image || post.media_url;
  const videoUrl = isVideo
    ? post.videos?.[0]?.hls_playlist || post.videos?.[0]?.video
    : null;
  const videoSources = isVideo
  ? {
      hls: post.videos?.[0]?.hls_playlist || null,
      mp4: post.videos?.[0]?.video || null,
    }
  : null;
  const audioUrl = isAudio ? post.audio?.audio : null;
  const videoThumbnail = post.videos?.[0]?.thumbnail;
  const audioCoverImage =
    post.audio?.cover_image || post.images?.[0]?.image || null;
  const isOwner = user?.id === post.user?.id;
  const profileDob = user?.dob || user?.profile?.dob;
  const age = calculateAge(profileDob);
  const isUnder18 = typeof age === "number" && age < 18;
  const sensitiveAllowed =
    user?.is_sensitive_allowed ?? user?.profile?.is_sensitive_allowed;
  const canViewSensitive =
    sensitiveAllowed === true && typeof age === "number" && !isUnder18;
  const isSensitivePost = post.is_sensitive === true;
  const isSensitiveBlocked = isSensitivePost && !canViewSensitive;

  const mediaRefForTracker = isVideo ? videoRef : isAudio ? audioRef : null;
  const mediaDuration =
    (isVideo && videoDuration) ||
    (isAudio && (post.audio?.duration || audioDuration)) ||
    0;

  useInteractionTracker({
    postId: post.id,
    isVisible,
    mediaType: post.media_type,
    mediaRef: mediaRefForTracker,
    duration: mediaDuration,
  });

  const formatPlayerTime = (timeInSeconds) => {
    if (!timeInSeconds || isNaN(timeInSeconds)) return "0:00";
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60);
    return `${minutes}:${seconds.toString().padStart(2, "0")}`;
  };

  const handleVideoMetadataLoad = useCallback(() => {
    if (videoRef.current) {
      const duration = videoRef.current.duration;
      if (duration && duration > 0) setVideoDuration(duration);
    }
  }, []);

  const handleAudioMetadataLoad = useCallback(() => {
    if (audioRef.current) {
      const duration = audioRef.current.duration;
      if (duration && duration > 0) setAudioDuration(duration);
    }
  }, []);

  useEffect(() => {
    if (!isVideo) return;
    const updateVideoTime = () => {
      if (videoRef.current && !isVideoSeeking) {
        setVideoCurrentTime(videoRef.current.currentTime || 0);
      }
    };
    const interval = setInterval(updateVideoTime, 100);
    return () => clearInterval(interval);
  }, [isVideo, isVideoSeeking]);

  useEffect(() => {
    if (!isAudio) return;
    const updateAudioTime = () => {
      if (audioRef.current && !isAudioSeeking) {
        setAudioCurrentTime(audioRef.current.currentTime || 0);
      }
    };
    const interval = setInterval(updateAudioTime, 100);
    return () => clearInterval(interval);
  }, [isAudio, isAudioSeeking]);

  const handleSensitiveClick = useCallback(() => {
    if (isUnder18) {
      setShowAgeRestrictedModal(true);
      return;
    }

    setShowSensitiveSettingsModal(true);
  }, [isUnder18]);

  const handleVideoProgressClick = (e) => {
    if (isSensitiveBlocked) {
      handleSensitiveClick();
      return;
    }

    if (!videoDuration) return;
    const progressBar = videoProgressBarRef.current;
    if (!progressBar) return;
    const rect = progressBar.getBoundingClientRect();
    const clickPosition = (e.clientX - rect.left) / rect.width;
    const newTime = Math.max(
      0,
      Math.min(videoDuration, clickPosition * videoDuration),
    );
    setVideoCurrentTime(newTime);
    setIsVideoSeeking(true);
    if (videoRef.current) videoRef.current.currentTime = newTime;
    setTimeout(() => setIsVideoSeeking(false), 100);
  };

  const handleAudioProgressClick = (e) => {
    if (isSensitiveBlocked) {
      handleSensitiveClick();
      return;
    }

    const duration = post.audio?.duration || audioDuration;
    if (!duration) return;
    const progressBar = audioProgressBarRef.current;
    if (!progressBar) return;
    const rect = progressBar.getBoundingClientRect();
    const clickPosition = (e.clientX - rect.left) / rect.width;
    const newTime = Math.max(0, Math.min(duration, clickPosition * duration));
    setAudioCurrentTime(newTime);
    setIsAudioSeeking(true);
    if (audioRef.current) audioRef.current.currentTime = newTime;
    setTimeout(() => setIsAudioSeeking(false), 100);
  };

  const handleVideoSkipForward = () => {
    if (isSensitiveBlocked) return;
    if (videoRef.current) {
      const newTime = Math.min(videoDuration, videoCurrentTime + 5);
      videoRef.current.currentTime = newTime;
      setVideoCurrentTime(newTime);
    }
  };
  const handleVideoSkipBackward = () => {
    if (isSensitiveBlocked) return;
    if (videoRef.current) {
      const newTime = Math.max(0, videoCurrentTime - 5);
      videoRef.current.currentTime = newTime;
      setVideoCurrentTime(newTime);
    }
  };
  const handleAudioSkipForward = () => {
    if (isSensitiveBlocked) return;
    const duration = post.audio?.duration || audioDuration;
    if (audioRef.current && duration) {
      const newTime = Math.min(duration, audioCurrentTime + 5);
      audioRef.current.currentTime = newTime;
      setAudioCurrentTime(newTime);
    }
  };
  const handleAudioSkipBackward = () => {
    if (isSensitiveBlocked) return;
    const duration = post.audio?.duration || audioDuration;
    if (audioRef.current && duration) {
      const newTime = Math.max(0, audioCurrentTime - 5);
      audioRef.current.currentTime = newTime;
      setAudioCurrentTime(newTime);
    }
  };

  const toggleVideoPlay = () => {
    if (isSensitiveBlocked) {
      handleSensitiveClick();
      return;
    }

    if (!videoRef.current || !isVideo) return;
    if (!userInteracted) setUserInteracted();
    if (videoRef.current.paused) {
      setActivePost(post.id);
      videoRef.current.play().catch((error) => {
        console.log("Manual play failed:", error);
        videoRef.current.muted = true;
        videoRef.current.play();
      });
    } else {
      videoRef.current.pause();
      if (activePostId === post.id) clearActivePost();
    }
  };

  const toggleAudioPlay = () => {
    if (isSensitiveBlocked) {
      handleSensitiveClick();
      return;
    }

    if (!audioRef.current || !isAudio) return;
    if (!userInteracted) setUserInteracted();
    if (audioRef.current.paused) {
      setActivePost(post.id);
      audioRef.current.play().catch((error) => {
        console.log("Manual play failed:", error);
        audioRef.current.muted = true;
        audioRef.current.play();
      });
    } else {
      audioRef.current.pause();
      if (activePostId === post.id) clearActivePost();
    }
  };

  const handleGlobalMuteToggle = () => {
    if (isSensitiveBlocked) return;
    if (!userInteracted) setUserInteracted();
    toggleMute();
  };

  useEffect(() => {
    const handleUserInteraction = () => {
      if (!userInteracted) setUserInteracted();
    };
    window.addEventListener("click", handleUserInteraction, { once: true });
    window.addEventListener("touchstart", handleUserInteraction, {
      once: true,
    });
    window.addEventListener("keydown", handleUserInteraction, { once: true });
    return () => {
      window.removeEventListener("click", handleUserInteraction);
      window.removeEventListener("touchstart", handleUserInteraction);
      window.removeEventListener("keydown", handleUserInteraction);
    };
  }, [userInteracted, setUserInteracted]);

  useEffect(() => {
    if (!videoRef.current || !isVideo) return;
    const video = videoRef.current;
    if (isSensitiveBlocked) {
      video.pause();
      return;
    }

    if (shouldPlay(post.id) && isVisible && userInteracted) {
      const playPromise = video.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            video.muted = shouldMute(post.id);
          })
          .catch((error) => {
            console.log("Video autoplay failed:", error.name);
            if (error.name === "NotAllowedError") {
              video.muted = true;
              video.play().catch(() => {});
            }
          });
      }
    } else if (isVisible && !userInteracted) {
      video.muted = true;
      video.play().catch(() => {});
    } else {
      video.pause();
    }
  }, [
    post.id,
    isVisible,
    shouldPlay,
    shouldMute,
    isVideo,
    userInteracted,
    isSensitiveBlocked,
  ]);

  useEffect(() => {
    if (!audioRef.current || !isAudio) return;
    const audio = audioRef.current;
    if (isSensitiveBlocked) {
      audio.pause();
      return;
    }

    if (shouldPlay(post.id) && isVisible && userInteracted) {
      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            audio.muted = shouldMute(post.id);
          })
          .catch((error) => {
            console.log("Audio autoplay failed:", error.name);
            if (error.name === "NotAllowedError") {
              audio.muted = true;
              audio.play().catch(() => {});
            }
          });
      }
    } else if (isVisible && !userInteracted) {
      audio.muted = true;
      audio.play().catch(() => {});
    } else {
      audio.pause();
    }
  }, [
    post.id,
    isVisible,
    shouldPlay,
    shouldMute,
    isAudio,
    userInteracted,
    isSensitiveBlocked,
  ]);

  useEffect(() => {
    if (videoRef.current && isVideo)
      videoRef.current.muted = shouldMute(post.id);
    if (audioRef.current && isAudio)
      audioRef.current.muted = shouldMute(post.id);
  }, [
    isMuted,
    activePostId,
    post.id,
    isVideo,
    isAudio,
    shouldMute,
    userInteracted,
  ]);

  const handleVideoLoadStart = () => setVideoLoading(true);
  const handleVideoCanPlay = () => setVideoLoading(false);
  const handleAudioLoadStart = () => setAudioLoading(true);
  const handleAudioCanPlay = () => setAudioLoading(false);

  const renderViewCount = (mediaType) => {
    if (post.views_count > 0) {
      return (
        <div
          className="
          absolute top-2 right-2 z-20
          flex items-center gap-1
          rounded-full
          bg-black/45
          px-1
          text-white
          dark:border dark:border-border-dark
        "
        >
          <Eye className="h-3.5 w-3.5 opacity-90" />

          <span className="text-[11px] font-semibold tracking-wide">
            {formatNumber(post.views_count)}
          </span>
        </div>
      );
    }

    return null;
  };

  const handlePollVote = () => onUpdate?.();
  const shouldTruncate = post.caption?.length > 150;

  return (
    <>
    <motion.article
      ref={elementRef}
      className="bg-card dark:bg-card-dark overflow-hidden"
    >
      <VibeHeader
        post={post}
        isOwner={isOwner}
        user={user}
        showFullCaption={showFullCaption}
        setShowFullCaption={setShowFullCaption}
        shouldTruncate={shouldTruncate}
      />

      <div className="relative w-full overflow-hidden group flex items-center justify-center bg-background-dark">
        <MediaRenderer
          post={post}
          videoSources={videoSources}
          images={post.images || []}
          videos={post.videos || []}
          audio={post.audio || null}
          isImage={isImage}
          isVideo={isVideo}
          isAudio={isAudio}
          isPoll={isPoll}
          imageUrl={imageUrl}
          videoUrl={videoUrl}
          audioUrl={audioUrl}
          videoThumbnail={videoThumbnail}
          audioCoverImage={audioCoverImage}
          title={post.audio?.title}
          videoRef={videoRef}
          audioRef={audioRef}
          videoProgressBarRef={videoProgressBarRef}
          audioProgressBarRef={audioProgressBarRef}
          videoCurrentTime={videoCurrentTime}
          videoDuration={videoDuration}
          audioCurrentTime={audioCurrentTime}
          audioDuration={audioDuration}
          videoLoading={videoLoading}
          audioLoading={audioLoading}
          videoPlayCount={videoPlayCount}
          audioPlayCount={audioPlayCount}
          isMuted={isMuted}
          onVideoProgressClick={handleVideoProgressClick}
          onAudioProgressClick={handleAudioProgressClick}
          onVideoSkipForward={handleVideoSkipForward}
          onVideoSkipBackward={handleVideoSkipBackward}
          onAudioSkipForward={handleAudioSkipForward}
          onAudioSkipBackward={handleAudioSkipBackward}
          toggleVideoPlay={toggleVideoPlay}
          toggleAudioPlay={toggleAudioPlay}
          handleGlobalMuteToggle={handleGlobalMuteToggle}
          onVideoEnded={() => {
            setVideoPlayCount((prev) => {
              const next = prev + 1;
              if (next < 3 && videoRef.current) {
                videoRef.current.currentTime = 0;
                setTimeout(() => videoRef.current?.play(), 50);
                return next;
              }
              clearActivePost();
              return 0;
            });
          }}
          onAudioEnded={() => {
            setAudioPlayCount((prev) => {
              const next = prev + 1;
              if (next < 3 && audioRef.current) {
                audioRef.current.currentTime = 0;
                setTimeout(() => audioRef.current?.play(), 50);
                return next;
              }
              clearActivePost();
              return 0;
            });
          }}
          onVideoLoadStart={handleVideoLoadStart}
          onVideoCanPlay={handleVideoCanPlay}
          onAudioLoadStart={handleAudioLoadStart}
          onAudioCanPlay={handleAudioCanPlay}
          onVideoMetadataLoad={handleVideoMetadataLoad}
          onAudioMetadataLoad={handleAudioMetadataLoad}
          renderViewCount={renderViewCount}
          onPollVote={handlePollVote}
          formatPlayerTime={formatPlayerTime}
          isSensitiveBlocked={isSensitiveBlocked}
          onSensitiveClick={handleSensitiveClick}
        />
      </div>

      <VibeFooter
        post={post}
        isOwner={isOwner}
        isPoll={isPoll}
        isAudio={isAudio}
        onUpdate={onUpdate}
      />
    </motion.article>
      <SensitiveContentSettingsModal
        isOpen={showSensitiveSettingsModal}
        onClose={() => setShowSensitiveSettingsModal(false)}
      />
      <AgeRestrictedModal
        isOpen={showAgeRestrictedModal}
        onClose={() => setShowAgeRestrictedModal(false)}
      />
    </>
  );
};

export default VibeCard;
