import React from "react";
import { AnimatePresence, motion } from "framer-motion";
import PrivateProfileLock from "./PrivateProfileLock";
import ProfilePostsTab from "./tabs/ProfilePostsTab";
import ProfileVideosTab from "./tabs/ProfileVideosTab";
import ProfileAudiosTab from "./tabs/ProfileAudiosTab";

const tabMotion = {
  initial: { opacity: 0, y: 18 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -18 },
  transition: { duration: 0.24, ease: "easeOut" },
};

const ProfileContent = ({
  activeTab,
  profileUserId,
  username,
  fullName,
  isOwnProfile,
  isPrivateLocked,
}) => {
  if (isPrivateLocked) {
    return (
      <motion.div {...tabMotion}>
        <PrivateProfileLock username={username} fullName={fullName} />
      </motion.div>
    );
  }

  return (
    <AnimatePresence mode="wait">
      {activeTab === "posts" ? (
        <motion.div key="posts" {...tabMotion}>
          <ProfilePostsTab
            profileUserId={profileUserId}
            isOwnProfile={isOwnProfile}
            username={username}
          />
        </motion.div>
      ) : null}

      {activeTab === "videos" ? (
        <motion.div key="videos" {...tabMotion}>
          <ProfileVideosTab
            profileUserId={profileUserId}
            username={username}
          />
        </motion.div>
      ) : null}

      {activeTab === "audios" ? (
        <motion.div key="audios" {...tabMotion}>
          <ProfileAudiosTab
            profileUserId={profileUserId}
            username={username}
          />
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
};

export default React.memo(ProfileContent);
