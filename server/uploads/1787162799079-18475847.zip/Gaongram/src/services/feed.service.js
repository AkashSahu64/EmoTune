import api from '../config/axios.js';

export const feedService = {
  // Get all blogs
  getBlogs: async (params = {}) => {
    const response = await api.get('/blogs/', { params });
    return response.data;
  },
  
  // Get single blog
  getBlog: async (id) => {
    const response = await api.get(`/blogs/${id}/`);
    return response.data;
  },
  
  // Create blog
  createBlog: async (blogData) => {
    const response = await api.post('/blogs/', blogData);
    return response.data;
  },
  
  // Update blog
  updateBlog: async (id, blogData) => {
    const response = await api.put(`/blogs/${id}/`, blogData);
    return response.data;
  },
  
  // Partial update blog
  patchBlog: async (id, blogData) => {
    const response = await api.patch(`/blogs/${id}/`, blogData);
    return response.data;
  },
  
  // Delete blog
  deleteBlog: async (id) => {
    await api.delete(`/blogs/${id}/`);
  },
};