import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { storyService } from '../services/story.service.js';
import { useAuthStore } from '../store/authStore.js';

const storyMatches = (story, storyId) => String(story?.id) === String(storyId);

const removeStoryFromCarousel = (items, storyId) => {
  if (!Array.isArray(items)) return items;

  return items
    .map((item) => {
      if (item?.type !== 'story' || !Array.isArray(item.stories)) return item;
      const stories = item.stories.filter((story) => !storyMatches(story, storyId));
      if (!stories.length) return null;

      return {
        ...item,
        stories,
        storyId: stories[0]?.id ?? item.storyId,
        preview: stories[0]?.story ?? item.preview,
      };
    })
    .filter(Boolean);
};

const removeStoryFromResponse = (response, storyId) => {
  if (!response?.data?.results) return response;

  return {
    ...response,
    data: {
      ...response.data,
      results: response.data.results.filter((story) => !storyMatches(story, storyId)),
    },
  };
};

export const useStoryViewer = (storyId) => {
  const { user } = useAuthStore();
  const queryClient = useQueryClient();

  // Fetch story details
  const storyQuery = useQuery({
    queryKey: ['story', storyId],
    queryFn: () => storyService.getStoryById(storyId),
    enabled: !!storyId,
    retry: 1,
  });

  const story = storyQuery.data?.data;

  // Fetch viewers only if current user is owner
  const viewersQuery = useQuery({
    queryKey: ['story-viewers', storyId],
    queryFn: () => storyService.getStoryViewers(storyId),
    enabled: !!storyId && story?.user_id === user?.id,
    retry: 1,
  });

  // Like mutation
  const likeMutation = useMutation({
  mutationFn: (storyId) => storyService.likeToggle(storyId),
  onMutate: async (storyId) => {
    await queryClient.cancelQueries({ queryKey: ['story', storyId] });
    const previous = queryClient.getQueryData(['story', storyId]);
    queryClient.setQueryData(['story', storyId], (old) => {
      if (!old?.data) return old;
      const wasLiked = Boolean(old.data.is_liked);
      return {
        ...old,
        data: {
          ...old.data,
          is_liked: !wasLiked,
          likes_count: Math.max(0, (old.data.likes_count || 0) + (wasLiked ? -1 : 1)),
        },
      };
    });
    return { previous, storyId };
  },
  onError: (_err, storyId, context) => {
    if (context?.previous !== undefined) {
      queryClient.setQueryData(['story', context.storyId || storyId], context.previous);
    }
  },
  onSettled: (_, __, storyId) => {
    queryClient.invalidateQueries({ queryKey: ['story', storyId] });
    queryClient.invalidateQueries({ queryKey: ['stories-feed'] });
    queryClient.invalidateQueries({ queryKey: ['stories-me'] });
  },
});

const deleteMutation = useMutation({
  mutationFn: (storyId) => storyService.deleteStory(storyId),
  onMutate: async (storyId) => {
    await queryClient.cancelQueries({ queryKey: ['stories-feed'] });
    await queryClient.cancelQueries({ queryKey: ['stories-me'] });
    await queryClient.cancelQueries({ queryKey: ['story', storyId] });

    const previousFeed = queryClient.getQueryData(['stories-feed']);
    const previousMe = queryClient.getQueryData(['stories-me']);
    const previousStory = queryClient.getQueryData(['story', storyId]);

    queryClient.setQueryData(['stories-feed'], (old) => removeStoryFromCarousel(old, storyId));
    queryClient.setQueryData(['stories-me'], (old) => removeStoryFromResponse(old, storyId));
    queryClient.removeQueries({ queryKey: ['story', storyId] });

    return { previousFeed, previousMe, previousStory, storyId };
  },
  onError: (_err, storyId, context) => {
    if (context?.previousFeed !== undefined) {
      queryClient.setQueryData(['stories-feed'], context.previousFeed);
    }
    if (context?.previousMe !== undefined) {
      queryClient.setQueryData(['stories-me'], context.previousMe);
    }
    if (context?.previousStory !== undefined) {
      queryClient.setQueryData(['story', storyId], context.previousStory);
    }
  },
  onSettled: (_, __, storyId) => {
    queryClient.invalidateQueries({ queryKey: ['stories-feed'] });
    queryClient.invalidateQueries({ queryKey: ['stories-me'] });
    queryClient.removeQueries({ queryKey: ['story', storyId] });
  },
});

  return {
    story,
    viewers: viewersQuery.data,
    isLoading: storyQuery.isLoading,
    isError: storyQuery.isError,
    likeStory: likeMutation.mutateAsync,
    isLiking: likeMutation.isPending,
    deleteStory: deleteMutation.mutateAsync,
    isDeleting: deleteMutation.isPending,
  };
};
