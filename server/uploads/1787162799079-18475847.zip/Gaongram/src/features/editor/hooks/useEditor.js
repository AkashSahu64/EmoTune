import { useContext } from "react";
import { EditorContext } from "../core/EditorContext.jsx";

export const useEditor = () => {
  const context = useContext(EditorContext);
  if (!context) throw new Error("useEditor must be used inside EditorProvider");
  return context;
};

export default useEditor;
