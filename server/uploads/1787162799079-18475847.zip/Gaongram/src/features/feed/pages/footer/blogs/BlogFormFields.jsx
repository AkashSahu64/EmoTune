// src/features/blogs/components/BlogFormFields.jsx
import React from "react";
import { motion } from "framer-motion";

const BlogFormFields = ({ formData, setFormData, errors, isEdit }) => {
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setFormData((prev) => ({
      ...prev,
      image: file || null,
    }));
  };

  const inputClassName =
    "w-full px-4 py-2 rounded-lg border border-border dark:border-border-dark bg-background dark:bg-background-dark text-foreground dark:text-foreground-dark focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all";

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-6"
    >
      {/* Basic Info */}
      <section className="space-y-4">
        <h3 className="text-lg font-semibold">Basic Information</h3>

        <div>
          <label className="block text-sm font-medium mb-1">Title *</label>
          <input
            type="text"
            name="title"
            value={formData.title || ""}
            onChange={handleChange}
            className={inputClassName}
            placeholder="Enter blog title"
          />
          {errors.title && <p className="text-danger text-sm mt-1">{errors.title}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Slug</label>
          <input
            type="text"
            name="slug"
            value={formData.slug || ""}
            onChange={handleChange}
            className={inputClassName}
            placeholder="auto-generated if left empty"
          />
          {errors.slug && <p className="text-danger text-sm mt-1">{errors.slug}</p>}
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Content *</label>
          <textarea
            name="content"
            value={formData.content || ""}
            onChange={handleChange}
            rows={12}
            className={inputClassName}
            placeholder="Write your blog content (HTML allowed)"
          />
          {errors.content && <p className="text-danger text-sm mt-1">{errors.content}</p>}
        </div>
      </section>

      {/* SEO Meta */}
      <section className="space-y-4">
        <h3 className="text-lg font-semibold">SEO Metadata</h3>
        <div>
          <label className="block text-sm font-medium mb-1">Meta Title</label>
          <input
            type="text"
            name="meta_title"
            value={formData.meta_title || ""}
            onChange={handleChange}
            className={inputClassName}
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Meta Description</label>
          <textarea
            name="meta_description"
            value={formData.meta_description || ""}
            onChange={handleChange}
            rows={2}
            className={inputClassName}
          />
        </div>
      </section>

      {/* Hindi Translation */}
      <section className="space-y-4">
        <h3 className="text-lg font-semibold">Hindi (हिन्दी)</h3>
        <div>
          <label className="block text-sm font-medium mb-1">Title (Hindi)</label>
          <input
            type="text"
            name="title_hi"
            value={formData.title_hi || ""}
            onChange={handleChange}
            className={inputClassName}
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Content (Hindi)</label>
          <textarea
            name="content_hi"
            value={formData.content_hi || ""}
            onChange={handleChange}
            rows={6}
            className={inputClassName}
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Meta Title (Hindi)</label>
          <input
            type="text"
            name="meta_title_hi"
            value={formData.meta_title_hi || ""}
            onChange={handleChange}
            className={inputClassName}
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Meta Description (Hindi)</label>
          <textarea
            name="meta_description_hi"
            value={formData.meta_description_hi || ""}
            onChange={handleChange}
            rows={2}
            className={inputClassName}
          />
        </div>
      </section>

      {/* Urdu Translation */}
      <section className="space-y-4">
        <h3 className="text-lg font-semibold">Urdu (اردو)</h3>
        <div>
          <label className="block text-sm font-medium mb-1">Title (Urdu)</label>
          <input
            type="text"
            name="title_ur"
            value={formData.title_ur || ""}
            onChange={handleChange}
            className={inputClassName}
            dir="rtl"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Content (Urdu)</label>
          <textarea
            name="content_ur"
            value={formData.content_ur || ""}
            onChange={handleChange}
            rows={6}
            className={inputClassName}
            dir="rtl"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Meta Title (Urdu)</label>
          <input
            type="text"
            name="meta_title_ur"
            value={formData.meta_title_ur || ""}
            onChange={handleChange}
            className={inputClassName}
            dir="rtl"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Meta Description (Urdu)</label>
          <textarea
            name="meta_description_ur"
            value={formData.meta_description_ur || ""}
            onChange={handleChange}
            rows={2}
            className={inputClassName}
            dir="rtl"
          />
        </div>
      </section>

      {/* Image Upload */}
      <section className="space-y-4">
        <h3 className="text-lg font-semibold">Featured Image</h3>
        <div>
          <label className="block text-sm font-medium mb-1">Image</label>
          <input
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="block w-full text-sm text-foreground dark:text-foreground-dark file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-primary file:text-white hover:file:bg-primary-light transition-colors"
          />
          {isEdit && formData.image && typeof formData.image === "string" && (
            <div className="mt-2">
              <img
                src={formData.image}
                alt="Current"
                className="h-20 w-auto rounded-lg border border-border"
              />
              <p className="text-xs text-mutedForeground mt-1">Current image. Upload a new one to replace.</p>
            </div>
          )}
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Image Alt Text</label>
          <input
            type="text"
            name="image_alt_text"
            value={formData.image_alt_text || ""}
            onChange={handleChange}
            className={inputClassName}
          />
        </div>
      </section>

      {/* Flags and Options */}
      <section className="space-y-4">
        <h3 className="text-lg font-semibold">Publishing Options</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center">
            <input
              type="checkbox"
              id="is_published"
              name="is_published"
              checked={formData.is_published || false}
              onChange={handleChange}
              className="h-4 w-4 rounded border-border text-primary focus:ring-primary"
            />
            <label htmlFor="is_published" className="ml-2 text-sm">
              Published
            </label>
          </div>
          <div className="flex items-center">
            <input
              type="checkbox"
              id="is_featured"
              name="is_featured"
              checked={formData.is_featured || false}
              onChange={handleChange}
              className="h-4 w-4 rounded border-border text-primary focus:ring-primary"
            />
            <label htmlFor="is_featured" className="ml-2 text-sm">
              Featured
            </label>
          </div>
          <div className="flex items-center">
            <input
              type="checkbox"
              id="allow_comments"
              name="allow_comments"
              checked={formData.allow_comments || false}
              onChange={handleChange}
              className="h-4 w-4 rounded border-border text-primary focus:ring-primary"
            />
            <label htmlFor="allow_comments" className="ml-2 text-sm">
              Allow Comments
            </label>
          </div>
          <div className="flex items-center">
            <input
              type="checkbox"
              id="is_staff_post"
              name="is_staff_post"
              checked={formData.is_staff_post || false}
              onChange={handleChange}
              className="h-4 w-4 rounded border-border text-primary focus:ring-primary"
            />
            <label htmlFor="is_staff_post" className="ml-2 text-sm">
              Staff Post
            </label>
          </div>
        </div>
      </section>

      {/* Category field (assuming category ID) */}
      <div>
        <label className="block text-sm font-medium mb-1">Category ID</label>
        <input
          type="number"
          name="category"
          value={formData.category || ""}
          onChange={handleChange}
          className={inputClassName}
        />
        <p className="text-xs text-mutedForeground mt-1">Enter category ID (should be an integer)</p>
      </div>
    </motion.div>
  );
};

export default BlogFormFields;