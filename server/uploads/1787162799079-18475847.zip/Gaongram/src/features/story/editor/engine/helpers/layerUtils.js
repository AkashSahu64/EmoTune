export const getLayerName = (layer) => {
  if (layer.name) return layer.name;
  if (layer.type === "base") return "Base media";
  if (layer.type === "text") return "Text";
  if (layer.type === "emoji") return "Sticker";
  if (layer.type === "gif") return "GIF";
  if (layer.type === "music") return "Music";
  if (layer.type === "frame") return "Frame";
  return "Media";
};

export const LAYER_STACK_RANK = {
  base: 0,
  media: 10,
  image: 10,
  video: 10,
  text: 20,
  emoji: 30,
  gif: 30,
  music: 35,
  sticker: 35,
  frame: 90,
};

export const getLayerRank = (layer) => LAYER_STACK_RANK[layer?.type] ?? 20;

export const sortLayers = (layers) =>
  [...layers].sort((a, b) => {
    if (a.type === "base" && b.type !== "base") return -1;
    if (a.type !== "base" && b.type === "base") return 1;

    const rankDiff = getLayerRank(a) - getLayerRank(b);
    if (rankDiff !== 0) return rankDiff;

    return (a.zIndex || 0) - (b.zIndex || 0);
  });

export const isBaseLayerObject = (object) =>
  object?.__storyLayerType === "base" ||
  object?.storyLayerType === "base" ||
  String(object?.layerId || "").startsWith("base-");

export const isFilterableObject = (object) =>
  !!object &&
  isBaseLayerObject(object) &&
  (object.type === "image" || object.type === "video");

export const isLayerSelectable = (layer) =>
  !!layer && layer.visible !== false && !layer.locked;
