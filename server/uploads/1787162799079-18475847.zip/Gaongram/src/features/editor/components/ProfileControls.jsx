export { default } from "../../profile/components/image-editor/EditorFooter.jsx";
