export const getPointerDistance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

export const getPointerMidpoint = (a, b) => ({
  x: (a.x + b.x) / 2,
  y: (a.y + b.y) / 2,
});

export const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

export const normalizeWheelZoom = (event, currentZoom, min = 1, max = 4) => {
  const direction = event.deltaY > 0 ? -1 : 1;
  return clamp(currentZoom + direction * 0.08, min, max);
};
