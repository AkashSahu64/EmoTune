import React from 'react';

const StoryProgressBars = ({ stories, currentIndex, progress }) => {
  if (!stories.length) return null;

  return (
    <div className="absolute left-3 right-3 top-[calc(env(safe-area-inset-top)+0.75rem)] z-50 flex gap-1 sm:left-4 sm:right-4">
      {stories.map((_, idx) => (
        <div key={idx} className="h-1 flex-1 bg-white/30 rounded-full overflow-hidden" aria-hidden="true">
          <div
            className="h-full origin-left bg-white transition-transform duration-75 ease-linear will-change-transform"
            style={{
              transform: `scaleX(${
                idx === currentIndex ? progress / 100 : idx < currentIndex ? 1 : 0
              })`,
            }}
          />
        </div>
      ))}
    </div>
  );
};

export default React.memo(StoryProgressBars);
