import React, { useState, useEffect, useMemo } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Check, ChevronLeft, Plus, Search } from "lucide-react";
import { vibeService } from "../../services/vibe.service.js";
import { playlistService } from "../../services/playlist.service.js";
import { usePlaylistStore } from "../../store/playlistStore.js";
import Avatar from "../common/Avatar.jsx";

const AddAudioList = () => {
  const { id: playlistId } = useParams();
  const navigate = useNavigate();

  const [audios, setAudios] = useState([]);
  const [alreadyAdded, setAlreadyAdded] = useState(new Set()); 
  const [selected, setSelected] = useState(new Set());
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [search, setSearch] = useState("");
  const { addPlaylistItem, removePlaylistItem } = usePlaylistStore();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const audioRes = await vibeService.getVibePosts({
        audio: true,
        limit: 50,
      });

      const playlistRes = await playlistService.getPlaylistDetail(
        playlistId
      );

      const addedSet = new Set(
        (playlistRes.data?.items || []).map((i) => i.audio?.id)
      );

      setAlreadyAdded(addedSet);  
      setSelected(new Set());      
      setAudios(audioRes.data || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  // ===== SELECT =====
  const toggleSelect = (audioId) => {
    // 🔥 already added ko toggle nahi karna
    if (alreadyAdded.has(audioId)) return;

    setSelected((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(audioId)) newSet.delete(audioId);
      else newSet.add(audioId);
      return newSet;
    });
  };

  // ===== ADD ONLY NEW ONES =====
  const handleAdd = async () => {
    if (selected.size === 0) return;

    setSubmitting(true);
    const selectedIds = Array.from(selected);
    try {
      selectedIds.forEach((audioId) => {
        const match = audios.find((item) => item.audio?.id === audioId);
        addPlaylistItem(playlistId, {
          id: `temp-${playlistId}-${audioId}`,
          audio: match?.audio || { id: audioId },
          order: 0,
          is_liked: false,
          isOptimistic: true,
        });
      });
      const results = await Promise.all(
        selectedIds.map((audioId) => playlistService.addAudioToPlaylist(playlistId, audioId)),
      );
      selectedIds.forEach((audioId, index) => {
        removePlaylistItem(playlistId, audioId);
        if (results[index]?.data?.id) {
          addPlaylistItem(playlistId, results[index].data);
        }
      });
      navigate(`/playlists/${playlistId}`);
    } catch (e) {
      selectedIds.forEach((audioId) => removePlaylistItem(playlistId, audioId));
      console.error(e);
    } finally {
      setSubmitting(false);
    }
  };

  // ===== SEARCH =====
  const filteredAudios = useMemo(() => {
    if (!search.trim()) return audios;

    return audios.filter((item) =>
      item.audio?.title
        ?.toLowerCase()
        .includes(search.toLowerCase())
    );
  }, [audios, search]);

  return (
    <div className="min-h-screen bg-white dark:bg-black">
      {/* HEADER */}
      <div className="sticky top-0 bg-white dark:bg-black z-10 border-b border-gray-200 dark:border-gray-800">
        <div className="flex items-center p-4">
          <button onClick={() => navigate(-1)}>
            <ChevronLeft className="w-6 h-6 text-black dark:text-white" />
          </button>

          <h1 className="flex-1 text-center font-semibold text-lg text-black dark:text-white">
            Add Audio
          </h1>

          <button
            onClick={handleAdd}
            disabled={selected.size === 0 || submitting}
            className="text-sm font-semibold text-gaon-green disabled:opacity-50"
          >
            {submitting ? "Adding..." : `Add (${selected.size})`}
          </button>
        </div>

        {/* SEARCH */}
        <div className="px-4 pb-4">
          <div className="flex items-center gap-2 bg-gray-100 dark:bg-gray-900 rounded-xl px-4 py-3">
            <Search className="w-5 h-5 text-gray-400" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search songs..."
              className="bg-transparent outline-none w-full text-sm text-black dark:text-white placeholder-gray-500"
            />
          </div>
        </div>
      </div>

      {/* LIST */}
      <div className="p-4 space-y-1">
        {loading ? (
          <div className="text-center py-10 text-gray-400">
            Loading audios...
          </div>
        ) : (
          filteredAudios.map((item) => {
            const audio = item.audio;
            if (!audio?.id) return null;

            const isAdded = alreadyAdded.has(audio.id);
            const isSelected = selected.has(audio.id);

            return (
              <div
                key={audio.id}
                onClick={() => toggleSelect(audio.id)}
                className="flex items-center gap-4 bg-gray-50 dark:bg-gray-900 rounded-lg py-1 px-4 border border-gray-200 dark:border-gray-800 cursor-pointer"
              >
                <Avatar
                  src={audio.cover_image}
                  alt={audio.title}
                  size="medium"
                  className="rounded-xl"
                />

                <div className="flex-1">
                  <div className="font-semibold text-gray-900 dark:text-white">
                    {audio.title}
                  </div>
                  <div className="text-sm text-gray-500">
                    @{item.user?.username}
                  </div>
                </div>

                <div className="w-6 h-6 rounded-full bg-gaon-green/90 flex items-center justify-center">
                  {isAdded || isSelected ? (
                    <Check className="w-4 h-4 text-white" />
                  ) : (
                    <Plus className="w-4 h-4 text-white" />
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default AddAudioList;
