// src/features/feed/createPost/CreateImagePostModal.jsx
import React, { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { X, Pencil } from "lucide-react";
import { useAuthStore } from "../../../store/authStore.js";
import { useUIStore } from "../../../store/uiStore.js";
import { postCreateService } from "../../../services/postCreate.service.js";
import { showSuccess, showError } from "../../../utils/toast.js";
import Button from "../../../components/common/Button.jsx";
import UploadZone from "./UploadZone.jsx";
import PostCaptionEditor from "./PostCaptionEditor.jsx";
import MediaEditorModal from "./MediaEditorModal.jsx";
import { FEED_EVENTS, publishFeedEvent } from "../../../utils/feedEvents.js";
import SensitiveContentCheckbox from "./SensitiveContentCheckbox.jsx";

const MediaPreview = ({ file, alt, className }) => {
  const previewUrl = useMemo(() => URL.createObjectURL(file), [file]);

  useEffect(() => {
    return () => URL.revokeObjectURL(previewUrl);
  }, [previewUrl]);

  if (file?.type?.startsWith("video/")) {
    return <video src={previewUrl} className={className} muted playsInline controls />;
  }

  return <img src={previewUrl} alt={alt} className={className} />;
};

const CreateImagePostModal = () => {
  const { user } = useAuthStore();
  const { closeModal } = useUIStore();
  const [caption, setCaption] = useState("");
  const [privacy, setPrivacy] = useState("public");
  const [images, setImages] = useState([]);
  const [currentEditingIndex, setCurrentEditingIndex] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [location, setLocation] = useState("");
  const [isSensitive, setIsSensitive] = useState(false);

  const handleFileSelect = (files) => {
    // files can be array or single
    const newFiles = Array.isArray(files) ? files : [files];
    const total = images.length + newFiles.length;
    if (total > 10) {
      showError("Maximum 10 images allowed");
      return;
    }
    // Start editing the first new image
    setImages((prev) => [...prev, ...newFiles]);
    setCurrentEditingIndex(images.length); // index of the first new
  };

  const handleEditComplete = (updatedFiles) => {
    setImages(Array.isArray(updatedFiles) ? updatedFiles : images);
    setCurrentEditingIndex(null);
  };

  const removeImage = (index) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async () => {
    if (images.length === 0) {
      showError("Please select at least one image");
      return;
    }

    setIsSubmitting(true);
    const formData = new FormData();
    formData.append("content", caption);
    formData.append("author", user?.id);
    formData.append("privacy", privacy);
    formData.append("is_sensitive", isSensitive);
    if (location) formData.append("location", location);
    const videoItems = images.filter((item) => item?.type?.startsWith("video/") || item?.editorMetadata?.mediaType === "video");
    const imageItems = images.filter((item) => !videoItems.includes(item));

    if (videoItems.length > 0) {
      formData.append("media_type", "video");
      videoItems.forEach((video, index) => {
        formData.append(`videos[${index}]video`, video);
        if (video.editorThumbnail) {
          formData.append(`videos[${index}]thumbnail`, video.editorThumbnail);
        }
        if (video.editorMetadata) {
          formData.append(`videos[${index}]metadata`, JSON.stringify(video.editorMetadata));
        }
      });
    } else {
      formData.append("media_type", images.length > 1 ? "carousel" : "image");
      imageItems.forEach((img, index) => {
        formData.append(`images[${index}]image`, img);
      });
    }
    formData.append("show_profile", "false");

    try {
      await postCreateService.createPost(formData);
      showSuccess("Image post created!");
      closeModal();
      publishFeedEvent({ type: FEED_EVENTS.CREATED });
    } catch (err) {
      showError("Failed to create post");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.22 }}
      className=" w-full max-w-lg mx-auto bg-muted dark:bg-muted-dark text-foreground dark:text-foreground-dark rounded-xl overflow-visible z-10"
    >
      {/* Header */}
      <div className="flex items-center justify-between border-b border-border dark:border-border-dark px-4 py-2">
        <h2 className="text-base font-bold">Create Image Post</h2>
        <button
          onClick={closeModal}
          className="p-2 text-foreground dark:text-foreground-dark rounded-full hover:bg-mutedForeground/20 dark:hover:bg-mutedForeground-dark/30 transition"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="max-h-[75vh] overflow-y-auto px-4 py-4 space-y-4 hide-scrollbar">
        {/* User info & privacy */}
        {/* <div className="flex items-center gap-3">
          <Avatar src={user?.avatar} alt={user?.username} size="medium" />
          <div>
            <p className="font-semibold">{user?.username}</p>
            <select
              value={privacy}
              onChange={(e) => setPrivacy(e.target.value)}
              className="text-xs text-gray-500 bg-transparent outline-none"
            >
              <option value="public">🌍 Public</option>
              <option value="friends">👥 Friends</option>
              <option value="private">🔒 Private</option>
            </select>
          </div>
        </div> */}

        {/* Caption */}
        <PostCaptionEditor caption={caption} setCaption={setCaption} />

        {/* Image upload */}
        <div className="mb-4">
          <label className="block font-medium mb-2">Images</label>
          <UploadZone
            onFileSelect={handleFileSelect}
            accept="image/*"
            maxSizeMB={10}
            multiple
          />
        </div>

        {/* Preview grid */}
        {images.length > 0 && (
          <div className="mb-4 grid grid-cols-3 gap-2">
            {images.map((img, idx) => (
              <div key={idx} className="relative aspect-square">
                <MediaPreview
                  file={img}
                  alt={`preview ${idx}`}
                  className="w-full h-full object-cover rounded-lg"
                />
                <button
                  onClick={() => removeImage(idx)}
                  className="absolute top-1 right-1 p-1 bg-black/50 text-white rounded-full"
                >
                  <X className="w-3 h-3" />
                </button>
                <button
                  onClick={() => setCurrentEditingIndex(idx)}
                  className="absolute bottom-1 right-1 "
                >
                  <Pencil className="w-6 h-6 p-1.5 bg-black/50 text-white rounded-full" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Location */}
        {/* <div className="mb-6">
          <input
            type="text"
            placeholder="Add location (optional)"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg"
          />
        </div> */}

        <div className="mb-4">
          <SensitiveContentCheckbox
            checked={isSensitive}
            onChange={setIsSensitive}
          />
        </div>

        {/* Submit */}
        <Button
          variant="primary"
          fullWidth
          onClick={handleSubmit}
          loading={isSubmitting}
          disabled={images.length === 0}
        >
          Post
        </Button>
      </div>

      {/* Media Editor Modal */}
      {currentEditingIndex !== null && (
        <MediaEditorModal
          isOpen={true}
          onClose={() => setCurrentEditingIndex(null)}
          mediaFile={images}
          activeIndex={currentEditingIndex}
          setActiveIndex={setCurrentEditingIndex}
          onSave={handleEditComplete}
          mediaType="image"
        />
      )}
    </motion.div>
  );
};

export default CreateImagePostModal;
