import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ChevronLeft, MoreHorizontal, Play } from "lucide-react";
import { playlistService } from "../../services/playlist.service.js";
import PlaylistOptionsMenu from "../../components/playlist/PlaylistOptionsMenu.jsx";
import Avatar from "../../components/common/Avatar.jsx";
import Loader from "../../components/common/Loader.jsx";
import ConfirmModal from "../../components/common/ConfirmModal.jsx";
import { getAudioDuration } from "../../utils/getAudioDuration.js";
import { formatPlayerTime } from "../../utils/formatTime.js";
import Seo from "../../components/seo/Seo.jsx";
import { buildPlaylistSeo, buildStaticPageSeo } from "../../seo/seoBuilders.js";
import { shouldSkipLiveSeoFetch } from "../../seo/seoUtils.js";
import { usePlayerStore } from "../../store/playerStore.js";

const PlaylistDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const skipLiveFetch = shouldSkipLiveSeoFetch({
    allowConfiguredApi: Boolean(id),
  });

  const [playlist, setPlaylist] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showOptions, setShowOptions] = useState(false);
  const [showRenameModal, setShowRenameModal] = useState(false);
  const [renameValue, setRenameValue] = useState("");
  const [durations, setDurations] = useState({});
  const [showPrivacyConfirm, setShowPrivacyConfirm] = useState(false);
  const [showRemoveConfirm, setShowRemoveConfirm] = useState(false);
  const [removeTarget, setRemoveTarget] = useState(null);
  const { setQueue } = usePlayerStore();

  useEffect(() => {
    if (skipLiveFetch) {
      setLoading(false);
      return;
    }

    fetchPlaylist();
  }, [id, skipLiveFetch]);

  useEffect(() => {
    if (!playlist?.items?.length) return;

    const loadDurations = async () => {
      const results = {};

      await Promise.all(
        playlist.items.map(async (item) => {
          const audio = item.audio;

          if (!audio?.id) return;

          // backend duration exists
          if (audio.duration) {
            results[audio.id] = audio.duration;
            return;
          }

          // frontend calculate
          const duration = await getAudioDuration(audio.audio);

          results[audio.id] = duration;
        }),
      );

      setDurations(results);
    };

    loadDurations();
  }, [playlist]);

  const fetchPlaylist = async () => {
    setLoading(true);
    try {
      const res = await playlistService.getPlaylistDetail(id);
      setPlaylist(res.data);
    } catch (error) {
      navigate("/playlists");
    } finally {
      setLoading(false);
    }
  };

 const handlePlayAll = () => {
  if (!playlist?.items?.length) return;

  const tracks = playlist.items.map((item) => ({
    id: item.audio?.id,
    title: item.audio?.title,
    src: item.audio?.audio,
    cover: item.audio?.cover_image,
    artist: item.audio?.username || "Unknown Artist",
    audio: item.audio,
  }));

  setQueue(tracks, 0, {
    isPlaying: true,
    force: true,
  });

  // ✅ ONLY PLAYLIST
  navigate(`/audio?playlist=${playlist.id}`);
};

const handlePlayTrack = (clickedIndex) => {
  if (!playlist?.items?.length) return;

  const tracks = playlist.items.map((item) => ({
    id: item.audio?.id,
    title: item.audio?.title,
    src: item.audio?.audio,
    cover: item.audio?.cover_image,
    artist: item.audio?.username || "Unknown Artist",

    audio: item.audio,
    feed_post: item.audio?.feed_post,
  }));

  const selectedTrack = tracks[clickedIndex];

  setQueue(tracks, clickedIndex, {
    isPlaying: true,
    force: true,
  });

  navigate(
    `/audio?playlist=${playlist.id}&start=${
      selectedTrack.feed_post || selectedTrack.id
    }`
  );
};

  // ⭐ NOW ONLY OPEN CONFIRM MODAL
  const handlePrivacyToggleClick = () => {
    setShowPrivacyConfirm(true);
  };

  // ⭐ ACTUAL API CALL AFTER CONFIRM
  const confirmPrivacyToggle = async () => {
    const updated = await playlistService.updatePlaylist(playlist.id, {
      is_public: !playlist.is_public,
    });
    setPlaylist(updated.data);
    setShowPrivacyConfirm(false);
  };

  const confirmRename = async () => {
    if (!renameValue.trim()) return;

    const updated = await playlistService.updatePlaylist(playlist.id, {
      title: renameValue,
    });

    setPlaylist(updated.data);
    setShowRenameModal(false);
  };

  const handleEdit = (field) => {
    if (field === "title") {
      setRenameValue(playlist.title || "");
      setShowRenameModal(true);
    }

    if (field === "cover") {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = "image/*";

      input.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const res = await playlistService.updatePlaylist(playlist.id, {
          cover_image: file,
        });

        setPlaylist(res.data);
      };

      input.click();
    }
  };

  // ⭐ OPEN REMOVE CONFIRM
  const handleRemoveClick = (item) => {
    setRemoveTarget(item);
    setShowRemoveConfirm(true);
  };

  // ⭐ REMOVE AFTER CONFIRM
  const confirmRemove = async () => {
    if (!removeTarget) return;

    await playlistService.removeAudioFromPlaylist(
      playlist.id,
      removeTarget.audio.id,
    );

    setPlaylist((prev) => ({
      ...prev,
      items: prev.items.filter((i) => i.id !== removeTarget.id),
    }));

    setShowRemoveConfirm(false);
    setRemoveTarget(null);
  };

  if (loading || !playlist) {
    return (
      <>
        <Seo
          {...buildStaticPageSeo("playlists", {
            path: `/playlists/${id || ""}`,
          })}
        />
        <div className="h-screen flex items-center justify-center bg-white dark:bg-black">
          <Loader />
        </div>
      </>
    );
  }

  return (
    <>
      <Seo
        {...buildPlaylistSeo(playlist, { id, path: `/playlists/${id || ""}` })}
      />
      <div className="min-h-screen bg-white dark:bg-black">
        {/* HERO */}
        <div className="relative h-[200px] md:h-[300px] w-full overflow-hidden">
          <div
            className="absolute inset-0 bg-cover bg-center scale-105"
            style={{ backgroundImage: `url(${playlist.cover_image})` }}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/40 to-white dark:to-black" />

          <div className="sticky top-0 z-10 p-4">
            <button
              onClick={() => navigate(-1)}
              className="p-2 bg-black/50 backdrop-blur-sm rounded-full text-white"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          </div>

          <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-6">
            <h1 className="text-3xl md:text-4xl font-semibold text-white drop-shadow">
              {playlist.title}
            </h1>

            <p className="mt-2 text-white/80 text-sm">
              {playlist.items?.length}{" "}
              {playlist.items?.length === 1 ? "Track" : "Tracks"}
            </p>

            <div className="flex items-center gap-4 lg:gap-12 mt-7">
              {/* ⭐ PRIVACY BUTTON */}
              <button
                onClick={handlePrivacyToggleClick}
                className="px-2 py-1 rounded-full bg-white/20 backdrop-blur border border-white/30 text-white"
              >
                🌍 {playlist.is_public ? "Public" : "Private"}
              </button>

              <button
                onClick={() => setShowOptions(true)}
                className="w-10 h-10 rounded-full bg-white shadow flex items-center justify-center"
              >
                <MoreHorizontal className="w-5 h-5 text-gray-700" />
              </button>

              <button
                onClick={handlePlayAll}
                className="w-12 h-12 rounded-full bg-gaon-green flex items-center justify-center shadow-md"
              >
                <Play className="w-6 h-6 text-white ml-1" />
              </button>
            </div>
          </div>
        </div>

        {/* TRACK LIST */}
        <div className="px-2 lg:px-4 mt-4 lg:mt-8 pb-24 space-y-1">
          {playlist.items?.map(
            (item, index) =>
              console.log("Rendering item:", item) || (
                <div
                  key={item.id}
                  className=" group relative flex items-center gap-3 px-3 py-1 rounded-lg bg-muted dark:bg-muted-dark border border-border dark:borderborder-dark hover:shadow-sm overflow-hidden"
                >
                  <Avatar
                    src={item.audio.cover_image}
                    alt={item.audio.title}
                    size="medium"
                    className=" rounded-xl object-cover shadow-md"
                  />

                  {/* INFO */}
                  <div className="flex-1 min-w-0 leading-tight">
                    <h3
                      className=" text-sm md:text-base font-semibold text-gray-900 dark:text-white truncate"
                    >
                      {item.audio.title}
                    </h3>

                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-gray-500 dark:text-gray-400">
                        {formatPlayerTime(durations[item.audio.id] || 0)}
                      </span>

                      <span className="w-1 h-1 rounded-full bg-gray-400" />

                      <span className="text-xs text-gray-500 dark:text-gray-400">
                        Audio Track
                      </span>
                    </div>
                  </div>

                  {/* ACTIONS */}
                  <div className="flex items-center gap-2">
                    {/* OPTIONS */}
                    <button
                      onClick={() => handleRemoveClick(item)}
                      className=" w-9 h-9 rounded-full flex items-center justify-center text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-800 hover:text-black dark:hover:text-white transition"
                    >
                      <MoreHorizontal className="w-5 h-5" />
                    </button>

                    {/* PLAY BUTTON */}
                    <button
                      onClick={() => handlePlayTrack(index)}
                      className=" w-9 h-9 rounded-full bg-primary text-white flex items-center justify-center shadow-lg hover:scale-110 active:scale-95 transition-all duration-200"
                    >
                      <Play className="w-4 h-4 fill-white ml-0.5" />
                    </button>
                  </div>

                  {/* HOVER GLOW */}
                  <div
                    className=" absolute inset-0 opacity-0 group-hover:opacity-100 bg-gradient-to-r from-primary/5 to-transparent pointer-events-none transition duration-300"
                  />
                </div>
              ),
          )}
        </div>

        <PlaylistOptionsMenu
          isOpen={showOptions}
          onClose={() => setShowOptions(false)}
          playlist={playlist}
          onEdit={handleEdit}
        />

        {/* ⭐ PRIVACY CONFIRM */}
        <ConfirmModal
          isOpen={showPrivacyConfirm}
          onClose={() => setShowPrivacyConfirm(false)}
          onConfirm={confirmPrivacyToggle}
          title="Change privacy?"
          message={`Make this playlist ${
            playlist.is_public ? "Private" : "Public"
          }?`}
          confirmText="Yes"
          cancelText="Cancel"
        />

        {/* ⭐ REMOVE CONFIRM */}
        <ConfirmModal
          isOpen={showRemoveConfirm}
          onClose={() => setShowRemoveConfirm(false)}
          onConfirm={confirmRemove}
          title="Remove song?"
          message="Are you sure you want to remove this audio from playlist?"
          confirmText="Remove"
          cancelText="Cancel"
          type="error"
        />

        <ConfirmModal
          isOpen={showRenameModal}
          onClose={() => setShowRenameModal(false)}
          onConfirm={confirmRename}
          title="Edit playlist name"
          confirmText="Save"
          cancelText="Cancel"
          type="info"
          message={
            <input
              type="text"
              value={renameValue}
              onChange={(e) => setRenameValue(e.target.value)}
              className="w-full mt-2 border border-gray-300 rounded-lg px-3 py-2"
              placeholder="Enter playlist name"
            />
          }
        />
      </div>
    </>
  );
};

export default PlaylistDetailPage;
