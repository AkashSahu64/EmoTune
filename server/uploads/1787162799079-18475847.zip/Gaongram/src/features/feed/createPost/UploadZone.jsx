// src/features/feed/createPost/UploadZone.jsx
import React, { useRef } from 'react';
import { Upload } from 'lucide-react';

const UploadZone = ({ onFileSelect, accept, maxSizeMB = 50, multiple = false }) => {
  const fileInputRef = useRef(null);

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const files = Array.from(e.dataTransfer.files);
    const validFiles = files.filter(file => file.type.startsWith(accept.split(',')[0].split('/')[0]));
    if (validFiles.length) {
      onFileSelect(multiple ? validFiles : validFiles[0]);
    }
  };

  return (
    <div
      onClick={() => fileInputRef.current?.click()}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      className="border-2 border-dashed border-border dark:border-border-dark rounded-xl p-3 text-center cursor-pointer hover:border-primary/80 dark:hover:border-primary/80 transition-colors"
    >
      <input
        type="file"
        ref={fileInputRef}
        onChange={(e) => onFileSelect(multiple ? Array.from(e.target.files) : e.target.files[0])}
        accept={accept}
        multiple={multiple}
        className="hidden"
      />
      <Upload className="w-12 h-12 text-foreground dark:text-foreground-dark mx-auto mb-3" />
      <p className="font-medium text-foreground dark:text-foreground-dark">Click or drag to upload</p>
      <p className="text-sm text-foreground/60 dark:text-foreground-dark/60 mt-1">Max {maxSizeMB}MB</p>
    </div>
  );
};

export default UploadZone;