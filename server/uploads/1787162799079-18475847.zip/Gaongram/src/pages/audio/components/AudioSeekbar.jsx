// pages/audio/components/AudioSeekbar.jsx
import React from "react";

const AudioSeekbar = React.memo(
  ({
    duration,
    currentTime,
    progressPercentage,
    audioError,
    hasError,
    onSeek,
    formatTime,
  }) => {
    return (
      <div className="mb-2">
        <div className="relative h-1 bg-white/20 rounded-md cursor-pointer group">
          {/* Invisible Bottom Click Area */}
          <div
            className="absolute top-0 left-0 w-full h-3"
            onClick={(e) => {
              if (!duration || audioError || hasError) return;

              const rect = e.currentTarget.getBoundingClientRect();
              const clickPosition = (e.clientX - rect.left) / rect.width;
              const newTime = clickPosition * duration;

              onSeek(newTime);
            }}
          />

          {/* Progress Fill */}
          <div
            className="absolute h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all duration-200"
            style={{ width: `${progressPercentage}%` }}
          />

          {/* Thumb */}
          <div
            className="absolute w-3 h-3 bg-white rounded-full -top-1 transform -translate-x-1/2 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
            style={{ left: `${progressPercentage}%` }}
          />
        </div>

        {/* Time Row */}
        <div className="flex justify-between text-xs text-gray-400 mt-0.5">
          <span>{formatTime(currentTime)}</span>
          <span>{formatTime(duration)}</span>
        </div>
      </div>
    );
  },
);

AudioSeekbar.displayName = "AudioSeekbar";

export default AudioSeekbar;
