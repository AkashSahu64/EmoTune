export { default } from "../../profile/components/image-editor/CropperView.jsx";
