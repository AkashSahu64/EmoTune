// src/features/feed/createPost/components/editor/filterPresets.js

export const FILTER_PRESETS = {
  Natural: {
    brightness: 100,
    contrast: 100,
    saturation: 100,
  },

  Warm: {
    brightness: 108,
    contrast: 104,
    saturation: 115,
  },

  Cool: {
    brightness: 96,
    contrast: 110,
    saturation: 88,
  },

  Dramatic: {
    brightness: 90,
    contrast: 135,
    saturation: 110,
  },

  Soft: {
    brightness: 105,
    contrast: 92,
    saturation: 92,
  },
};