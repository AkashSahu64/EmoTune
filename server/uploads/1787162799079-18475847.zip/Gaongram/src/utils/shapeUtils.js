// src/features/feed/createPost/components/editor/utils/shapeUtils.js
export function getShapeBounds(shape) {
  switch (shape.type) {
    case "rect":
      return {
        x: Math.min(shape.start.x, shape.end.x),
        y: Math.min(shape.start.y, shape.end.y),
        w: Math.abs(shape.end.x - shape.start.x),
        h: Math.abs(shape.end.y - shape.start.y),
      };
    case "circle":
      const cx = (shape.start.x + shape.end.x) / 2;
      const cy = (shape.start.y + shape.end.y) / 2;
      const rx = Math.abs(shape.end.x - shape.start.x) / 2;
      const ry = Math.abs(shape.end.y - shape.start.y) / 2;
      return { x: cx - rx, y: cy - ry, w: rx * 2, h: ry * 2 };
    case "triangle":
      const midX = (shape.start.x + shape.end.x) / 2;
      return {
        x: Math.min(shape.start.x, shape.end.x),
        y: Math.min(shape.start.y, shape.end.y),
        w: Math.abs(shape.end.x - shape.start.x),
        h: Math.abs(shape.end.y - shape.start.y),
      };
    case "hexagon":
      const hcx = (shape.start.x + shape.end.x) / 2;
      const hcy = (shape.start.y + shape.end.y) / 2;
      const hdx = Math.abs(shape.end.x - shape.start.x) / 2;
      const hdy = Math.abs(shape.end.y - shape.start.y) / 2;
      return { x: hcx - hdx, y: hcy - hdy, w: hdx * 2, h: hdy * 2 };
    default:
      return { x: 0, y: 0, w: 0, h: 0 };
  }
}

export function hitTestShape(shape, point) {
  const b = getShapeBounds(shape);
  const pad = 8;
  return (
    point.x >= b.x - pad &&
    point.x <= b.x + b.w + pad &&
    point.y >= b.y - pad &&
    point.y <= b.y + b.h + pad
  );
}

export function drawShape(ctx, shape) {
  ctx.save();
  ctx.globalAlpha = shape.opacity ?? 1;
  ctx.strokeStyle = shape.strokeColor;
  ctx.lineWidth = shape.strokeWidth;
  ctx.setLineDash(shape.lineDash || []);
  ctx.globalAlpha = shape.opacity ?? 1;

  if (shape.fillColor) {
    ctx.fillStyle = shape.fillColor;

    ctx.globalAlpha = shape.opacity ?? 1;
  }

  const { start, end } = shape;
  switch (shape.type) {
    case "rect":
      if (shape.fillColor) {
        ctx.fillRect(
          Math.min(start.x, end.x),
          Math.min(start.y, end.y),
          Math.abs(end.x - start.x),
          Math.abs(end.y - start.y),
        );
      }
      ctx.strokeRect(
        Math.min(start.x, end.x),
        Math.min(start.y, end.y),
        Math.abs(end.x - start.x),
        Math.abs(end.y - start.y),
      );
      break;
    case "circle":
      const cx = (start.x + end.x) / 2;
      const cy = (start.y + end.y) / 2;
      const rx = Math.abs(end.x - start.x) / 2;
      const ry = Math.abs(end.y - start.y) / 2;
      ctx.beginPath();
      ctx.ellipse(cx, cy, rx, ry, 0, 0, 2 * Math.PI);
      if (shape.fillColor) ctx.fill();
      ctx.stroke();
      break;
    case "triangle":
      const midX = (start.x + end.x) / 2;
      ctx.beginPath();
      ctx.moveTo(midX, start.y);
      ctx.lineTo(end.x, end.y);
      ctx.lineTo(start.x, end.y);
      ctx.closePath();
      if (shape.fillColor) ctx.fill();
      ctx.stroke();
      break;
    case "hexagon":
      const hcx = (start.x + end.x) / 2;
      const hcy = (start.y + end.y) / 2;
      const hdx = Math.abs(end.x - start.x) / 2;
      const hdy = Math.abs(end.y - start.y) / 2;
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const angle = (Math.PI / 3) * i - Math.PI / 2;
        const px = hcx + hdx * Math.cos(angle);
        const py = hcy + hdy * Math.sin(angle);
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      if (shape.fillColor) ctx.fill();
      ctx.stroke();
      break;
    case "line":
    case "arrow":
    case "dashed":
    case "dashdot":
    case "dot":
      ctx.beginPath();
      ctx.moveTo(start.x, start.y);
      ctx.lineTo(end.x, end.y);
      ctx.stroke();
      if (shape.type === "arrow") {
        const angle = Math.atan2(end.y - start.y, end.x - start.x);
        const headLen = shape.strokeWidth * 3;
        ctx.save();
        ctx.translate(end.x, end.y);
        ctx.rotate(angle);
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(-headLen, -headLen / 2);
        ctx.lineTo(-headLen, headLen / 2);
        ctx.closePath();
        if (shape.fillColor) ctx.fill();
        ctx.fillStyle = shape.strokeColor;
        ctx.fill();
        ctx.setLineDash([]);
        ctx.restore();
      }
      break;
    default:
      break;
  }
  ctx.restore();
}
