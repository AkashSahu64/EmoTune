import { create } from "zustand";

const MAX_HISTORY = 50;

const useCanvasStore = create((set, get) => ({
  // =========================
  // STATE
  // =========================
  canvasEngine: null,
  aspectRatio: "9:16",
  canvasWidth: 1080,
  canvasHeight: 1920,
  activeLayerId: null,

  music: null, // { id, title, audio_url, cover_image }

  globalFilters: {
    brightness: 0,
    contrast: 0,
    saturation: 0,
    blur: 0,
  },

  history: [],
  historyIndex: -1,

  // =========================
  // ACTIONS
  // =========================

  setCanvasEngine: (engine) => {
    set({ canvasEngine: engine });
  },

  setAspectRatio: (ratio) => {
    const sizes = {
      "9:16": { w: 1080, h: 1920 },
      "1:1": { w: 1080, h: 1080 },
      "4:5": { w: 1080, h: 1350 },
    };

    const size = sizes[ratio] || sizes["9:16"];

    set({
      aspectRatio: ratio,
      canvasWidth: size.w,
      canvasHeight: size.h,
    });

    try {
      get().canvasEngine?.resize(size.w, size.h);
    } catch (err) {
      console.error("Canvas resize error:", err);
    }
  },

  setActiveLayer: (layerId) => {
    set({ activeLayerId: layerId });
  },

  setMusic: (track) => {
    set({ music: track });
  },

  updateGlobalFilters: (newFilters) => {
    set((state) => ({
      globalFilters: { ...state.globalFilters, ...newFilters },
    }));

    try {
      get().canvasEngine?.applyGlobalFilters(newFilters);
    } catch (err) {
      console.error("Filter apply error:", err);
    }
  },

  // =========================
  // HISTORY (UNDO / REDO)
  // =========================

  saveSnapshot: () => {
    const engine = get().canvasEngine;
    if (!engine) return;

    try {
      const json = engine.getStateJSON();

      const { history, historyIndex } = get();

      let newHistory = history.slice(0, historyIndex + 1);
      newHistory.push(json);

      // Limit history size
      if (newHistory.length > MAX_HISTORY) {
        newHistory.shift();
      }

      set({
        history: newHistory,
        historyIndex: newHistory.length - 1,
      });
    } catch (err) {
      console.error("Snapshot save error:", err);
    }
  },

  undo: () => {
    const { history, historyIndex } = get();

    if (historyIndex <= 0) return;

    const newIndex = historyIndex - 1;

    try {
      get().canvasEngine?.loadStateJSON(history[newIndex]);
      set({ historyIndex: newIndex });
    } catch (err) {
      console.error("Undo error:", err);
    }
  },

  redo: () => {
    const { history, historyIndex } = get();

    if (historyIndex >= history.length - 1) return;

    const newIndex = historyIndex + 1;

    try {
      get().canvasEngine?.loadStateJSON(history[newIndex]);
      set({ historyIndex: newIndex });
    } catch (err) {
      console.error("Redo error:", err);
    }
  },

  // =========================
  // RESET
  // =========================

  resetEditor: () =>
    set({
      activeLayerId: null,
      music: null,
      globalFilters: {
        brightness: 0,
        contrast: 0,
        saturation: 0,
        blur: 0,
      },
      history: [],
      historyIndex: -1,
    }),
}));

export default useCanvasStore;