import { useCallback } from "react";
import { useAuthStore } from "../store/authStore.js";
import { useUIStore } from "../store/uiStore.js";
import { vibeService } from "../services/vibe.service.js";
import { showSuccess, showError } from "../utils/toast.js";
import { useReport } from "./useReport.js";
import { copyTextToClipboard } from "../utils/clipboard.js";

/**
 * Global hook for post actions (like, share, report, etc.)
 * Provides consistent optimistic updates and auth handling.
 */
export const usePostActions = () => {
  const { user, isAuthenticated } = useAuthStore();
  const { openModal } = useUIStore();
  const { openReport } = useReport();

  const handleLike = useCallback(
    async (postId, currentIsLiked, currentLikeCount, onUpdate) => {
      if (!isAuthenticated) {
        openModal("login");
        return;
      }

      const newIsLiked = !currentIsLiked;
      const newLikeCount = newIsLiked
        ? currentLikeCount + 1
        : currentLikeCount - 1;

      onUpdate?.({
        is_liked: newIsLiked,
        total_likes: newLikeCount,
      });

      try {
        await vibeService.likePost(postId);

        return {
          success: true,
          isLiked: newIsLiked,
          likeCount: newLikeCount,
        };
      } catch (error) {
        onUpdate?.({
          is_liked: currentIsLiked,
          total_likes: currentLikeCount,
        });

        return { success: false };
      }
    },
    [isAuthenticated, openModal],
  );

  const handleCopyLink = useCallback(async (url) => {
    const copied = await copyTextToClipboard(url);

    if (copied) {
      showSuccess("Link copied to clipboard!");
      return { success: true };
    }

    showError("Failed to copy link");
    return { success: false };
  }, []);

  const handleShare = useCallback(
  async (postId, username, postType = "vibe", options = {}) => {
    const path =
      options.url ||
      (postType === "reels"
        ? `/profile/${username}/reels/${postId}`
        : `/profile/${username}/post/${postId}`);

    const shareUrl = `${window.location.origin}${path}`;
    const shareText = options.text || "Check this out on GaonGram";

    if (navigator.share) {
      try {
        await navigator.share({
          title: options.title || shareText,
          text: options.text,
          url: shareUrl,
        });

        return { success: true };
      } catch (error) {
        if (error.name !== "AbortError") {
          return handleCopyLink(shareUrl);
        }

        return { success: false, error };
      }
    }

    return handleCopyLink(shareUrl);
  },
  [handleCopyLink],
);

  const handleReport = useCallback(
    (postId, postData = null) => {
      openReport({
        modelType: "post",
        objectId: postId,
        objectData: postData,
      });
    },
    [openReport],
  );

  const handleOptions = useCallback(
    (postId, isOwner, postData = null) => {
      openModal("post-options", {
        postId,
        authorId: postData?.user?.id,
        isOwner,
        post: postData,
        onHide: () => {},
      });
    },
    [openModal],
  );

  const handleComments = useCallback(
    (postId, onUpdate) => {
      if (!isAuthenticated) {
        openModal("login");
        return;
      }

      openModal("comments", {
        postId,

        // ✅ parent + reply BOTH increase
        onCommentAdded: () => {
          onUpdate?.({
            comments_count: (prev) => (typeof prev === "number" ? prev + 1 : 1),
          });
        },

        // ✅ delete decrease
        onCommentDeleted: () => {
          onUpdate?.({
            comments_count: (prev) =>
              Math.max(0, typeof prev === "number" ? prev - 1 : 0),
          });
        },
      });
    },
    [isAuthenticated, openModal],
  );

  return {
    handleLike,
    handleShare,
    handleCopyLink,
    handleOptions,
    handleReport,
    handleComments,
    isAuthenticated,
    user,
  };
};
