import React, { useRef } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";

import {
  Heart,
  MessageCircle,
  Eye,
  Play,
  Music2,
  ImageIcon,
} from "lucide-react";

import { useMediaStore } from "../../../store/mediaStore";
import SensitiveContentOverlay from "../../../components/vibe/SensitiveContentOverlay.jsx";
import { useAuthStore } from "../../../store/authStore";
import { calculateAge } from "../../../utils/calculateAge";

const PostGrid = ({ posts }) => {
  const videoRefs = useRef({});

  const navigate = useNavigate();

  const { user } = useAuthStore();

  const profileDob = user?.dob || user?.profile?.dob;

  const age = calculateAge(profileDob);

  const isUnder18 = typeof age === "number" && age < 18;

  const sensitiveAllowed =
    user?.is_sensitive_allowed ?? user?.profile?.is_sensitive_allowed;

  const canViewSensitive =
    sensitiveAllowed === true && typeof age === "number" && !isUnder18;

  const setActivePost = useMediaStore((state) => state.setActivePost);

  // Compact number format
  const formatNumber = (value) => {
    return new Intl.NumberFormat("en", {
      notation: "compact",
      maximumFractionDigits: 1,
    }).format(Number(value || 0));
  };
  // Hover play
  const handleMouseEnter = async (postId) => {
    const video = videoRefs.current[postId];

    if (!video) return;

    try {
      video.currentTime = 0;
      await video.play();
    } catch (err) {
      console.log("Autoplay blocked:", err);
    }
  };

  // Hover pause
  const handleMouseLeave = (postId) => {
    const video = videoRefs.current[postId];

    if (!video) return;

    video.pause();
    video.currentTime = 0;
  };

  // Navigate based on media type
  const handlePostClick = (post) => {
    setActivePost(post);

    // VIDEO
    if (post.videos?.length > 0) {
      navigate(`/vibe-feed/${post.id}`);
      return;
    }

    // AUDIO
    if (post.audio) {
      navigate(`/vibe-feed/${post.id}`);
      return;
    }

    // IMAGE
    if (post.images?.length > 0) {
      navigate(`/vibe-feed/${post.id}`);
      return;
    }

    navigate(`/vibe-feed/${post.id}`);
  };

  const handleSensitiveClick = (event, post) => {
    event.stopPropagation();

    navigate(`/vibe-feed/${post.id}`);
  };

  // Content badge
  const renderTypeIcon = (post) => {
    // Multiple media
    if (post.images?.length > 1 || post.videos?.length > 1) {
      return <ImageIcon className="w-4 h-4 text-white" />;
    }

    // Video
    if (post.media_type === "video" || post.videos?.length > 0) {
      return <Play className="w-4 h-4 text-white fill-white" />;
    }

    // Audio
    if (post.media_type === "audio" || post.audio) {
      return <Music2 className="w-4 h-4 text-white" />;
    }

    return null;
  };

  // Empty fallback
  if (!posts?.length) {
    return null;
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-1 sm:gap-2">
      {posts.map((post, index) => {
        const isSensitiveBlocked =
          post.is_sensitive === true && !canViewSensitive;

        // Thumbnail
        const image =
          post.images?.[0]?.image ||
          post.videos?.[0]?.thumbnail ||
          post.audio?.cover_image ||
          post.media_url ||
          "/placeholder-image.jpg";
        const videoUrl = post.videos?.[0]?.video;

        const isPlayableVideo = videoUrl && !videoUrl.includes(".m3u8");

        return (
          <motion.div
            key={post.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: index * 0.03 }}
            whileHover={{ scale: 0.98 }}
            className="
              relative
              aspect-square
              cursor-pointer
              overflow-hidden
              rounded-xl
              group
              bg-muted
            "
            onClick={() => handlePostClick(post)}
            onMouseEnter={() => handleMouseEnter(post.id)}
            onMouseLeave={() => handleMouseLeave(post.id)}
          >
            {/* Media */}
            {isPlayableVideo ? (
              <video
                ref={(el) => {
                  videoRefs.current[post.id] = el;
                }}
                src={videoUrl}
                muted
                loop
                playsInline
                preload="metadata"
                poster={image}
                className={`
  w-full
  h-full
  object-cover
  transition-transform
  duration-300
  group-hover:scale-105
  ${isSensitiveBlocked ? "blur-xl scale-110 brightness-75" : ""}
`}
              />
            ) : (
              <img
                src={image}
                alt={post.caption || "post"}
                className={`
  w-full
  h-full
  object-cover
  transition-transform
  duration-300
  group-hover:scale-105
  ${isSensitiveBlocked ? "blur-xl scale-110 brightness-75" : ""}
`}
                loading="lazy"
              />
            )}
            {/* Dark overlay */}

            {isSensitiveBlocked && (
              <SensitiveContentOverlay
                compact
                onClick={(event) => handleSensitiveClick(event, post)}
              />
            )}
            <div
              className="
                absolute
                inset-0
                bg-black/10
                group-hover:bg-black/40
                transition
              "
            />

            {/* Media type icon */}
            <div className="absolute top-2 right-2 z-10">
              <div
                className="
                  w-7
                  h-7
                  rounded-full
                  bg-black/50
                  backdrop-blur-sm
                  flex
                  items-center
                  justify-center
                "
              >
                {renderTypeIcon(post)}
              </div>
            </div>

            {/* Hover stats */}
            <div
              className="
                absolute
                inset-0
                opacity-0
                group-hover:opacity-100
                transition-opacity
                flex
                items-center
                justify-center
                gap-5
                text-white
                z-10
              "
            >
              <div className="flex items-center gap-1">
                <Heart className="w-5 h-5 fill-white" />
                <span className="text-sm font-semibold">
                  {formatNumber(post.likes_count)}
                </span>
              </div>

              <div className="flex items-center gap-1">
                <MessageCircle className="w-5 h-5 fill-white" />
                <span className="text-sm font-semibold">
                  {formatNumber(post.comments_count)}
                </span>
              </div>

              {post.views_count > 0 && (
                <div className="flex items-center gap-1">
                  <Eye className="w-5 h-5" />
                  <span className="text-sm font-semibold">
                    {formatNumber(post.views_count)}
                  </span>
                </div>
              )}
            </div>
          </motion.div>
        );
      })}
    </div>
  );
};

export default PostGrid;
