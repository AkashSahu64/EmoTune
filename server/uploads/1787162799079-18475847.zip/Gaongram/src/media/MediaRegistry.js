// media/MediaRegistry.js - FIXED
/**
 * Media Registry - Tracks all registered media elements
 */
import { mediaController } from './MediaController.js';
import { normalizeMediaId } from './MediaController.js';

class MediaRegistry {
  constructor() {
    this.registry = new Map();
  }

  // Register media element
  registerMedia(mediaId, element, type, options = {}) {
    const key = normalizeMediaId(mediaId);
    if (!key) return null;

    if (this.registry.has(key)) {
      this.unregisterMedia(mediaId);
    }

    const controls = mediaController.register(mediaId, element, type, options);
    this.registry.set(key, {
      element,
      type,
      controls,
      options,
      isVisible: false
    });

    return controls;
  }

  // Unregister media element
  unregisterMedia(mediaId) {
    const key = normalizeMediaId(mediaId);
    const media = this.registry.get(key);
    if (media) {
      mediaController.unregister(mediaId);
      this.registry.delete(key);
    }
  }

  // Update media visibility
  setMediaVisibility(mediaId, isVisible) {
    const media = this.registry.get(normalizeMediaId(mediaId));
    if (media) {
      media.isVisible = isVisible;
    }
  }

  // Get media by ID
  getMedia(mediaId) {
    return this.registry.get(normalizeMediaId(mediaId));
  }

  // Get all media
  getAllMedia() {
    return Array.from(this.registry.values());
  }

  // Get playing media
  getPlayingMedia() {
    return Array.from(this.registry.values()).find(
      media => media.controls.isPlaying()
    );
  }

  // Stop all media
  stopAll() {
    this.registry.forEach((media) => {
      media.controls.stop();
    });
  }

  // Pause all media
  pauseAll() {
    this.registry.forEach((media) => {
      media.controls.pause();
    });
  }

  // Cleanup registry
  cleanup() {
    this.registry.clear();
  }
}

// Create and export a singleton instance
export const mediaRegistry = new MediaRegistry();
