/* eslint-env node */
/* global console, process, URL, AbortController, setTimeout, clearTimeout, fetch */

const WHATSAPP_UA =
  "WhatsApp/2.24.0 Mozilla/5.0 (compatible; WhatsApp; +https://www.whatsapp.com/)";

const readMeta = (html, key) => {
  const patterns = [
    new RegExp(
      `<meta\\b[^>]*property=["']${key}["'][^>]*content=["']([^"']+)["'][^>]*>`,
      "i",
    ),
    new RegExp(
      `<meta\\b[^>]*content=["']([^"']+)["'][^>]*(?:property|name)=["']${key}["'][^>]*>`,
      "i",
    ),
  ];

  for (const pattern of patterns) {
    const match = html.match(pattern);
    if (match?.[1]) return match[1].replace(/&amp;/g, "&");
  }

  return "";
};

const fetchWithTimeout = async (url, options = {}) => {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12000);

  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
};

const requireMeta = (html, key) => {
  const value = readMeta(html, key);
  if (!value) throw new Error(`Missing ${key}`);
  return value;
};

const validateImage = async (pageUrl, imageUrl) => {
  const absoluteImageUrl = new URL(imageUrl, pageUrl).href;
  const response = await fetchWithTimeout(absoluteImageUrl, {
    redirect: "manual",
    headers: {
      Accept: "image/avif,image/webp,image/png,image/jpeg,image/*",
      "User-Agent": WHATSAPP_UA,
    },
  });

  if (response.status >= 300 && response.status < 400) {
    throw new Error(`Image redirects instead of returning 200: ${absoluteImageUrl}`);
  }
  if (response.status !== 200) {
    throw new Error(`Image returned HTTP ${response.status}: ${absoluteImageUrl}`);
  }

  const type = response.headers.get("content-type") || "";
  if (!type.startsWith("image/")) {
    throw new Error(`Image content-type is not image/*: ${type || "(empty)"}`);
  }
  if (/svg/i.test(type)) {
    throw new Error(`Image is SVG-only, which is unsafe for WhatsApp: ${absoluteImageUrl}`);
  }
};

const validatePage = async (pageUrl) => {
  const response = await fetchWithTimeout(pageUrl, {
    headers: {
      Accept: "text/html,*/*",
      "User-Agent": WHATSAPP_UA,
    },
  });

  if (response.status !== 200) {
    throw new Error(`Page returned HTTP ${response.status}: ${pageUrl}`);
  }

  const html = await response.text();
  const image = requireMeta(html, "og:image");
  const secureUrl = requireMeta(html, "og:image:secure_url");
  const type = requireMeta(html, "og:image:type");
  const width = requireMeta(html, "og:image:width");
  const height = requireMeta(html, "og:image:height");

  if (/svg/i.test(type)) throw new Error(`og:image:type must not be SVG: ${type}`);
  if (!Number(width) || !Number(height)) {
    throw new Error(`Invalid og:image dimensions: ${width}x${height}`);
  }

  await validateImage(pageUrl, image);
  await validateImage(pageUrl, secureUrl);

  console.log(`OK ${pageUrl}`);
  console.log(`  og:image ${new URL(image, pageUrl).href}`);
  console.log(`  og:image:type ${type}`);
  console.log(`  og:image:size ${width}x${height}`);
};

const urls = process.argv.slice(2);
if (!urls.length) {
  console.error(
    "Usage: npm run seo:validate-social -- https://gaongram.com/profile/akash_a90f",
  );
  process.exit(1);
}

for (const url of urls) {
  await validatePage(url);
}
