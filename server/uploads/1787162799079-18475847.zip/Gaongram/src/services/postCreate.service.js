// src/services/postCreate.service.js
import api from '../config/axios.js';

export const postCreateService = {
  /**
   * Create a new vibe post (unified endpoint for all post types)
   * @param {FormData} formData - Contains all fields: content, media, poll, etc.
   */
  createPost: async (formData) => {
  const response = await api.post('/vibe-posts/', formData);
  return response.data;
},

  /**
   * (Optional) Patch an existing post if needed (for updates)
   */
  patchPost: async (id, formData) => {
    const response = await api.patch(`/vibe-posts/${id}/`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return response.data;
  },
};