const REACT_SNAP_USER_AGENT = "ReactSnap";

export * from "../../seo/metadata/utils.mjs";
export { getCanonicalUrl, getContentUrl } from "../../seo/canonical/index.mjs";
export {
  getPostAuthor,
  getPostCaption,
  getPostImage,
  getPostMediaType,
  getPostVideoUrl,
  getProfileDisplayName,
  getProfileImage,
  getProfileUsername,
} from "../../seo/builders/index.mjs";

export const isBrowser = () => typeof window !== "undefined";

export const isReactSnapPrerender = () =>
  typeof navigator !== "undefined" &&
  navigator.userAgent === REACT_SNAP_USER_AGENT;

export const hasConfiguredApiBaseUrl = () =>
  Boolean(import.meta.env.VITE_API_BASE_URL);

export const shouldSkipLiveSeoFetch = ({ allowConfiguredApi = false } = {}) =>
  isReactSnapPrerender() &&
  !(allowConfiguredApi && hasConfiguredApiBaseUrl());
