import React, { useEffect, useState, useRef, useCallback, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { useAuthStore } from "../../store/authStore.js";
import { useUIStore } from "../../store/uiStore.js";
import { useMediaStore } from "../../store/mediaStore.js";
import { vibeService } from "../../services/vibe.service.js";
import { playlistService } from "../../services/playlist.service.js";
import { showError, showSuccess } from "../../utils/toast.js";
import { mediaController } from "../../media/MediaController.js";
import Seo from "../../components/seo/Seo.jsx";
import { buildAudioSeo, buildStaticPageSeo } from "../../seo/seoBuilders.js";
import { shouldSkipLiveSeoFetch } from "../../seo/seoUtils.js";
import Loader from "../../components/common/Loader.jsx";
import EmptyState from "../../components/common/EmptyState.jsx";
import { Music } from "lucide-react";
import AudioFeed from "./AudioFeed.jsx";
import { t } from "i18next";


const AudioPage = () => {
  const { user, isAuthenticated } = useAuthStore();
  const { openModal } = useUIStore();
  const { setUserInteracted, userInteracted, markManualControl, canAutoplayPost } = useMediaStore();

  const [searchParams] = useSearchParams();
  const playlistId = searchParams.get("playlist");
  const singleAudioId = searchParams.get("single");
  const startPostId = searchParams.get("start");
  const fromProfile = searchParams.get("fromProfile");
  const skipLiveFetch = shouldSkipLiveSeoFetch({
    allowConfiguredApi: Boolean(startPostId || singleAudioId || playlistId || fromProfile),
  });

  // Page‑based pagination states
  const [audioPosts, setAudioPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);

  // Other existing states
  const [playbackRates, setPlaybackRates] = useState({});
  const [isInPlaylist, setIsInPlaylist] = useState({});
  const [audioErrors, setAudioErrors] = useState({});
  const [playingStates, setPlayingStates] = useState({});
  const [sleepTimer, setSleepTimer] = useState(null);
  const [remainingTime, setRemainingTime] = useState(0);

  const lastAudioCardRef = useRef(null);
  const scrollContainerRef = useRef(null);
  const initialAutoplayDoneRef = useRef(false);
  const feedKey = playlistId
    ? `audio-scroll-playlist-${playlistId}`
    : fromProfile
    ? `audio-scroll-profile-${fromProfile}`
    : "audio-scroll-feed";

  const targetAudioForSeo = useMemo(() => {
    if (!audioPosts.length) return null;
    const targetId = startPostId || singleAudioId;
    if (targetId) {
      return audioPosts.find((post) => String(post.id) === String(targetId));
    }
    return audioPosts[0];
  }, [audioPosts, singleAudioId, startPostId]);

  const audioSeo = useMemo(() => {
    if (targetAudioForSeo) {
      return buildAudioSeo(targetAudioForSeo, {
        path: startPostId
          ? `/audio?start=${startPostId}`
          : singleAudioId
          ? `/audio?single=${singleAudioId}`
          : "/audio",
      });
    }

    return buildStaticPageSeo("audio", {
      path: startPostId
        ? `/audio?start=${startPostId}`
        : singleAudioId
        ? `/audio?single=${singleAudioId}`
        : "/audio",
    });
  }, [singleAudioId, startPostId, targetAudioForSeo]);


  // Fetch functions remain the same, but without any view/save logic
  const fetchAudio = async (pageNum, append = false) => {
    try {
      let rawData = [];
      if (fromProfile) {
        const res = await vibeService.getVibePosts({ author: fromProfile, audio: true, page: pageNum });
        rawData = res.data || [];
      } else if (singleAudioId) {
        const res = await vibeService.getVibePosts({ audio: true, audio_id: Number(singleAudioId), page: pageNum });
        rawData = res.data || [];
      } else if (playlistId) {
        const res = await playlistService.getPlaylistDetail(playlistId);
        const items = res.data?.items || [];
        rawData = items.map((item) => ({
          id: item.audio?.feed_post || item.audio?.id,
          audio: item.audio,
          user: item.user || {
            id: item.audio?.author,
            username: item.audio?.user_name || "",
            avatar: item.audio?.profile_image,
          },
          author: item.author || item.audio?.author,
          is_liked: false,
          views_count: item.audio?.views_count || 0,
          likes_count: item.audio?.total_likes || 0,
          comments_count: item.audio?.comments_count || 0,
          times_ago: "",
          created_at: item.created_at,
        }));
        setHasMore(false);
      } else {
        const res = await vibeService.getVibePosts({ audio: true, page: pageNum });
        rawData = res.data || [];
      }

      if (!playlistId && rawData.length === 0) {
        setHasMore(false);
        return;
      }

      const newPosts = rawData;
      setAudioPosts(prev => {
        const combined = append ? [...prev, ...newPosts] : newPosts;
        return combined.filter((post, idx, self) => idx === self.findIndex(p => String(p.id) === String(post.id)));
      });
    } catch (err) {
      console.error("Failed to fetch audio:", err);
      showError(err.message || t("failed_to_load_audio"));
    }
  };

  const fetchAudioById = async (id) => {
    try {
      const res = await vibeService.getVibePost(id);
      const post = res?.data;
      if (!post?.id) {
        showError(t("audio_not_found"));
        return;
      }
      setAudioPosts([post]);
      setHasMore(false);
    } catch (err) {
      showError(t("failed_to_load_audio"));
    }
  };

  useEffect(() => {
    const init = async () => {
      if (skipLiveFetch) {
        setLoading(false);
        setAudioPosts([]);
        setHasMore(false);
        return;
      }

      setLoading(true);
      setPage(1);
      setAudioPosts([]);
      setHasMore(true);
      initialAutoplayDoneRef.current = false;
      if (startPostId) {
        await fetchAudioById(startPostId);
      } else {
        await fetchAudio(1, false);
      }
      setLoading(false);
    };
    init();
  }, [fromProfile, singleAudioId, playlistId, skipLiveFetch]);

  const loadMore = useCallback(async () => {
    if (startPostId) return;
    if (loadingMore || !hasMore) return;
    setLoadingMore(true);
    const nextPage = page + 1;
    await fetchAudio(nextPage, true);
    setPage(nextPage);
    setLoadingMore(false);
  }, [loadingMore, hasMore, page, startPostId]);

  useEffect(() => {
    if (startPostId) return;
    if (!hasMore || loading || loadingMore) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) loadMore(); },
      { threshold: 0.1, rootMargin: "100px" }
    );
    const el = lastAudioCardRef.current;
    if (el) observer.observe(el);
    return () => observer.disconnect();
  }, [hasMore, loading, loadingMore, loadMore, startPostId]);

  useEffect(() => {
    const onPlay = ({ mediaId }) => {
      setPlayingStates((prev) => {
        const next = {};
        Object.keys(prev).forEach((id) => {
          next[id] = false;
        });
        next[mediaId] = true;
        return next;
      });
    };
    const onPause = ({ mediaId }) => {
      setPlayingStates((prev) => ({ ...prev, [mediaId]: false }));
    };
    mediaController.on("mediaPlay", onPlay);
    mediaController.on("mediaPause", onPause);
    mediaController.on("stop", onPause);
    return () => {
      mediaController.off("mediaPlay", onPlay);
      mediaController.off("mediaPause", onPause);
      mediaController.off("stop", onPause);
    };
  }, []);

  useEffect(() => {
    const scroller = scrollContainerRef.current;
    if (!scroller || startPostId || singleAudioId || playlistId) return undefined;
    const saved = Number(sessionStorage.getItem(feedKey) || 0);
    if (saved > 0) {
      requestAnimationFrame(() => {
        scroller.scrollTop = saved;
      });
    }
    const saveScroll = () => {
      sessionStorage.setItem(feedKey, String(scroller.scrollTop));
    };
    scroller.addEventListener("scroll", saveScroll, { passive: true });
    return () => {
      saveScroll();
      scroller.removeEventListener("scroll", saveScroll);
    };
  }, [feedKey, startPostId, singleAudioId, playlistId, audioPosts.length]);

  // Sleep timer logic (unchanged)
  useEffect(() => {
    if (!sleepTimer) return;
    const interval = setInterval(() => {
      const timeLeft = Math.max(0, sleepTimer.endTime - Date.now());
      setRemainingTime(timeLeft);
      if (timeLeft <= 0) {
        clearInterval(interval);
        if (mediaController.activeMedia) {
          mediaController.stop(mediaController.activeMedia);
        }
        setSleepTimer(null);
        setRemainingTime(0);
        showSuccess(t("stop_sleep_timer"));
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [sleepTimer]);

  // Handle user interaction for audio (unmute)
  useEffect(() => {
    if (skipLiveFetch) return;
    const handleUserInteraction = () => {
      if (!userInteracted) {
        setUserInteracted();
      }
    };
    window.addEventListener("click", handleUserInteraction, { once: true });
    window.addEventListener("touchstart", handleUserInteraction, {
      once: true,
    });
    return () => {
      window.removeEventListener("click", handleUserInteraction);
      window.removeEventListener("touchstart", handleUserInteraction);
    };
  }, [skipLiveFetch, userInteracted, setUserInteracted]);

  // Autoplay & scroll to startPostId (if provided)
  useEffect(() => {
  if (!audioPosts.length || initialAutoplayDoneRef.current) return;

  const idToPlay = startPostId || (mediaController.activeMedia ? null : audioPosts[0]?.id);
  if (!idToPlay || !userInteracted || !canAutoplayPost(idToPlay)) return;
  initialAutoplayDoneRef.current = true;

  const el = document.querySelector(`[data-audio-id="${idToPlay}"]`);

  if (el) {
    el.scrollIntoView({ behavior: "auto", block: "center" });
  }

  setTimeout(() => {
    mediaController.play(idToPlay, {
      autoplay: true,
      manual: false,
      muted: !userInteracted,
    }).catch(() => {});
  }, 300);
}, [audioPosts, startPostId, userInteracted, canAutoplayPost]);

  // Auto‑next when audio ends
  const handleAudioEnded = useCallback(
    (audioId) => {
      if (!audioPosts.length) return;
      const currentIndex = audioPosts.findIndex(p => String(p.id) === String(audioId));
      if (currentIndex === -1 || currentIndex >= audioPosts.length - 1) return;
      const nextId = audioPosts[currentIndex + 1].id;
      setTimeout(() => {
        const nextEl = document.querySelector(`[data-audio-id="${nextId}"]`);
        if (nextEl) nextEl.scrollIntoView({ behavior: "smooth", block: "center" });
        mediaController.play(nextId, {
          autoplay: true,
          manual: false,
          muted: !userInteracted,
        }).catch(() => {});
      }, 50);
    },
    [audioPosts, userInteracted]
  );

  // Handlers (unchanged from original)
  const handleAudioError = useCallback((audioId) => {
    console.warn(`Audio ${audioId} failed to load`);
    setAudioErrors((prev) => ({ ...prev, [audioId]: true }));
    mediaController.pause(audioId);
    setPlayingStates((prev) => ({ ...prev, [audioId]: false }));
  }, []);

  const handleSetSleepTimer = useCallback((durationMs) => {
    const endTime = Date.now() + durationMs;
    setSleepTimer({ endTime, duration: durationMs });
    showSuccess(t("start_sleep_timer"));
  }, []);

  const handleCancelSleepTimer = useCallback(() => {
    setSleepTimer(null);
    setRemainingTime(0);
    showSuccess("Sleep timer cancelled");
  }, []);

  const handlePreviousCard = useCallback(
    (audioId) => {
      if (!audioPosts.length) return;
      const currentIndex = audioPosts.findIndex((post) => String(post.id) === String(audioId));
      if (currentIndex > 0) {
        const prevPost = audioPosts[currentIndex - 1];
        mediaController.pause(audioId);
        markManualControl(prevPost.id);
        setTimeout(() => {
          const prevElement = document.querySelector(
            `[data-audio-id="${prevPost.id}"]`,
          );
          if (prevElement) {
            prevElement.scrollIntoView({ behavior: "smooth", block: "center" });
          }
          mediaController.play(prevPost.id, { manual: true }).catch(() => {});
        }, 50);
      }
    },
    [audioPosts, markManualControl],
  );

  const handleNextCard = useCallback(
    (audioId) => {
      if (!audioPosts.length) return;
      const currentIndex = audioPosts.findIndex((p) => String(p.id) === String(audioId));
      if (currentIndex !== -1 && currentIndex < audioPosts.length - 1) {
        const nextPost = audioPosts[currentIndex + 1];
        mediaController.pause(audioId);
        markManualControl(nextPost.id);
        setTimeout(() => {
          const nextElement = document.querySelector(
            `[data-audio-id="${nextPost.id}"]`,
          );
          if (nextElement) {
            nextElement.scrollIntoView({ behavior: "smooth", block: "center" });
          }
          mediaController.play(nextPost.id, { manual: true }).catch(() => {});
        }, 50);
      }
    },
    [audioPosts, markManualControl],
  );

  const handleSpeedChange = useCallback(
    (audioId) => {
      const rates = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];
      const currentRate = playbackRates[audioId] || 1;
      const currentIndex = rates.indexOf(currentRate);
      const nextRate = rates[(currentIndex + 1) % rates.length];
      setPlaybackRates((prev) => ({ ...prev, [audioId]: nextRate }));
    },
    [playbackRates],
  );

  const handlePlaylistToggle = useCallback(
    async (audioId) => {
      if (!isAuthenticated) {
        openModal("login");
        return;
      }
      try {
        if (isInPlaylist[audioId]) {
          await vibeService.unsaveVibePost(audioId);
          setIsInPlaylist((prev) => ({ ...prev, [audioId]: false }));
          showSuccess("Removed from playlist");
        } else {
          await vibeService.saveVibePost(audioId);
          setIsInPlaylist((prev) => ({ ...prev, [audioId]: true }));
          showSuccess("Added to playlist");
        }
        // Optionally refresh feed – but we'll rely on optimistic update
      } catch (error) {
        console.error("Playlist error:", error);
        showError("Failed to update playlist");
      }
    },
    [isAuthenticated, isInPlaylist, openModal],
  );

  const handleShare = useCallback((audioId, title) => {
    const shareUrl = `${window.location.origin}/audio?start=${audioId}`;
    const post = audioPosts.find(p => p.id === audioId);
    openModal("share", {
      audioId,
      title: title || post?.audio?.title,
      cover: post?.audio?.cover_image,
      artist: post?.user?.username,
      url: shareUrl,
    });
  }, [audioPosts, openModal]);

 const handleLike = useCallback(
    async (audioId, isLiked) => {
      if (!isAuthenticated) { openModal("login"); return; }
      const delta = isLiked ? -1 : 1;
      setAudioPosts(prev =>
        prev.map(p =>
          String(p.id) === String(audioId)
            ? {
                ...p,
                is_liked: !isLiked,
                likes_count: Math.max(0, (p.likes_count || 0) + delta),
                audio: p.audio
                  ? {
                      ...p.audio,
                      is_liked: !isLiked,
                      total_likes: Math.max(0, (p.audio.total_likes ?? p.likes_count ?? 0) + delta),
                    }
                  : p.audio,
              }
            : p
        )
      );
      try {
        if (isLiked) await vibeService.unlikePost(audioId);
        else await vibeService.likePost(audioId);
      } catch (error) {
        setAudioPosts(prev =>
          prev.map(p =>
            String(p.id) === String(audioId)
              ? {
                  ...p,
                  is_liked: isLiked,
                  likes_count: Math.max(0, (p.likes_count || 0) - delta),
                  audio: p.audio
                    ? {
                        ...p.audio,
                        is_liked: isLiked,
                        total_likes: Math.max(0, (p.audio.total_likes ?? p.likes_count ?? 0) - delta),
                      }
                    : p.audio,
                }
              : p
          )
        );
        showError("Failed to update like");
      }
    },
    [isAuthenticated, openModal]
  );


  const handleAudioTap = useCallback(
    (audioId) => {
      if (!userInteracted) setUserInteracted();
      markManualControl(audioId);
      const instance = mediaController.getMediaInstance(audioId);
      const isPlaying = instance?.playing && !instance?.element?.paused;
      if (isPlaying) {
        mediaController.pause(audioId);
        setPlayingStates(prev => ({ ...prev, [audioId]: false }));
      } else {
        mediaController.play(audioId, { manual: true }).then(() => setPlayingStates(prev => ({ ...prev, [audioId]: true })))
          .catch(() => setPlayingStates(prev => ({ ...prev, [audioId]: false })));
      }
    },
    [userInteracted, setUserInteracted, markManualControl]
  );

  // Loading states
  if (loading && audioPosts.length === 0) {
    return (
      <>
        <Seo {...audioSeo} />
        <div className="h-screen bg-background dark:bg-black flex items-center justify-center">
          <Loader />
        </div>
      </>
    );
  }

  if (!loading && audioPosts.length === 0 && !hasMore) {
    return (
      <>
        <Seo {...audioSeo} />
        <div className="h-screen bg-background dark:bg-black flex items-center justify-center">
          <EmptyState
            icon={Music}
            title={t("no_audio")}
            description={t("be_first_audio")}
            darkMode
          />
        </div>
      </>
    );
  }

  return (
    <>
      <Seo {...audioSeo} />
      <AudioFeed
        audioPosts={audioPosts}
        playingStates={playingStates}
        playbackRates={playbackRates}
        audioErrors={audioErrors}
        user={user}
        hasMore={hasMore}
        loadingMore={loadingMore}
        lastAudioCardRef={lastAudioCardRef}
        scrollContainerRef={scrollContainerRef}
        onAudioEnded={handleAudioEnded}
        onAudioError={handleAudioError}
        onPreviousCard={handlePreviousCard}
        onNextCard={handleNextCard}
        onSpeedChange={handleSpeedChange}
        onShare={handleShare}
        onLike={handleLike}
        onAudioTap={handleAudioTap}
        onComments={(postId) => openModal("comments", { postId })}
        onOptions={(postId, isOwner) => openModal("post-options", { postId, isOwner })}
        sleepTimer={sleepTimer}
        remainingTime={remainingTime}
        onSetSleepTimer={handleSetSleepTimer}
        onCancelSleepTimer={handleCancelSleepTimer}
        isPlaylistMode={!!playlistId && !singleAudioId}
      />
    </>
  );
};

export default AudioPage;
