import { create } from "zustand";

const normalizeUserId = (userId) => {
  if (userId === undefined || userId === null || userId === "") {
    return null;
  }

  return String(userId);
};

const updateUserSet = (source, userId, shouldAdd) => {
  const normalizedUserId = normalizeUserId(userId);

  if (!normalizedUserId) {
    return source;
  }

  const nextSet = new Set(source);

  if (shouldAdd) {
    nextSet.add(normalizedUserId);
  } else {
    nextSet.delete(normalizedUserId);
  }

  return nextSet;
};

export const useBlockStore = create((set) => ({
  blockedUsers: new Set(),
  blockedByUsers: new Set(),

  setBlocked: (userId) =>
    set((state) => ({
      blockedUsers: updateUserSet(state.blockedUsers, userId, true),
    })),

  setUnblocked: (userId) =>
    set((state) => ({
      blockedUsers: updateUserSet(state.blockedUsers, userId, false),
    })),

  setBlockedBy: (userId) =>
    set((state) => ({
      blockedByUsers: updateUserSet(state.blockedByUsers, userId, true),
    })),

  removeBlockedBy: (userId) =>
    set((state) => ({
      blockedByUsers: updateUserSet(state.blockedByUsers, userId, false),
    })),

  hydrateFromProfile: (profile) =>
    set((state) => {
      const userId = normalizeUserId(profile?.user_id ?? profile?.id);

      if (!profile || !userId) {
        return state;
      }

      return {
        blockedUsers: updateUserSet(
          state.blockedUsers,
          userId,
          Boolean(profile.is_blocked),
        ),
        blockedByUsers: updateUserSet(
          state.blockedByUsers,
          userId,
          Boolean(profile.blocked_by),
        ),
      };
    }),
}));
