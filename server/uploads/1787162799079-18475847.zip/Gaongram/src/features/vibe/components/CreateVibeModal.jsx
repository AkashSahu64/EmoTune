// CreateVibeModal.jsx
import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import {
  X,
  Music,
  Video,
  BarChart3,
  Image,
  Smile,
  MapPin,
  Users,
  Globe,
  Loader2,
  Plus,
  Trash2,
} from 'lucide-react';
import { useAuthStore } from '../../../store/authStore.js';
import { useUIStore } from '../../../store/uiStore.js';
import { vibeAPI } from '../api.js';
import { showSuccess, showError } from '../../../utils/toast.js';
import Avatar from '../../../components/common/Avatar.jsx';
import Button from '../../../components/common/Button.jsx';
import { FEED_EVENTS, publishFeedEvent } from '../../../utils/feedEvents.js';

const CreateVibeModal = () => {
  const { user } = useAuthStore();
  const { closeModal } = useUIStore();
  
  const [step, setStep] = useState(1);
  const [vibeType, setVibeType] = useState('music');
  const [caption, setCaption] = useState('');
  const [media, setMedia] = useState(null);
  const [pollOptions, setPollOptions] = useState(['', '']);
  const [pollDuration, setPollDuration] = useState(24);
  const [location, setLocation] = useState('');
  const [tags, setTags] = useState([]);
  const [privacy, setPrivacy] = useState('public');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const fileInputRef = useRef(null);

  const vibeTypes = [
    { id: 'music', label: 'Music', icon: Music, color: 'text-green-500' },
    { id: 'video', label: 'Video', icon: Video, color: 'text-red-500' },
    { id: 'poll', label: 'Poll', icon: BarChart3, color: 'text-purple-500' },
  ];

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (vibeType === 'music' && !file.type.startsWith('audio/')) {
      showError('Please select an audio file');
      return;
    }

    if (vibeType === 'video' && !file.type.startsWith('video/')) {
      showError('Please select a video file');
      return;
    }

    if (file.size > 50 * 1024 * 1024) { // 50MB
      showError('File size must be less than 50MB');
      return;
    }

    setMedia(file);
  };

  const addPollOption = () => {
    if (pollOptions.length < 6) {
      setPollOptions([...pollOptions, '']);
    }
  };

  const removePollOption = (index) => {
    if (pollOptions.length > 2) {
      setPollOptions(pollOptions.filter((_, i) => i !== index));
    }
  };

  const updatePollOption = (index, value) => {
    const newOptions = [...pollOptions];
    newOptions[index] = value;
    setPollOptions(newOptions);
  };

  const handleSubmit = async () => {
    // Validation
    if (!caption.trim()) {
      showError('Please add a caption');
      return;
    }

    if (vibeType !== 'poll' && !media) {
      showError('Please select a file');
      return;
    }

    if (vibeType === 'poll') {
      const validOptions = pollOptions.filter(opt => opt.trim());
      if (validOptions.length < 2) {
        showError('Please add at least 2 poll options');
        return;
      }
    }

    setIsSubmitting(true);

    try {
    const formData = new FormData();
    formData.append('caption', caption);
    formData.append('type', vibeType);
    formData.append('privacy', privacy);
    
    if (location) formData.append('location', location);
    if (tags.length > 0) formData.append('tags', JSON.stringify(tags));
    
    if (vibeType === 'poll') {
      formData.append('poll_options', JSON.stringify(pollOptions.filter(opt => opt.trim())));
      formData.append('poll_duration', pollDuration);
    } else if (media) {
      formData.append('media', media);
    }

    // Use the create API
    const response = await vibeAPI.createVibePost(formData);
    
    // If we have additional updates, use the patch API
    if (response.data?.id) {
      // Example: Update with additional metadata using patch
      await vibeService.patchVibePost(response.data.id, {
        // Additional metadata if needed
      });
    }
    
    showSuccess('Vibe post created successfully!');
    closeModal();
    publishFeedEvent({ type: FEED_EVENTS.CREATED });
  } catch (error) {
    showError('Failed to create vibe post');
  } finally {
    setIsSubmitting(false);
  }
};

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="text-center py-8">
            <h3 className="text-xl font-bold text-foreground dark:text-foreground-dark mb-6">Create Vibe</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {vibeTypes.map((type) => (
                <button
                  key={type.id}
                  onClick={() => {
                    setVibeType(type.id);
                    setStep(2);
                  }}
                  className="p-6 border-2 border-border dark:border-border-dark rounded-xl hover:border-primary hover:bg-muted dark:hover:bg-muted-dark transition-colors"
                >
                  <type.icon className={`w-12 h-12 ${type.color} mx-auto mb-3`} />
                  <span className="font-semibold text-foreground dark:text-foreground-dark">{type.label}</span>
                </button>
              ))}
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            {/* Vibe Type Header */}
            <div className="flex items-center justify-center space-x-3 mb-6">
              {vibeTypes.find(t => t.id === vibeType).icon({
                className: `w-8 h-8 ${vibeTypes.find(t => t.id === vibeType).color}`
              })}
              <h3 className="text-xl font-bold text-foreground dark:text-foreground-dark">
                Create {vibeTypes.find(t => t.id === vibeType).label} Vibe
              </h3>
            </div>

            {/* Media Upload (for music/video) */}
            {(vibeType === 'music' || vibeType === 'video') && (
              <div className="border-2 border-dashed border-border dark:border-border-dark rounded-xl p-8 text-center bg-background dark:bg-background-dark">
                {media ? (
                  <div className="space-y-4">
                    <div className="flex items-center justify-center space-x-3">
                      {vibeType === 'music' ? (
                        <Music className="w-12 h-12 text-green-500" />
                      ) : (
                        <Video className="w-12 h-12 text-red-500" />
                      )}
                      <div className="text-left">
                        <p className="font-medium text-foreground dark:text-foreground-dark truncate">{media.name}</p>
                        <p className="text-sm text-mutedForeground dark:text-mutedForeground-dark">
                          {(media.size / (1024 * 1024)).toFixed(2)} MB
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => setMedia(null)}
                      className="text-red-600 hover:text-red-700 text-sm"
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <>
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileUpload}
                      accept={vibeType === 'music' ? 'audio/*' : 'video/*'}
                      className="hidden"
                    />
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full py-12 border-2 border-dashed border-border dark:border-border-dark rounded-lg hover:border-primary transition-colors bg-background dark:bg-background-dark"
                    >
                      <div className="mx-auto w-16 h-16 bg-muted dark:bg-muted-dark rounded-full flex items-center justify-center mb-4">
                        {vibeType === 'music' ? (
                          <Music className="w-8 h-8 text-mutedForeground dark:text-mutedForeground-dark" />
                        ) : (
                          <Video className="w-8 h-8 text-mutedForeground dark:text-mutedForeground-dark" />
                        )}
                      </div>
                      <p className="font-medium text-foreground dark:text-foreground-dark">
                        Select {vibeType === 'music' ? 'audio' : 'video'} file
                      </p>
                      <p className="text-sm text-mutedForeground dark:text-mutedForeground-dark mt-1">
                        MP3, WAV, AAC (Max 50MB)
                      </p>
                    </button>
                  </>
                )}
              </div>
            )}

            {/* Poll Creation */}
            {vibeType === 'poll' && (
              <div className="space-y-4">
                <h4 className="font-semibold text-foreground dark:text-foreground-dark">Poll Options</h4>
                
                {pollOptions.map((option, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={option}
                      onChange={(e) => updatePollOption(index, e.target.value)}
                      placeholder={`Option ${index + 1}`}
                      className="flex-1 px-4 py-2 border border-border dark:border-border-dark rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent bg-background dark:bg-background-dark text-foreground dark:text-foreground-dark"
                    />
                    {pollOptions.length > 2 && (
                      <button
                        onClick={() => removePollOption(index)}
                        className="p-2 text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
                
                {pollOptions.length < 6 && (
                  <button
                    onClick={addPollOption}
                    className="flex items-center space-x-2 text-primary hover:text-primary-light"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add option</span>
                  </button>
                )}

                {/* Poll Duration */}
                <div className="pt-4 border-t border-border dark:border-border-dark">
                  <label className="block font-medium text-foreground dark:text-foreground-dark mb-2">
                    Poll Duration
                  </label>
                  <select
                    value={pollDuration}
                    onChange={(e) => setPollDuration(parseInt(e.target.value))}
                    className="w-full px-4 py-2 border border-border dark:border-border-dark rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent bg-background dark:bg-background-dark text-foreground dark:text-foreground-dark"
                  >
                    <option value={1}>1 hour</option>
                    <option value={6}>6 hours</option>
                    <option value={24}>24 hours</option>
                    <option value={48}>2 days</option>
                    <option value={168}>1 week</option>
                  </select>
                </div>
              </div>
            )}

            {/* Caption */}
            <div>
              <label className="block font-medium text-foreground dark:text-foreground-dark mb-2">
                Caption
              </label>
              <textarea
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                placeholder="What's this vibe about?"
                className="w-full px-4 py-3 border border-border dark:border-border-dark rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent resize-none bg-background dark:bg-background-dark text-foreground dark:text-foreground-dark"
                rows={3}
              />
            </div>

            {/* Location */}
            <div>
              <label className="block font-medium text-foreground dark:text-foreground-dark mb-2">
                Location (optional)
              </label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Add location"
                className="w-full px-4 py-2 border border-border dark:border-border-dark rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent bg-background dark:bg-background-dark text-foreground dark:text-foreground-dark"
              />
            </div>

            {/* Privacy */}
            <div>
              <label className="block font-medium text-foreground dark:text-foreground-dark mb-2">
                Privacy
              </label>
              <select
                value={privacy}
                onChange={(e) => setPrivacy(e.target.value)}
                className="w-full px-4 py-2 border border-border dark:border-border-dark rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent bg-background dark:bg-background-dark text-foreground dark:text-foreground-dark"
              >
                <option value="public">🌍 Public</option>
                <option value="friends">👥 Friends</option>
                <option value="private">🔒 Private</option>
              </select>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-3 pt-4">
              <Button
                variant="outline"
                fullWidth
                onClick={() => setStep(1)}
              >
                Back
              </Button>
              <Button
                variant="primary"
                fullWidth
                onClick={handleSubmit}
                loading={isSubmitting}
                disabled={
                  !caption.trim() ||
                  (vibeType !== 'poll' && !media) ||
                  (vibeType === 'poll' && pollOptions.filter(opt => opt.trim()).length < 2)
                }
              >
                Create Vibe
              </Button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="max-h-[90vh] overflow-y-auto bg-card dark:bg-card-dark">
      {/* Header */}
      <div className="sticky top-0 bg-card dark:bg-card-dark border-b border-border dark:border-border-dark z-10 p-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-foreground dark:text-foreground-dark">
            {step === 1 ? 'Create Vibe' : 'Add Details'}
          </h2>
          <button
            onClick={closeModal}
            className="p-2 text-mutedForeground dark:text-mutedForeground-dark hover:text-foreground dark:hover:text-foreground-dark rounded-full hover:bg-muted dark:hover:bg-muted-dark"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* User Info */}
      <div className="p-6 border-b border-border dark:border-border-dark">
        <div className="flex items-center space-x-3">
          <Avatar src={user?.avatar} alt={user?.username} size="medium" />
          <div>
            <p className="font-semibold text-foreground dark:text-foreground-dark">{user?.username}</p>
            <select
              value={privacy}
              onChange={(e) => setPrivacy(e.target.value)}
              className="text-sm text-mutedForeground dark:text-mutedForeground-dark bg-transparent border-none focus:ring-0"
            >
              <option value="public">🌍 Public</option>
              <option value="friends">👥 Friends</option>
              <option value="private">🔒 Private</option>
            </select>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {renderStep()}
      </div>
    </div>
  );
};

export default CreateVibeModal;
