import React from 'react';
import { motion } from 'framer-motion';
import { Image, FileText, Users, Camera } from 'lucide-react';
import { useTranslation } from "react-i18next";

const EmptyState = ({
  icon = 'image',
  title,
  description,
  action,
  className = '',
}) => {
  const { t } = useTranslation();

  const icons = {
    image: <Image size={48} className="text-gray-400" />,
    document: <FileText size={48} className="text-gray-400" />,
    users: <Users size={48} className="text-gray-400" />,
    camera: <Camera size={48} className="text-gray-400" />,
  };

  // ✅ Resolve translated fallback
  const resolvedTitle = title || t("empty_default_title");
  const resolvedDescription =
    description || t("empty_default_description");

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`flex flex-col items-center justify-center py-12 px-4 text-center ${className}`}
    >
      <div className="mb-4 p-4 bg-gray-100 rounded-full">
        {icons[icon] || icons.image}
      </div>
      
      <h3 className="text-lg font-semibold text-gray-900 mb-2">
        {resolvedTitle}
      </h3>
      
      <p className="text-gray-500 max-w-md mb-6">
        {resolvedDescription}
      </p>
      
      {action && (
        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
          {action}
        </motion.div>
      )}
    </motion.div>
  );
};

export default EmptyState;