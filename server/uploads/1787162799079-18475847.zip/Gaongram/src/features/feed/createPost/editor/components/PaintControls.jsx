import {
  Brush,
  Minus,
  Square,
  Circle,
  MoveRight,
  Hexagon,
  Triangle,
  Eraser,
  Droplets,
  Grid2X2,
  Undo2,
  Redo2,
  Paintbrush,
  Droplet,
  Sparkles,
  Slash,
  PenTool,


} from "lucide-react";


import ToolButton from "./ToolButton";

const PaintControls = ({
  paintTool,
  setPaintTool,

  brushColor,
  setBrushColor,

  brushSize,
  setBrushSize,
  opacity,
  setOpacity,

  undoPaint,
  redoPaint,
  
}) => {

  return (

    <div className="space-y-2">

      <div className="grid grid-cols-4 gap-2">

        <ToolButton
          active={paintTool === "draw"}
          onClick={() =>
            setPaintTool("draw")
          }
          icon={Brush}
          label="Draw"
        />
       

        <ToolButton
          active={paintTool === "soft"}
          onClick={() =>
            setPaintTool("soft")
          }
          icon={PenTool}
          label="Soft"
        />
        <ToolButton
          active={paintTool === "dashed"}
          onClick={() =>
            setPaintTool("dashed")
          }
          icon={Slash}
          label="Dash"
        />

        <ToolButton
          active={paintTool === "watercolor"}
          onClick={() =>
            setPaintTool("watercolor")
          }
          icon={Droplet}
          label="Water"
        />

        <ToolButton
          active={paintTool === "neon"}
          onClick={() =>
            setPaintTool("neon")
          }
          icon={Sparkles}
          label="Neon"
        />

        <ToolButton
          active={paintTool === "line"}
          onClick={() =>
            setPaintTool("line")
          }
          icon={Minus}
          label="Line"
        />

        <ToolButton
          active={paintTool === "arrow"}
          onClick={() =>
            setPaintTool("arrow")
          }
          icon={MoveRight}
          label="Arrow"
        />

        <ToolButton
          active={paintTool === "rect"}
          onClick={() =>
            setPaintTool("rect")
          }
          icon={Square}
          label="Rect"
        />

        <ToolButton
          active={paintTool === "circle"}
          onClick={() =>
            setPaintTool("circle")
          }
          icon={Circle}
          label="Circle"
        />

        <ToolButton
          active={paintTool === "triangle"}
          onClick={() =>
            setPaintTool("triangle")
          }
          icon={Triangle}
          label="Triangle"
        />

        <ToolButton
          active={paintTool === "hexagon"}
          onClick={() =>
            setPaintTool("hexagon")
          }
          icon={Hexagon}
          label="Hex"
        />

        <ToolButton
          active={paintTool === "eraser"}
          onClick={() =>
            setPaintTool("eraser")
          }
          icon={Eraser}
          label="Erase"
        />

        <ToolButton
          active={paintTool === "blur"}
          onClick={() =>
            setPaintTool("blur")
          }
          icon={Droplets}
          label="Blur"
        />

        <ToolButton
          active={paintTool === "pixel"}
          onClick={() =>
            setPaintTool("pixel")
          }
          icon={Grid2X2}
          label="Pixel"
        />

      </div>

      {/* COLOR */}

      <input
        type="color"
        value={brushColor}
        onChange={(e) =>
          setBrushColor(e.target.value)
        }
        className="
          w-full
          h-10
          rounded-xl
        "
      />

      {/* SIZE */}

      <div className="space-y-1">

        <div className="flex items-center justify-between">

          <span className="text-[11px]">
            Brush Size
          </span>

          <span className="text-[11px]">
            {brushSize}px
          </span>

        </div>
        {/* OPACITY */}


        <input
          type="range"
          min={1}
          max={80}
          value={brushSize}
          onChange={(e) =>
            setBrushSize(
              Number(e.target.value)
            )
          }
          className="w-full"
        />

      </div>
      <div className="space-y-1">

      <div className="flex items-center justify-between">

        <span className="text-[11px]">
          Opacity
        </span>

        <span className="text-[11px]">
          {Math.round(opacity * 100)}%
        </span>

      </div>

      <input
        type="range"
        min={0.1}
        max={1}
        step={0.1}
        value={opacity}
        onChange={(e) =>
          setOpacity(
            Number(e.target.value)
          )
        }
        className="w-full"
      />

    </div>


      {/* ACTIONS */}

      <div className="grid grid-cols-2 gap-2">

        <button
          onClick={undoPaint}
          className="
            h-9
            rounded-xl
            bg-gray-100
            flex
            items-center
            justify-center
            gap-1
            text-[11px]
          "
        >

          <Undo2 className="w-3 h-3" />

          Undo

        </button>

        <button
          onClick={redoPaint}
          className="
            h-9
            rounded-xl
            bg-gray-100
            flex
            items-center
            justify-center
            gap-1
            text-[11px]
          "
        >

          <Redo2 className="w-3 h-3" />

          Redo

        </button>

      </div>

    </div>

  );

};

export default PaintControls;