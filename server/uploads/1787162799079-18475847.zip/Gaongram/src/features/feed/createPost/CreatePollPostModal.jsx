// src/features/feed/createPost/CreatePollPostModal.jsx
import React, { useState } from "react";
import { X } from "lucide-react";
import { useAuthStore } from "../../../store/authStore.js";
import { useUIStore } from "../../../store/uiStore.js";
import { postCreateService } from "../../../services/postCreate.service.js";
import { showSuccess, showError } from "../../../utils/toast.js";
import Avatar from "../../../components/common/Avatar.jsx";
import Button from "../../../components/common/Button.jsx";
import PollBuilder from "./PollBuilder.jsx";
import PostCaptionEditor from "./PostCaptionEditor.jsx";
import { FEED_EVENTS, publishFeedEvent } from "../../../utils/feedEvents.js";

const CreatePollPostModal = () => {
  const { user } = useAuthStore();
  const { closeModal } = useUIStore();

  const [caption, setCaption] = useState("");
  const [pollQuestion, setPollQuestion] = useState("");
  const [pollOptions, setPollOptions] = useState(["", ""]);
  const [pollDuration, setPollDuration] = useState(24);
  const [privacy, setPrivacy] = useState("public");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!pollQuestion.trim()) {
      showError("Please enter a poll question");
      return;
    }

    const validOptions = pollOptions.filter((opt) => opt.trim());
    if (validOptions.length < 2) {
      showError("Please add at least two poll options");
      return;
    }

    setIsSubmitting(true);

    const formData = new FormData();
    formData.append("content", caption);
    formData.append("poll_question", pollQuestion);
    formData.append("author", user?.id);
    formData.append("poll_options", JSON.stringify(validOptions));
    formData.append("poll_duration", pollDuration);
    formData.append("privacy", privacy);
    formData.append("show_profile", "false");

    try {
      await postCreateService.createPost(formData);
      showSuccess("Poll post created!");
      closeModal();
      publishFeedEvent({ type: FEED_EVENTS.CREATED });
    } catch {
      showError("Failed to create post");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="w-full max-w-lg bg-card dark:bg-card-dark rounded-2xl overflow-hidden">

      {/* 🔥 HEADER (Unified Composer Header) */}
      <div className="sticky top-0 z-20 border-b border-border dark:border-border-dark px-4 py-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold">Create Poll</h2>

          <button
            onClick={closeModal}
            className="p-2 rounded-full hover:bg-mutedForeground/20 dark:hover:bg-mutedForeground-dark/30 transition"
          >
            <X className="w-4 h-4 text-foreground dark:text-foreground-dark" />
          </button>
        </div>
      </div>

      {/* 🔥 BODY SCROLL AREA */}
      <div className="max-h-[75vh] overflow-y-auto px-4 py-4 space-y-4 hide-scrollbar">

        {/* USER ROW */}
        {/* <div className="flex items-center gap-3">
          <Avatar src={user?.avatar} alt={user?.username} size="medium" />

          <div>
            <p className="text-sm font-semibold">{user?.username}</p>

            <select
              value={privacy}
              onChange={(e) => setPrivacy(e.target.value)}
              className="text-xs text-gray-500 bg-transparent outline-none"
            >
              <option value="public">🌍 Public</option>
              <option value="friends">👥 Friends</option>
              <option value="private">🔒 Private</option>
            </select>
          </div>
        </div> */}

        {/* CAPTION */}
        <div>
          <PostCaptionEditor caption={caption} setCaption={setCaption} />
        </div>

        {/* POLL QUESTION */}
        <input
          type="text"
          value={pollQuestion}
          onChange={(e) => setPollQuestion(e.target.value)}
          placeholder="Ask a question..."
          className="w-full px-4 py-2 border border-border dark:border-border-dark bg-muted dark:bg-muted-dark rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/80"
        />

        {/* POLL BUILDER */}
        <div className="bg-muted dark:bg-muted-dark rounded-xl p-3">
          <PollBuilder
            options={pollOptions}
            setOptions={setPollOptions}
            duration={pollDuration}
            setDuration={setPollDuration}
          />
        </div>

        {/* SUBMIT */}
        <Button
          variant="primary"
          fullWidth
          onClick={handleSubmit}
          loading={isSubmitting}
          disabled={
            !pollQuestion.trim() ||
            pollOptions.filter((opt) => opt.trim()).length < 2
          }
        >
          Post Poll
        </Button>
      </div>
    </div>
  );
};

export default CreatePollPostModal;
