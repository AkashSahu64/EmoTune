export const fitObjectToCanvas = (object, canvas, mode = "contain") => {
  if (!object || !canvas) return;
  const canvasWidth = canvas.getWidth();
  const canvasHeight = canvas.getHeight();
  const objectWidth = object.width || canvasWidth;
  const objectHeight = object.height || canvasHeight;
  const scale =
    mode === "cover"
      ? Math.max(canvasWidth / objectWidth, canvasHeight / objectHeight)
      : Math.min(canvasWidth / objectWidth, canvasHeight / objectHeight);

  object.set({
    left: canvasWidth / 2,
    top: canvasHeight / 2,
    originX: "center",
    originY: "center",
    scaleX: scale,
    scaleY: scale,
  });
  object.setCoords();
};

export const flushCanvas = (canvas) => {
  if (!canvas) return;
  canvas.getObjects().forEach((object) => {
    object.dirty = true;
  });
  canvas.requestRenderAll();
};
