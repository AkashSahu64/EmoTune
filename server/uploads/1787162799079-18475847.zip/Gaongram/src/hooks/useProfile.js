import { useEffect, useMemo } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { profileAPI } from "../features/profile/profileApi";
import { profileKeys } from "../features/profile/profileKeys";
import { useAuth } from "./useAuth";
import { useFollowStore } from "../store/useFollowStore";
import { shouldSkipLiveSeoFetch } from "../seo/seoUtils";

const isNumericIdentifier = (identifier) =>
  /^\d+$/.test(String(identifier || ""));

const mergeProfileData = (currentProfile, updates) => {
  if (!currentProfile) {
    return updates;
  }

  const mergedProfile = {
    ...currentProfile,
    ...updates,
  };

  if (!mergedProfile.full_name) {
    mergedProfile.full_name = [
      mergedProfile.first_name,
      mergedProfile.last_name,
    ]
      .filter(Boolean)
      .join(" ")
      .trim();
  }

  return mergedProfile;
};

const getProfileCacheKeys = (identifier, profile) => {
  const queryKeys = [profileKeys.byIdentifier(identifier)];
  const ids = [profile?.id, profile?.user_id].filter(Boolean);
  const seen = new Set();

  for (const id of ids) {
    const cacheKey = JSON.stringify(profileKeys.byId(id));

    if (!seen.has(cacheKey)) {
      seen.add(cacheKey);
      queryKeys.push(profileKeys.byId(id));
    }
  }

  return queryKeys;
};

const syncProfileCaches = (queryClient, identifier, profile) => {
  if (!profile) return;

  for (const queryKey of getProfileCacheKeys(identifier, profile)) {
    queryClient.setQueryData(queryKey, profile);
  }
};

const normalizeProfile = (profile) => {
  if (!profile) return null;

  const stats = profile.stats || profile.counts || profile.metrics || {};

  return {
    id: profile.id,
    userId: profile.user_id,
    username: profile.username,
    fullName:
      profile.full_name ||
      [profile.first_name, profile.last_name].filter(Boolean).join(" ").trim(),
    firstName: profile.first_name,
    lastName: profile.last_name,
    email: profile.email,
    phone: profile.phone,
    profileImage: profile.photo || profile.profile_image || "",
    coverImage: profile.background_image || "",
    bio: profile.bio || "",
    externalLink: profile.external_link || "",
    location: [profile.city, profile.state, profile.country]
      .filter(Boolean)
      .join(", "),
    address: profile.address,
    pinCode: profile.pin_code,
    isPrivate: Boolean(profile.is_private),
    isVerified: Boolean(profile.is_verified),
    isBusiness: Boolean(profile.is_business_profile),
    isOnline: Boolean(profile.is_online),
    lastOnline: profile.last_online,
    stats: {
      posts: Number(
        profile.posts_count ??
          profile.post_count ??
          profile.postsCount ??
          stats.posts ??
          stats.posts_count ??
          0,
      ),
      followers: Number(
        profile.followers_count ??
          profile.follower_count ??
          profile.followersCount ??
          stats.followers ??
          stats.followers_count ??
          0,
      ),
      following: Number(
        profile.following_count ??
          profile.followingCount ??
          stats.following ??
          stats.following_count ??
          0,
      ),
    },
    isFollowing: Boolean(profile.is_following),
    isFollowingRequested: Boolean(profile.is_following_requested),
    isFollowedBy: Boolean(profile.is_followed_by),
  };
};

export const useProfile = (identifier) => {
  const { user: currentUser } = useAuth();
  const queryClient = useQueryClient();
  const syncFromProfile = useFollowStore((state) => state.syncFromProfile);

  const {
    data: profile,
    isLoading,
    isFetching,
    isError,
    error,
    refetch,
    dataUpdatedAt,
  } = useQuery({
    queryKey: profileKeys.byIdentifier(identifier),
    queryFn: () =>
      isNumericIdentifier(identifier)
        ? profileAPI.getProfileById(identifier)
        : profileAPI.getProfileByUsername(identifier),
    enabled:
      Boolean(identifier) &&
      !shouldSkipLiveSeoFetch({ allowConfiguredApi: true }),
    staleTime: 5 * 60 * 1000,
  });

  useEffect(() => {
    if (!profile) return;

    syncFromProfile(profile);
    syncProfileCaches(queryClient, identifier, profile);
  }, [identifier, profile, queryClient, syncFromProfile]);

  const updateProfileMutation = useMutation({
    mutationFn: async ({ data }) => {
      if (!profile?.user_id) throw new Error("Profile user_id not found");
      return profileAPI.updateProfile(profile.user_id, data);
    },
    onMutate: async ({ data }) => {
      if (!profile) return undefined;

      const cacheKeys = getProfileCacheKeys(identifier, profile);

      await Promise.all(
        cacheKeys.map((queryKey) =>
          queryClient.cancelQueries({ queryKey }),
        ),
      );

      const previousSnapshots = cacheKeys.map((queryKey) => [
        queryKey,
        queryClient.getQueryData(queryKey),
      ]);

      if (!(data instanceof FormData)) {
        const optimisticProfile = mergeProfileData(profile, data);
        syncProfileCaches(queryClient, identifier, optimisticProfile);
      }

      return { previousSnapshots };
    },
    onSuccess: (serverData) => {
      const mergedProfile = mergeProfileData(profile, serverData);

      syncProfileCaches(queryClient, identifier, mergedProfile);
      syncFromProfile(mergedProfile);
      queryClient.invalidateQueries({
        queryKey: profileKeys.byIdentifier(identifier),
      });

      if (profile?.id) {
        queryClient.invalidateQueries({
          queryKey: profileKeys.byId(profile.id),
        });
      }

      if (profile?.user_id) {
        queryClient.invalidateQueries({
          queryKey: profileKeys.byId(profile.user_id),
        });
        queryClient.invalidateQueries({
          queryKey: profileKeys.followers(profile.user_id),
        });
        queryClient.invalidateQueries({
          queryKey: profileKeys.following(profile.user_id),
        });
      }
    },
    onError: (_error, _variables, context) => {
      for (const [queryKey, snapshot] of context?.previousSnapshots || []) {
        if (snapshot) {
          queryClient.setQueryData(queryKey, snapshot);
        }
      }
    },
  });

  const normalizedProfile = useMemo(() => normalizeProfile(profile), [profile]);
  const isOwnProfile = currentUser?.user_id === profile?.user_id;

  return {
    profile,
    normalizedProfile,
    isLoading,
    isFetching,
    isError,
    error,
    refetch,
    updateProfile: updateProfileMutation.mutateAsync,
    isUpdating: updateProfileMutation.isPending,
    isOwnProfile,
    profileUpdatedAt: dataUpdatedAt,
  };
};
