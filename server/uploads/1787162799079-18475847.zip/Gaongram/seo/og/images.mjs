/* global URL */
import { SEO_CONFIG, getSiteUrl } from "../metadata/config.mjs";
import { cleanText, escapeHtml, formatCount, toAbsoluteUrl } from "../metadata/utils.mjs";

export const ogImageUrl = (entity, identifier, version = "") => {
  const url = new URL(
    `/api/og/${encodeURIComponent(entity)}/${encodeURIComponent(
      String(identifier || "preview"),
    )}`,
    getSiteUrl(),
  );
  if (version) url.searchParams.set("v", String(version));
  return url.href;
};

const svgText = (value, x, y, size, weight = 500, fill = "#0f172a") =>
  `<text x="${x}" y="${y}" font-family="Inter, Arial, sans-serif" font-size="${size}" font-weight="${weight}" fill="${fill}">${escapeHtml(
    value,
  )}</text>`;

export const renderOgSvg = ({
  entity = "GaonGram",
  title = SEO_CONFIG.siteName,
  subtitle = "",
  description = "",
  image = SEO_CONFIG.defaultImage,
  stats = [],
} = {}) => {
  const safeTitle = cleanText(title).slice(0, 72);
  const safeSubtitle = cleanText(subtitle).slice(0, 96);
  const safeDescription = cleanText(description).slice(0, 120);
  const rawImage = String(image || "").trim();
  const absoluteImage = rawImage.startsWith("data:image/")
    ? rawImage
    : toAbsoluteUrl(image, SEO_CONFIG.defaultImage);
  const statsLine = stats.filter(Boolean).join("   ");

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630" role="img" aria-label="${escapeHtml(
    safeTitle,
  )}">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#f8fafc"/>
      <stop offset="0.52" stop-color="#ecfdf5"/>
      <stop offset="1" stop-color="#fff7ed"/>
    </linearGradient>
    <clipPath id="avatarClip"><circle cx="184" cy="226" r="112"/></clipPath>
  </defs>
  <rect width="1200" height="630" fill="url(#bg)"/>
  <rect x="72" y="72" width="1056" height="486" rx="36" fill="#ffffff" opacity="0.94"/>
  <rect x="72" y="72" width="1056" height="486" rx="36" fill="none" stroke="#d1fae5" stroke-width="2"/>
  <circle cx="184" cy="226" r="122" fill="#16a34a" opacity="0.15"/>
  <image href="${escapeHtml(absoluteImage)}" x="72" y="114" width="224" height="224" preserveAspectRatio="xMidYMid slice" clip-path="url(#avatarClip)"/>
  <circle cx="184" cy="226" r="112" fill="none" stroke="#15803d" stroke-width="6"/>
  ${svgText(SEO_CONFIG.siteName, 88, 520, 34, 800, "#15803d")}
  ${svgText(entity.toUpperCase(), 332, 170, 24, 800, "#166534")}
  ${svgText(safeTitle, 332, 238, 52, 800, "#111827")}
  ${safeSubtitle ? svgText(safeSubtitle, 336, 296, 28, 600, "#475569") : ""}
  ${statsLine ? svgText(statsLine, 336, 365, 34, 700, "#0f172a") : ""}
  ${safeDescription ? svgText(safeDescription, 336, 430, 28, 500, "#334155") : ""}
  <rect x="912" y="466" width="176" height="54" rx="27" fill="#16a34a"/>
  ${svgText("gaongram.com", 936, 501, 22, 800, "#ffffff")}
</svg>`;
};

export const buildProfileOgImagePayload = (profile) => {
  const username = profile.username || profile.user_name || "";
  const fullName = profile.fullName || profile.full_name || username || "GaonGram user";
  return {
    entity: "Profile",
    title: `${fullName}${username ? ` (@${username})` : ""}`,
    subtitle: profile.bio || "",
    image: profile.profileImage || profile.profile_image || profile.photo,
    stats: [
      `${formatCount(profile.followers ?? profile.followers_count)} Followers`,
      `${formatCount(profile.following ?? profile.following_count)} Following`,
      `${formatCount(profile.posts ?? profile.posts_count)} Posts`,
    ],
  };
};
