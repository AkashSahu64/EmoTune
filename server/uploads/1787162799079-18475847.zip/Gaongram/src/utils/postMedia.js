const getExtensionFromUrl = (url = "") => {
  try {
    const pathname = new URL(url, window.location.origin).pathname;
    const extension = pathname.split(".").pop();
    return extension && extension.length <= 5 ? extension : "";
  } catch {
    return "";
  }
};

const getExtensionFromType = (type = "") => {
  if (!type.includes("/")) return "";
  return type.split("/").pop().replace("jpeg", "jpg");
};

export const getPostMediaDownloads = (post, postId) => {
  if (!post) return [];

  const baseName = `gaongram-post-${postId || post.id || "media"}`;
  const assets = [];

  if (Array.isArray(post.images)) {
    post.images.forEach((image, index) => {
      const url = image?.image || image?.url;
      if (url) {
        assets.push({
          url,
          filename: `${baseName}-image-${index + 1}.${getExtensionFromUrl(url) || "jpg"}`,
        });
      }
    });
  }

  if (Array.isArray(post.videos)) {
    post.videos.forEach((video, index) => {
      const url = video?.video || video?.url;
      if (url) {
        assets.push({
          url,
          filename: `${baseName}-video-${index + 1}.${getExtensionFromUrl(url) || "mp4"}`,
        });
      }
    });
  }

  const audioUrl = post.audio?.audio;
  if (audioUrl) {
    assets.push({
      url: audioUrl,
      filename: `${baseName}-audio.${getExtensionFromUrl(audioUrl) || "mp3"}`,
    });
  }

  return assets;
};

export const downloadUrl = async ({ url, filename, signal }) => {
  if (!url) {
    throw new Error("No media URL available");
  }

  try {
    const response = await fetch(url, {
      credentials: "include",
      mode: "cors",
      signal,
    });

    if (!response.ok) {
      throw new Error(`Download failed with ${response.status}`);
    }

    const blob = await response.blob();
    const objectUrl = URL.createObjectURL(blob);
    const extension = getExtensionFromType(blob.type) || getExtensionFromUrl(url);

    triggerAnchorDownload(
      objectUrl,
      filename || `gaongram-media${extension ? `.${extension}` : ""}`,
    );

    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
    return;
  } catch (error) {
    if (error.name === "AbortError") {
      throw error;
    }

    triggerAnchorDownload(url, filename || "gaongram-media");
  }
};

const triggerAnchorDownload = (href, filename) => {
  const anchor = document.createElement("a");
  anchor.href = href;
  anchor.download = filename;
  anchor.rel = "noopener noreferrer";
  anchor.target = "_blank";
  anchor.style.display = "none";
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
};
