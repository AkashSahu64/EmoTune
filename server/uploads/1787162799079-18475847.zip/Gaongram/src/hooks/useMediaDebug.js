import { useEffect } from 'react';
import { useMediaStore } from '../store/mediaStore.js';

export const useMediaDebug = () => {
  const { getActiveState } = useMediaStore();
  
  useEffect(() => {
    const logState = () => {
      const state = getActiveState();
      console.log('Media Store State:', state);
    };
    
    // Log on state changes
    const handleActiveChange = () => logState();
    const handleMuteToggle = () => logState();
    
    window.addEventListener('media:activePostChanged', handleActiveChange);
    window.addEventListener('media:muteToggled', handleMuteToggle);
    
    return () => {
      window.removeEventListener('media:activePostChanged', handleActiveChange);
      window.removeEventListener('media:muteToggled', handleMuteToggle);
    };
  }, [getActiveState]);
};