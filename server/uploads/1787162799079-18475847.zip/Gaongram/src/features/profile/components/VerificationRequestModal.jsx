import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X,
  Upload,
  FileText,
  Image as ImageIcon,
  Trash2,
  AlertCircle,
} from "lucide-react";
import { useTranslation } from "react-i18next";
import { profileAPI } from "../profileApi";
import { showToast } from "../../../utils/toast";
import Button from "../../../components/common/Button";

const ACCEPTED_FILE_TYPES = [
  "image/jpeg",
  "image/png",
  "image/gif",
  "image/webp",
  "application/pdf",
];
const MAX_FILES = 5;
const MAX_FILE_SIZE_MB = 10; // adjust as needed

const VerificationRequestModal = ({ isOpen, onClose, onSuccess }) => {
  const { t } = useTranslation();
  const [reason, setReason] = useState("");
  const [files, setFiles] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState({});
  const fileInputRef = useRef(null);
  const [link, setLink] = useState("");

  // Reset state when modal opens/closes
  useEffect(() => {
    return () => {
      files.forEach((file) => {
        if (file.preview) {
          URL.revokeObjectURL(file.preview);
        }
      });
    };
  }, [files]);

  useEffect(() => {
    if (!isOpen) {
      setReason("");
      setLink("");
      setFiles([]);
      setErrors({});
    }
  }, [isOpen]);

  const validate = () => {
    const newErrors = {};
    if (!reason.trim()) newErrors.reason = t("reason_required");
    else if (reason.trim().length < 20)
      newErrors.reason = t("reason_min_length", { min: 20 });
    if (files.length === 0) newErrors.files = t("at_least_one_document");
    if (link && !/^https?:\/\/.+/i.test(link)) {
      newErrors.link = t("invalid_url");
    }
    if (files.length > MAX_FILES)
      newErrors.files = t("max_files_exceeded", { max: MAX_FILES });
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleFileChange = (e) => {
    const selected = Array.from(e.target.files);
    const validFiles = [];
    const errorsList = [];

    for (const file of selected) {
      if (!ACCEPTED_FILE_TYPES.includes(file.type)) {
        errorsList.push(`${file.name}: ${t("invalid_file_type")}`);
        continue;
      }
      if (file.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
        errorsList.push(
          `${file.name}: ${t("file_too_large", { size: MAX_FILE_SIZE_MB })}`,
        );
        continue;
      }
      if (files.length + validFiles.length >= MAX_FILES) {
        errorsList.push(t("max_files_exceeded", { max: MAX_FILES }));
        break;
      }
      // Create preview URL for images only
      const preview = file.type.startsWith("image/")
        ? URL.createObjectURL(file)
        : null;
      validFiles.push({ file, preview, id: Date.now() + Math.random() });
    }

    if (errorsList.length) {
      showToast(errorsList.join(", "), "error");
    }
    setFiles((prev) => [...prev, ...validFiles]);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const removeFile = (id) => {
    setFiles((prev) => {
      const removed = prev.find((f) => f.id === id);
      if (removed?.preview) URL.revokeObjectURL(removed.preview);
      return prev.filter((f) => f.id !== id);
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    const formData = new FormData();
    formData.append("reason", reason.trim());
    if (link.trim()) {
      formData.append("link", link.trim());
    }
    files.forEach(({ file }) => {
      formData.append("documents", file);
    });

    try {
      const response = await profileAPI.submitVerificationRequest(formData);
      if (response.success) {
        showToast(t("verification_submitted_success"), "success");
        onSuccess?.(); // refresh status in parent
        onClose();
      } else {
        throw new Error(response.message || t("submission_failed"));
      }
    } catch (error) {
      const message =
        error.response?.data?.message ||
        error.message ||
        t("submission_failed");
      showToast(message, "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-6">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm"
          onClick={onClose}
        />

        {/* Modal */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative bg-white dark:bg-card-dark rounded-xl shadow-xl w-full max-w-md overflow-hidden"
        >
          {/* Header */}
          <div className="px-5 py-2 border-b border-border dark:border-border-dark bg-card dark:bg-card-dark">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-foreground dark:text-foreground-dark">
                {t("verification_request")}
              </h3>
              <button
                onClick={onClose}
                className="p-1.5 text-gray-400 hover:text-foreground dark:hover:text-foreground-dark hover:bg-gray-100 dark:hover:bg-muted-dark rounded-lg transition-colors"
              >
                <X size={20} />
              </button>
            </div>
            <p className="text-xs text-mutedForeground dark:text-mutedForeground-dark">
              {t("verification_modal_subtitle")}
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit}>
            <div className="max-h-[60vh] md:max-h-[70vh] overflow-y-auto p-6 space-y-5 hide-scrollbar">
              {/* Reason textarea */}
              <div>
                <label className="block text-sm font-medium text-foreground dark:text-foreground-dark mb-1">
                  {t("reason_for_verification")}{" "}
                  <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  rows={4}
                  className={`w-full px-3 py-2 bg-white dark:bg-muted-dark border ${errors.reason ? "border-red-500" : "border-border dark:border-border-dark"} rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 transition-colors`}
                  placeholder={t("verification_reason_placeholder")}
                />
                {errors.reason && (
                  <p className="text-red-500 text-xs mt-1">{errors.reason}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground dark:text-foreground-dark mb-1">
                  {t("reference_link")}
                  <span className="text-xs text-mutedForeground ml-1">
                    ({t("optional")})
                  </span>
                </label>

                <input
                  type="url"
                  value={link}
                  onChange={(e) => setLink(e.target.value)}
                  placeholder="https://gaongram.com/username"
                  className={`w-full px-3 py-2 bg-white dark:bg-muted-dark border ${
                    errors.link
                      ? "border-red-500"
                      : "border-border dark:border-border-dark"
                  } rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 transition-colors`}
                />

                {errors.link && (
                  <p className="text-red-500 text-xs mt-1">{errors.link}</p>
                )}
              </div>

              {/* File upload area */}
              <div>
                <label className="block text-sm font-medium text-foreground dark:text-foreground-dark mb-1">
                  {t("supporting_documents")}{" "}
                  <span className="text-red-500">*</span>
                </label>
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-border dark:border-border-dark rounded-lg p-6 text-center cursor-pointer hover:border-primary transition-colors bg-gray-50 dark:bg-muted-dark/30"
                >
                  <Upload className="w-8 h-8 mx-auto text-mutedForeground dark:text-mutedForeground-dark mb-2" />
                  <p className="text-sm text-foreground dark:text-foreground-dark">
                    {t("drag_drop_upload")}
                  </p>
                  <p className="text-xs text-mutedForeground dark:text-mutedForeground-dark mt-1">
                    {t("accepted_formats")}: JPEG, PNG, GIF, WebP, PDF (max{" "}
                    {MAX_FILE_SIZE_MB}MB)
                  </p>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="mt-3"
                  >
                    {t("select_files")}
                  </Button>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  accept={ACCEPTED_FILE_TYPES.join(",")}
                  onChange={handleFileChange}
                  className="hidden"
                />
                {errors.files && (
                  <p className="text-red-500 text-xs mt-1">{errors.files}</p>
                )}
              </div>

              {/* File previews */}
              {files.length > 0 && (
                <div className="space-y-2">
                  <p className="text-xs font-medium text-foreground dark:text-foreground-dark">
                    {t("selected_files")} ({files.length}/{MAX_FILES})
                  </p>
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {files.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between bg-gray-100 dark:bg-muted-dark p-2 rounded-lg"
                      >
                        <div className="flex items-center gap-2">
                          {item.preview ? (
                            <img
                              src={item.preview}
                              alt="preview"
                              className="w-8 h-8 object-cover rounded"
                            />
                          ) : (
                            <FileText className="w-6 h-6 text-mutedForeground" />
                          )}
                          <span className="text-sm truncate max-w-[180px]">
                            {item.file.name}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeFile(item.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
            {/* Footer */}
            <div className="sticky bottom-0 bg-white dark:bg-card-dark border-t border-border dark:border-border-dark px-6 py-3">
              <div className="flex justify-end gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClose}
                  className="border-gray-300 dark:border-border-dark text-foreground dark:text-foreground-dark hover:bg-gray-50 dark:hover:bg-muted-dark rounded-lg px-4"
                >
                  {t("cancel")}
                </Button>

                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-primary hover:bg-primary-light rounded-lg px-4 shadow-md text-white"
                >
                  {isSubmitting ? t("submitting") : t("submit_request")}
                </Button>
              </div>
            </div>
          </form>
        </motion.div>
      </div>
    </div>
  );
};

export default VerificationRequestModal;
