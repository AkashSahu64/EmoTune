// components/FollowingModal.jsx - PREMIUM REDESIGN
import React from 'react';
import FollowersModal from './FollowersModal';

const FollowingModal = (props) => {
  return <FollowersModal {...props} type="following" />;
};

export default FollowingModal;