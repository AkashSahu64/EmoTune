import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

const AppSidebar = ({ isOpen, onClose }) => {
  const { pathname } = useLocation();

  const links = [
    { name: "About", path: "/about" },
    { name: "Blog", path: "/blogs" },
    { name: "Careers", external: "https://careers.gaongram.in" },
    { name: "Help Center", path: "/help-center" },
    { name: "Safety", path: "/safety" },
    { name: "Community Guidelines", path: "/community-guidelines" },
    { name: "Privacy", path: "/privacy" },
    { name: "Terms", path: "/terms" },
    { name: "Language", path: "/language" },
    { name: "Contact", path: "/locations" },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* 🔥 Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.4 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black z-40"
          />

          {/* 🔥 Sidebar */}
          <motion.div
            initial={{ x: -300 }}
            animate={{ x: 0 }}
            exit={{ x: -300 }}
            transition={{ type: "spring", stiffness: 260, damping: 25 }}
            className="fixed top-0 left-0 h-full w-72 bg-white dark:bg-background-dark z-50 shadow-xl p-5 flex flex-col"
          >
            {/* Header */}
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-semibold">Menu</h2>
              <button onClick={onClose}>
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Links */}
            <div className="flex flex-col gap-3 text-lg font-semibold text-foreground dark:text-foreground-dark">
              {links.map((link) => {
                if (link.external) {
                  return (
                    <a
                      key={link.name}
                      href={link.external}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-primary transition"
                    >
                      {link.name}
                    </a>
                  );
                }

                const isActive = pathname === link.path;

                return (
                  <Link
                    key={link.name}
                    to={link.path}
                    onClick={onClose}
                    className={`transition ${
                      isActive
                        ? "text-primary font-medium"
                        : "hover:text-primary"
                    }`}
                  >
                    {link.name}
                  </Link>
                );
              })}
            </div>

            {/* Footer (reuse style) */}
            <div className="mt-auto pt-6 text-xs text-mutedForeground">
              © {new Date().getFullYear()} GaonGram
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default AppSidebar;