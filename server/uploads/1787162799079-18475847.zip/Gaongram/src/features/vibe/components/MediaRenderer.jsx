import React from "react";
import ImageMedia from "./media/ImageMedia";
import VideoMedia from "./media/VideoMedia";
import AudioMedia from "./media/AudioMedia";
import PollMedia from "./media/PollMedia";
import TextMedia from "./media/TextMedia";

const MediaRenderer = (props) => {
  const { isImage, isVideo, isAudio, isPoll, post } = props;

  // 🔥 POLL FIRST
  if (isPoll) {
    return <PollMedia {...props} />;
  }

  if (isVideo) {
    return <VideoMedia {...props} videoSources={props.videoSources} />;
  }

  if (isAudio) {
    return <AudioMedia {...props} />;
  }

  if (isImage) {
    return <ImageMedia {...props} />;
  }

  // Default text
  return <TextMedia {...props} post={post} />;
};

export default MediaRenderer;