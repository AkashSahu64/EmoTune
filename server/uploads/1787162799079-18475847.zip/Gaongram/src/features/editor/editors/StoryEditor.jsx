import React from "react";
import UnifiedCanvasEditor from "./UnifiedCanvasEditor.jsx";
import storyEditorConfig from "../configurations/story.config.js";

const StoryEditor = (props) => {
  const config = props.file?.type?.startsWith("video/")
    ? { ...storyEditorConfig, title: "Create video story" }
    : storyEditorConfig;

  return <UnifiedCanvasEditor {...props} mode="story" config={config} />;
};

export default StoryEditor;
