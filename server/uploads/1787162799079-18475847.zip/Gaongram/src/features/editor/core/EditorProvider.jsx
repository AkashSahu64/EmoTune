import React, { useMemo, useState } from "react";
import { EditorContext } from "./EditorContext.jsx";
import { getEditorConfig } from "./editorConfig.js";

const createInitialState = (config) => ({
  activeTool: config.defaultTool || "text",
  isReady: false,
  isBusy: false,
  error: "",
  progress: 0,
  progressMessage: "",
  previewUrl: null,
});

export const EditorProvider = ({ config: configProp, children }) => {
  const config = useMemo(() => getEditorConfig(configProp), [configProp]);
  const [state, setState] = useState(() => createInitialState(config));

  const value = useMemo(
    () => ({
      config,
      state,
      setState,
      setActiveTool: (activeTool) => setState((prev) => ({ ...prev, activeTool })),
      setReady: (isReady) => setState((prev) => ({ ...prev, isReady })),
      setBusy: (isBusy) => setState((prev) => ({ ...prev, isBusy })),
      setError: (error) => setState((prev) => ({ ...prev, error })),
      setProgress: (progress, progressMessage = "") =>
        setState((prev) => ({ ...prev, progress, progressMessage })),
      setPreviewUrl: (previewUrl) => setState((prev) => ({ ...prev, previewUrl })),
      resetUiState: () => setState(createInitialState(config)),
    }),
    [config, state],
  );

  return <EditorContext.Provider value={value}>{children}</EditorContext.Provider>;
};

export default EditorProvider;
