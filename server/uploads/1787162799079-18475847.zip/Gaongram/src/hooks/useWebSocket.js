import { useEffect, useRef, useCallback } from 'react';
import { useAuth } from './useAuth';

export const useWebSocket = () => {
  const { user, token } = useAuth();
  const socketRef = useRef(null);
  const eventHandlersRef = useRef(new Map());

  const connect = useCallback(() => {
    if (!user || !token || socketRef.current?.readyState === WebSocket.OPEN) {
      return;
    }

    const wsUrl = process.env.REACT_APP_WS_URL || `ws://localhost:3000/ws`;
    const socket = new WebSocket(`${wsUrl}?token=${token}`);
    
    socket.onopen = () => {
      console.log('WebSocket connected');
      // Send authentication
      socket.send(JSON.stringify({
        type: 'AUTH',
        userId: user.id
      }));
    };

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        const handlers = eventHandlersRef.current.get(data.type) || [];
        handlers.forEach(handler => handler(data.payload));
      } catch (error) {
        console.error('Failed to parse WebSocket message:', error);
      }
    };

    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    socket.onclose = () => {
      console.log('WebSocket disconnected');
      // Attempt to reconnect after delay
      setTimeout(() => {
        if (user && token) {
          connect();
        }
      }, 3000);
    };

    socketRef.current = socket;
  }, [user, token]);

  const disconnect = useCallback(() => {
    if (socketRef.current) {
      socketRef.current.close();
      socketRef.current = null;
    }
  }, []);

  const subscribe = useCallback((eventType, handler) => {
    if (!eventHandlersRef.current.has(eventType)) {
      eventHandlersRef.current.set(eventType, []);
    }
    eventHandlersRef.current.get(eventType).push(handler);
  }, []);

  const unsubscribe = useCallback((eventType, handler) => {
    if (eventHandlersRef.current.has(eventType)) {
      const handlers = eventHandlersRef.current.get(eventType);
      const index = handlers.indexOf(handler);
      if (index > -1) {
        handlers.splice(index, 1);
      }
    }
  }, []);

  const send = useCallback((type, payload) => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({ type, payload }));
    }
  }, []);

  // Connect on mount and when user changes
  useEffect(() => {
    if (user && token) {
      connect();
    }
    
    return () => {
      disconnect();
    };
  }, [user, token, connect, disconnect]);

  return {
    subscribe,
    unsubscribe,
    send,
    isConnected: socketRef.current?.readyState === WebSocket.OPEN
  };
};