import React, { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { useNavigate, useLocation } from "react-router-dom";
import { LockKeyhole } from "lucide-react";
import { useAuthStore } from "../../../store/authStore.js";
import { showError, showSuccess } from "../../../utils/toast.js";
import Button from "../../../components/common/Button.jsx";
import Seo from "../../../components/seo/Seo.jsx";
import { buildStaticPageSeo } from "../../../seo/seoBuilders.js";

const VerifyOtp = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { verifyOtp, loading } = useAuthStore();

  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [timer, setTimer] = useState(60);
  const [isTimerActive, setIsTimerActive] = useState(true);
  const [email, setEmail] = useState("");
  const otpRefs = useRef([]);

  useEffect(() => {
    const locationEmail = location.state?.email;
    const storedEmail = localStorage.getItem("pending_email");

    if (locationEmail) {
      setEmail(locationEmail);
      localStorage.setItem("pending_email", locationEmail);
    } else if (storedEmail) {
      setEmail(storedEmail);
    } else {
      navigate("/register");
    }
  }, [location, navigate]);

  useEffect(() => {
    let interval;
    if (isTimerActive && timer > 0) {
      interval = setInterval(() => {
        setTimer((prev) => prev - 1);
      }, 1000);
    } else if (timer === 0) {
      setIsTimerActive(false);
    }
    return () => clearInterval(interval);
  }, [isTimerActive, timer]);

  const handleOtpChange = (index, value) => {
    if (value.length > 1) value = value.charAt(0);
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    if (value && index < 5) {
      otpRefs.current[index + 1].focus();
    }
  };

  const handleKeyDown = (index, e) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      otpRefs.current[index - 1].focus();
    }
  };

  const handlePaste = (e) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData("text").slice(0, 6);
    const newOtp = [...otp];
    for (let i = 0; i < pastedData.length; i++) {
      if (i < 6) newOtp[i] = pastedData[i];
    }
    setOtp(newOtp);
    const lastFilledIndex = Math.min(pastedData.length, 5);
    if (otpRefs.current[lastFilledIndex]) {
      otpRefs.current[lastFilledIndex].focus();
    }
  };

  const handleResendOtp = () => {
    setTimer(60);
    setIsTimerActive(true);
    showSuccess("New OTP sent to your email");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const otpCode = otp.join("");
    if (otpCode.length !== 6) {
      showError("Please enter the 6-digit OTP");
      return;
    }
    try {
      const otpData = { email, otp: otpCode };
      const result = await verifyOtp(otpData);
      if (result.success) {
        showSuccess("Account verified successfully!");
        localStorage.removeItem("pending_email");
        navigate("/");
      } else {
        showError(result.error || "OTP verification failed");
      }
    } catch (error) {
      showError("An unexpected error occurred");
    }
  };

  const handleChangeEmail = () => {
    localStorage.removeItem("pending_email");
    navigate("/register");
  };

  return (
    <>
      <Seo {...buildStaticPageSeo("verifyOtp")} />

      <div className="min-h-screen bg-login-hero flex items-center justify-center px-3 sm:px-4 lg:px-6">
        <div className="w-full max-w-sm">
          {/* Lock area with ripple rings */}
          {/* PERFECT CENTER LOCK + RIPPLE WAVES */}
          <div className="relative flex justify-center mb-8">
            {/* Ripple Layer (absolute center of lock) */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              {[0, 1, 2].map((i) => (
                <motion.div
                  key={i}
                  initial={{ scale: 1, opacity: 0.5 }}
                  animate={{ scale: 3.4, opacity: 0 }}
                  transition={{
                    duration: 2.4,
                    ease: "easeOut",
                    repeat: Infinity,
                    delay: i * 0.8,
                  }}
                  className="
                    absolute
                    w-14 h-14
                    rounded-full
                    border-2 border-white/25
                  "
                />
              ))}
            </div>

            {/* LOCK CIRCLE — TRUE CENTER ELEMENT */}
            <div
              className="
                relative
                backdrop-blur-md
                bg-light-card/20
                border border-gray-100/30
                rounded-full
                p-5
                shadow-premium
                z-10
            "
            >
              <LockKeyhole className="w-12 h-12 text-white" />
            </div>
          </div>

          {/* Glass Card */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <div className="backdrop-blur-md bg-light-card/10 border border-gray-100/30 shadow-premium rounded-xl3 px-5 sm:px-6 py-8 overflow-hidden">
              <h2 className="text-2xl font-bold text-white text-center">
                OTP Verification 🔐
              </h2>
              <p className="text-light-subtext text-sm mb-4 text-center">
                Enter the 6-digit code sent to your email
              </p>
              <p className="text-center text-white font-medium mb-6">{email}</p>

              <form className="space-y-5" onSubmit={handleSubmit}>
                {/* OTP Inputs – centered, no overflow */}
                <div onPaste={handlePaste}>
                  <label className="block text-sm font-medium text-light-subtext mb-3 text-center">
                    Verification code
                  </label>
                  <div className="flex justify-center gap-2 flex-wrap max-w-full overflow-hidden">
                    {otp.map((digit, index) => (
                      <input
                        key={index}
                        ref={(el) => (otpRefs.current[index] = el)}
                        type="text"
                        inputMode="numeric"
                        pattern="[0-9]*"
                        maxLength="1"
                        value={digit}
                        onChange={(e) => handleOtpChange(index, e.target.value)}
                        onKeyDown={(e) => handleKeyDown(index, e)}
                        className="w-10 h-10 sm:w-12 sm:h-12 flex-shrink-0 text-center text-xl font-semibold border border-light-border/50 rounded-lg bg-light-card/20 text-white focus:outline-none focus:ring-2 focus:ring-instagram-pink focus:border-transparent transition-all"
                      />
                    ))}
                  </div>
                </div>

                {/* Timer / Resend */}
                <div className="text-center">
                  {isTimerActive ? (
                    <p className="text-sm text-light-subtext">
                      Resend code in{" "}
                      <span className="font-semibold text-instagram-pink">
                        {timer}s
                      </span>
                    </p>
                  ) : (
                    <button
                      type="button"
                      onClick={handleResendOtp}
                      className="text-sm font-medium text-viral-blue hover:text-viral-blue/80 transition-colors"
                    >
                      Resend verification code
                    </button>
                  )}
                </div>

                {/* Verify Button */}
                <Button
                  type="submit"
                  variant="primary"
                  size="medium"
                  loading={loading}
                  fullWidth
                  className="py-2.5 text-base font-semibold bg-green-950/80 hover:bg-green-950/100 text-white shadow-premium hover:shadow-emerald transition-all"
                >
                  Verify Account
                </Button>

                {/* Change email link */}
                <div className="text-center">
                  <button
                    type="button"
                    onClick={handleChangeEmail}
                    className="text-sm font-medium text-viral-blue hover:text-viral-blue/80 transition-colors"
                  >
                    Change email
                  </button>
                </div>
              </form>

              {/* Help text */}
              <p className="mt-6 text-xs text-center text-light-subtext/70">
                Didn't receive the email? Check your spam folder.
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default VerifyOtp;
