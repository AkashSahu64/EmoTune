// utils/mediaHelpers.js
/**
 * Utility functions for media handling
 */

// Format time utility
export const formatPlayerTime = (timeInSeconds) => {
  if (!timeInSeconds || isNaN(timeInSeconds)) return '0:00';
  const minutes = Math.floor(timeInSeconds / 60);
  const seconds = Math.floor(timeInSeconds % 60);
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
};

// Get media URL from post
export const getMediaUrl = (post) => {
  if ((post.media_type === 'video' || post.videos?.length > 0) && post.videos?.[0]) {
    return post.videos[0].hls_playlist || post.videos[0].video;
  }
  if ((post.media_type === 'audio' || post.audio) && post.audio?.audio) {
    return post.audio.audio;
  }
  return null;
};

// Get media thumbnail/cover
export const getMediaThumbnail = (post) => {
  if (post.media_type === 'video' || post.videos?.length > 0) {
    return post.videos?.[0]?.thumbnail;
  }
  if (post.media_type === 'audio' || post.audio) {
    return post.audio?.cover_image;
  }
  return null;
};

// Get media type
export const getMediaType = (post) => {
  if (post.media_type === 'video' || post.videos?.length > 0) {
    return 'video';
  }
  if (post.media_type === 'audio' || post.audio) {
    return 'audio';
  }
  if (post.media_type === 'poll') {
    return 'poll';
  }
  return null;
};

// Check if media is loaded
export const isMediaLoaded = (element) => {
  return element && element.readyState >= 2;
};

// Handle media errors
export const handleMediaError = (error, element, fallbackSrc = null) => {
  console.error('Media error:', error);
  
  if (fallbackSrc && element) {
    element.src = fallbackSrc;
    element.load();
  }
  
  return {
    hasError: true,
    error,
    fallbackUsed: !!fallbackSrc
  };
};

// Calculate progress percentage
export const calculateProgress = (current, duration) => {
  if (!duration || duration <= 0) return 0;
  return Math.min(100, (current / duration) * 100);
};

// Generate media metadata for analytics
export const getMediaMetadata = (post) => {
  return {
    id: post.id,
    type: getMediaType(post),
    duration: post.videos?.[0]?.duration || post.audio?.duration || 0,
    author: post.user?.username || 'unknown',
    timestamp: post.created_at
  };
};