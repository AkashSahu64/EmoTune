import { motion } from "framer-motion";

const FloatingEmojis = () => {
  return (
    <div className="hidden lg:block absolute inset-0 pointer-events-none">
      <motion.div
        animate={{ y: [0, -10, 0], x: [0, 6, -6, 0] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        className="absolute left-[46%] top-[36%] text-2xl z-[18]"
      >
        ✨
      </motion.div>
      <motion.div
        animate={{ y: [0, -10, 0], x: [0, 6, -6, 0] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut", delay: 0.3 }}
        className="absolute left-[58%] top-[70%] text-3xl z-[18]"
      >
        🔥
      </motion.div>
      <motion.div
        animate={{ y: [0, -10, 0], x: [0, 6, -6, 0] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut", delay: 0.6 }}
        className="absolute left-[52%] top-[15%] text-xl z-[18]"
      >
        💬
      </motion.div>
    </div>
  );
};

export default FloatingEmojis;