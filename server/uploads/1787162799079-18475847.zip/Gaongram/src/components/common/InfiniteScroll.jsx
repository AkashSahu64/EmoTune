import React, { useCallback, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import Loader from './Loader.jsx';

const InfiniteScroll = ({
  children,
  hasMore,
  isLoading,
  onLoadMore,
  threshold = 0.8,
  className = '',
  loadingComponent,
  endMessage = "You've reached the end",
  scrollContainer = null,
}) => {
  const observerRef = useRef();
  const loaderRef = useRef();
  
  const handleObserver = useCallback((entries) => {
    const target = entries[0];
    if (target.isIntersecting && hasMore && !isLoading) {
      onLoadMore();
    }
  }, [hasMore, isLoading, onLoadMore]);
  
  useEffect(() => {
    const options = {
      root: scrollContainer?.current || null,
      rootMargin: '20px',
      threshold,
    };
    
    observerRef.current = new IntersectionObserver(handleObserver, options);
    
    if (loaderRef.current) {
      observerRef.current.observe(loaderRef.current);
    }
    
    return () => {
      if (observerRef.current) {
        observerRef.current.disconnect();
      }
    };
  }, [handleObserver, threshold, scrollContainer]);
  
  return (
    <div className={className}>
      {children}
      
      <div ref={loaderRef} className="py-8">
        {isLoading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex justify-center"
          >
            {loadingComponent || <Loader />}
          </motion.div>
        )}
        
        {!hasMore && !isLoading && children && React.Children.count(children) > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-8 text-gray-500 text-sm"
          >
            {endMessage}
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default InfiniteScroll;