// src/features/feed/createPost/CreateTextPostModal.jsx
import React, { useState } from "react";
import { X } from "lucide-react";
import { useAuthStore } from "../../../store/authStore.js";
import { useUIStore } from "../../../store/uiStore.js";
import { postCreateService } from "../../../services/postCreate.service.js";
import { showSuccess, showError } from "../../../utils/toast.js";
import Avatar from "../../../components/common/Avatar.jsx";
import Button from "../../../components/common/Button.jsx";
import PostCaptionEditor from "./PostCaptionEditor.jsx";
import { FEED_EVENTS, publishFeedEvent } from "../../../utils/feedEvents.js";

const CreateTextPostModal = () => {
  const { user } = useAuthStore();
  const { closeModal } = useUIStore();

  const [caption, setCaption] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [privacy, setPrivacy] = useState("public");
  const [location, setLocation] = useState("");

  const handleSubmit = async () => {
    if (!caption.trim()) {
      showError("Please write something");
      return;
    }

    setIsSubmitting(true);

    const formData = new FormData();
    formData.append("content", caption);
    formData.append("privacy", privacy);
    formData.append("author", user?.id);
    if (location) formData.append("location", location);
    formData.append("show_profile", "false");

    try {
      await postCreateService.createPost(formData);
      showSuccess("Text post created!");
      closeModal();
      publishFeedEvent({ type: FEED_EVENTS.CREATED });
    } catch {
      showError("Failed to create post");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="w-full max-w-lg bg-card dark:bg-card-dark rounded-2xl overflow-hidden">

      {/* 🔥 HEADER (same as all composers) */}
      <div className="sticky top-0 z-20 border-b border-border dark:border-border-dark px-4 py-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold">Create Text Post</h2>

          <button
            onClick={closeModal}
            className="p-2 rounded-full hover:bg-mutedForeground/20 dark:hover:bg-mutedForeground-dark/30 transition"
          >
            <X className="w-4 h-4 text-foreground dark:text-foreground-dark" />
          </button>
        </div>
      </div>

      {/* 🔥 SCROLL BODY */}
      <div className="max-h-[75vh] overflow-y-auto px-4 py-4 space-y-4 hide-scrollbar">

        {/* USER ROW */}
        {/* <div className="flex items-center gap-3">
          <Avatar src={user?.avatar} alt={user?.username} size="medium" />

          <div>
            <p className="text-sm font-semibold">{user?.username}</p>

            <select
              value={privacy}
              onChange={(e) => setPrivacy(e.target.value)}
              className="text-xs text-foreground dark:text-foreground-dark bg-transparent outline-none"
            >
              <option value="public">🌍 Public</option>
              <option value="friends">👥 Friends</option>
              <option value="private">🔒 Private</option>
            </select>
          </div>
        </div> */}

        {/* CAPTION */}
        <div>
          <PostCaptionEditor caption={caption} setCaption={setCaption} />
        </div>

        {/* LOCATION */}
        {/* <input
          type="text"
          placeholder="Add location (optional)"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          className="
            w-full
            px-4
            py-2
            border
            rounded-lg
            text-sm
            focus:outline-none
            focus:ring-2
            focus:ring-gray-200
          "
        /> */}

        {/* SUBMIT */}
        <Button
          variant="primary"
          fullWidth
          onClick={handleSubmit}
          loading={isSubmitting}
          disabled={!caption.trim()}
        >
          Post
        </Button>
      </div>
    </div>
  );
};

export default CreateTextPostModal;
