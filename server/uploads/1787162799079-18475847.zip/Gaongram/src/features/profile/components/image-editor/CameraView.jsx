import React from 'react';
import { motion } from 'framer-motion';
import Button from '../../../../components/common/Button';
import { Camera } from 'lucide-react';
import Webcam from 'react-webcam';

const CameraView = ({ 
  showCamera, 
  webcamRef, 
  onCapture, 
  onToggleCamera, 
  onBack,
  config 
}) => (
  <motion.div
    key="camera"
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -10 }}
    className="space-y-6"
  >
    <div className="relative rounded-xl overflow-hidden bg-gray-900 aspect-video">
      {showCamera ? (
        <Webcam
          ref={webcamRef}
          audio={false}
          screenshotFormat="image/jpeg"
          videoConstraints={{
            facingMode: 'user',
            width: { ideal: config.maxWidth },
            height: { ideal: config.maxHeight },
          }}
          className="w-full h-full object-cover"
          onUserMediaError={() => {
            showToast('Camera access denied or not available', 'error');
            onBack();
          }}
        />
      ) : (
        <div className="w-full h-full flex items-center justify-center">
          <div className="text-center">
            <Camera size={48} className="text-gray-400 mx-auto mb-4" />
            <p className="text-gray-300">Camera preview will appear here</p>
          </div>
        </div>
      )}
      
      {/* Aspect Ratio Guide */}
      <div className="absolute inset-0 flex items-center justify-center">
        {config.type === 'profile' ? (
          <div className="w-64 h-64 border-2 border-white/30 rounded-full" />
        ) : (
          <div className="w-3/4 h-32 border-2 border-white/30 rounded-lg" />
        )}
      </div>
    </div>
    
    <div className="flex justify-center gap-4">
      {!showCamera ? (
        <Button
          onClick={onToggleCamera}
          className="bg-gaon-green-gradient hover:opacity-90 rounded-xl px-8"
          startIcon={<Camera size={18} />}
        >
          Start Camera
        </Button>
      ) : (
        <>
          <Button
            onClick={onCapture}
            className="bg-gaon-green-gradient hover:opacity-90 rounded-xl px-8"
            startIcon={<Camera size={18} />}
          >
            Capture Photo
          </Button>
          <Button
            variant="outline"
            onClick={onToggleCamera}
            className="border-gray-300 hover:bg-gray-50 rounded-xl"
          >
            Stop Camera
          </Button>
        </>
      )}
      
      <Button
        variant="outline"
        onClick={onBack}
        className="border-gray-300 hover:bg-gray-50 rounded-xl"
      >
        Back
      </Button>
    </div>
  </motion.div>
);

export default CameraView;