// components/EditCoverImageModal.jsx - REFACTORED WITH SHARED ARCHITECTURE
import React from 'react';
import BaseImageEditor from '../components/image-editor/BaseImageEditor';
import ImageSourceSelector from '../components/image-editor/ImageSourceSelector';
import CameraView from '../components/image-editor/CameraView';
import CropperView from '../components/image-editor/CropperView';
import FiltersPanel from '../components/image-editor/FiltersPanel';
import EditorFooter from '../components/image-editor/EditorFooter';
import EditorHeader from '../components/image-editor/EditorHeader';

// Cover-specific configuration
const COVER_CONFIG = {
  type: "cover",
  defaultAspect: 3,
  cropShape: "rect",
  outputKey: "background_image",
  maxWidth: 1920,
  maxHeight: 1080,
  aspectRatios: [
    { label: 'Standard (3:1)', value: 3/1 },
    { label: 'Wide (2:1)', value: 2/1 },
    { label: 'Cinematic (16:9)', value: 16/9 },
    { label: 'Ultra Wide (4:1)', value: 4/1 },
    { label: 'Free', value: null },
  ]
};

const EditCoverImageModal = ({ 
  isOpen, 
  onClose, 
  profile, 
  onUpdate, 
  isUpdating 
}) => {
  return (
    <BaseImageEditor
      isOpen={isOpen}
      onClose={onClose}
      profile={profile}
      onUpdate={onUpdate}
      isUpdating={isUpdating}
      config={COVER_CONFIG}
      
      // UI Components
      renderHeader={({ mode, onClose, config }) => (
        <EditorHeader mode={mode} onClose={onClose} config={config} />
      )}
      
      renderSourceSelector={({ imagePreview, fileInputRef, onFileSelect, onCameraSelect, config }) => (
        <ImageSourceSelector
          imagePreview={imagePreview}
          fileInputRef={fileInputRef}
          onFileSelect={onFileSelect}
          onCameraSelect={onCameraSelect}
          config={config}
        />
      )}
      
      renderCameraView={({ showCamera, webcamRef, onCapture, onToggleCamera, onBack, config }) => (
        <CameraView
          showCamera={showCamera}
          webcamRef={webcamRef}
          onCapture={onCapture}
          onToggleCamera={onToggleCamera}
          onBack={onBack}
          config={config}
        />
      )}
      
      renderCropperView={({ 
        selectedImage, 
        crop, 
        zoom, 
        rotation, 
        aspect, 
        onCropChange, 
        onZoomChange, 
        onRotationChange, 
        onAspectChange, 
        onCropComplete,
        onNext,
        onReset,
        config 
      }) => (
        <CropperView
          selectedImage={selectedImage}
          crop={crop}
          zoom={zoom}
          rotation={rotation}
          aspect={aspect}
          onCropChange={onCropChange}
          onZoomChange={onZoomChange}
          onRotationChange={onRotationChange}
          onAspectChange={onAspectChange}
          onCropComplete={onCropComplete}
          onNext={onNext}
          onReset={onReset}
          config={config}
        />
      )}
      
      renderFiltersPanel={({ imagePreview, filters, onFilterChange, onBack, onResetFilters, config }) => (
        <FiltersPanel
          imagePreview={imagePreview}
          filters={filters}
          onFilterChange={onFilterChange}
          onBack={onBack}
          onResetFilters={onResetFilters}
          config={config}
        />
      )}
      
      renderFooter={({ onCancel, onSubmit, isUpdating, isDisabled, config }) => (
        <EditorFooter
          onCancel={onCancel}
          onSubmit={onSubmit}
          isUpdating={isUpdating}
          isDisabled={isDisabled}
          config={config}
        />
      )}
    />
  );
};

export default EditCoverImageModal;