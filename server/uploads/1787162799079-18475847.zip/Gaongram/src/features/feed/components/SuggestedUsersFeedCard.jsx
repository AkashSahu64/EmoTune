import { useNavigate } from "react-router-dom";
import { useUIStore } from "../../../store/uiStore.js";
import { useFollow } from "../../../hooks/useFollow.js";
import Avatar from "../../../components/common/Avatar.jsx";
import Button from "../../../components/common/Button.jsx";
import { useTranslation } from "react-i18next";

// Individual user item
const SuggestedUserItem = ({ user }) => {
  const navigate = useNavigate();
  const { t } = useTranslation();

  const { toggleFollow, isFollowing, isFollowingRequested, isLoading } =
    useFollow(user.user_id || user.id, user.is_private);

  const handleProfileClick = () => {
    navigate(`/profile/${user.username || user.user_id || user.id}`);
  };

  const handleFollowClick = (e) => {
    e.stopPropagation();
    toggleFollow();
  };

  let labelKey = "follow";
  let variant = "primary";
  let disabled = isLoading;

  if (isFollowingRequested) {
    labelKey = "requested";
    variant = "outline";
    disabled = true;
  } else if (isFollowing) {
    labelKey = "following";
    variant = "outline";
  }

  return (
    <div
      onClick={handleProfileClick}
      className="min-w-32 bg-muted dark:bg-muted-dark border border-border dark:border-border-dark rounded-lg p-2 flex flex-col items-center text-center cursor-pointer"
    >
      <img
        src={user.avatar}
        alt={user.username}
        className="w-14 h-14 rounded-full object-cover mb-2 border-2 border-primary"
      />

      <p className="text-sm font-medium truncate w-full text-foreground dark:text-foreground-dark">
        {user.username}
      </p>

      <p className="text-xs text-mutedForeground dark:text-mutedForeground-dark truncate w-full mb-2">
        {user.name}
      </p>

      <Button
        size="small"
        variant={variant}
        onClick={handleFollowClick}
        disabled={disabled}
        className={`
          px-3 py-0.5 text-sm
        `}
      >
        {t(labelKey)}
      </Button>
    </div>
  );
};

const SuggestedUsersFeedCard = ({ users = [], allUsers = [] }) => {
  const { openModal } = useUIStore();
  const { t } = useTranslation();

  if (!users.length) return null;

  const handleSeeAll = () => {
    openModal("suggested-users-modal", {
      users: allUsers.length ? allUsers : users,
    });
  };

  return (
    <div className="bg-card dark:bg-card-dark shadow-soft px-1 py-3">

      <div className="flex items-center justify-between mb-3 px-2">
        <h3 className="font-semibold text-foreground dark:text-foreground-dark">
          {t("suggested_for_you")}
        </h3>

        <button
          onClick={handleSeeAll}
          className="text-sm font-medium text-primary"
        >
          {t("see_all")}
        </button>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-2 hide-scrollbar">
        {users.map((user, index) => (
          <SuggestedUserItem key={index} user={user} />
        ))}
      </div>
    </div>
  );
};

export default SuggestedUsersFeedCard;