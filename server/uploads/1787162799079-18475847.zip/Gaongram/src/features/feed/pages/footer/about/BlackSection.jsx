import React, { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";

const leftText = "Where everyday moments";
const rightText = "bring Bharat together";

const splitText = (text) => text.split(" ");

const BlackSection = () => {
  const ref = useRef(null);

  // 🔥 Scroll tracking
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });

  // 🎯 Parallax animations
  const leftX = useTransform(scrollYProgress, [0, 1], [-120, 0]);
  const rightX = useTransform(scrollYProgress, [0, 1], [120, 0]);

  const opacity = useTransform(
    scrollYProgress,
    [0, 0.2, 0.8, 1],
    [0, 1, 1, 0]
  );

  const scale = useTransform(scrollYProgress, [0, 1], [0.95, 1]);

  return (
    <section ref={ref} className="relative overflow-hidden">

      {/* 🌗 Background */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-background dark:bg-background-dark" />

        {/* Glow */}
        <motion.div
          style={{ scale }}
          className="absolute w-[500px] h-[500px] bg-primary/10 blur-[120px] rounded-full top-[-150px] left-[-100px]"
        />
        <motion.div
          style={{ scale }}
          className="absolute w-[400px] h-[400px] bg-viral-blue/10 blur-[120px] rounded-full bottom-[-150px] right-[-100px]"
        />
      </div>

      <div className="max-w-7xl mx-auto px-16">

        <div className="grid md:grid-cols-2 gap-8 items-center">

          {/* 🔥 LEFT TEXT */}
          <motion.div
            style={{ x: leftX, opacity }}
            className="text-4xl md:text-6xl lg:text-7xl font-extrabold flex flex-wrap gap-x-3"
          >
            {splitText(leftText).map((word, i) => (
              <motion.span
                key={i}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{
                  delay: i * 0.05,
                  duration: 0.5,
                }}
                viewport={{ once: true }}
              >
                {word}
              </motion.span>
            ))}
          </motion.div>

          {/* 🔥 RIGHT TEXT */}
          <motion.div
            style={{ x: rightX, opacity }}
            className="text-4xl md:text-6xl lg:text-7xl font-extrabold flex flex-wrap gap-x-3 md:justify-end"
          >
            {splitText(rightText).map((word, i) => (
              <motion.span
                key={i}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{
                  delay: i * 0.05,
                  duration: 0.5,
                }}
                viewport={{ once: true }}
              >
                {word}
              </motion.span>
            ))}
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default BlackSection;