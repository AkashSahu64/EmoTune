import React, { useEffect, useRef, useState } from "react";
import { Send, Smile, Image as ImageIcon, X } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuthStore } from "../../store/authStore.js";
import { useUIStore } from "../../store/uiStore.js";
import { commentService } from "../../services/comment.service.js";
import { showSuccess, showError } from "../../utils/toast.js";
import Avatar from "../../components/common/Avatar.jsx";
import Button from "../../components/common/Button.jsx";
import { useTranslation } from "react-i18next";

const isSameId = (a, b) => String(a) === String(b);

const toBoolean = (value) => {
  if (typeof value === "boolean") return value;
  if (typeof value === "string") return value.toLowerCase() === "true";
  return Boolean(value);
};

const getCreatedComment = (response) => {
  const candidates = [response?.data?.data, response?.data, response];

  return candidates.find(
    (candidate) =>
      candidate &&
      typeof candidate === "object" &&
      !Array.isArray(candidate) &&
      (candidate.id || candidate.comment),
  );
};

const withCommentResults = (old, updateResults, updateCount) => {
  if (!old) return old;

  if (Array.isArray(old)) {
    return updateResults(old);
  }

  if (Array.isArray(old?.data?.results)) {
    return {
      ...old,
      data: {
        ...old.data,
        results: updateResults(old.data.results),
        count: updateCount ? updateCount(old.data.count) : old.data.count,
      },
    };
  }

  if (Array.isArray(old?.data)) {
    return {
      ...old,
      data: updateResults(old.data),
    };
  }

  return old;
};

const insertComment = (comments, commentToInsert, parentId) => {
  if (!parentId) {
    return [
      commentToInsert,
      ...comments.filter((comment) => !isSameId(comment.id, commentToInsert.id)),
    ];
  }

  return comments.map((comment) => {
    if (isSameId(comment.id, parentId)) {
      const existingReplies = Array.isArray(comment.replies)
        ? comment.replies
        : [];

      return {
        ...comment,
        replies: [
          ...existingReplies.filter(
            (reply) => !isSameId(reply.id, commentToInsert.id),
          ),
          commentToInsert,
        ],
      };
    }

    if (Array.isArray(comment.replies) && comment.replies.length > 0) {
      return {
        ...comment,
        replies: insertComment(comment.replies, commentToInsert, parentId),
      };
    }

    return comment;
  });
};

const replaceTempComment = (comments, tempId, realComment, parentId) => {
  let replaced = false;

  const replaceInTree = (items) =>
    items.reduce((next, item) => {
      if (
        realComment.id &&
        isSameId(item.id, realComment.id) &&
        !isSameId(item.id, tempId)
      ) {
        return next;
      }

      if (isSameId(item.id, tempId)) {
        replaced = true;
        next.push({
          ...item,
          ...realComment,
          replies: Array.isArray(realComment.replies)
            ? realComment.replies
            : item.replies || [],
        });
        return next;
      }

      next.push({
        ...item,
        replies: Array.isArray(item.replies)
          ? replaceInTree(item.replies)
          : item.replies,
      });
      return next;
    }, []);

  const withoutTemp = replaceInTree(comments);
  return replaced
    ? withoutTemp
    : insertComment(withoutTemp, realComment, parentId);
};

const CommentBox = ({ blogId, postId, onCommentAdded, replyTo = null }) => {
  const { user, isAuthenticated } = useAuthStore();
  const { openModal } = useUIStore();
  const queryClient = useQueryClient();
  const { t } = useTranslation();

  const [comment, setComment] = useState("");
  const [images, setImages] = useState([]);
  const [imagePreviews, setImagePreviews] = useState([]);
  const submitLockRef = useRef(false);
  const commentQueryKey = postId
    ? ["comments", postId]
    : blogId
    ? ["blog-comments", blogId]
    : null;

  useEffect(() => {
    const previews = images.map((image) => ({
      file: image,
      url: URL.createObjectURL(image),
    }));

    setImagePreviews(previews);

    return () => {
      previews.forEach((preview) => URL.revokeObjectURL(preview.url));
    };
  }, [images]);

  const mutation = useMutation({
    mutationFn: (commentData) => commentService.createComment(commentData),
    onMutate: async (newCommentData) => {
      if (!commentQueryKey) return {};

      await queryClient.cancelQueries({ queryKey: commentQueryKey });

      const previousComments = queryClient.getQueryData(commentQueryKey);
      const tempId = `temp-comment-${Date.now()}-${Math.random()
        .toString(36)
        .slice(2)}`;
      const isReply = Boolean(newCommentData.parent);

      const optimisticComment = {
        id: tempId,
        user: user?.id,
        username: user?.username || user?.name || "",
        post: isReply ? undefined : newCommentData.postId,
        parent: newCommentData.parent || null,
        profile_image: user?.profile_image || user?.avatar,
        comment: newCommentData.comment,
        created_at: new Date().toISOString(),
        likes_count: 0,
        is_liked: false,
        replies: [],
        is_verified: Boolean(user?.is_verified),
        is_optimistic: true,
      };

      queryClient.setQueryData(commentQueryKey, (old) =>
        withCommentResults(
          old,
          (comments) =>
            insertComment(comments, optimisticComment, newCommentData.parent),
          (count = 0) => (isReply ? count : count + 1),
        ),
      );

      return { previousComments, tempId, optimisticComment };
    },
    onSuccess: (data, variables, context) => {
      const serverComment = getCreatedComment(data);
      const realComment = {
        ...context?.optimisticComment,
        ...serverComment,
        id: serverComment?.id ?? context?.tempId,
        post: serverComment?.post ?? (variables.parent ? undefined : postId),
        parent: serverComment?.parent ?? variables.parent ?? null,
        comment: serverComment?.comment ?? variables.comment,
        likes_count: serverComment?.likes_count ?? 0,
        is_liked: toBoolean(serverComment?.is_liked),
        replies: Array.isArray(serverComment?.replies)
          ? serverComment.replies
          : [],
        is_optimistic: false,
      };

      if (commentQueryKey && context?.tempId) {
        queryClient.setQueryData(commentQueryKey, (old) =>
          withCommentResults(old, (comments) =>
            replaceTempComment(
              comments,
              context.tempId,
              realComment,
              variables.parent,
            ),
          ),
        );
      }

      showSuccess(t("comment_added"));
      setComment("");
      setImages([]);

      if (blogId) {
        queryClient.invalidateQueries({ queryKey: ["blog", blogId] });
        queryClient.invalidateQueries({ queryKey: ["blog-comments", blogId] });
      }

      if (postId) {
        queryClient.invalidateQueries({ queryKey: ["post", postId] });
      }

      onCommentAdded?.(realComment, Boolean(variables.parent));
    },
    onError: (err, variables, context) => {
      if (commentQueryKey && context?.previousComments) {
        queryClient.setQueryData(commentQueryKey, context.previousComments);
      }

      showError(t("comment_failed"));
    },
    onSettled: () => {
      submitLockRef.current = false;
    },
  });

  const handleSubmit = (event) => {
    event.preventDefault();

    if (submitLockRef.current || mutation.isPending) return;

    if (!isAuthenticated) {
      openModal("login");
      return;
    }

    if (!comment.trim() && images.length === 0) return;

    submitLockRef.current = true;

    mutation.mutate({
      comment: comment.trim(),
      postId: postId || blogId,
      parent: replyTo,
      images,
    });
  };

  const handleImageUpload = (event) => {
    const files = Array.from(event.target.files);

    const validImages = files.filter(
      (file) => file.type.startsWith("image/") && file.size <= 5 * 1024 * 1024,
    );

    if (validImages.length + images.length > 4) {
      showError(t("max_images"));
      return;
    }

    setImages((prev) => [...prev, ...validImages]);
    event.target.value = "";
  };

  const removeImage = (index) => {
    setImages((prev) => prev.filter((_, imageIndex) => imageIndex !== index));
  };

  if (!isAuthenticated) {
    return (
      <div className="bg-gray-50 dark:bg-muted-dark rounded-lg p-4 text-center">
        <p className="text-mutedForeground dark:text-mutedForeground-dark mb-3">
          {t("login_to_comment")}
        </p>
        <Button
          variant="primary"
          size="small"
          onClick={() => openModal("login")}
        >
          {t("login")}
        </Button>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-card-dark rounded-xl border border-border dark:border-border-dark">
      <div className="flex items-center space-x-3 p-4 border-b border-border dark:border-border-dark">
        <Avatar
          src={user?.profile_image || user?.avatar}
          alt={user?.username}
          size="medium"
        />
        <div>
          <p className="font-medium text-foreground dark:text-foreground-dark">
            {user?.username}
          </p>
          <p className="text-sm text-mutedForeground dark:text-mutedForeground-dark">
            {t("add_comment")}
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="p-4">
        <div className="mb-4">
          <textarea
            value={comment}
            onChange={(event) => setComment(event.target.value)}
            placeholder={t("write_comment")}
            disabled={mutation.isPending}
            className="w-full min-h-[100px] p-3 border border-border dark:border-border-dark bg-white dark:bg-card-dark rounded-lg focus:ring-2 focus:ring-instagram-pink focus:border-transparent resize-none text-foreground dark:text-foreground-dark"
            rows={3}
          />
        </div>

        {imagePreviews.length > 0 && (
          <div className="mb-4">
            <div className="grid grid-cols-4 gap-2">
              {imagePreviews.map((preview, index) => (
                <div key={`${preview.file.name}-${index}`} className="relative group">
                  <img
                    src={preview.url}
                    alt={`Preview ${index + 1}`}
                    className="w-full h-24 object-cover rounded-lg"
                  />
                  <button
                    type="button"
                    onClick={() => removeImage(index)}
                    className="absolute -top-2 -right-2 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <label className="cursor-pointer p-2 text-mutedForeground dark:text-mutedForeground-dark hover:text-foreground dark:hover:text-foreground-dark rounded-full hover:bg-gray-100 dark:hover:bg-muted-dark">
              <ImageIcon className="w-5 h-5" />
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handleImageUpload}
                disabled={mutation.isPending}
                className="hidden"
              />
            </label>

            <button
              type="button"
              className="p-2 text-mutedForeground dark:text-mutedForeground-dark hover:text-foreground dark:hover:text-foreground-dark rounded-full hover:bg-gray-100 dark:hover:bg-muted-dark"
            >
              <Smile className="w-5 h-5" />
            </button>
          </div>

          <div className="flex items-center space-x-3">
            <Button
              type="button"
              variant="ghost"
              onClick={() => {
                setComment("");
                setImages([]);
              }}
              disabled={mutation.isPending || (!comment && images.length === 0)}
            >
              {t("cancel")}
            </Button>

            <Button
              type="submit"
              variant="primary"
              loading={mutation.isPending}
              disabled={
                mutation.isPending || (!comment.trim() && images.length === 0)
              }
              startIcon={<Send className="w-4 h-4" />}
            >
              {replyTo ? t("reply") : t("comment")}
            </Button>
          </div>
        </div>
      </form>

      <div className="px-4 py-3 bg-gray-50 dark:bg-muted-dark border-t border-border dark:border-border-dark rounded-b-xl">
        <p className="text-xs text-mutedForeground dark:text-mutedForeground-dark">
          {t("comment_guidelines")}
        </p>
      </div>
    </div>
  );
};

export default CommentBox;
