import React from "react";
import { motion } from "framer-motion";
import { X, Eye, Heart } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const StoryViewersSheet = ({
  viewers = [],
  totalViews = 0,
  totalLikes = 0,
  onClose,
}) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/70 z-50 flex items-end"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="bg-white dark:bg-card-dark w-full max-w-[25rem] mx-auto rounded-t-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* HEADER */}
        <div className="flex items-center justify-between px-4 py-2 border-b border-border dark:border-border-dark">
          <h3 className="font-semibold text-lg">Story insights</h3>

          <button onClick={onClose}>
            <X size={22} />
          </button>
        </div>

        {/* STATS */}
        <div className="flex justify-around py-2 border-b border-border dark:border-border-dark">
          <div className="text-center">
            <div className="flex items-center justify-center gap-1">
              <Eye className="text-gray-500" size={18} />
              <p className="text-lg font-semibold">{totalViews}</p>
            </div>
            <p className="text-xs text-gray-500">Views</p>
          </div>

          <div className="text-center">
            <div className="flex items-center justify-center gap-1">
              <Heart className="text-gray-500" size={18} />
              <p className="text-lg font-semibold">{totalLikes}</p>
            </div>
            <p className="text-xs text-gray-500">Likes</p>
          </div>
        </div>

        {/* VIEWERS LIST */}
        <div className="max-h-[400px] overflow-y-auto">
          {viewers.length === 0 ? (
            <div className="p-8 text-center text-gray-500">No viewers yet</div>
          ) : (
            viewers.map((viewer) => (
              <div
                key={viewer.id}
                className="flex items-center justify-between px-4 py-2 border-b border-border dark:border-border-dark"
              >
                <div className="flex items-center gap-3">
                  <img
                    src={
                      viewer.profile_image ||
                      `https://ui-avatars.com/api/?name=${viewer.username}`
                    }
                    className="w-10 h-10 rounded-full object-cover"
                  />

                  <div>
                    <p className="font-medium">{viewer.username}</p>

                    <p className="text-xs text-gray-500">
                      {viewer.seen_at
                        ? formatDistanceToNow(new Date(viewer.seen_at), {
                            addSuffix: true,
                          })
                        : ""}
                    </p>
                  </div>
                </div>

                {/* LIKE ICON */}
                {viewer.is_liked ? (
                  <Heart size={18} className="text-red-500 fill-red-500" />
                ) : (
                  <Heart size={18} className="text-gray-300" />
                )}
              </div>
            ))
          )}
        </div>
      </motion.div>
    </motion.div>
  );
};

export default React.memo(StoryViewersSheet);
