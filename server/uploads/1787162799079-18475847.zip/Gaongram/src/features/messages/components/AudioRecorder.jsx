// src/features/messages/components/AudioRecorder.jsx
import React, { useState, useRef } from 'react';
import { Mic, Square, Play, Pause, Send } from 'lucide-react';

const AudioRecorder = ({ onSave, onCancel }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [audioURL, setAudioURL] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const audioRef = useRef(null);
  
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      audioChunksRef.current = [];
      
      mediaRecorderRef.current.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };
      
      mediaRecorderRef.current.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const url = URL.createObjectURL(audioBlob);
        setAudioURL(url);
        stream.getTracks().forEach(track => track.stop());
      };
      
      mediaRecorderRef.current.start();
      setIsRecording(true);
    } catch (error) {
      console.error('Error accessing microphone:', error);
    }
  };
  
  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };
  
  const togglePlayback = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };
  
  const handleSend = () => {
    if (audioURL) {
      fetch(audioURL)
        .then(res => res.blob())
        .then(blob => {
          onSave(blob);
        });
    }
  };
  
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Record Audio</h3>
      
      {!audioURL ? (
        <div className="flex justify-center gap-4">
          {!isRecording ? (
            <button
              onClick={startRecording}
              className="p-4 bg-red-500 text-white rounded-full hover:bg-red-600 transition"
            >
              <Mic className="w-6 h-6" />
            </button>
          ) : (
            <button
              onClick={stopRecording}
              className="p-4 bg-gray-500 text-white rounded-full hover:bg-gray-600 transition animate-pulse"
            >
              <Square className="w-6 h-6" />
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          <audio ref={audioRef} src={audioURL} onEnded={() => setIsPlaying(false)} />
          
          <div className="flex justify-center gap-4">
            <button
              onClick={togglePlayback}
              className="p-3 bg-primary text-white rounded-full"
            >
              {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
            </button>
            
            <button
              onClick={handleSend}
              className="p-3 bg-green-500 text-white rounded-full"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
      
      <div className="flex justify-end gap-2">
        <button onClick={onCancel} className="px-4 py-2 text-gray-600">
          Cancel
        </button>
      </div>
    </div>
  );
};

export default AudioRecorder;