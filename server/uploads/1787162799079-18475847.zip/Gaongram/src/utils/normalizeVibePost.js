export const parsePollOptions = (value) => {
  if (Array.isArray(value)) {
    return value
      .map((option) =>
        typeof option === "string"
          ? option
          : option?.text || option?.label || option?.option || "",
      )
      .map((option) => String(option).trim())
      .filter(Boolean);
  }

  if (typeof value !== "string") {
    return [];
  }

  const trimmed = value.trim();
  if (!trimmed) {
    return [];
  }

  if (trimmed.startsWith("[")) {
    try {
      return parsePollOptions(JSON.parse(trimmed));
    } catch {
      // Fall back to comma splitting below.
    }
  }

  return trimmed
    .split(",")
    .map((option) => option.trim())
    .filter(Boolean);
};

export const normalizeVibePost = (rawPost) => {
  const item = rawPost?.data || rawPost;

  if (!item || typeof item !== "object") {
    return null;
  }

  const pollOptions = parsePollOptions(item.poll_options || item.poll?.poll_options);
  const hasPoll = Boolean(item.poll_question || item.poll?.poll_question || pollOptions.length);
  const videos = item.videos || [];
  const images = item.images || [];
  const audio = item.audio || null;

  let mediaType = item.media_type || "text";
  let mediaUrl = item.media_url || null;

  if (videos.length) {
    mediaType = "video";
    mediaUrl = videos[0]?.hls_playlist || videos[0]?.video || mediaUrl;
  } else if (audio) {
    mediaType = "audio";
    mediaUrl = audio.audio || mediaUrl;
  } else if (images.length) {
    mediaType = "image";
    mediaUrl = images[0]?.image || mediaUrl;
  } else if (hasPoll) {
    mediaType = "poll";
  }

  return {
    ...item,
    id: item.id,
    user: item.user || {
      id: item.author,
      username: item.user_name,
      avatar: item.profile_image,
      is_private: item.is_private,
      is_verified: item.is_verified,
    },
    caption: item.caption ?? item.content ?? "",
    created_at: item.created_at,
    times_ago: item.times_ago,
    views_count: item.views_count ?? 0,
    likes_count: item.likes_count ?? item.total_likes ?? 0,
    comments_count: item.comments_count ?? 0,
    is_liked: item.is_liked === true,
    is_following: item.is_following ?? false,
    is_sensitive: item.is_sensitive === true,
    media_type: mediaType,
    media_url: mediaUrl,
    videos,
    audio,
    images,
    poll_question: item.poll_question || item.poll?.poll_question || null,
    poll_options: pollOptions,
    poll_votes: item.poll_votes || item.poll?.poll_votes || {},
    poll: hasPoll
      ? {
          poll_question: item.poll_question || item.poll?.poll_question || "Poll",
          poll_options: pollOptions,
          poll_votes: item.poll_votes || item.poll?.poll_votes || {},
          user_vote: item.user_vote ?? item.poll?.user_vote ?? null,
          expires_at: item.expires_at || item.poll?.expires_at || null,
        }
      : null,
    user_vote: item.user_vote,
  };
};
