// src/features/feed/createPost/components/editor/hooks/useCanvasHistory.js
import { useState, useRef, useCallback } from "react";

const MAX_HISTORY = 30;

export function useCanvasHistory(initialState = { paint: null, shapes: [] }) {
  const undoStack = useRef([]);
  const redoStack = useRef([]);
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);

  const push = useCallback((paintData, shapes) => {
    undoStack.current.push({ paint: paintData, shapes: [...shapes] });
    if (undoStack.current.length > MAX_HISTORY) undoStack.current.shift();
    redoStack.current = [];
    setCanUndo(true);
    setCanRedo(false);
  }, []);

  const undo = useCallback((applyFn) => {
    if (undoStack.current.length === 0) return;
    const current = undoStack.current.pop();
    redoStack.current.push(current);
    const prev = undoStack.current[undoStack.current.length - 1];
    applyFn(prev ? prev.paint : null, prev ? [...prev.shapes] : []);
    setCanUndo(undoStack.current.length > 0);
    setCanRedo(true);
  }, []);

  const redo = useCallback((applyFn) => {
    if (redoStack.current.length === 0) return;
    const next = redoStack.current.pop();
    undoStack.current.push(next);
    applyFn(next.paint, [...next.shapes]);
    setCanUndo(true);
    setCanRedo(redoStack.current.length > 0);
  }, []);

  const clear = useCallback(() => {
    undoStack.current = [];
    redoStack.current = [];
    setCanUndo(false);
    setCanRedo(false);
  }, []);

  return { push, undo, redo, clear, canUndo, canRedo };
}