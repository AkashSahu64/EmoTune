import React from "react";

const FeedLoader = () => (
  <div className="flex justify-center py-4">
    <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
  </div>
);

export default FeedLoader;