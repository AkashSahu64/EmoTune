export const createImage = (url) =>
  new Promise((resolve, reject) => {
    const image = new Image();

    image.addEventListener("load", () => resolve(image));

    image.addEventListener("error", (error) => reject(error));

    image.setAttribute("crossOrigin", "anonymous");

    image.src = url;
  });

/**
 * Degree → radian
 */

export function getRadianAngle(degreeValue) {
  return (degreeValue * Math.PI) / 180;
}

/**
 * Rotate size helper
 */

export function rotateSize(width, height, rotation) {
  const rotRad = getRadianAngle(rotation);

  return {
    width:
      Math.abs(Math.cos(rotRad) * width) + Math.abs(Math.sin(rotRad) * height),

    height:
      Math.abs(Math.sin(rotRad) * width) + Math.abs(Math.cos(rotRad) * height),
  };
}

/**
 * FINAL ACCURATE CROP
 * Instagram-style crop
 */

export async function getCroppedImage(
  imageSrc,
  pixelCrop,
  rotation = 0,
  filters = {
    brightness: 100,
    contrast: 100,
    saturation: 100,
  },

  flip = {
    horizontal: false,
    vertical: false,
  },
) {
  const image = await createImage(imageSrc);

  const canvas = document.createElement("canvas");

  const ctx = canvas.getContext("2d");

  if (!ctx) {
    throw new Error("No canvas context");
  }

  const rotRad = getRadianAngle(rotation);

  // Calculate bounding box

  const { width: bBoxWidth, height: bBoxHeight } = rotateSize(
    image.width,
    image.height,
    rotation,
  );

  // Temp canvas

  const tempCanvas = document.createElement("canvas");

  const tempCtx = tempCanvas.getContext("2d");

  tempCanvas.width = bBoxWidth;

  tempCanvas.height = bBoxHeight;

  // Apply filters

  tempCtx.filter = `
    brightness(${filters.brightness}%)
    contrast(${filters.contrast}%)
    saturate(${filters.saturation}%)
  `;

  // Move center

  tempCtx.translate(bBoxWidth / 2, bBoxHeight / 2);

  tempCtx.rotate(rotRad);
  tempCtx.scale(flip.horizontal ? -1 : 1, flip.vertical ? -1 : 1);

  tempCtx.drawImage(image, -image.width / 2, -image.height / 2);

  // Final crop canvas

  canvas.width = pixelCrop.width;

  canvas.height = pixelCrop.height;

  ctx.imageSmoothingEnabled = true;

  ctx.imageSmoothingQuality = "high";

  ctx.drawImage(
    tempCanvas,
    pixelCrop.x,
    pixelCrop.y,
    pixelCrop.width,
    pixelCrop.height,
    0,
    0,
    pixelCrop.width,
    pixelCrop.height,
  );

  return new Promise((resolve) => {
    canvas.toBlob(
      (blob) => {
        resolve({
          blob,
          url: URL.createObjectURL(blob),
        });
      },
      "image/jpeg",
      0.95,
    );
  });
}
/**
 * Resize image
 */

export async function resizeImage(file, maxWidth, maxHeight) {
  return new Promise((resolve) => {
    const img = new Image();

    img.onload = () => {
      const canvas = document.createElement("canvas");

      let width = img.width;

      let height = img.height;

      // WIDTH

      if (width > maxWidth) {
        const ratio = maxWidth / width;

        width = maxWidth;

        height = height * ratio;
      }

      // HEIGHT

      if (height > maxHeight) {
        const ratio = maxHeight / height;

        height = maxHeight;

        width = width * ratio;
      }

      canvas.width = width;

      canvas.height = height;

      const ctx = canvas.getContext("2d");

      if (ctx) {
        ctx.imageSmoothingEnabled = true;

        ctx.imageSmoothingQuality = "high";

        ctx.drawImage(img, 0, 0, width, height);

        canvas.toBlob(
          (blob) => {
            if (blob) {
              resolve({
                blob,

                url: URL.createObjectURL(blob),

                width,

                height,
              });
            }
          },

          "image/jpeg",

          0.9,
        );
      }
    };

    img.src = URL.createObjectURL(file);
  });
}

/**
 * Compress image
 */

export async function compressImage(file, maxSizeMB = 5) {
  const maxSizeBytes = maxSizeMB * 1024 * 1024;

  if (file.size <= maxSizeBytes) {
    return file;
  }

  return new Promise((resolve) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      const img = new Image();

      img.onload = () => {
        const canvas = document.createElement("canvas");

        canvas.width = img.width;

        canvas.height = img.height;

        const ctx = canvas.getContext("2d");

        ctx.drawImage(img, 0, 0);

        const compress = (quality) => {
          canvas.toBlob(
            (blob) => {
              if (!blob) {
                return;
              }

              if (blob.size <= maxSizeBytes || quality <= 0.1) {
                resolve(
                  new File([blob], file.name, {
                    type: "image/jpeg",
                  }),
                );
              } else {
                compress(quality - 0.1);
              }
            },

            "image/jpeg",

            quality,
          );
        };

        compress(0.9);
      };

      img.src = e.target.result;
    };

    reader.readAsDataURL(file);
  });
}