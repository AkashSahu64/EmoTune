// src/components/help/CategoryGrid.jsx
import React from "react";
import { motion } from "framer-motion";

const CategoryGrid = ({ categories, onSelectCategory, selectedCategory }) => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
      {categories.map((cat, idx) => {
        const Icon = cat.icon;
        return (
          <motion.button
            key={cat.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            whileHover={{
              scale: 1.01,
              boxShadow: "0 0px 10px rgba(0,0,0,0.1)",
            }}
            onClick={() =>
              onSelectCategory(selectedCategory === cat.id ? null : cat.id)
            }
            className={`p-2 rounded-xl border transition-all text-left ${
              selectedCategory === cat.id
                ? "border-primary bg-primary/5 dark:bg-primary/10"
                : "border-border dark:border-border-dark bg-card dark:bg-card-dark"
            }`}
          >
            {/* 🔥 FLEX ROW */}
            <div className="flex items-center gap-4">
              {/* ICON */}
              <div
                className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  selectedCategory === cat.id
                    ? "bg-primary text-white"
                    : "bg-muted dark:bg-muted-dark text-primary"
                }`}
              >
                <Icon className="w-5 h-5" />
              </div>

              {/* TEXT */}
              <div className="flex flex-col">
                <h3 className="font-medium text-sm text-foreground dark:text-foreground-dark">
                  {cat.name}
                </h3>
                <p className="text-xs text-mutedForeground">
                  {cat.count} articles
                </p>
              </div>
            </div>
          </motion.button>
        );
      })}
    </div>
  );
};

export default CategoryGrid;
