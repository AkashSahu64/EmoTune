import { create } from "zustand";
import { ASPECT_RATIOS, DEFAULT_FILTERS } from "./utils/filterPresets.js";
import { sortLayers } from "./engine/helpers/layerUtils.js";
import { normalizeStoryMusic } from "../audio/storyAudioManager.js";

const HISTORY_LIMIT = 40;

const createId = (prefix = "layer") =>
  `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;

const cloneFilters = (filters) => ({ ...DEFAULT_FILTERS, ...(filters || {}) });

const editorSnapshot = (state) => ({
  layers: state.layers,
  activeLayerId: state.activeLayerId,
  filters: state.filters,
  music: state.music,
  frame: state.frame,
  aspectRatio: state.aspectRatio,
});

const pushHistory = (state) => ({
  past: [...state.past.slice(-(HISTORY_LIMIT - 1)), editorSnapshot(state)],
  future: [],
});

const normalizeZIndexes = (layers) =>
  sortLayers(layers).map((layer, index) => ({ ...layer, zIndex: index }));

const normalizeLayer = (layer, fallbackZIndex = 0) => ({
  opacity: 1,
  rotation: 0,
  scaleX: 1,
  scaleY: 1,
  locked: false,
  visible: true,
  ...layer,
  filters: cloneFilters(layer.filters),
  zIndex: Number.isFinite(layer.zIndex) ? layer.zIndex : fallbackZIndex,
});

const removeMusicLayers = (layers) => layers.filter((layer) => layer.type !== "music");

const initialState = {
  layers: [],
  activeLayerId: null,
  past: [],
  future: [],
  filters: { ...DEFAULT_FILTERS },
  music: null,
  frame: null,
  aspectRatio: "9:16",
  revision: 0,
};

export const useCanvasStore = create((set, get) => ({
  ...initialState,

  resetEditor: () =>
    set({
      ...initialState,
      filters: { ...DEFAULT_FILTERS },
    }),

  createLayerId: createId,

  addLayer: (layer, options = {}) => {
    const { recordHistory = true, select = true } = options;
    const id = layer.id || createId(layer.type || "layer");

    set((state) => {
      const history = recordHistory ? pushHistory(state) : {};
      const nextLayer = normalizeLayer(
        {
          ...layer,
          id,
        },
        state.layers.length,
      );

      return {
        ...history,
        layers: normalizeZIndexes([...state.layers, nextLayer]),
        activeLayerId: select && !nextLayer.locked && nextLayer.visible !== false
          ? id
          : state.activeLayerId,
        revision: state.revision + 1,
      };
    });

    return id;
  },

  setLayers: (layers, options = {}) => {
    const { recordHistory = true } = options;
    set((state) => {
      const history = recordHistory ? pushHistory(state) : {};
      const normalizedLayers = normalizeZIndexes(
        layers.map((layer, index) => normalizeLayer(layer, index)),
      );
      const hasActiveLayer = normalizedLayers.some(
        (layer) => layer.id === state.activeLayerId && !layer.locked && layer.visible !== false,
      );

      return {
        ...history,
        layers: normalizedLayers,
        activeLayerId: hasActiveLayer ? state.activeLayerId : null,
        revision: state.revision + 1,
      };
    });
  },

  updateLayer: (id, patch, options = {}) => {
    const { recordHistory = true } = options;
    if (!id) return;

    set((state) => {
      const index = state.layers.findIndex((layer) => layer.id === id);
      if (index === -1) return state;

      const history = recordHistory ? pushHistory(state) : {};
      const layers = state.layers.map((layer) =>
        layer.id === id
          ? normalizeLayer(
              {
                ...layer,
                ...patch,
                filters: patch.filters ? { ...layer.filters, ...patch.filters } : layer.filters,
                style: patch.style ? { ...layer.style, ...patch.style } : layer.style,
              },
              index,
            )
          : layer,
      );
      const updatedLayer = layers.find((layer) => layer.id === id);
      const activeLayerId =
        state.activeLayerId === id &&
        (updatedLayer?.locked || updatedLayer?.visible === false)
          ? null
          : state.activeLayerId;

      return {
        ...history,
        layers,
        activeLayerId,
        revision: state.revision + 1,
      };
    });
  },

  removeLayer: (id, options = {}) => {
    const { recordHistory = true, force = false } = options;
    if (!id) return;

    set((state) => {
      const layer = state.layers.find((item) => item.id === id);
      if (!layer || (!force && (layer.locked || layer.type === "base"))) return state;
      const history = recordHistory ? pushHistory(state) : {};
      const layers = normalizeZIndexes(state.layers.filter((item) => item.id !== id));

      return {
        ...history,
        layers,
        activeLayerId: state.activeLayerId === id ? null : state.activeLayerId,
        revision: state.revision + 1,
      };
    });
  },

  duplicateLayer: (id) => {
    const layer = get().layers.find((item) => item.id === id);
    if (!layer || layer.locked || layer.type === "base") return null;

    const duplicate = {
      ...layer,
      id: createId(layer.type),
      name: `${layer.name || "Layer"} copy`,
      left: (layer.left || 0) + 36,
      top: (layer.top || 0) + 36,
      zIndex: get().layers.length,
    };

    return get().addLayer(duplicate);
  },

  reorderLayer: (id, direction) => {
    set((state) => {
      const ordered = sortLayers(state.layers);
      const movable = ordered.filter((layer) => layer.type !== "base" && !layer.locked);
      const currentIndex = movable.findIndex((layer) => layer.id === id);
      if (currentIndex === -1) return state;

      const targetIndex = direction === "up" ? currentIndex + 1 : currentIndex - 1;
      if (targetIndex < 0 || targetIndex >= movable.length) return state;

      const history = pushHistory(state);
      const nextMovable = [...movable];
      const [item] = nextMovable.splice(currentIndex, 1);
      nextMovable.splice(targetIndex, 0, item);

      const nextById = new Map(nextMovable.map((layer) => [layer.id, layer]));
      const next = ordered.map((layer) => nextById.get(layer.id) || layer);

      return {
        ...history,
        layers: normalizeZIndexes(next),
        revision: state.revision + 1,
      };
    });
  },

  reorderLayersByIds: (orderedIds, options = {}) => {
    const { topToBottom = true, recordHistory = true } = options;
    set((state) => {
      if (!Array.isArray(orderedIds) || orderedIds.length === 0) return state;

      const byId = new Map(state.layers.map((layer) => [layer.id, layer]));
      const visualOrder = orderedIds.map((id) => byId.get(id)).filter(Boolean);
      const bottomToTop = topToBottom ? [...visualOrder].reverse() : visualOrder;
      const fixed = state.layers.filter(
        (layer) => layer.type === "base" || layer.locked || !orderedIds.includes(layer.id),
      );
      const movable = bottomToTop.filter((layer) => layer.type !== "base" && !layer.locked);
      const merged = [...fixed.filter((layer) => layer.type === "base"), ...movable];

      state.layers.forEach((layer) => {
        if (!merged.some((item) => item.id === layer.id)) merged.push(layer);
      });

      const history = recordHistory ? pushHistory(state) : {};
      return {
        ...history,
        layers: normalizeZIndexes(merged),
        revision: state.revision + 1,
      };
    });
  },

  setActiveLayerId: (id) =>
    set((state) => {
      if (!id) return { activeLayerId: null };
      const layer = state.layers.find((item) => item.id === id);
      if (!layer || layer.locked || layer.visible === false) return { activeLayerId: null };
      return { activeLayerId: id };
    }),

  setGlobalFilters: (filters, options = {}) => {
    const { recordHistory = true } = options;
    set((state) => {
      const history = recordHistory ? pushHistory(state) : {};
      return {
        ...history,
        filters: cloneFilters({ ...state.filters, ...filters }),
        revision: state.revision + 1,
      };
    });
  },

  resetGlobalFilters: () =>
    set((state) => ({
      ...pushHistory(state),
      filters: { ...DEFAULT_FILTERS },
      revision: state.revision + 1,
    })),

  setLayerFilters: (id, filters, options = {}) => {
    get().updateLayer(id, { filters: cloneFilters(filters) }, options);
  },

  setMusic: (music, options = {}) => {
    const { recordHistory = true } = options;
    set((state) => {
      const normalizedMusic = normalizeStoryMusic(music);
      const history = recordHistory ? pushHistory(state) : {};
      const shouldReplaceSticker =
        normalizedMusic &&
        state.music?.id &&
        normalizedMusic.id &&
        state.music.id !== normalizedMusic.id;
      const layers = normalizedMusic && !shouldReplaceSticker
        ? state.layers
        : removeMusicLayers(state.layers);
      const activeLayerId =
        (normalizedMusic && !shouldReplaceSticker) ||
        !state.layers.some((layer) => layer.type === "music" && layer.id === state.activeLayerId)
          ? state.activeLayerId
          : null;

      return {
        ...history,
        music: normalizedMusic,
        layers: normalizeZIndexes(layers),
        activeLayerId,
        revision: state.revision + 1,
      };
    });
  },

  setFrame: (frame) =>
    set((state) => ({
      ...pushHistory(state),
      frame,
      revision: state.revision + 1,
    })),

  setAspectRatio: (aspectRatio) => {
    if (!ASPECT_RATIOS[aspectRatio]) return;
    set((state) => ({
      ...pushHistory(state),
      aspectRatio,
      revision: state.revision + 1,
    }));
  },

  undo: () =>
    set((state) => {
      if (!state.past.length) return state;
      const previous = state.past[state.past.length - 1];
      return {
        ...state,
        ...previous,
        past: state.past.slice(0, -1),
        future: [editorSnapshot(state), ...state.future],
        revision: state.revision + 1,
      };
    }),

  redo: () =>
    set((state) => {
      if (!state.future.length) return state;
      const next = state.future[0];
      return {
        ...state,
        ...next,
        past: [...state.past, editorSnapshot(state)].slice(-HISTORY_LIMIT),
        future: state.future.slice(1),
        revision: state.revision + 1,
      };
    }),
}));

export const selectActiveLayer = (state) =>
  state.layers.find((layer) => layer.id === state.activeLayerId) || null;
