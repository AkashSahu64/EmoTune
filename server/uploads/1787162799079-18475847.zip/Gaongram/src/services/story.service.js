import api from '../config/axios.js';

export const storyService = {
  // Get stories feed (followed users)
  getStoriesFeed: async () => {
    try {
      const response = await api.get('/stories-feed/');
      return response.data;
    } catch (error) {
      console.error('Error fetching stories feed:', error);
      throw error;
    }
  },

  // Get user's own stories
  getMyStories: async () => {
    try {
      const response = await api.get('/stories-me/');
      return response.data;
    } catch (error) {
      console.error('Error fetching user stories:', error);
      throw error;
    }
  },

  // Get single story by ID
  getStoryById: async (id) => {
    try {
      const response = await api.get(`/stories/${id}/`);
      return response.data;
    } catch (error) {
      console.error('Error fetching story by ID:', error);
      throw error;
    }
  },

  // Get story viewers list
  getStoryViewers: async (id) => {
    try {
      const response = await api.get(`/stories-viewers/${id}/`);
      return response.data;
    } catch (error) {
      console.error('Error fetching story viewers:', error);
      throw error;
    }
  },

  // Create new story
  createStory: async (formData, onProgress) => {
    try {
      const response = await api.post('/stories/', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (event) => {
          if (!event.total) return;
          const percent = Math.round((event.loaded * 100) / event.total);
          onProgress?.(percent);
        },
      });
      return response.data;
    } catch (error) {
      console.error('Error creating story:', error);
      throw error;
    }
  },

  // Delete story
  deleteStory: async (id) => {
    try {
      const response = await api.delete(`/stories/${id}/`);
      return response.data;
    } catch (error) {
      console.error('Error deleting story:', error);
      throw error;
    }
  },

  // Like/unlike a story
  likeToggle: async (storyId) => {
    try {
      const response = await api.post(`/stories/${storyId}/like-toggle/`);
      return response.data;
    } catch (error) {
      console.error('Error toggling story like:', error);
      throw error;
    }
  },
};


export const vibeAudioService = {
  /**
   * Fetch paginated audios
   */
  getAudios: async (page = 1) => {
    try {
      const res = await api.get(`/vibe-audios/?page=${page}`);

      const payload = res.data;

      const data = payload?.data;

      return {
        data: data?.results || [],
        next: data?.next || null,
        previous: data?.previous || null,
        count: data?.count || 0,
      };
    } catch (err) {
      console.error("Error fetching audios:", err);
      return {
        data: [],
        next: null,
        previous: null,
        count: 0,
      };
    }
  },
};