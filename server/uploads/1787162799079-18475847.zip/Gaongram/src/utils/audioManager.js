import { mediaController } from '../media/MediaController.js';

const resolveSrc = (src) => {
  if (!src || typeof window === 'undefined') return src || '';
  try {
    return new URL(src, window.location.href).href;
  } catch {
    return src;
  }
};

export const ensureAudioElement = (mediaId, src, type = 'audio') => {
  if (!mediaId) return null;

  // Get or create persistent container
  let container = document.getElementById('global-audio-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'global-audio-container';
    container.style.display = 'none';
    document.body.appendChild(container);
  }

  // Check if already registered
  let instance = mediaController.getMediaInstance(mediaId);
  if (instance && instance.element) {
    const nextSrc = resolveSrc(src);
    if (nextSrc && instance.element.src !== nextSrc && mediaController.activeMedia !== String(mediaId)) {
      instance.element.src = nextSrc;
    }
    mediaController.register(mediaId, instance.element, type);
    return instance.element;
  }

  // Create new audio element
  const audio = document.createElement('audio');
  audio.src = resolveSrc(src);
  audio.preload = 'metadata';
  audio.playsInline = true;
  audio.controls = false;
  audio.className = 'persistent-audio';
  container.appendChild(audio);

  // Register with MediaController
  mediaController.register(mediaId, audio, type);
  return audio;
};
