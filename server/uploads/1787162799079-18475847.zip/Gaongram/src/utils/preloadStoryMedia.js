export const preloadStoryMedia = (story) => {
  if (!story) return;
  if (story.story_type === 'video') {
    const video = document.createElement('video');
    video.src = story.story;
    video.preload = 'metadata';
  } else {
    const img = new Image();
    img.src = story.story;
  }
};