// src/features/feed/createPost/CreateAudioPostModal.jsx
import React, { useEffect, useMemo, useState } from "react";
import { X } from "lucide-react";
import { useAuthStore } from "../../../store/authStore.js";
import { useUIStore } from "../../../store/uiStore.js";
import { postCreateService } from "../../../services/postCreate.service.js";
import { showSuccess, showError } from "../../../utils/toast.js";
import Button from "../../../components/common/Button.jsx";
import UploadZone from "./UploadZone.jsx";
import PostCaptionEditor from "./PostCaptionEditor.jsx";
import { FEED_EVENTS, publishFeedEvent } from "../../../utils/feedEvents.js";
import SensitiveContentCheckbox from "./SensitiveContentCheckbox.jsx";

const ObjectUrlPreview = ({ file, type, alt, className }) => {
  const previewUrl = useMemo(() => URL.createObjectURL(file), [file]);

  useEffect(() => {
    return () => URL.revokeObjectURL(previewUrl);
  }, [previewUrl]);

  if (type === "audio") {
    return <audio controls src={previewUrl} className={className} />;
  }

  return <img src={previewUrl} alt={alt} className={className} />;
};

const CreateAudioPostModal = () => {
  const { user } = useAuthStore();
  const { closeModal } = useUIStore();

  const [caption, setCaption] = useState("");
  const [audio, setAudio] = useState(null);
  const [audioTitle, setAudioTitle] = useState("");
  const [coverImage, setCoverImage] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [privacy, setPrivacy] = useState("public");
  const [isSensitive, setIsSensitive] = useState(false);

  const handleAudioSelect = (file) => {
    if (file) setAudio(file);
  };

  const handleCoverSelect = (file) => {
    if (file) setCoverImage(file);
  };

  const handleSubmit = async () => {
  if (!audio) {
    showError("Please select an audio file");
    return;
  }

  setIsSubmitting(true);

  const formData = new FormData();

  // BASIC FIELDS
  formData.append("content", caption || "");
  formData.append("author", user?.id);
  formData.append("privacy", privacy);
  formData.append("is_sensitive", isSensitive);
  formData.append("show_profile", "false");

  // 🔥 AUDIO NESTED DATA (IMPORTANT)
  formData.append("audio.audio", audio); // FILE
  formData.append("audio.title", audioTitle || "Untitled");
  formData.append("audio.type", "others");

  // OPTIONAL COVER IMAGE
  if (coverImage) {
    formData.append("audio.cover_image", coverImage);
  }

  try {
    await postCreateService.createPost(formData);

    showSuccess("Audio post created!");
    closeModal();
    publishFeedEvent({ type: FEED_EVENTS.CREATED });
  } catch (err) {
    showError("Failed to create post");
  } finally {
    setIsSubmitting(false);
  }
};

  return (
    <div className="w-full max-w-lg bg-card dark:bg-card-dark rounded-2xl overflow-hidden">

      {/* 🔥 HEADER (Same style as image/video) */}
      <div className="sticky top-0 z-20 border-b border-border dark:border-border-dark px-4 py-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold">Create Audio Post</h2>

          <button
            onClick={closeModal}
            className="p-2 rounded-full hover:bg-mutedForeground/20 dark:hover:bg-mutedForeground-dark/30 transition"
          >
            <X className="w-4 h-4 text-foreground dark:text-foreground-dark" />
          </button>
        </div>
      </div>

      {/* 🔥 BODY SCROLL AREA */}
      <div className="max-h-[75vh] overflow-y-auto px-4 py-4 space-y-4 hide-scrollbar">

        {/* USER ROW */}
        {/* <div className="flex items-center gap-3">
          <Avatar src={user?.avatar} alt={user?.username} size="medium" />

          <div>
            <p className="text-sm font-semibold">{user?.username}</p>

            <select
              value={privacy}
              onChange={(e) => setPrivacy(e.target.value)}
              className="text-xs text-foreground dark:text-foreground-dark bg-transparent outline-none"
            >
              <option value="public">🌍 Public</option>
              <option value="friends">👥 Friends</option>
              <option value="private">🔒 Private</option>
            </select>
          </div>
        </div> */}

        {/* CAPTION */}
        <div>
          <PostCaptionEditor caption={caption} setCaption={setCaption} />
        </div>

        {/* AUDIO TITLE */}
        <input
          type="text"
          value={audioTitle}
          onChange={(e) => setAudioTitle(e.target.value)}
          placeholder="Audio title"
          className="w-full px-4 py-2 border rounded-lg text-sm bg-transparent focus:ring-2 focus:ring-primary/80 focus:outline-none"
        />

        {/* AUDIO UPLOAD */}
        <div>
          <p className="text-sm font-medium mb-2">Audio File</p>

          <UploadZone
            onFileSelect={handleAudioSelect}
            accept="audio/*"
            maxSizeMB={50}
            multiple={false}
          />

          {/* AUDIO PREVIEW */}
          {audio && (
            <div className="mt-3">
              <ObjectUrlPreview file={audio} type="audio" className="w-full" />
            </div>
          )}
        </div>

        {/* COVER IMAGE */}
        <div>
          <p className="text-sm font-medium mb-2">Cover Image (optional)</p>

          <UploadZone
            onFileSelect={handleCoverSelect}
            accept="image/*"
            maxSizeMB={5}
            multiple={false}
          />

          {coverImage && (
            <div className="mt-3 flex justify-center">
              <ObjectUrlPreview
                file={coverImage}
                alt="cover preview"
                className="w-32 h-32 object-cover rounded-lg"
              />
            </div>
          )}
        </div>

        <SensitiveContentCheckbox
          checked={isSensitive}
          onChange={setIsSensitive}
        />

        {/* SUBMIT */}
        <Button
          variant="primary"
          fullWidth
          onClick={handleSubmit}
          loading={isSubmitting}
          disabled={!audio}
        >
          Post
        </Button>
      </div>
    </div>
  );
};

export default CreateAudioPostModal;
