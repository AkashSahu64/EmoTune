// pages/Audio.jsx
import AudioPage from './audio/AudioPage.jsx';

export default AudioPage;