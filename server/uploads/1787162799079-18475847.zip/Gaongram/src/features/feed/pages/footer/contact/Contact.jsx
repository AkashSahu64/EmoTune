// src/pages/Contact.jsx
import React, { useState } from "react";
import { motion, useInView } from "framer-motion";
import {
  MapPin,
  Send,
  CheckCircle,
  Globe,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import MinimalLayout from "../../../components/layout/MinimalLayout";
import Seo from "../../../../../components/seo/Seo.jsx";
import { buildStaticPageSeo } from "../../../../../seo/seoBuilders.js";

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.25, 0.1, 0.25, 1] },
  },
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1, delayChildren: 0.1 },
  },
};

const scaleIn = {
  hidden: { opacity: 0, scale: 0.96 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { duration: 0.5, ease: [0.25, 0.1, 0.25, 1] },
  },
};

const useAnimateOnView = (threshold = 0.2) => {
  const ref = React.useRef(null);
  const isInView = useInView(ref, { once: true, amount: threshold });
  return { ref, isInView };
};

const FAQItem = ({ question, answer, isOpen, onClick }) => {
  return (
    <div className="border-b border-border/30 dark:border-border-dark/30 last:border-0">
      <button
        onClick={onClick}
        className="w-full py-5 flex items-center justify-between text-left group"
      >
        <span className="font-medium text-foreground dark:text-foreground-dark group-hover:text-primary transition-colors">
          {question}
        </span>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.25, ease: [0.25, 0.1, 0.25, 1] }}
          className="p-1 rounded-full text-mutedForeground group-hover:text-primary transition-colors"
        >
          <ChevronDown className="w-5 h-5" />
        </motion.div>
      </button>
      <motion.div
        initial={false}
        animate={{ height: isOpen ? "auto" : 0, opacity: isOpen ? 1 : 0 }}
        transition={{ duration: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
        className="overflow-hidden"
      >
        <p className="pb-5 text-mutedForeground dark:text-mutedForeground-dark leading-relaxed">
          {answer}
        </p>
      </motion.div>
    </div>
  );
};

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "Support",
    message: "",
  });
  const [formStatus, setFormStatus] = useState("idle");
  const [errors, setErrors] = useState({});
  const [openFAQ, setOpenFAQ] = useState(null);

  const heroRef = useAnimateOnView();
  const formRef = useAnimateOnView();
  const faqRef = useAnimateOnView();

  const faqs = [
    {
      q: "How quickly can I expect a reply?",
      a: "We aim to respond to all inquiries within 24 hours. Priority support is available for emergency reports.",
    },
    {
      q: "Can I report a safety concern anonymously?",
      a: "Yes, our reporting system allows anonymous submissions. Your identity is protected.",
    },
    {
      q: "Is my data secure when I contact support?",
      a: "Absolutely. All communication is encrypted and adheres to our strict privacy policy.",
    },
    {
      q: "What details should I include in my message?",
      a: "Please include as much relevant information as possible, such as screenshots, usernames, or links. This helps our team resolve your issue faster.",
    },
    {
      q: "Do you provide support in regional languages?",
      a: "Yes, we support multiple Indian languages to ensure a smooth experience for all users across different regions.",
    },
  ];

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = "Name is required";
    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Email is invalid";
    }
    if (!formData.message.trim()) newErrors.message = "Message is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    setFormStatus("loading");
    setTimeout(() => {
      setFormStatus("success");
      setFormData({ name: "", email: "", subject: "Support", message: "" });
      setTimeout(() => setFormStatus("idle"), 4000);
    }, 1500);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: null }));
    }
  };

  return (
    <MinimalLayout>
      <Seo {...buildStaticPageSeo("contact")} />
      <div className="min-h-screen bg-background dark:bg-background-dark">
        <div className="fixed inset-0 -z-10 overflow-hidden">
          <div className="absolute top-0 -left-20 w-[600px] h-[600px] bg-primary/8 rounded-full blur-3xl opacity-50" />
          <div className="absolute bottom-0 -right-20 w-[600px] h-[600px] bg-primary/8 rounded-full blur-3xl opacity-50" />
        </div>

        <section
          ref={heroRef.ref}
          className="relative pt-8 md:pt-12 lg:pt-16 pb-8"
        >
          <div className="max-w-5xl mx-auto px-4 text-center">
            <motion.div
              initial="hidden"
              animate={heroRef.isInView ? "visible" : "hidden"}
              variants={staggerContainer}
            >
              <motion.h1
                variants={fadeUp}
                className="text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight text-foreground dark:text-foreground-dark mb-12"
              >
                We're here to help
              </motion.h1>
              <motion.p
                variants={fadeUp}
                className="text-lg md:text-xl text-mutedForeground dark:text-mutedForeground-dark max-w-3xl mx-auto"
              >
                Reach out to our friendly support team. We'll get back to you as
                soon as possible.
              </motion.p>
            </motion.div>
          </div>
        </section>

        <section ref={formRef.ref} className="py-8 md:py-12">
          <div className="max-w-6xl mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
              <motion.div
                initial="hidden"
                animate={formRef.isInView ? "visible" : "hidden"}
                variants={scaleIn}
                className="relative bg-white/70 dark:bg-card-dark/70 backdrop-blur-2xl rounded-3xl p-6 md:p-8 border border-gray-200 dark:border-border-dark/30 overflow-hidden"
              >
                {/* subtle gradient glow */}
                <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10 opacity-30 pointer-events-none" />

                <div className="relative">
                  <h2 className="text-2xl md:text-3xl font-bold mb-1 text-foreground dark:text-foreground-dark">
                    Send a message
                  </h2>
                  <p className="text-mutedForeground mb-6">
                    We'll get back to you as soon as possible.
                  </p>

                  <form onSubmit={handleSubmit} className="space-y-5">
                    {/* NAME */}
                    <div className="space-y-1.5">
                      <label className="text-sm font-medium text-foreground dark:text-foreground-dark">
                        Full name
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Ramesh Kumar"
                        className={`w-full px-4 py-3 rounded-xl border bg-background/60 dark:bg-background-dark/60 backdrop-blur-md transition-all duration-300 focus:outline-none focus:ring-2 ${
                          errors.name
                            ? "border-red-400 ring-red-200"
                            : "border-border/40 focus:ring-primary/30 focus:border-primary/50 hover:border-primary/40"
                        }`}
                      />
                      {errors.name && (
                        <p className="text-red-500 text-xs">{errors.name}</p>
                      )}
                    </div>

                    {/* EMAIL */}
                    <div className="space-y-1.5">
                      <label className="text-sm font-medium text-foreground dark:text-foreground-dark">
                        Email address
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="ramesh@example.com"
                        className={`w-full px-4 py-3 rounded-xl border bg-background/60 dark:bg-background-dark/60 backdrop-blur-md transition-all duration-300 focus:outline-none focus:ring-2 ${
                          errors.email
                            ? "border-red-400 ring-red-200"
                            : "border-border/40 focus:ring-primary/30 focus:border-primary/50 hover:border-primary/40"
                        }`}
                      />
                      {errors.email && (
                        <p className="text-red-500 text-xs">{errors.email}</p>
                      )}
                    </div>

                    {/* SUBJECT */}
                    <div className="space-y-1.5">
                      <label className="text-sm font-medium text-foreground dark:text-foreground-dark">
                        What can we help with?
                      </label>
                      <select
                        name="subject"
                        value={formData.subject}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-xl border bg-background/60 dark:bg-background-dark/60 backdrop-blur-md transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/50 hover:border-primary/40"
                      >
                        <option value="Support">General Support</option>
                        <option value="Report">Report a Problem</option>
                        <option value="Feedback">Feedback</option>
                        <option value="Business">Business Inquiry</option>
                      </select>
                    </div>

                    {/* MESSAGE */}
                    <div className="space-y-1.5">
                      <label className="text-sm font-medium text-foreground dark:text-foreground-dark">
                        Message
                      </label>
                      <textarea
                        rows="4"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        placeholder="Tell us more..."
                        className={`w-full px-4 py-3 rounded-xl border bg-background/60 dark:bg-background-dark/60 backdrop-blur-md transition-all duration-300 focus:outline-none focus:ring-2 resize-none ${
                          errors.message
                            ? "border-red-400 ring-red-200"
                            : "border-border/40 focus:ring-primary/30 focus:border-primary/50 hover:border-primary/40"
                        }`}
                      />
                      {errors.message && (
                        <p className="text-red-500 text-xs">{errors.message}</p>
                      )}
                    </div>

                    {/* BUTTON */}
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.97 }}
                      type="submit"
                      disabled={formStatus === "loading"}
                      className={`w-full py-2 text-xl rounded-xl font-medium transition-all flex items-center justify-center gap-2 ${
                        formStatus === "success"
                          ? "bg-green-500 text-white shadow-lg shadow-green-500/30"
                          : "bg-primary text-white shadow-lg shadow-primary/30 hover:shadow-primary/50"
                      }`}
                    >
                      {formStatus === "loading" ? (
                        <>
                          <svg
                            className="animate-spin h-5 w-5"
                            viewBox="0 0 24 24"
                          >
                            <circle
                              className="opacity-25"
                              cx="12"
                              cy="12"
                              r="10"
                              stroke="currentColor"
                              strokeWidth="4"
                              fill="none"
                            />
                            <path
                              className="opacity-75"
                              fill="currentColor"
                              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                            />
                          </svg>
                          Sending...
                        </>
                      ) : formStatus === "success" ? (
                        <>
                          <CheckCircle size={24} /> Message Sent!
                        </>
                      ) : (
                        <>
                          <Send size={24} /> Send Message
                        </>
                      )}
                    </motion.button>

                    {/* TRUST TEXT */}
                    <p className="text-sm text-mutedForeground text-center pt-2">
                      🔒 Your information is safe. We never share your data.
                    </p>
                  </form>
                </div>
              </motion.div>

              <motion.div
                initial="hidden"
                animate={formRef.isInView ? "visible" : "hidden"}
                variants={staggerContainer}
                className="space-y-3"
              >
                {/* ADDRESS CARD */}
                <motion.div
                  variants={fadeUp}
                  // whileHover={{ y: -4 }}
                  className="relative bg-white/70 dark:bg-card-dark/70 backdrop-blur-2xl rounded-2xl py-4 px-6 border border-gray-200 dark:border-border-dark/30 shadow-[0_1px_50px_rgba(0,0,0,0.06)] overflow-hidden transition-all"
                >
                  {/* subtle gradient glow */}
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-accent/10 opacity-30 pointer-events-none" />

                  <div className="relative flex items-start gap-4">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                      <MapPin className="text-primary" size={24} />
                    </div>

                    <div>
                      <h2 className="font-semibold text-xl text-foreground dark:text-foreground-dark">
                        Visit us
                      </h2>
                      <p className="text-md text-mutedForeground leading-relaxed">
                        GaonGram Technologies Pvt. Ltd. <br />
                        Priti Nagar, Anna Market, Lucknow - 226001, Uttar
                        Pradesh, India
                      </p>
                    </div>
                  </div>
                </motion.div>

                {/* FAQ SECTION */}
                <section ref={faqRef.ref} className="py-8">
                  <div className="max-w-4xl mx-auto">
                    <motion.div
                      initial="hidden"
                      animate={faqRef.isInView ? "visible" : "hidden"}
                      variants={staggerContainer}
                    >
                      <motion.h2
                        variants={fadeUp}
                        className="text-4xl font-bold text-center mb-8 text-foreground dark:text-foreground-dark"
                      >
                        Frequently Asked Questions
                      </motion.h2>

                      <motion.div
                        variants={fadeUp}
                        className="bg-white/70 dark:bg-card-dark/70 backdrop-blur-2xl rounded-2xl border border-gray-200 dark:border-border-dark/30 divide-y divide-border/20 dark:divide-border-dark/20 overflow-hidden"
                      >
                        {faqs.map((faq, idx) => (
                          <div
                            key={idx}
                            className="px-4 md:px-6 hover:bg-primary/5 transition-colors duration-300"
                          >
                            <FAQItem
                              question={faq.q}
                              answer={faq.a}
                              isOpen={openFAQ === idx}
                              onClick={() =>
                                setOpenFAQ(openFAQ === idx ? null : idx)
                              }
                            />
                          </div>
                        ))}
                      </motion.div>
                    </motion.div>
                  </div>
                </section>

                {/* TRUST / SECURITY CARD */}
                <motion.div
                  variants={fadeUp}
                  whileHover={{ scale: 1.005 }}
                  className="relative flex items-center gap-4 px-5 py-3 rounded-2xl bg-gradient-to-br from-primary/10 via-transparent to-accent/10 backdrop-blur-xl border border-primary/20 shadow-sm overflow-hidden"
                >
                  {/* glow effect */}
                  <div className="absolute inset-0 bg-primary/5 blur-2xl opacity-30 pointer-events-none" />

                  <div className="relative w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center flex-shrink-0">
                    <Globe className="w-5 h-5 text-primary" />
                  </div>

                  <p className="relative text-sm text-mutedForeground leading-relaxed">
                    All data is encrypted and stored in India. Your privacy is
                    our priority.
                  </p>
                </motion.div>
              </motion.div>
            </div>
          </div>
        </section>
      </div>
    </MinimalLayout>
  );
};

export default Contact;
