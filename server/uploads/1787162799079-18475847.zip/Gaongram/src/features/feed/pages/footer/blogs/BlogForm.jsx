// src/features/blogs/pages/BlogForm.jsx
import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import Button from "../../../../../components/common/Button";
import BlogFormFields from "./BlogFormFields";
import blogService from "../../../../../services/blogService";
import { useBlog } from "../../../../../hooks/useBlog";
import { showSuccess, showError } from "../../../../../utils/toast";
import { canEditBlog } from "../../../../../utils/blogPermissions";
import PublicLayout from "../../../components/layout/PublicLayout";

const BlogForm = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(id);
  const { blog, loading: loadingBlog } = useBlog(isEdit ? id : null);

  const [formData, setFormData] = useState({
    title: "",
    content: "",
    meta_title: "",
    meta_description: "",
    title_hi: "",
    content_hi: "",
    meta_title_hi: "",
    meta_description_hi: "",
    title_ur: "",
    content_ur: "",
    meta_title_ur: "",
    meta_description_ur: "",
    slug: "",
    is_staff_post: false,
    image: null,
    image_alt_text: "",
    is_published: false,
    allow_comments: true,
    is_featured: false,
    category: "",
  });

  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [authChecked, setAuthChecked] = useState(false);

  // Authorization check when editing
  useEffect(() => {
    if (isEdit && !loadingBlog && blog) {
      if (!canEditBlog(blog)) {
        showError("You are not authorized to edit this blog.");
        navigate("/blogs");
      } else {
        setAuthChecked(true);
      }
    } else if (!isEdit) {
      setAuthChecked(true);
    }
  }, [isEdit, loadingBlog, blog, navigate]);

  // Populate form when editing and authorized
  useEffect(() => {
    if (isEdit && blog && authChecked) {
      setFormData({
        title: blog.title || "",
        content: blog.content || "",
        meta_title: blog.meta_title || "",
        meta_description: blog.meta_description || "",
        title_hi: blog.title_hi || "",
        content_hi: blog.content_hi || "",
        meta_title_hi: blog.meta_title_hi || "",
        meta_description_hi: blog.meta_description_hi || "",
        title_ur: blog.title_ur || "",
        content_ur: blog.content_ur || "",
        meta_title_ur: blog.meta_title_ur || "",
        meta_description_ur: blog.meta_description_ur || "",
        slug: blog.slug || "",
        is_staff_post: blog.is_staff_post || false,
        image: blog.image || null,
        image_alt_text: blog.image_alt_text || "",
        is_published: blog.is_published || false,
        allow_comments: blog.allow_comments || true,
        is_featured: blog.is_featured || false,
        category: blog.category || "",
      });
    }
  }, [blog, isEdit, authChecked]);

  const validate = () => {
    const newErrors = {};
    if (!formData.title?.trim()) newErrors.title = "Title is required";
    if (!formData.content?.trim()) newErrors.content = "Content is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    // Additional ownership check for edit
    if (isEdit && !canEditBlog(blog)) {
      showError("You are not authorized to edit this blog.");
      navigate("/blogs");
      return;
    }

    setSubmitting(true);
    setErrors({});

    try {
      const payload = new FormData();
      Object.entries(formData).forEach(([key, value]) => {
        if (key === "image") {
          if (value instanceof File) {
            payload.append("image", value);
          }
        } else if (value !== null && value !== undefined) {
          payload.append(key, value);
        }
      });

      let response;
      if (isEdit) {
        response = await blogService.updateBlog(id, payload);
      } else {
        response = await blogService.createBlog(payload);
      }

      if (response.success) {
        showSuccess(
          isEdit ? "Blog updated successfully" : "Blog created successfully",
        );
        navigate(`/blogs/${response.data.id}`);
      } else {
        if (response.errors) {
          setErrors(response.errors);
        } else {
          showError(response.message || "Something went wrong");
        }
      }
    } catch (error) {
      console.error("Submit error:", error);
      if (error.response?.data?.errors) {
        setErrors(error.response.data.errors);
      } else {
        showError(error.message || "Failed to save blog");
      }
    } finally {
      setSubmitting(false);
    }
  };

  // Show loading state while checking auth
  if (isEdit && (loadingBlog || !authChecked)) {
    return (
      <div className="container max-w-4xl mx-auto px-4 py-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/3" />
          <div className="h-64 bg-muted rounded" />
        </div>
      </div>
    );
  }

  return (
    <PublicLayout>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="container max-w-4xl mx-auto px-4 py-8"
      >
        <div className="mb-8">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-viral-pink bg-clip-text text-transparent">
            {isEdit ? "Edit Blog" : "Create New Blog"}
          </h1>
          <p className="text-mutedForeground dark:text-mutedForeground-dark mt-1">
            {isEdit
              ? "Update your blog post"
              : "Share your thoughts with the world"}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="bg-card dark:bg-card-dark rounded-xl2 p-6 md:p-8 shadow-soft border border-border dark:border-border-dark">
            <BlogFormFields
              formData={formData}
              setFormData={setFormData}
              errors={errors}
              isEdit={isEdit}
            />
          </div>

          <div className="flex justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate(-1)}
              disabled={submitting}
            >
              Cancel
            </Button>
            <Button type="submit" loading={submitting}>
              {isEdit ? "Update Blog" : "Publish Blog"}
            </Button>
          </div>
        </form>
      </motion.div>
    </PublicLayout>
  );
};

export default BlogForm;
