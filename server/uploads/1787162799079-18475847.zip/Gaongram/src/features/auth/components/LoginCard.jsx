// src/features/auth/components/LoginCard.jsx
import React, { useState } from "react";
import { motion } from "framer-motion";
import { Link, useNavigate } from "react-router-dom";
import { Mail, Lock, Eye, EyeOff } from "lucide-react";
import { FcGoogle } from "react-icons/fc";
import { useAuthStore } from "../../../store/authStore.js";
import { useUIStore } from "../../../store/uiStore.js";
// import { showError } from "../../../utils/toast.js";
import Button from "../../../components/common/Button.jsx";
import logo from "../../../assets/logo.png";
import { API_BASE_URL } from "../../../config/env.js";

const LoginCard = () => {
  const navigate = useNavigate();
  const { login, loading } = useAuthStore();
  const { modal, closeModal } = useUIStore();
  const onSuccess = modal.data?.onSuccess;

  const [formData, setFormData] = useState({
    identifier: "",
    password: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState("");

  const validateForm = () => {
    const newErrors = {};
    if (!formData.identifier.trim()) {
      newErrors.identifier = "Email / Username / Phone is required";
    }
    if (!formData.password) {
      newErrors.password = "Password is required";
    } else if (formData.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    try {
      const result = await login({
        email: formData.identifier,
        password: formData.password,
      });
      if (result.success) {
        navigate("/verify-otp", {
          state: { email: formData.email },
        });
      } else {
        // ✅ GLOBAL ERROR
        setServerError(result.message || "Registration failed");

        // ✅ FIELD LEVEL ERRORS
        if (result.errors) {
          const formattedErrors = {};

          Object.keys(result.errors).forEach((key) => {
            formattedErrors[key] = result.errors[key][0];
          });

          setErrors((prev) => ({
            ...prev,
            ...formattedErrors,
          }));
        }
      }
    } catch (error) {
      showError("An unexpected error occurred");
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  return (
    <div className="backdrop-blur-md bg-light-card/10 shadow-premium border border-gray-100/30 rounded-xl3 px-6 py-3">
      {/* Logo */}
      <div className="flex justify-center mb-2">
        <img
          src={logo}
          alt="GaonGram Logo"
          className="w-28 h-28 object-contain drop-shadow-premium"
        />
      </div>

      {/* Server Error */}
      {serverError && (
        <div className="mb-3 p-2 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm text-center">
          {serverError}
        </div>
      )}

      {/* Heading */}
      <h2 className="text-2xl font-bold text-white">Welcome Back 👋</h2>
      <p className="text-light-subtext text-sm mb-6">Log in to your account</p>

      <form className="space-y-4" onSubmit={handleSubmit}>
        {/* Identifier Field */}
        <motion.div
          animate={errors.identifier ? { x: [0, -4, 4, -4, 0] } : {}}
          transition={{ duration: 0.3 }}
        >
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Mail className="h-5 w-5 text-light-subtext" />
            </div>
            <input
              id="identifier"
              name="identifier"
              type="text"
              autoComplete="email"
              value={formData.identifier}
              onChange={handleChange}
              className={`block w-full pl-10 pr-3 py-2 border ${
                errors.identifier ? "border-danger" : "border-light-border/50"
              } rounded-lg bg-light-card/20 placeholder-light-subtext text-light-text focus:outline-none focus:ring-2 focus:ring-instagram-pink focus:border-transparent transition-shadow`}
              placeholder="Email or phone number"
            />
          </div>
          {errors.identifier && (
            <p className="mt-1 text-sm text-danger">{errors.identifier}</p>
          )}
        </motion.div>

        {/* Password Field */}
        <motion.div
          animate={errors.password ? { x: [0, -4, 4, -4, 0] } : {}}
          transition={{ duration: 0.3 }}
        >
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Lock className="h-5 w-5 text-light-subtext" />
            </div>
            <input
              id="password"
              name="password"
              type={showPassword ? "text" : "password"}
              autoComplete="current-password"
              value={formData.password}
              onChange={handleChange}
              className={`block w-full pl-10 pr-10 py-2 border ${
                errors.password ? "border-danger" : "border-light-border/50"
              } rounded-lg bg-light-card/20 placeholder-light-subtext text-light-text focus:outline-none focus:ring-2 focus:ring-instagram-pink focus:border-transparent transition-shadow`}
              placeholder="Password"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute inset-y-0 right-0 pr-3 flex items-center"
            >
              {showPassword ? (
                <EyeOff className="h-5 w-5 text-light-subtext" />
              ) : (
                <Eye className="h-5 w-5 text-light-subtext" />
              )}
            </button>
          </div>
          {errors.password && (
            <p className="mt-1 text-sm text-danger">{errors.password}</p>
          )}
        </motion.div>

        {/* Remember me & Forgot password */}
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <input
              id="remember-me"
              name="remember-me"
              type="checkbox"
              className="h-3 w-3 rounded border-light-border text-primary focus:ring-primary"
            />
            <label
              htmlFor="remember-me"
              className="ml-2 text-sm text-light-subtext"
            >
              Remember me
            </label>
          </div>
          <div className="text-sm">
            <Link
              to="/forgot-password"
              className="font-medium text-light-subtext hover:text-light-subtext/80 transition-colors"
            >
              Forgot password?
            </Link>
          </div>
        </div>

        {/* Login Button */}
        <motion.div
          whileHover={{ scale: 1.01 }}
          //   transition={{ type: "spring", stiffness: 400, damping: 10 }}
        >
          <Button
            type="submit"
            variant="primary"
            size="medium"
            loading={loading}
            fullWidth
            className="py-2.5 text-base font-semibold bg-green-950/80 hover:bg-green-950/100 text-white shadow-premium hover:shadow-emerald transition-all"
          >
            Log in
          </Button>
        </motion.div>

        {/* Divider */}
        <div className="relative my-8 flex items-center">
          <div className="flex-1 h-px bg-light-border/60"></div>
          <span className="mx-4 px-3 py-1 text-xs text-light-subtext bg-light-card/20 backdrop-blur-sm rounded-full border border-white/10">
            or continue with
          </span>
          <div className="flex-1 h-px bg-light-border/60"></div>
        </div>

        {/* Google Login */}
        <Button
          type="button"
          size="medium"
          fullWidth
          onClick={() =>
            (window.location.href = `${API_BASE_URL}/auth/google/`)
          }
          className="py-2.5 border border-light-border/50 bg-light-card/20 hover:bg-light-muted/25 flex items-center justify-center"
        >
          <FcGoogle className="w-5 h-5 mr-2" />
          Continue with Google
        </Button>
      </form>

      {/* Sign up link */}
      <p className="mt-8 text-center text-sm text-light-subtext">
        Don't have an account?{" "}
        <Link
          to="/register"
          className="font-medium text-viral-blue hover:text-viral-blue/80 transition-colors"
        >
          Sign up
        </Link>
      </p>

      {/* Terms & Privacy */}
      <div className="mt-6">
        <p className="text-xs text-center text-light-subtext/70">
          By continuing, you agree to our{" "}
          <a href="/terms" className="text-instagram-pink hover:underline">
            Terms
          </a>{" "}
          and{" "}
          <a href="/privacy" className="text-instagram-pink hover:underline">
            Privacy Policy
          </a>
          .
        </p>
      </div>
    </div>
  );
};

export default LoginCard;
