import React, { useState } from "react";
import { Eye, Plus } from "lucide-react";
import { formatNumber } from "../../../utils/formatTime.js";
import AudioMuteButton from "./AudioMuteButton.jsx";
import ExplorePlaylistButton from "../../../components/playlist/ExplorePlaylistButton.jsx";
import PlaylistBottomSheet from "../../../components/playlist/PlaylistBottomSheet.jsx";
import { useTranslation } from "react-i18next";

const AudioCover = React.memo(
  ({
    audioId,
    coverImage,
    audioTitle,
    audioError,
    hasError,
    viewsCount,
    isMuted,
    onToggleMute,
    children,
    isPlaylistMode = false,
  }) => {
    const [isBottomSheetOpen, setIsBottomSheetOpen] = useState(false);
    const { t } = useTranslation();  

    const getCoverImage = () => {
      return coverImage || "https://gaongram.com/preview.png";
    };

    const handlePlusClick = () => {
      setIsBottomSheetOpen(true);
    };

    return (
      <div className="relative h-[60%] bg-gradient-to-b from-gray-900 to-black">
        <img
          src={getCoverImage()}
          alt={audioTitle || t("audio_cover")} 
          className="w-full h-full object-cover opacity-60"
          onError={(e) => {
            e.target.src = "https://gaongram.com/preview.png";
          }}
        />

        {children}

        <AudioMuteButton isMuted={isMuted} onToggleMute={onToggleMute} />

        <ExplorePlaylistButton />

        {/* Error Indicator */}
        {(audioError || hasError) && (
          <div className="absolute top-4 left-4 bg-red-500/90 text-white px-3 py-1.5 rounded-full text-xs backdrop-blur-sm">
            {t("audio_unavailable")} 
          </div>
        )}

        {/* Views count */}
        {viewsCount > 0 && (
          <div className="absolute top-4 right-4 flex items-center space-x-1 bg-black/50 text-white px-1.5 py-1 rounded-full text-xs backdrop-blur-sm">
            <Eye className="w-3.5 h-3.5" />
            <span className="font-medium">
              {formatNumber(viewsCount)} 
            </span>
          </div>
        )}

        {/* Plus button */}
        {!isPlaylistMode && (
          <button
            onClick={handlePlusClick}
            disabled={audioError || hasError}
            className="absolute bottom-4 right-4 p-1.5 bg-black/50 text-white rounded-full backdrop-blur-sm hover:bg-black/70 transition-colors z-10 disabled:opacity-40"
            aria-label={t("add_to_playlist")} 
          >
            <Plus className="w-5.5 h-5.5" />
          </button>
        )}

        {/* Bottom Sheet */}
        {isBottomSheetOpen && (
          <PlaylistBottomSheet
            isOpen={isBottomSheetOpen}
            onClose={() => setIsBottomSheetOpen(false)}
            audioId={Number(audioId)}
            audioTitle={audioTitle}
          />
        )}
      </div>
    );
  }
);

AudioCover.displayName = "AudioCover";

export default AudioCover;
