// src/features/feed/createPost/PostCaptionEditor.jsx
import React from 'react';
import EmojiPickerInput from './EmojiPickerInput';

const PostCaptionEditor = ({ caption, setCaption }) => {
  return (
    <div className="mb-2">
      <label className="block font-medium text-foreground dark:text-foreground-dark mb-2">Caption</label>
      <EmojiPickerInput
        value={caption}
        onChange={setCaption}
        placeholder="Write a caption..."
        rows={2}
      />
    </div>
  );
};

export default PostCaptionEditor;