import api from '../config/axios.js';
import { showSuccess, showError } from '../utils/toast.js';

const unwrap = (payload) => payload?.data?.data ?? payload?.data ?? payload;

const normalizePaginatedPlaylists = (payload) => {
  const data = unwrap(payload);
  if (Array.isArray(data)) {
    return { results: data, next: null, previous: null, count: data.length };
  }
  return {
    count: data?.count ?? 0,
    next: data?.next ?? null,
    previous: data?.previous ?? null,
    results: Array.isArray(data?.results) ? data.results : [],
  };
};

const normalizePlaylist = (payload) => {
  const data = unwrap(payload);
  return {
    ...data,
    items: Array.isArray(data?.items) ? data.items : [],
  };
};

const buildPlaylistFormData = (data = {}) => {
  const title = String(data.title || '').trim();
  if (!title && data.title !== undefined) {
    throw new Error('Playlist title is required');
  }

  const formData = new FormData();
  if (title) formData.append('title', title);
  if (data.is_public !== undefined) {
    formData.append('is_public', data.is_public ? 'true' : 'false');
  }
  if (typeof File !== 'undefined' && data.cover_image instanceof File) {
    formData.append('cover_image', data.cover_image);
  }
  return formData;
};

class PlaylistService {
  async getPlaylists(params = {}) {
    try {
      const res = await api.get('/playlists/', { params });
      const data = normalizePaginatedPlaylists(res);
      return { success: true, data, nextCursor: data.next };
    } catch (error) {
      console.error('Failed to fetch playlists:', error);
      return {
        success: false,
        data: { count: 0, next: null, previous: null, results: [] },
        nextCursor: null,
      };
    }
  }

  async getPlaylistDetail(id) {
    try {
      const res = await api.get(`/playlists/${id}/`);
      return { success: true, data: normalizePlaylist(res) };
    } catch (error) {
      console.error(`Failed to fetch playlist ${id}:`, error);
      showError('Could not load playlist');
      throw error;
    }
  }

  async createPlaylist(data) {
    try {
      const formData = buildPlaylistFormData(data);
      const res = await api.post('/playlists/', formData);
      showSuccess('Playlist created');
      return { success: true, data: normalizePlaylist(res) };
    } catch (error) {
      console.error('Create playlist failed:', error);
      showError(error.message || 'Failed to create playlist');
      throw error;
    }
  }

  async updatePlaylist(id, data) {
    try {
      const formData = buildPlaylistFormData(data);
      const res = await api.patch(`/playlists/${id}/`, formData);
      showSuccess('Playlist updated');
      return { success: true, data: normalizePlaylist(res) };
    } catch (error) {
      console.error(`Update playlist ${id} failed:`, error);
      showError(error.message || 'Update failed');
      throw error;
    }
  }

  async addAudioToPlaylist(playlistId, audioId) {
    try {
      const res = await api.post(`/playlists/${playlistId}/`, { audio_id: audioId });
      showSuccess('Added to playlist');
      return { success: true, data: unwrap(res) };
    } catch (error) {
      console.error(`Add audio ${audioId} to playlist ${playlistId} failed:`, error);
      showError('Could not add audio');
      throw error;
    }
  }

  async removeAudioFromPlaylist(playlistId, audioId) {
    try {
      await api.delete(`/playlists/${playlistId}/`, { data: { audio_id: audioId } });
      showSuccess('Removed from playlist');
      return { success: true };
    } catch (error) {
      console.error(`Remove audio ${audioId} from playlist ${playlistId} failed:`, error);
      showError('Could not remove audio');
      throw error;
    }
  }

  async deletePlaylist(playlistId) {
    try {
      await api.delete(`/playlists/${playlistId}/`, {
        data: { delete_playlist: true },
      });
      showSuccess('Playlist deleted');
      return { success: true };
    } catch (error) {
      console.error(`Delete playlist ${playlistId} failed:`, error);
      showError('Could not delete playlist');
      throw error;
    }
  }
}

export const playlistService = new PlaylistService();
