import React, { useEffect } from "react";
import { HelmetProvider } from "react-helmet-async";
import { BrowserRouter } from "react-router-dom";
import { QueryClientProvider } from "@tanstack/react-query";
// import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { Toaster } from "react-hot-toast";
import Router from "./Router.jsx";
import Providers from "./Providers.jsx";
import ErrorBoundary from "./ErrorBoundary.jsx";
import { useMediaStore } from "../store/mediaStore.js";
import MiniPlayerWrapper from "../pages/audio/components/MiniPlayerWrapper.jsx";
import { SocketProvider } from "../context/SocketProvider.jsx";
import { queryClient } from "./queryClient.js";
import { useAuthStore } from "../store/authStore.js";
import { initializeTheme } from "../utils/theme.js";

const App = () => {
  useEffect(() => {
    initializeTheme();

    const handleAuthInvalid = () => {
      useAuthStore.getState().clearSession({ notify: false });
    };

    const handleUserInteraction = () => {
      const mediaStore = useMediaStore.getState();
      if (!mediaStore.userInteracted) {
        mediaStore.setUserInteracted();
      }
    };
    window.addEventListener("gaongram:auth-invalid", handleAuthInvalid);
    window.addEventListener("click", handleUserInteraction);
    window.addEventListener("touchstart", handleUserInteraction);
    window.addEventListener("keydown", handleUserInteraction);
    return () => {
      window.removeEventListener("gaongram:auth-invalid", handleAuthInvalid);
      window.removeEventListener("click", handleUserInteraction);
      window.removeEventListener("touchstart", handleUserInteraction);
      window.removeEventListener("keydown", handleUserInteraction);
    };
  }, []);

  return (
    <SocketProvider>
      <ErrorBoundary>
        <HelmetProvider>
          <QueryClientProvider client={queryClient}>
            <BrowserRouter>
              <Providers>
                <Router />
                <MiniPlayerWrapper />
              </Providers>
            </BrowserRouter>
          </QueryClientProvider>
        </HelmetProvider>

        <Toaster
          position="top-center"
          gutter={12}
          containerStyle={{ margin: "8px" }}
          toastOptions={{
            success: { duration: 3000 },
            error: { duration: 5000 },
          }}
        />
        <div id="global-audio-container" style={{ display: "none" }} />
      </ErrorBoundary>
    </SocketProvider>
  );
};

export default App;