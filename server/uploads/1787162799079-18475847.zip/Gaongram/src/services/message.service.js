// src/services/messageService.js
import api from "../config/axios.js";

export const messageService = {
  // Send a new message
 sendMessage: async (receiverId, data) => {
  const formData = new FormData();

  formData.append("receiver", receiverId);

  if (data.message?.trim()) {
    formData.append("message", data.message.trim());
  }

  // ✅ FIXED HERE
  if (data.files && data.files.length > 0) {
    data.files.forEach((file) => {
      formData.append("files", file); // 🔥 IMPORTANT
    });
  }

  formData.append("file_type", data.file_type || "others");
  formData.append("read_status", "sent");
  formData.append("message_status", "active");

  try {
    const response = await api.post("/messages/", formData);
    return response.data;
  } catch (error) {
    console.log("ERROR RESPONSE:", error.response?.data);
    throw error;
  }
},

  // Get message history with another user
  getMessageHistory: async (receiverId, page = 1) => {
    const response = await api.get(`/messages-history/${receiverId}/`, {
      params: { page },
    });
    return response.data;
  },

  // Get all chat users
  getChatUsers: async (page = 1) => {
    const response = await api.get("/messages-users/", { params: { page } });
    return response.data;
  },

  // Get single message
  getMessage: async (messageId) => {
    const response = await api.get(`/messages/${messageId}/`);
    return response.data;
  },

  // Update message (full)
  updateMessage: async (messageId, data) => {
    const response = await api.put(`/messages/${messageId}/`, data);
    return response.data;
  },

  // Patch message (partial)
  patchMessage: async (messageId, data) => {
    const payload = {
      receiver: data.receiver,
      message: data.message ?? "", // ✅ safe fallback
      file: data.file ?? null,
      file_type: data.file_type || "others", // ✅ REQUIRED
      read_status: data.read_status || "sent",
      message_status: data.message_status || "active",
    };

    const response = await api.patch(`/messages/${messageId}/`, payload);
    return response.data;
  },

  // Delete message
  deleteMessage: async (messageId, forEveryone = false) => {
  if (!messageId) {
    throw new Error("Message ID is required");
  }

  const formData = new FormData();
  formData.append("id", messageId);
  formData.append("delete_for_me", !forEveryone);

  const response = await api.delete(`/messages/${messageId}/`, {
    data: formData,
  });

  return response.data;
},

  // Clear entire chat
  clearChat: async (receiverId) => {
    const response = await api.post(`/messages-clear-all/${receiverId}/`);
    return response.data;
  },

  // Block/unblock user
  toggleBlockUser: async (userId) => {
    const response = await api.post(`/block-user-toggle/${userId}/`);
    return response.data;
  },

  // Mark message as read (helper)
  markMessagesAsRead: async (messages, receiverId) => {
    const promises = messages.map((msg) =>
      api.patch(`/messages/${msg.id}/`, {
        receiver: receiverId,
        message: msg.message || "",
        file: msg.file || null,
        file_type: msg.file_type || "others",
        read_status: "sent",
        message_status: "active",
      }),
    );

    await Promise.all(promises);
  },
};
