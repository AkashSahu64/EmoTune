// components/EditProfileDetailsModal.jsx
import React, { useState, useEffect } from 'react';
import { X, Globe, Lock } from 'lucide-react';
import { motion } from 'framer-motion';
import Button from '../../../components/common/Button';
import { showToast } from '../../../utils/toast';

const EditProfileDetailsModal = ({
  isOpen,
  onClose,
  profile,
  onUpdate,
  isUpdating
}) => {
  const [formData, setFormData] = useState({
    first_name: profile?.first_name || '',
    last_name: profile?.last_name || '',
    username: profile?.username || '',
    bio: profile?.bio || '',
    external_link: profile?.external_link || '',
    dob: profile?.dob ? profile.dob.split('T')[0] : '',
    is_private: profile?.is_private || false,
    gender: profile?.gender || '',
    address: profile?.address || '',
    city: profile?.city || '',
    state: profile?.state || '',
    country: profile?.country || '',
    pin_code: profile?.pin_code || '',
  });

  useEffect(() => {
    if (profile) {
      // Handle gender: "not_selected" should be treated as empty (editable)
      let genderValue = profile?.gender || '';
      if (genderValue === 'not_selected') {
        genderValue = '';
      }

      setFormData({
        first_name: profile?.first_name || '',
        last_name: profile?.last_name || '',
        username: profile?.username || '',
        bio: profile?.bio || '',
        external_link: profile?.external_link || '',
        dob: profile?.dob ? profile.dob.split('T')[0] : '',
        is_private: profile?.is_private || false,
        gender: genderValue,
        address: profile?.address || '',
        city: profile?.city || '',
        state: profile?.state || '',
        country: profile?.country || '',
        pin_code: profile?.pin_code || '',
      });
    }
  }, [profile]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = {
      first_name: formData.first_name,
      last_name: formData.last_name,
      bio: formData.bio,
      external_link: formData.external_link,
      dob: formData.dob,
      is_private: formData.is_private,
      gender: formData.gender,
      address: formData.address,
      city: formData.city,
      state: formData.state,
      country: formData.country,
      pin_code: formData.pin_code,
    };
    try {
      await onUpdate({ data: payload });
      onClose();
    } catch {
      showToast('Failed to update profile', 'error');
    }
  };

  if (!isOpen) return null;

  // Helper: field is locked if it has a real value (not null, not empty, not "not_selected")
  const isFieldLocked = (value) => {
    return value !== null && value !== '' && value !== 'not_selected';
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-6">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm"
          onClick={onClose}
        />

        {/* Modal */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative bg-white dark:bg-card-dark rounded-xl shadow-xl w-full max-w-md overflow-hidden"
        >
          {/* Header */}
          <div className="px-6 py-2 border-b border-border dark:border-border-dark bg-gradient-to-r from-gaon-cream to-white dark:from-gray-800 dark:to-card-dark">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-foreground dark:text-foreground-dark">
                Edit Profile
              </h3>
              <button
                onClick={onClose}
                className="p-1.5 text-gray-400 hover:text-foreground dark:hover:text-foreground-dark hover:bg-gray-100 dark:hover:bg-muted-dark rounded-lg transition-colors"
              >
                <X size={20} />
              </button>
            </div>
          </div>

          {/* Form */}
          <form
            onSubmit={handleSubmit}
            className="max-h-[60vh] md:max-h-[70vh] overflow-y-auto hide-scrollbar"
          >
            <div className="py-2 px-6 space-y-4">
              {/* Names */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  label="First Name"
                  value={formData.first_name}
                  onChange={(v) => setFormData({ ...formData, first_name: v })}
                />
                <Input
                  label="Last Name"
                  value={formData.last_name}
                  onChange={(v) => setFormData({ ...formData, last_name: v })}
                />
              </div>

              {/* Username (disabled) */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-mutedForeground-dark mb-2">
                  Username
                </label>
                <input
                  type="text"
                  value={formData.username}
                  disabled
                  className="w-full px-2 py-2 border border-gray-200 dark:border-border-dark rounded-md bg-gray-100 dark:bg-muted-dark cursor-not-allowed text-gray-500 dark:text-gray-400"
                />
              </div>

              {/* Bio */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-mutedForeground-dark mb-2">
                  Bio
                </label>
                <textarea
                  rows={3}
                  value={formData.bio}
                  onChange={(e) =>
                    setFormData({ ...formData, bio: e.target.value })
                  }
                  className="w-full px-2 py-2 border border-gray-200 dark:border-border-dark rounded-md focus:ring-2 focus:ring-primary/20 focus:border-primary resize-none transition-all bg-white dark:bg-card-dark text-foreground dark:text-foreground-dark"
                />
                <div className="text-right text-xs text-gray-500 dark:text-gray-400 mt-2">
                  {formData.bio.length}/150
                </div>
              </div>

              {/* Website */}
              <Input
                label="Website"
                placeholder="https://example.com"
                value={formData.external_link || ''}
                onChange={(v) =>
                  setFormData({ ...formData, external_link: v })
                }
              />

              {/* Date of Birth */}
              <Input
                label="Date of Birth"
                type="date"
                value={formData.dob}
                onChange={(v) => setFormData({ ...formData, dob: v })}
              />

              {/* Gender (select) */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-mutedForeground-dark mb-2">
                  Gender
                </label>
                <select
                  value={formData.gender}
                  onChange={(e) =>
                    setFormData({ ...formData, gender: e.target.value })
                  }
                  disabled={isFieldLocked(profile?.gender)}
                  className={`w-full px-2 py-2 border border-gray-200 dark:border-border-dark rounded-md focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all bg-white dark:bg-card-dark text-foreground dark:text-foreground-dark ${
                    isFieldLocked(profile?.gender)
                      ? 'bg-gray-100 dark:bg-muted-dark cursor-not-allowed'
                      : ''
                  }`}
                >
                  <option value="">Select gender</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                  <option value="prefer_not_to_say">Prefer not to say</option>
                </select>
                {isFieldLocked(profile?.gender) && (
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Gender is already set and cannot be changed.
                  </p>
                )}
              </div>

              {/* Location fields */}
              <Input
                label="Address"
                value={formData.address}
                onChange={(v) => setFormData({ ...formData, address: v })}
                disabled={isFieldLocked(profile?.address)}
                helpText={
                  isFieldLocked(profile?.address)
                    ? 'Address is already set and cannot be changed.'
                    : undefined
                }
              />
              <Input
                label="City"
                value={formData.city}
                onChange={(v) => setFormData({ ...formData, city: v })}
                disabled={isFieldLocked(profile?.city)}
                helpText={
                  isFieldLocked(profile?.city)
                    ? 'City is already set and cannot be changed.'
                    : undefined
                }
              />
              <Input
                label="State"
                value={formData.state}
                onChange={(v) => setFormData({ ...formData, state: v })}
                disabled={isFieldLocked(profile?.state)}
                helpText={
                  isFieldLocked(profile?.state)
                    ? 'State is already set and cannot be changed.'
                    : undefined
                }
              />
              <Input
                label="Country"
                value={formData.country}
                onChange={(v) => setFormData({ ...formData, country: v })}
                disabled={isFieldLocked(profile?.country)}
                helpText={
                  isFieldLocked(profile?.country)
                    ? 'Country is already set and cannot be changed.'
                    : undefined
                }
              />
              <Input
                label="Pin Code"
                value={formData.pin_code}
                onChange={(v) => setFormData({ ...formData, pin_code: v })}
                disabled={isFieldLocked(profile?.pin_code)}
                helpText={
                  isFieldLocked(profile?.pin_code)
                    ? 'Pin code is already set and cannot be changed.'
                    : undefined
                }
              />

              {/* Privacy Toggle */}
              <div className="p-2 bg-gradient-to-r from-gray-50 to-gray-100 dark:from-muted-dark dark:to-muted-dark rounded-md border border-gray-200 dark:border-border-dark">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {formData.is_private ? (
                      <div className="p-2 bg-red-50 dark:bg-red-900/20 rounded-lg">
                        <Lock className="w-5 h-5 text-red-600 dark:text-red-400" />
                      </div>
                    ) : (
                      <div className="p-2 bg-green-50 dark:bg-green-900/20 rounded-lg">
                        <Globe className="w-5 h-5 text-green-600 dark:text-green-400" />
                      </div>
                    )}
                    <div>
                      <p className="font-medium text-gray-900 dark:text-foreground-dark">
                        {formData.is_private ? 'Private Account' : 'Public Account'}
                      </p>
                      <p className="text-sm text-gray-600 dark:text-mutedForeground-dark">
                        {formData.is_private
                          ? 'Only approved followers can see your posts'
                          : 'Anyone can see your posts and follow you'}
                      </p>
                    </div>
                  </div>

                  {/* Toggle */}
                  <button
                    type="button"
                    role="switch"
                    aria-checked={formData.is_private}
                    onClick={() =>
                      setFormData({
                        ...formData,
                        is_private: !formData.is_private,
                      })
                    }
                    className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${
                      formData.is_private ? 'bg-red-500' : 'bg-green-500'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        formData.is_private ? 'translate-x-5' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="sticky bottom-0 bg-white dark:bg-card-dark border-t border-border dark:border-border-dark px-6 py-2">
              <div className="flex justify-end gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClose}
                  disabled={isUpdating}
                  className="border-gray-300 dark:border-border-dark text-foreground dark:text-foreground-dark hover:bg-gray-50 dark:hover:bg-muted-dark rounded-lg px-4"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  loading={isUpdating}
                  disabled={isUpdating}
                  className="bg-primary hover:bg-primary-light rounded-lg px-2 shadow-md text-white"
                >
                  {isUpdating ? 'Saving...' : 'Save Changes'}
                </Button>
              </div>
            </div>
          </form>
        </motion.div>
      </div>
    </div>
  );
};

/* Reusable input with dark mode support and optional disabled state */
const Input = ({ label, value, onChange, placeholder, type = 'text', disabled, helpText }) => (
  <div>
    <label className="block text-sm font-medium text-gray-700 dark:text-mutedForeground-dark mb-2">
      {label}
    </label>
    <input
      type={type}
      value={value}
      placeholder={placeholder}
      onChange={(e) => onChange(e.target.value)}
      disabled={disabled}
      className={`w-full px-2 py-2 border border-gray-200 dark:border-border-dark rounded-md focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all bg-white dark:bg-card-dark text-foreground dark:text-foreground-dark ${
        disabled
          ? 'bg-gray-100 dark:bg-muted-dark cursor-not-allowed'
          : ''
      }`}
    />
    {helpText && (
      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{helpText}</p>
    )}
  </div>
);

export default EditProfileDetailsModal;