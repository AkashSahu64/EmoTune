/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,jsx}"],

  theme: {
    extend: {
      colors: {
        // Brand core
        primary: {
          DEFAULT: "#0E4D38",
          light: "#116149",
          soft: "#1B7A5A",
        },

        // Viral accent
        viral: {
          pink: "#E1306C",
          purple: "#833AB4",
          orange: "#F77737",
          blue: "#3B82F6",
        },

        // Gold premium
        accent: {
          DEFAULT: "#C6A75E",
          light: "#E6C77A",
          soft: "#F3DFA2",
        },

        // Semantic light mode
        background: {
          DEFAULT: "#FAFAFB",
          dark: "#0B0F14",
        },
        card: {
          DEFAULT: "#FFFFFF",
          dark: "#121821",
        },
        muted: {
          DEFAULT: "#F3F4F6",
          dark: "#1A222C",
        },
        border: {
          DEFAULT: "#E5E7EB",
          dark: "#263041",
        },
        foreground: {
          DEFAULT: "#111827",
          dark: "#F3F4F6",
        },
        mutedForeground: {
          DEFAULT: "#7b7b7b",
          dark: "#9CA3AF",
        },

        // Original light/dark objects (kept for compatibility)
        light: {
          bg: "#FAFAFB",
          card: "#FFFFFF",
          muted: "#F3F4F6",
          border: "#E5E7EB",
          text: "#111827",
          subtext: "#D1D5DB",
        },
        dark: {
          bg: "#0B0F14",
          card: "#121821",
          muted: "#1A222C",
          border: "#263041",
          text: "#F3F4F6",
          subtext: "#9CA3AF",
        },

        // Status colors
        success: "#22C55E",
        warning: "#F59E0B",
        danger: "#EF4444",
        info: "#3B82F6",
      },

      backgroundImage: {
        "hero-social":
          "linear-gradient(135deg, #0E4D38 0%, #833AB4 40%, #E1306C 70%, #F77737 100%)",
        "login-hero":
          "linear-gradient(180deg, #0F2F34 0%, #173E3F 60%, #214A46 100%)",
        "story-ring": "linear-gradient(45deg, #833AB4, #E1306C, #F77737)",
        "emerald-glow":
          "radial-gradient(circle at top left, rgba(17,97,73,0.4), transparent)",
        "viral-glow":
          "radial-gradient(circle at center, rgba(225,48,108,0.35), transparent)",
        "dark-overlay": "linear-gradient(to top, rgba(0,0,0,0.7), transparent)",
        "glass-shine":
          "linear-gradient(145deg, rgba(255,255,255,0.06), transparent)",
      },

      fontFamily: {
        sans: [
          "Inter",
          "SF Pro Display",
          "-apple-system",
          "BlinkMacSystemFont",
          "Segoe UI",
          "Roboto",
          "Helvetica",
          "Arial",
          "sans-serif",
        ],
      },

      animation: {
        "fade-in": "fadeIn 0.4s ease-out",
        "slide-up": "slideUp 0.3s ease-out",
        "float-slow": "float 6s ease-in-out infinite",
        "pulse-soft": "pulseSoft 2.5s ease-in-out infinite",
        "bounce-soft": "bounceSoft 1.5s infinite",
        "glow-pulse": "glowPulse 2s ease-in-out infinite",
      },

      keyframes: {
        fadeIn: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        slideUp: {
          "0%": { transform: "translateY(12px)", opacity: "0" },
          "100%": { transform: "translateY(0)", opacity: "1" },
        },
        float: {
          "0%,100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-8px)" },
        },
        pulseSoft: {
          "0%,100%": { opacity: "1" },
          "50%": { opacity: "0.75" },
        },
        bounceSoft: {
          "0%,100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-4px)" },
        },
        glowPulse: {
          "0%,100%": {
            boxShadow: "0 0 15px rgba(225,48,108,0.4)",
          },
          "50%": {
            boxShadow: "0 0 25px rgba(225,48,108,0.7)",
          },
        },
      },

      boxShadow: {
        soft: "0 5px 20px rgba(0,0,0,0.06)",
        premium: "0 10px 30px rgba(0,0,0,0.12)",
        "premium-dark": "0 10px 30px rgba(0,0,0,0.6)",
        glow: "0 0 25px rgba(225,48,108,0.45)",
        emerald: "0 0 25px rgba(17,97,73,0.4)",
      },

      borderRadius: {
        xl2: "1.25rem",
        xl3: "1.75rem",
      },
    },
  },

  plugins: [],
}