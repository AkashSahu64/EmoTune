/* eslint-env node */
/* global process, console */
import { existsSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import {
  buildPlaceholderProfile,
  buildProfileHtml,
  fetchProfileByIdentifier,
  fetchPublicProfiles,
  getApiBaseUrl,
  getSiteUrl,
  normalizeProfile,
  writeProfileSnapshot,
} from "./profile-seo.mjs";

const scriptDir = dirname(fileURLToPath(import.meta.url));

const readFallbackProfiles = () => {
  const fallbackPath = resolve(scriptDir, "profiles.json");
  if (!existsSync(fallbackPath)) return [];

  try {
    const parsed = JSON.parse(readFileSync(fallbackPath, "utf8"));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

const configuredProfiles = () => {
  if (!process.env.PROFILE_USERNAMES) return [];

  return process.env.PROFILE_USERNAMES.split(",")
    .map((username) => username.trim())
    .filter(Boolean)
    .map((username) => ({ username }));
};

const uniqueProfiles = (profiles) => {
  const seen = new Set();
  const result = [];

  for (const profile of profiles) {
    const normalized = normalizeProfile(profile);
    const key = normalized.username || normalized.id;
    if (!key || seen.has(String(key).toLowerCase())) continue;

    seen.add(String(key).toLowerCase());
    result.push(profile);
  }

  return result;
};

async function loadProfilesToSnapshot() {
  const explicit = configuredProfiles();
  if (explicit.length) return explicit;

  const publicProfiles = await fetchPublicProfiles();
  if (publicProfiles.length) return publicProfiles;

  return readFallbackProfiles();
}

async function main() {
  console.log("Generating profile SEO snapshots...");
  console.log(`Site URL: ${getSiteUrl()}`);
  console.log(`API URL: ${getApiBaseUrl()}`);

  const templatePath = resolve("dist", "index.html");
  if (!existsSync(templatePath)) {
    throw new Error("dist/index.html is missing. Run the Vite build first.");
  }

  const templateHtml = readFileSync(templatePath, "utf8");
  const profiles = uniqueProfiles(await loadProfilesToSnapshot());

  if (!profiles.length) {
    console.warn("No profiles were available for static snapshot generation.");
    return;
  }

  let generated = 0;
  for (const profileSeed of profiles) {
    const normalizedSeed = normalizeProfile(profileSeed);
    const identifier = normalizedSeed.username || normalizedSeed.id;
    if (!identifier) continue;

    try {
      const profile = await fetchProfileByIdentifier(identifier);
      const html = buildProfileHtml(templateHtml, profile, identifier);
      const normalized = normalizeProfile(profile, identifier);
      const primaryIdentifier = normalized.username || identifier;
      writeProfileSnapshot(primaryIdentifier, html);
      if (normalized.userId && String(normalized.userId) !== String(primaryIdentifier)) {
        writeProfileSnapshot(normalized.userId, html);
      }
      if (normalized.id && String(normalized.id) !== String(primaryIdentifier)) {
        writeProfileSnapshot(normalized.id, html);
      }
      generated += 1;
      console.log(`Generated /profile/${primaryIdentifier}`);
    } catch (error) {
      const profile = buildPlaceholderProfile(identifier);
      const html = buildProfileHtml(templateHtml, profile, identifier);
      writeProfileSnapshot(identifier, html);
      generated += 1;
      console.warn(
        `Generated fallback /profile/${identifier}: ${error.message}`,
      );
    }
  }

  console.log(`Profile snapshots generated: ${generated}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
