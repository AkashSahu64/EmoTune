import React, { useState } from "react";
import { motion } from "framer-motion";
import { Link, useNavigate } from "react-router-dom";
import { Mail, Lock, User, Phone, Eye, EyeOff } from "lucide-react";
import { FcGoogle } from "react-icons/fc";
import { useAuthStore } from "../../../store/authStore.js";
// import { showError } from '../../../utils/toast.js';
import Button from "../../../components/common/Button.jsx";
import Seo from "../../../components/seo/Seo.jsx";
import { buildStaticPageSeo } from "../../../seo/seoBuilders.js";
import logo from "../../../assets/logo.png";

// Hero components (same as Login)
import SocialHeroStack from "../components/authHero/SocialHeroStack.jsx";
import AnalyticsGlassPanel from "../components/authHero/AnalyticsGlassPanel";
import ReelPreviewCard from "../components/authHero/ReelPreviewCard";
import FloatingEmojis from "../components/authHero/FloatingEmojis";

const Register = () => {
  const navigate = useNavigate();
  const { register, loading } = useAuthStore();
  const [serverError, setServerError] = useState("");

  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({});

  // Image URLs (same as Login)
  const cardImages = [
    // Influencer taking selfie for social media
    "https://images.unsplash.com/photo-1544723795-3fb6469f5b39?q=80&w=1200&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1556740738-b6a63e27c4df?w=400&h=600&fit=crop&auto=format",
    "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=400&h=600&fit=crop&auto=format",
  ];
  const validateForm = () => {
    const newErrors = {};

    if (!formData.fullName.trim()) {
      newErrors.fullName = "Full name is required";
    } else if (formData.fullName.length < 3) {
      newErrors.fullName = "Full name must be at least 3 characters";
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Email is invalid";
    }

    if (!formData.phone.trim()) {
      newErrors.phone = "Phone number is required";
    } else if (!/^[0-9]{10,15}$/.test(formData.phone.replace(/\D/g, ""))) {
      newErrors.phone = "Phone number is invalid (10-15 digits)";
    }

    if (!formData.password) {
      newErrors.password = "Password is required";
    } else if (formData.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters";
    }

    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) return;

    setServerError(""); // reset

    try {
      const userData = {
        full_name: formData.fullName,
        email: formData.email,
        phone: formData.phone,
        password: formData.password,
      };

      const result = await register(userData);

      if (result.success) {
        navigate("/verify-otp", {
          state: { email: formData.email },
        });
      } else {
        // ✅ GLOBAL ERROR
        setServerError(result.message || "Registration failed");

        // ✅ FIELD LEVEL ERRORS
        if (result.errors) {
          const formattedErrors = {};

          Object.keys(result.errors).forEach((key) => {
            formattedErrors[key] = result.errors[key][0];
          });

          setErrors((prev) => ({
            ...prev,
            ...formattedErrors,
          }));
        }
      }
    } catch (error) {
      setServerError("Something went wrong");
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: "",
      }));
    }
  };

  return (
    <>
      <Seo {...buildStaticPageSeo("register")} />

      <div className="min-h-screen bg-login-hero flex items-center justify-center px-3 sm:px-4 lg:px-6 pt-8 pb-8">
        {/* Two-column layout: left 2/3, right 1/3 */}
        <div className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-3 gap-2 lg:gap-4 items-center relative">
          {/* LEFT SIDE – Social Hero Stack (col-span-2) */}
          <div className="hidden lg:block relative h-[680px] w-full col-span-2 overflow-visible pt-20">
            {/* Background glow layer - z-0 */}
            <div className="absolute inset-0 blur-3xl opacity-20 bg-viral-purple/60 rounded-full z-0" />

            <SocialHeroStack images={cardImages} />
          </div>

          {/* CENTER GAP COMPONENTS */}
          <AnalyticsGlassPanel />
          <ReelPreviewCard />
          <FloatingEmojis />

          {/* RIGHT SIDE – Register Card (col-span-1) */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="w-full max-w-sm mx-auto lg:mx-0 lg:ml-auto col-span-1"
          >
            <div className="backdrop-blur-md bg-light-card/10 shadow-premium border border-gray-100/30 rounded-xl3 px-6 py-2">
              {/* Logo */}
              <div className="flex justify-center mb-2">
                <img
                  src={logo}
                  alt="GaonGram Logo"
                  className="w-28 h-28 object-contain drop-shadow-premium"
                />
              </div>

              {/* Server Error */}
              {serverError && (
                <div className="mb-3 p-2 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm text-center">
                  {serverError}
                </div>
              )}

              {/* Heading */}
              <h2 className="text-2xl font-bold text-white">
                Create account 👋
              </h2>
              <p className="text-light-subtext text-sm mb-5">
                Sign up to get started
              </p>

              <form className="space-y-3" onSubmit={handleSubmit}>
                {/* Full Name Field */}
                <div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <User className="h-5 w-5 text-light-subtext" />
                    </div>
                    <input
                      id="fullName"
                      name="fullName"
                      type="text"
                      autoComplete="name"
                      value={formData.fullName}
                      onChange={handleChange}
                      className={`block w-full pl-10 pr-3 py-2 border ${
                        errors.fullName
                          ? "border-danger"
                          : "border-light-border/50"
                      } rounded-lg bg-light-card/20 placeholder-light-subtext text-light-text focus:outline-none focus:ring-2 focus:ring-instagram-pink focus:border-transparent transition-shadow`}
                      placeholder="Full name"
                    />
                  </div>
                  {errors.fullName && (
                    <p className="mt-1 text-sm text-danger">
                      {errors.fullName}
                    </p>
                  )}
                </div>

                {/* Email Field */}
                <div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Mail className="h-5 w-5 text-light-subtext" />
                    </div>
                    <input
                      id="email"
                      name="email"
                      type="email"
                      autoComplete="email"
                      value={formData.email}
                      onChange={handleChange}
                      className={`block w-full pl-10 pr-3 py-2 border ${
                        errors.email
                          ? "border-danger"
                          : "border-light-border/50"
                      } rounded-lg bg-light-card/20 placeholder-light-subtext text-light-text focus:outline-none focus:ring-2 focus:ring-instagram-pink focus:border-transparent transition-shadow`}
                      placeholder="Email address"
                    />
                  </div>
                  {errors.email && (
                    <p className="mt-1 text-sm text-danger">{errors.email}</p>
                  )}
                </div>

                {/* Phone Field */}
                <div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Phone className="h-5 w-5 text-light-subtext" />
                    </div>
                    <input
                      id="phone"
                      name="phone"
                      type="tel"
                      autoComplete="tel"
                      value={formData.phone}
                      onChange={handleChange}
                      className={`block w-full pl-10 pr-3 py-2 border ${
                        errors.phone
                          ? "border-danger"
                          : "border-light-border/50"
                      } rounded-lg bg-light-card/20 placeholder-light-subtext text-light-text focus:outline-none focus:ring-2 focus:ring-instagram-pink focus:border-transparent transition-shadow`}
                      placeholder="Phone number"
                    />
                  </div>
                  {errors.phone && (
                    <p className="mt-1 text-sm text-danger">{errors.phone}</p>
                  )}
                </div>

                {/* Password Field */}
                <div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Lock className="h-5 w-5 text-light-subtext" />
                    </div>
                    <input
                      id="password"
                      name="password"
                      type={showPassword ? "text" : "password"}
                      autoComplete="new-password"
                      value={formData.password}
                      onChange={handleChange}
                      className={`block w-full pl-10 pr-10 py-2 border ${
                        errors.password
                          ? "border-danger"
                          : "border-light-border/50"
                      } rounded-lg bg-light-card/20 placeholder-light-subtext text-light-text focus:outline-none focus:ring-2 focus:ring-instagram-pink focus:border-transparent transition-shadow`}
                      placeholder="Password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center"
                    >
                      {showPassword ? (
                        <EyeOff className="h-5 w-5 text-light-subtext" />
                      ) : (
                        <Eye className="h-5 w-5 text-light-subtext" />
                      )}
                    </button>
                  </div>
                  {errors.password && (
                    <p className="mt-1 text-sm text-danger">
                      {errors.password}
                    </p>
                  )}
                </div>

                {/* Confirm Password Field */}
                <div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Lock className="h-5 w-5 text-light-subtext" />
                    </div>
                    <input
                      id="confirmPassword"
                      name="confirmPassword"
                      type={showPassword ? "text" : "password"}
                      autoComplete="new-password"
                      value={formData.confirmPassword}
                      onChange={handleChange}
                      className={`block w-full pl-10 pr-10 py-2 border ${
                        errors.confirmPassword
                          ? "border-danger"
                          : "border-light-border/50"
                      } rounded-lg bg-light-card/20 placeholder-light-subtext text-light-text focus:outline-none focus:ring-2 focus:ring-instagram-pink focus:border-transparent transition-shadow`}
                      placeholder="Confirm password"
                    />
                  </div>
                  {errors.confirmPassword && (
                    <p className="mt-1 text-sm text-danger">
                      {errors.confirmPassword}
                    </p>
                  )}
                </div>

                {/* Terms Agreement */}
                <div className="flex items-center">
                  <input
                    id="terms"
                    name="terms"
                    type="checkbox"
                    required
                    className="h-3 w-3 rounded border-light-border text-primary focus:ring-primary"
                  />
                  <label
                    htmlFor="terms"
                    className="ml-2 text-sm text-light-subtext"
                  >
                    I agree to the{" "}
                    <a
                      href="/terms"
                      className="text-instagram-pink hover:underline"
                    >
                      Terms
                    </a>{" "}
                    and{" "}
                    <a
                      href="/privacy"
                      className="text-instagram-pink hover:underline"
                    >
                      Privacy Policy
                    </a>
                  </label>
                </div>

                {/* Submit Button */}
                <Button
                  type="submit"
                  variant="primary"
                  size="medium"
                  loading={loading}
                  fullWidth
                  className="py-2.5 text-base font-semibold bg-green-950/80 hover:bg-green-950/100 text-white shadow-premium hover:shadow-emerald transition-all"
                >
                  Create Account
                </Button>

                {/* Divider */}
                <div className="relative my-8 flex items-center">
                  <div className="flex-1 h-px bg-light-border/60"></div>
                  <span className="mx-4 px-3 py-1 text-xs text-light-subtext bg-light-card/20 backdrop-blur-sm rounded-full border border-white/10">
                    or sign up with
                  </span>
                  <div className="flex-1 h-px bg-light-border/60"></div>
                </div>

                {/* Google Sign Up */}
                <Button
                  type="button"
                  size="medium"
                  fullWidth
                  onClick={() => navigate("/auth/google")}
                  className="py-2.5 border border-light-border/50 bg-light-card/20 hover:bg-light-muted/25 flex items-center justify-center"
                >
                  <FcGoogle className="w-5 h-5 mr-2" />
                  Continue with Google
                </Button>
              </form>

              {/* Sign in link */}
              <p className="mt-3 text-center text-sm text-light-subtext">
                Already have an account?{" "}
                <Link
                  to="/login"
                  className="font-medium text-viral-blue hover:text-viral-blue/80 transition-colors"
                >
                  Sign in
                </Link>
              </p>

              {/* Additional Info */}
              <div className="mt-4">
                <p className="text-xs text-center text-light-subtext/70">
                  By signing up, you agree to receive email updates and
                  promotions. You can unsubscribe at any time.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default Register;
