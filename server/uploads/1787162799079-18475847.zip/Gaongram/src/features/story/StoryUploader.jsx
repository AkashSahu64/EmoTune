import React, { lazy, Suspense, useEffect, useRef, useState } from "react";
import {
  AlertCircle,
  Camera,
  Image as ImageIcon,
  Loader2,
  UploadCloud,
  Video,
  X,
} from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { AnimatePresence, motion as Motion } from "framer-motion";
import { storyService } from "../../services/story.service.js";
import { useAuthStore } from "../../store/authStore.js";
import { useUIStore } from "../../store/uiStore.js";
import { storyAudioManager } from "./audio/storyAudioManager.js";
import { useCanvasStore } from "./editor/useCanvasStore.js";

const StoryEditor = lazy(() => import("./editor/StoryEditor.jsx"));

const MAX_IMAGE_SIZE = 20 * 1024 * 1024;
const MAX_VIDEO_SIZE = 100 * 1024 * 1024;

const revokeIfBlob = (url) => {
  if (url?.startsWith("blob:")) URL.revokeObjectURL(url);
};

const extractCreatedStory = (response) =>
  response?.data?.data || response?.data || response?.story || response || null;

const StoryUploader = () => {
  const { user } = useAuthStore();
  const { modal, closeModal } = useUIStore();
  const queryClient = useQueryClient();
  const fileInputRef = useRef(null);
  const imageInputRef = useRef(null);
  const videoInputRef = useRef(null);
  const uploadLockRef = useRef(false);
  const isOpen = modal.type === "create-story";

  const [editorFile, setEditorFile] = useState(null);
  const [editorFileType, setEditorFileType] = useState("image");
  const [previewUrl, setPreviewUrl] = useState(null);
  const [text, setText] = useState("");
  const [privacy] = useState("followers");
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState("");
  const [isDragging, setIsDragging] = useState(false);

  useEffect(() => {
    return () => {
      revokeIfBlob(previewUrl);
    };
  }, [previewUrl]);

  const resetForm = () => {
    revokeIfBlob(previewUrl);
    storyAudioManager.stop();
    useCanvasStore.getState().resetEditor();
    setEditorFile(null);
    setEditorFileType("image");
    setPreviewUrl(null);
    setText("");
    setUploadProgress(0);
    setError("");
    setIsDragging(false);
  };

  const handleClose = () => {
    if (uploadMutation.isPending) return;
    resetForm();
    closeModal();
  };

  const validateFile = (file) => {
    if (!file) return null;
    const isImage = file.type.startsWith("image/");
    const isVideo = file.type.startsWith("video/");

    if (!isImage && !isVideo) {
      return "Only images and videos are allowed.";
    }

    const maxSize = isVideo ? MAX_VIDEO_SIZE : MAX_IMAGE_SIZE;
    if (file.size > maxSize) {
      return `File too large. Max ${isVideo ? "100MB" : "20MB"}.`;
    }

    return null;
  };

  const openEditorForFile = (file) => {
    const validationError = validateFile(file);
    if (validationError) {
      setError(validationError);
      return;
    }

    revokeIfBlob(previewUrl);
    setEditorFile(file);
    setEditorFileType(file.type.startsWith("video/") ? "video" : "image");
    setPreviewUrl(URL.createObjectURL(file));
    setError("");
  };

  const handleFileSelect = (event, expectedType = "media") => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (file && expectedType === "image" && !file.type.startsWith("image/")) {
      setError("Please select an image file.");
      return;
    }
    if (file && expectedType === "video" && !file.type.startsWith("video/")) {
      setError("Please select a video file.");
      return;
    }
    openEditorForFile(file);
  };

  const handleDrop = (event) => {
    event.preventDefault();
    setIsDragging(false);
    openEditorForFile(event.dataTransfer.files?.[0]);
  };

  const uploadMutation = useMutation({
    mutationFn: async (payload) => {
      if (!payload?.file) throw new Error("No edited story file");
      const startedAt = performance.now();
      console.debug("[StoryExport]", "upload-start", {
        storyType: payload.storyType,
        bytes: payload.file.size,
        type: payload.file.type,
      });

      const formData = new FormData();
      formData.append("story", payload.file);
      formData.append("text", text || "");
      formData.append("story_type", payload.storyType || "image");
      formData.append("privacy", privacy);

      const metadataPayload = {
        ...(payload.metadata || {}),
      };
      formData.append("metadata", JSON.stringify(metadataPayload));

      try {
        return await storyService.createStory(formData, (percent) => {
          setUploadProgress(percent);
        });
      } finally {
        console.debug("[StoryExport]", "upload-finished", {
          ms: Math.round(performance.now() - startedAt),
        });
      }
    },
    onMutate: async (payload) => {
      await queryClient.cancelQueries({ queryKey: ["stories-feed"] });
      await queryClient.cancelQueries({ queryKey: ["stories-me"] });

      const previousFeed = queryClient.getQueryData(["stories-feed"]);
      const previousMe = queryClient.getQueryData(["stories-me"]);
      const optimisticPreview = payload.previewUrl || previewUrl;
      const storyType = payload.storyType || editorFileType;

      const optimisticStory = {
        id: `temp-${Date.now()}`,
        user_id: user?.id,
        username: user?.username,
        profile_image: user?.avatar,
        story: optimisticPreview,
        story_type: storyType,
        privacy,
        text,
        view_count: 0,
        likes_count: 0,
        is_liked: false,
        metadata: payload.metadata || {},
        music: payload.metadata?.music || null,
        created_at: new Date().toISOString(),
        expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
      };

      queryClient.setQueryData(["stories-me"], (old) => ({
        ...old,
        data: {
          ...old?.data,
          results: [optimisticStory, ...(old?.data?.results || [])],
        },
      }));

      queryClient.setQueryData(["stories-feed"], (old) => {
        if (!old?.data) return old;
        const newData = [...old.data];
        const ownIndex = newData.findIndex(
          (group) =>
            group.id === user?.id || group.stories?.[0]?.user_id === user?.id,
        );

        if (ownIndex >= 0) {
          newData[ownIndex] = {
            ...newData[ownIndex],
            stories: [optimisticStory, ...(newData[ownIndex].stories || [])],
          };
        } else {
          newData.unshift({
            id: user?.id,
            username: user?.username,
            has_unseen: false,
            stories: [optimisticStory],
          });
        }

        return { ...old, data: newData };
      });

      return { previousFeed, previousMe };
    },
    onError: (err, _payload, context) => {
      if (context?.previousFeed)
        queryClient.setQueryData(["stories-feed"], context.previousFeed);
      if (context?.previousMe)
        queryClient.setQueryData(["stories-me"], context.previousMe);
      setError(err.response?.data?.message || err.message || "Upload failed");
      setUploadProgress(0);
    },
    onSuccess: (response) => {
      const createdStory = extractCreatedStory(response);
      queryClient.invalidateQueries({ queryKey: ["stories-feed"] });
      queryClient.invalidateQueries({ queryKey: ["stories-me"] });
      if (createdStory?.id) {
        queryClient.setQueryData(["story", createdStory.id], (old) => ({
          ...old,
          data: old?.data || createdStory,
        }));
      }
      resetForm();
      closeModal();
    },
  });

  const handleEditorExport = async (payload) => {
    if (uploadLockRef.current || uploadMutation.isPending) return;
    uploadLockRef.current = true;
    setUploadProgress(0);
    storyAudioManager.stop();
    try {
      revokeIfBlob(previewUrl);
      setPreviewUrl(payload.previewUrl);
      await uploadMutation.mutateAsync(payload);
    } finally {
      uploadLockRef.current = false;
    }
  };

  if (!isOpen) return null;

  if (editorFile) {
    return (
      <Suspense
        fallback={
          <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black text-white">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        }
      >
        <StoryEditor
          file={editorFile}
          initialFileType={editorFileType}
          onCancel={handleClose}
          onExport={handleEditorExport}
          isUploading={uploadMutation.isPending}
          uploadProgress={uploadProgress}
          error={error}
        />
      </Suspense>
    );
  }

  return (
    <AnimatePresence>
      <Motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 overflow-y-auto bg-black/55 px-4 backdrop-blur-sm"
      >
        <div className="flex min-h-full items-center justify-center">
          <Motion.div
            initial={{ scale: 0.94, opacity: 0, y: 16 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.94, opacity: 0, y: 16 }}
            className="w-full max-w-md overflow-hidden rounded-2xl border border-border bg-muted shadow-premium dark:border-border-dark dark:bg-gray-950"
          >
            <div className="flex items-center justify-between border-b border-border px-4 py-1 dark:border-border-dark">
              <div>
                <h3 className="text-lg font-semibold text-foreground dark:text-foreground-dark">
                  Create story
                </h3>
                <p className="text-sm text-mutedForeground dark:text-mutedForeground-dark">
                  Upload, edit, preview, and share
                </p>
              </div>
              <button
                type="button"
                onClick={handleClose}
                className="flex h-10 w-10 items-center justify-center rounded-full text-gray-400 transition hover:bg-gray-100 hover:text-gray-700 dark:hover:bg-white/10 dark:hover:text-white"
                aria-label="Close"
              >
                <X size={20} />
              </button>
            </div>

            <div className="p-5">
              {error && (
                <div className="mb-4 flex items-start gap-2 rounded-2xl border border-red-200 bg-red-50 p-3 dark:border-red-800 dark:bg-red-900/20">
                  <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-red-500" />
                  <p className="text-sm text-red-600 dark:text-red-300">
                    {error}
                  </p>
                </div>
              )}

              <div
                role="button"
                tabIndex={0}
                onClick={() => fileInputRef.current?.click()}
                onKeyDown={(event) => {
                  if (event.key === "Enter" || event.key === " ") {
                    event.preventDefault();
                    fileInputRef.current?.click();
                  }
                }}
                onDragEnter={(event) => {
                  event.preventDefault();
                  setIsDragging(true);
                }}
                onDragOver={(event) => event.preventDefault()}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
                className={`flex w-full flex-col items-center justify-center rounded-2xl border-2 border-dashed px-5 py-8 text-center transition ${
                  isDragging
                    ? "border-border dark:border-border-dark bg-primary/5"
                    : "border-border bg-muted hover:border-primary/70 hover:bg-white dark:border-border-dark dark:bg-muted-dark dark:hover:border-primary/70"
                }`}
              >
                <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary text-white">
                  <Camera size={28} />
                </div>
                <p className="mt-4 text-base font-semibold text-foreground dark:text-foreground-dark">
                  Drag and drop a photo or video
                </p>
                <p className="mt-1 text-sm text-mutedForeground dark:text-mutedForeground-dark">
                  Images up to 20MB, videos up to 100MB
                </p>
                <div className="mt-5 flex gap-3">
                  <button
                    type="button"
                    onClick={(event) => {
                      event.stopPropagation();
                      imageInputRef.current?.click();
                    }}
                    className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-semibold text-gray-800 shadow-soft transition hover:bg-gray-100 dark:bg-white/10 dark:text-white dark:hover:bg-white/15"
                  >
                    <ImageIcon size={16} />
                    Image
                  </button>
                  <button
                    type="button"
                    onClick={(event) => {
                      event.stopPropagation();
                      videoInputRef.current?.click();
                    }}
                    className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-semibold text-gray-800 shadow-soft transition hover:bg-gray-100 dark:bg-white/10 dark:text-white dark:hover:bg-white/15"
                  >
                    <Video size={16} />
                    Video
                  </button>
                </div>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,video/*"
                className="hidden"
                onChange={(event) => handleFileSelect(event, "media")}
              />
              <input
                ref={imageInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(event) => handleFileSelect(event, "image")}
              />
              <input
                ref={videoInputRef}
                type="file"
                accept="video/*"
                className="hidden"
                onChange={(event) => handleFileSelect(event, "video")}
              />

              <div className="mt-5">
                <label className="block text-sm font-medium text-foreground dark:text-foreground-dark">
                  Caption
                </label>
                <textarea
                  value={text}
                  onChange={(event) => setText(event.target.value)}
                  maxLength={2200}
                  rows={3}
                  placeholder="Add a caption..."
                  className="mt-2 w-full resize-none rounded-2xl border border-border bg-white px-3 py-3 text-sm outline-none transition placeholder:text-mutedForeground focus:border-viral-pink dark:border-border-dark dark:bg-gray-900"
                />
                <div className="mt-1 flex justify-end text-xs text-mutedForeground">
                  {text.length}/2200
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 border-t border-border bg-gray-50 px-5 py-4 dark:border-border-dark dark:bg-gray-900">
              <button
                type="button"
                onClick={handleClose}
                className="rounded-full border border-border bg-white px-4 py-2 text-sm font-semibold text-gray-700 transition hover:bg-gray-100 dark:border-border-dark dark:bg-gray-950 dark:text-gray-200 dark:hover:bg-white/10"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center gap-2 rounded-full bg-gray-950 px-4 py-2 text-sm font-semibold text-white transition hover:bg-gray-800 dark:bg-white dark:text-gray-950 dark:hover:bg-gray-200"
              >
                <UploadCloud size={17} />
                Select file
              </button>
            </div>
          </Motion.div>
        </div>
      </Motion.div>
    </AnimatePresence>
  );
};

export default StoryUploader;
