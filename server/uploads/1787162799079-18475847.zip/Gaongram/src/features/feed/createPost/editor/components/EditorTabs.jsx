// src/features/feed/createPost/components/editor/components/EditorTabs.jsx

import {
  Crop,
  SlidersHorizontal,
  Brush,
} from "lucide-react";

const EditorTabs = ({
  tab,
  setTab,
}) => {

  return (

    <div className="flex gap-2 p-2 pb-1">

      <button
        onClick={() => setTab("crop")}
        className={`
          flex items-center gap-1
          h-8
          px-4
          rounded-full
          text-[11px]
          font-medium

          ${
            tab === "crop"
              ? "bg-primary text-white"
              : "bg-white text-gray-700 border border-gray-200"
          }
        `}
      >

        <Crop className="w-3 h-3" />

        Crop

      </button>

      <button
        onClick={() => setTab("filters")}
        className={`
          flex items-center gap-1
          h-8
          px-4
          rounded-full
          text-[11px]
          font-medium

          ${
            tab === "filters"
              ? "bg-primary text-white"
              : "bg-white text-gray-700 border border-gray-200"
          }
        `}
      >

        <SlidersHorizontal className="w-3 h-3" />

        Filters

      </button>

      <button
        onClick={() => setTab("paint")}
        className={`
          flex items-center gap-1
          h-8
          px-4
          rounded-full
          text-[11px]
          font-medium

          ${
            tab === "paint"
              ? "bg-primary text-white"
              : "bg-white text-gray-700 border border-gray-200"
          }
        `}
      >

        <Brush className="w-3 h-3" />

        Paint

      </button>

    </div>

  );

};

export default EditorTabs;