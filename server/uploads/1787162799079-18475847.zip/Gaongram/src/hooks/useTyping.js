// src/hooks/useTyping.js
import { useState, useCallback, useEffect, useRef } from 'react';
import { useChatStore } from '../store/chatStore';
import { useSocket } from '../context/SocketProvider';

export const useTyping = (chatId, currentUserId) => {
  const { addTypingUser, removeTypingUser, typingUsers } = useChatStore();
  const { emit, isConnected } = useSocket();
  const [isLocalTyping, setIsLocalTyping] = useState(false);
  const timeoutRef = useRef(null);

  // Send typing event to the other user
  const startTyping = useCallback(() => {
    if (!isLocalTyping) {
      setIsLocalTyping(true);
      if (isConnected) {
        emit('typing', { is_typing: true, receiver_id: chatId });
      }

      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      timeoutRef.current = setTimeout(() => {
        setIsLocalTyping(false);
        if (isConnected) {
          emit('typing', { is_typing: false, receiver_id: chatId });
        }
      }, 2000);
    }
  }, [isLocalTyping, isConnected, emit, chatId]);

  const stopTyping = useCallback(() => {
    if (isLocalTyping) {
      setIsLocalTyping(false);
      if (isConnected) {
        emit('typing', { is_typing: false, receiver_id: chatId });
      }
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    }
  }, [isLocalTyping, isConnected, emit, chatId]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      if (isConnected) {
        emit('typing', { is_typing: false, receiver_id: chatId });
      }
    };
  }, [isConnected, emit, chatId]);

  // Is the other user currently typing?
  const isOtherTyping = typingUsers.has(chatId);

  return {
    startTyping,
    stopTyping,
    isTyping: isOtherTyping,
  };
};