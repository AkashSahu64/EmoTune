// src/components/help/FAQAccordion.jsx
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

const FAQAccordion = ({ articles, expandedId, setExpandedId }) => {
  const toggle = (id) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="space-y-2">
      {articles.map(article => (
        <div 
          key={article.id} 
          id={`article-${article.id}`}
          className="border border-border dark:border-border-dark rounded-xl overflow-hidden bg-card dark:bg-card-dark"
        >
          <button
            onClick={() => toggle(article.id)}
            className="w-full px-5 py-4 text-left flex items-center justify-between hover:bg-muted/50 dark:hover:bg-muted-dark/50 transition"
          >
            <span className="font-medium text-foreground dark:text-foreground-dark">{article.question}</span>
            <motion.div
              animate={{ rotate: expandedId === article.id ? 180 : 0 }}
              transition={{ duration: 0.2 }}
            >
              <ChevronDown className="w-5 h-5 text-mutedForeground" />
            </motion.div>
          </button>
          <AnimatePresence>
            {expandedId === article.id && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <div className="px-5 pb-5 pt-1 text-mutedForeground dark:text-mutedForeground-dark border-t border-border dark:border-border-dark whitespace-pre-line">
                  {article.answer}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ))}
    </div>
  );
};

export default FAQAccordion;