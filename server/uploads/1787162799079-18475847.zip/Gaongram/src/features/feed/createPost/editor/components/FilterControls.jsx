// src/features/feed/createPost/components/editor/components/FilterControls.jsx

import {
  SunMedium,
  Contrast,
  Palette,
} from "lucide-react";

import FilterButton from "./FilterButton";

import { FILTER_PRESETS } from "../filterPresets";

const FilterControls = ({
  filters,
  setFilters,
}) => {

  return (

    <div className="space-y-2.5">

      <div className="flex gap-1.5 overflow-x-auto scrollbar-hide">

        {Object.entries(
          FILTER_PRESETS
        ).map(([name, preset]) => (

          <button
            key={name}
            onClick={() =>
              setFilters(preset)
            }
            className="
              h-7
              px-2.5
              rounded-lg
              bg-gray-100
              text-[10px]
              font-medium
              whitespace-nowrap
            "
          >

            {name}

          </button>

        ))}

      </div>

      <FilterButton
        icon={SunMedium}
        label="Brightness"
        value={filters.brightness}
        minus={() =>
          setFilters({
            ...filters,
            brightness:
              filters.brightness - 10,
          })
        }
        plus={() =>
          setFilters({
            ...filters,
            brightness:
              filters.brightness + 10,
          })
        }
      />

      <FilterButton
        icon={Contrast}
        label="Contrast"
        value={filters.contrast}
        minus={() =>
          setFilters({
            ...filters,
            contrast:
              filters.contrast - 10,
          })
        }
        plus={() =>
          setFilters({
            ...filters,
            contrast:
              filters.contrast + 10,
          })
        }
      />

      <FilterButton
        icon={Palette}
        label="Saturation"
        value={filters.saturation}
        minus={() =>
          setFilters({
            ...filters,
            saturation:
              filters.saturation - 10,
          })
        }
        plus={() =>
          setFilters({
            ...filters,
            saturation:
              filters.saturation + 10,
          })
        }
      />

    </div>

  );

};

export default FilterControls;