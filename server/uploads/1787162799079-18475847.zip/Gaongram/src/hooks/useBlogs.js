// src/features/blogs/hooks/useBlogs.js
import { useState, useEffect, useCallback } from "react";
import blogService from "../services/blogService";
import { showToast } from "../utils/toast";
import { shouldSkipLiveSeoFetch } from "../seo/seoUtils";

export const useBlogs = (initialParams = {}) => {
  const [blogs, setBlogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [pagination, setPagination] = useState({
    count: 0,
    next: null,
    previous: null,
  });
  const [params, setParams] = useState(initialParams);

  const fetchBlogs = useCallback(async () => {
    if (shouldSkipLiveSeoFetch()) {
      setBlogs([]);
      setLoading(false);
      setPagination({
        count: 0,
        next: null,
        previous: null,
      });
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const response = await blogService.getBlogs(params);
      if (response.success) {
        setBlogs(response.data.results);
        setPagination({
          count: response.data.count,
          next: response.data.next,
          previous: response.data.previous,
        });
      } else {
        throw new Error(response.message || "Failed to fetch blogs");
      }
    } catch (err) {
      setError(err);
      showToast(err.message || "Failed to load blogs", "error");
    } finally {
      setLoading(false);
    }
  }, [params]);

  useEffect(() => {
    fetchBlogs();
  }, [fetchBlogs]);

  const updateParams = (newParams) => {
    setParams((prev) => ({ ...prev, ...newParams }));
  };

  const goToPage = (page) => {
    updateParams({ page });
  };

  const refetch = fetchBlogs;

  return {
    blogs,
    loading,
    error,
    pagination,
    params,
    updateParams,
    goToPage,
    refetch,
  };
};
