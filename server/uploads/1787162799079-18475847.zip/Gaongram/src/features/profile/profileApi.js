import api from "../../config/axios.js";

export const profileAPI = {
  getProfileById: async (profileId) => {
    const response = await api.get(`/profiles/${profileId}/`);
    return response.data.data;
  },

  getProfileByUsername: async (username) => {
    const response = await api.get("/profiles/", {
      params: {
        search: username,
        limit: 20,
      },
    });

    const profiles = response.data.data?.results || [];
    const profile = profiles.find(
      (item) =>
        String(item.username || "").toLowerCase() ===
        String(username || "").toLowerCase(),
    );

    if (!profile) {
      throw new Error(`Profile with username "${username}" not found`);
    }

    return profile;
  },

  getAllProfiles: async (params = {}) => {
    const response = await api.get("/profiles/", { params });
    return response.data.data;
  },

  updateProfile: async (userId, data) => {
    const isFormData = data instanceof FormData;
    const response = await api.patch(`/profiles/${userId}/`, data, {
      headers: isFormData
        ? { "Content-Type": "multipart/form-data" }
        : { "Content-Type": "application/json" },
    });

    return response.data.data;
  },

  updateProfileFull: async (profileId, data) => {
    const response = await api.put(`/profiles/${profileId}/`, data);
    return response.data.data;
  },

  toggleFollow: async (userId) => {
    const response = await api.post(`/profiles/${userId}/follow/`);
    return response.data;
  },

  handleFollowRequest: async (requestId, action) => {
    const response = await api.post(`/handle-follow-request/${requestId}/`, {
      action,
    });
    return response.data;
  },

  getFollowers: async (userId, page = 1) => {
    const response = await api.get("/profiles/", {
      params: { followers: true, user_id: userId, page },
    });
    return response.data.data;
  },

  getFollowing: async (userId, page = 1) => {
    const response = await api.get("/profiles/", {
      params: { following: true, user_id: userId, page },
    });
    return response.data.data;
  },

  resolveProfileIdentifier: async (identifier) => {
    const isNumeric = /^\d+$/.test(String(identifier || ""));

    return isNumeric
      ? profileAPI.getProfileById(identifier)
      : profileAPI.getProfileByUsername(identifier);
  },

  getReports: async (page = 1) => {
    const response = await api.get("/reports/", { params: { page } });
    return response.data;
  },

  getBlockedUsers: async () => {
    const response = await api.get("/blocked-users/");
    return response.data;
  },

  toggleBlockUser: async (userId) => {
    const response = await api.post(`/block-user-toggle/${userId}/`);
    return response.data;
  },

  submitVerificationRequest: async (formData) => {
    const response = await api.post("/verification/", formData, {
      headers: { "Content-Type": "multipart/form-data" },
    });
    return response.data;
  },

  getVerificationStatus: async (userId) => {
    try {
      const response = await api.get(`/profiles/${userId}/`);
      const profile = response.data.data;

      return {
        status:
          profile.verification_status ||
          (profile.is_verified ? "approved" : null),
      };
    } catch (error) {
      return null;
    }
  },

  getReportPost: async (postId) => {
    const response = await api.get(`/vibe-posts/${postId}/`);
    return response.data.data;
  },

  getReportUser: async (userId) => {
    const response = await api.get(`/profiles/${userId}/`);
    return response.data.data;
  },
};
