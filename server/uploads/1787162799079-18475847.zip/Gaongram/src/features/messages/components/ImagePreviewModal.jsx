// src/features/messages/components/ImagePreviewModal.jsx
import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ZoomIn, ZoomOut, ChevronLeft, ChevronRight } from 'lucide-react';

const ImagePreviewModal = ({ isOpen, onClose, images, initialIndex = 0 }) => {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [scale, setScale] = useState(1);

  useEffect(() => {
    const handleKey = (e) => {
      if (!isOpen) return;
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft') prevImage();
      if (e.key === 'ArrowRight') nextImage();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, currentIndex]);

  const nextImage = () => setCurrentIndex((prev) => (prev + 1) % images.length);
  const prevImage = () => setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
  const zoomIn = () => setScale((s) => Math.min(s + 0.2, 3));
  const zoomOut = () => setScale((s) => Math.max(s - 0.2, 0.5));

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center"
        onClick={onClose}
      >
        <div className="absolute top-4 right-4 flex gap-2 z-10">
          <button onClick={zoomIn} className="p-2 bg-white/20 rounded-full hover:bg-white/30">
            <ZoomIn className="w-5 h-5 text-white" />
          </button>
          <button onClick={zoomOut} className="p-2 bg-white/20 rounded-full hover:bg-white/30">
            <ZoomOut className="w-5 h-5 text-white" />
          </button>
          <button onClick={onClose} className="p-2 bg-white/20 rounded-full hover:bg-white/30">
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {images.length > 1 && (
          <>
            <button
              onClick={prevImage}
              className="absolute left-4 top-1/2 -translate-y-1/2 p-2 bg-white/20 rounded-full"
            >
              <ChevronLeft className="w-6 h-6 text-white" />
            </button>
            <button
              onClick={nextImage}
              className="absolute right-4 top-1/2 -translate-y-1/2 p-2 bg-white/20 rounded-full"
            >
              <ChevronRight className="w-6 h-6 text-white" />
            </button>
          </>
        )}

        <div className="max-w-[90vw] max-h-[90vh] overflow-auto flex items-center justify-center">
          <motion.img
            src={images[currentIndex].url}
            alt="preview"
            className="object-contain max-w-full max-h-full"
            style={{ transform: `scale(${scale})`, transition: 'transform 0.2s' }}
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default ImagePreviewModal;