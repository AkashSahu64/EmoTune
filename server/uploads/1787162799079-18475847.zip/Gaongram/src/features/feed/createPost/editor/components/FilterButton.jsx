// src/features/feed/createPost/components/editor/components/FilterButton.jsx

const FilterButton = ({
  icon: Icon,
  label,
  value,
  minus,
  plus,
}) => (

  <div className="flex items-center justify-between bg-gray-100 rounded-xl px-2.5 py-2">

    <div className="flex items-center gap-1.5">

      <Icon className="w-3.5 h-3.5 text-gray-600" />

      <span className="text-[11px] font-medium text-gray-700">
        {label}
      </span>

    </div>

    <div className="flex items-center gap-1.5">

      <button
        onClick={minus}
        className="
          w-5 h-5
          rounded-full
          bg-primary
          text-white
          text-[11px]
          flex items-center justify-center
        "
      >
        -
      </button>

      <span className="text-[10px] w-6 text-center font-medium">
        {value}
      </span>

      <button
        onClick={plus}
        className="
          w-5 h-5
          rounded-full
          bg-primary
          text-white
          text-[11px]
          flex items-center justify-center
        "
      >
        +
      </button>

    </div>

  </div>

);

export default FilterButton;