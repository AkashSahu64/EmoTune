import { fabric } from "fabric";

export const transformFromObject = (object) => ({
  left: Math.round(object.left || 0),
  top: Math.round(object.top || 0),
  width: Math.round(object.getScaledWidth ? object.getScaledWidth() : object.width || 0),
  height: Math.round(object.getScaledHeight ? object.getScaledHeight() : object.height || 0),
  scaleX: Number((object.scaleX || 1).toFixed(4)),
  scaleY: Number((object.scaleY || 1).toFixed(4)),
  rotation: Math.round(object.angle || 0),
  opacity: Number((object.opacity ?? 1).toFixed(3)),
});

export function readTextStyle(object) {
  return {
    fontFamily: object.fontFamily,
    fontSize: object.fontSize,
    fontWeight: object.fontWeight,
    fill: typeof object.fill === "string" ? object.fill : "#ffffff",
    textAlign: object.textAlign,
    letterSpacing: object.charSpacing || 0,
    opacity: object.opacity ?? 1,
    shadow: object.shadow ? object.shadow.toString() : "rgba(0,0,0,0.35) 0 4px 12px",
    effect: object.shadow ? "shadow" : "none",
    glowColor: "#E1306C",
    gradient: {
      enabled: typeof object.fill !== "string",
      from: "#E1306C",
      to: "#F77737",
    },
  };
}

export function applyTextStyle(object, style) {
  object.set({
    fontFamily: style.fontFamily ?? object.fontFamily,
    fontSize: style.fontSize ?? object.fontSize,
    fontWeight: style.fontWeight ?? object.fontWeight,
    fontStyle: style.fontStyle ?? object.fontStyle,
    textAlign: style.textAlign ?? object.textAlign,
    charSpacing: style.letterSpacing !== undefined ? style.letterSpacing : object.charSpacing,
    opacity: style.opacity ?? object.opacity,
  });

  if (style.gradient?.enabled) {
    const width = Math.max(object.width || 1, 1);
    object.set(
      "fill",
      new fabric.Gradient({
        type: "linear",
        gradientUnits: "pixels",
        coords: { x1: -width / 2, y1: 0, x2: width / 2, y2: 0 },
        colorStops: [
          { offset: 0, color: style.gradient.from || "#E1306C" },
          { offset: 1, color: style.gradient.to || "#F77737" },
        ],
      })
    );
  } else if (style.fill) {
    object.set("fill", style.fill);
  }

  if (style.effect === "neon") {
    object.set("shadow", new fabric.Shadow(`${style.glowColor || "#E1306C"} 0 0 24px`));
  } else if (style.effect === "glow") {
    object.set("shadow", new fabric.Shadow(`${style.glowColor || "#ffffff"} 0 0 18px`));
  } else if (style.shadow) {
    object.set("shadow", new fabric.Shadow(style.shadow));
  } else {
    object.set("shadow", null);
  }
}
