import React from "react";
import { AlertTriangle, CheckCircle, XCircle, Info } from "lucide-react";
import Button from "./Button.jsx";

const ConfirmModal = ({
  isOpen,
  title = "Confirm Action",
  message,
  type = "warning",
  confirmText = "Confirm",
  cancelText = "Cancel",
  onConfirm,
  onClose,
  isLoading = false,
}) => {
  if (!isOpen) return null;

  const icons = {
    warning: AlertTriangle,
    success: CheckCircle,
    error: XCircle,
    info: Info,
  };

  const colors = {
    warning: "text-yellow-500",
    success: "text-green-500",
    error: "text-red-500",
    info: "text-blue-500",
  };

  const Icon = icons[type];
  const colorClass = colors[type];

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/50"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative bg-white rounded-2xl shadow-xl p-6 w-full max-w-md mx-4 z-10">
        <div className="text-center">
          <div className="mx-auto flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-4">
            <Icon className={`w-8 h-8 ${colorClass}`} />
          </div>

          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            {title}
          </h3>

          {message && (
            <p className="text-gray-600 mb-6">
              {message}
            </p>
          )}

          <div className="flex space-x-3">
            <Button
              variant="outline"
              fullWidth
              onClick={onClose}
              disabled={isLoading}
            >
              {cancelText}
            </Button>

            <Button
              variant={
                type === "warning" || type === "error"
                  ? "danger"
                  : "primary"
              }
              fullWidth
              onClick={onConfirm}
              loading={isLoading}
            >
              {confirmText}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConfirmModal;
