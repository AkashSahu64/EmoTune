import api from "../config/axios";

export const hashtagService = {
  // TRENDING HASHTAGS
  getTrendingHashtags: async () => {
    const response = await api.get("/trending/");

    return {
      data: response.data,
    };
  },

  // TRENDING POSTS
  getTrendingPosts: async () => {
    const response = await api.get(
      "/trending-posts/"
    );

    return response.data;
  },

  // POSTS BY HASHTAG
  getPostsByHashtag: async (
    hashtag
  ) => {
    const response = await api.get(
      `/vibe-posts/?hashtag=${hashtag}`
    );

    return response.data;
  },
};