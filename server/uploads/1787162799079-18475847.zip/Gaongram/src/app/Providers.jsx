// src/providers/Providers.jsx
import React from "react";
import { motion as Motion, AnimatePresence } from "framer-motion";
import { useUIStore } from "../store/uiStore.js";
import { useAuthStore } from "../store/authStore.js";
import Modal from "../components/common/Modal.jsx";
import ToastContainer from "../components/common/ToastContainer.jsx";

// Existing modals
import CreateVibeModal from "../features/vibe/components/CreateVibeModal.jsx";
import CommentsModal from "../features/comments/CommentsModal.jsx";
import PostOptionsModal from "../features/feed/components/PostOptionsModal.jsx";
import LoginModal from "../features/auth/pages/Login.jsx";
import ConfirmModal from "../components/common/ConfirmModal.jsx";
import ReportModal from "../modules/report/ReportModal.jsx";
import CommentOptionsModal from "../features/comments/CommentOptionsModal.jsx";

// Post creation modals
import CreatePostSelectorModal from "../features/feed/createPost/CreatePostSelectorModal.jsx";
import CreateImagePostModal from "../features/feed/createPost/CreateImagePostModal.jsx";
import CreateVideoPostModal from "../features/feed/createPost/CreateVideoPostModal.jsx";
import CreateAudioPostModal from "../features/feed/createPost/CreateAudioPostModal.jsx";
import CreateTextPostModal from "../features/feed/createPost/CreateTextPostModal.jsx";
import CreatePollPostModal from "../features/feed/createPost/CreatePollPostModal.jsx";
import StoryUploader from "../features/story/StoryUploader.jsx";

// NEW suggested users modal
import SuggestedUsersModal from "../features/feed/components/SuggestedUsersModal.jsx";
import ShareModal from "../components/common/ShareModal.jsx";
import ConfirmStoryModal from "../features/story/components/ConfirmStoryModal.jsx";
import DeletePostConfirmModal from "../features/feed/components/deletePost/DeletePostConfirmModal.jsx";
import EditPostModal from "../features/feed/components/editPost/EditPostModal.jsx";

const Providers = ({ children }) => {
  const { modal, closeModal } = useUIStore();
  const logoutSequence = useAuthStore((state) => state.logoutSequence);

  const renderModalContent = () => {
    switch (modal.type) {
      // Existing cases
      case "create-vibe":
        return <CreateVibeModal />;
      case "comments":
        return <CommentsModal {...modal.data} />;
      case "post-options":
        return <PostOptionsModal {...modal.data} />;
      case "login":
        return <LoginModal />;
      case "confirm":
        return <ConfirmModal {...modal.data} />;
      case "confirm-story":
        return <ConfirmStoryModal {...modal.data} />;
      case "report":
        return <ReportModal {...modal.data} />;
      case "comment-options":
        return <CommentOptionsModal {...modal.data} />;

      // Post creation types
      case "create-post-selector":
        return <CreatePostSelectorModal />;
      case "create-image-post":
        return <CreateImagePostModal {...modal.data} />;
      case "create-video-post":
        return <CreateVideoPostModal {...modal.data} />;
      case "create-audio-post":
        return <CreateAudioPostModal {...modal.data} />;
      case "create-text-post":
        return <CreateTextPostModal {...modal.data} />;
      case "create-poll-post":
        return <CreatePollPostModal {...modal.data} />;
      case "create-story":
        return <StoryUploader />;

      // NEW suggested users modal
      case "suggested-users-modal":
        return <SuggestedUsersModal />;

      case "share":
        return <ShareModal {...modal.data} />;

      case "edit-post":
        return <EditPostModal {...modal.data} />;
      case "delete-confirm":
        return <DeletePostConfirmModal {...modal.data} />;
      default:
        return null;
    }
  };

  return (
    <>
      <AnimatePresence mode="wait">
        <Motion.div
          key={logoutSequence}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="min-h-screen"
        >
          {children}
        </Motion.div>
      </AnimatePresence>

      <Modal
        isOpen={modal.isOpen}
        onClose={closeModal}
        closeOnOverlayClick={modal.type !== "edit-post"}
        closeOnEscape={modal.type !== "edit-post"}
        size={modal.type === "comments" ? "large" : "medium"}
      >
        {renderModalContent()}
      </Modal>

      <ToastContainer />
    </>
  );
};

export default Providers;