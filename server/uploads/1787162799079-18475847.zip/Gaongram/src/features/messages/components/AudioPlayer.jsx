// src/features/messages/components/AudioPlayer.jsx (waveform version)
import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause } from 'lucide-react';

const AudioPlayer = ({ src }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const audioRef = useRef(null);
  const canvasRef = useRef(null);
  const animationRef = useRef();

  const drawWaveform = async () => {
    if (!canvasRef.current || !audioRef.current) return;
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const response = await fetch(src);
    const arrayBuffer = await response.arrayBuffer();
    const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
    const rawData = audioBuffer.getChannelData(0);
    const samples = 100;
    const blockSize = Math.floor(rawData.length / samples);
    const filteredData = [];
    for (let i = 0; i < samples; i++) {
      let sum = 0;
      for (let j = 0; j < blockSize; j++) {
        sum += Math.abs(rawData[i * blockSize + j]);
      }
      filteredData.push(sum / blockSize);
    }
    const max = Math.max(...filteredData);
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    const barWidth = width / samples;
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = '#3b82f6';
    filteredData.forEach((value, i) => {
      const barHeight = (value / max) * height * 0.8;
      const x = i * barWidth;
      const y = (height - barHeight) / 2;
      ctx.fillRect(x, y, barWidth - 1, barHeight);
    });
  };

  useEffect(() => {
    drawWaveform();
  }, [src]);

  const togglePlay = () => {
    if (isPlaying) {
      audioRef.current.pause();
      cancelAnimationFrame(animationRef.current);
    } else {
      audioRef.current.play();
      const update = () => {
        setCurrentTime(audioRef.current.currentTime);
        animationRef.current = requestAnimationFrame(update);
      };
      animationRef.current = requestAnimationFrame(update);
    }
    setIsPlaying(!isPlaying);
  };

  const formatTime = (sec) => {
    const mins = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${mins}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="flex items-center gap-3 p-2 bg-gray-100 dark:bg-gray-700 rounded-lg min-w-[220px]">
      <button onClick={togglePlay} className="w-8 h-8 flex items-center justify-center bg-blue-500 text-white rounded-full">
        {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
      </button>
      <canvas ref={canvasRef} width={150} height={40} className="flex-1" />
      <div className="text-xs text-gray-600 dark:text-gray-300 w-12">
        {formatTime(currentTime)} / {formatTime(duration)}
      </div>
      <audio
        ref={audioRef}
        src={src}
        onLoadedMetadata={(e) => setDuration(e.target.duration)}
        onEnded={() => setIsPlaying(false)}
      />
    </div>
  );
};

export default React.memo(AudioPlayer);