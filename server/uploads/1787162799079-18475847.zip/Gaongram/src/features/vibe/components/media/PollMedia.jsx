// components/vibe/media/PollMedia.jsx
import React from "react";
import PollVote from "../PollVote.jsx";

const PollMedia = ({ post, renderViewCount, onPollVote }) => {
  return (
    <div className="relative w-full bg-white dark:bg-background-dark">
      {renderViewCount("poll")}
      <div className="flex justify-center">
        <PollVote
          poll={post.poll}
          postId={post.id}
          onVote={onPollVote}
          totalVotes={post.poll?.total_votes}
          userVote={post.user_vote}
        />
      </div>
    </div>
  );
};

export default PollMedia;