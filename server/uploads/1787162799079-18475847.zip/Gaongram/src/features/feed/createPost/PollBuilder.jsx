// src/features/feed/createPost/PollBuilder.jsx
import React from 'react';
import { Plus, Trash2 } from 'lucide-react';

const PollBuilder = ({ options, setOptions, duration, setDuration }) => {
  const addOption = () => {
    if (options.length < 6) {
      setOptions([...options, '']);
    }
  };

  const removeOption = (index) => {
    if (options.length > 2) {
      setOptions(options.filter((_, i) => i !== index));
    }
  };

  const updateOption = (index, value) => {
    const newOptions = [...options];
    newOptions[index] = value;
    setOptions(newOptions);
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        {options.map((opt, idx) => (
          <div key={idx} className="flex items-center gap-2">
            <input
              type="text"
              value={opt}
              onChange={(e) => updateOption(idx, e.target.value)}
              placeholder={`Option ${idx + 1}`}
              className="flex-1 px-4 py-2 border border-border dark:border-border-dark bg-muted dark:bg-muted-dark rounded-lg focus:ring-2 focus:ring-primary/80 focus:outline-none"
            />
            {options.length > 2 && (
              <button
                type="button"
                onClick={() => removeOption(idx)}
                className="p-2 text-red-600 hover:text-red-700"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        ))}
      </div>

      {options.length < 6 && (
        <button
          type="button"
          onClick={addOption}
          className="flex items-center gap-2 text-primary hover:text-primary/80"
        >
          <Plus className="w-4 h-4" /> Add option
        </button>
      )}
    </div>
  );
};

export default PollBuilder;