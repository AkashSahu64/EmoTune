// src/features/feed/createPost/components/editor/components/ToolButton.jsx

const ToolButton = ({
  active,
  onClick,
  icon: Icon,
  label,
}) => (

  <button
    onClick={onClick}
    className={`
      h-12
      rounded-xl
      flex flex-col
      items-center
      justify-center
      gap-1
      transition-all
      duration-200

      ${
        active
          ? "bg-primary text-white"
          : "bg-gray-100 text-gray-700"
      }
    `}
  >

    <Icon className="w-4 h-4" />

    <span className="text-[10px] font-medium">
      {label}
    </span>

  </button>

);

export default ToolButton;