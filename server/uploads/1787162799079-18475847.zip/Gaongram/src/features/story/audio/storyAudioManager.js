const DEFAULT_SEGMENT_DURATION = 15;

const toFiniteNumber = (value, fallback = 0) => {
  const next = Number(value);
  return Number.isFinite(next) ? next : fallback;
};

const parseJsonObject = (value) => {
  if (!value) return null;
  if (typeof value === "object") return value;
  if (typeof value !== "string") return null;

  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === "object" ? parsed : null;
  } catch {
    return null;
  }
};

const firstDefined = (...values) =>
  values.find((value) => value !== undefined && value !== null && value !== "");

const firstString = (...values) =>
  values.find((value) => typeof value === "string" && value.trim());

const compactObjects = (items) =>
  items.filter((item) => item && typeof item === "object" && !Array.isArray(item));

const getField = (objects, keys, fallback = "") => {
  for (const object of objects) {
    for (const key of keys) {
      const value = object?.[key];
      if (value !== undefined && value !== null && value !== "") return value;
    }
  }
  return fallback;
};

const getStringField = (objects, keys, fallback = "") => {
  const value = getField(objects, keys, fallback);
  return typeof value === "string" ? value : fallback;
};

const isLocalDevHost = () => {
  if (typeof window === "undefined") return false;
  return ["localhost", "127.0.0.1", "::1"].includes(window.location.hostname);
};

export const normalizeStoryMediaUrl = (url) => {
  if (typeof url !== "string") return "";
  const trimmed = url.trim();
  if (!trimmed) return "";

  if (trimmed.startsWith("http://gaongram.com/")) {
    return trimmed.replace("http://gaongram.com/", "https://gaongram.com/");
  }

  try {
    const parsed = new URL(trimmed, window.location.href);
    if (
      isLocalDevHost() &&
      parsed.hostname === "gaongram.com" &&
      parsed.pathname.startsWith("/media/")
    ) {
      return `${parsed.pathname}${parsed.search}${parsed.hash}`;
    }
  } catch {
    return trimmed;
  }

  return trimmed;
};

export const isCorsSafeAudioUrl = (url) => {
  const normalized = normalizeStoryMediaUrl(url);
  if (!normalized) return false;
  if (normalized.startsWith("blob:") || normalized.startsWith("data:")) return true;

  try {
    return new URL(normalized, window.location.href).origin === window.location.origin;
  } catch {
    return false;
  }
};

export const normalizeStoryMusic = (music) => {
  const parsedMusic = parseJsonObject(music) || music;
  if (!parsedMusic) return null;

  const root = typeof parsedMusic === "string" ? { audio: parsedMusic } : parsedMusic;
  const metadata = parseJsonObject(root.metadata) || {};
  const metadataMusic = parseJsonObject(metadata.music) || {};
  const metadataAudio = parseJsonObject(metadata.audio) || {};
  const rootMusic = parseJsonObject(root.music) || {};
  const rootAudio = parseJsonObject(root.audio) || {};
  const rootAudioMetadata = parseJsonObject(root.audio_metadata) || {};
  const metadataAudioMetadata = parseJsonObject(metadata.audio_metadata) || {};
  const objects = compactObjects([
    rootMusic,
    rootAudio,
    rootAudioMetadata,
    metadataMusic,
    metadataAudio,
    metadataAudioMetadata,
    metadata,
    root,
  ]);

  const audio = normalizeStoryMediaUrl(
    firstString(
      getStringField(objects, [
        "audio",
        "audio_url",
        "audioUrl",
        "audioAudio",
        "audio_audio",
        "music_url",
        "musicUrl",
        "music_audio",
        "url",
        "file",
      ]),
      typeof root.audio === "string" ? root.audio : "",
      typeof root.music === "string" ? root.music : "",
    ),
  );

  if (!audio) return null;

  const startTime = Math.max(
    0,
    toFiniteNumber(
      firstDefined(
        getField(objects, [
          "startTime",
          "start_time",
          "music_start_time",
          "audio_start_time",
          "trimStart",
          "trim_start",
        ]),
      ),
      0,
    ),
  );
  const duration = Math.max(
    0.1,
    toFiniteNumber(
      firstDefined(
        getField(objects, [
          "duration",
          "music_duration",
          "clip_duration",
          "clipDuration",
          "segmentDuration",
          "segment_duration",
        ]),
      ),
      DEFAULT_SEGMENT_DURATION,
    ),
  );
  const sourceDuration = Math.max(
    duration,
    toFiniteNumber(
      firstDefined(
        getField(objects, [
          "sourceDuration",
          "source_duration",
          "track_duration",
          "trackDuration",
          "full_duration",
          "fullDuration",
          "audio_duration",
          "audioDuration",
        ]),
      ),
      duration,
    ),
  );

  return {
    id: firstDefined(getField(objects, ["id", "music_id", "audio_id"], ""), ""),
    audio,
    title: firstDefined(getField(objects, ["title", "audio_title", "music_title"], ""), "Story audio"),
    artist: firstDefined(getField(objects, ["artist", "audio_artist", "music_artist"], ""), ""),
    cover_image: normalizeStoryMediaUrl(
      firstDefined(
        getField(objects, [
          "cover_image",
          "coverImage",
          "audio_cover_image",
          "music_cover_image",
          "thumbnail",
          "image",
        ]),
        "",
      ),
    ),
    startTime,
    duration,
    sourceDuration,
    endTime: startTime + duration,
  };
};

class StoryAudioManager extends EventTarget {
  constructor() {
    super();
    this.audio = null;
    this.audioContext = null;
    this.sourceNode = null;
    this.analyserNode = null;
    this.rafId = null;
    this.music = null;
    this.loop = true;
    this.isPlaying = false;
    this.loadedAudioUrl = "";
    this.playRequestId = 0;
    this.blockedByAutoplay = false;
    this.resumeOnGesture = false;
    this.retryTimer = null;
    this.readyTimer = null;
    this.pendingPlayback = null;
    this.boundTimeUpdate = this.handleTimeUpdate.bind(this);
    this.boundEnded = this.handleEnded.bind(this);
    this.boundLoadedMetadata = this.handleLoadedMetadata.bind(this);
    this.boundGestureUnlock = this.handleGestureUnlock.bind(this);
  }

  getAudioElement() {
    if (this.audio) return this.audio;

    const audio = new Audio();
    audio.preload = "auto";
    audio.playsInline = true;
    audio.addEventListener("timeupdate", this.boundTimeUpdate);
    audio.addEventListener("ended", this.boundEnded);
    audio.addEventListener("loadedmetadata", this.boundLoadedMetadata);
    this.audio = audio;
    return audio;
  }

  addGestureUnlock() {
    if (this.hasGestureUnlock) return;
    this.hasGestureUnlock = true;
    window.addEventListener("pointerdown", this.boundGestureUnlock, { passive: true });
    window.addEventListener("touchstart", this.boundGestureUnlock, { passive: true });
    window.addEventListener("touchend", this.boundGestureUnlock, { passive: true });
    window.addEventListener("keydown", this.boundGestureUnlock);
  }

  removeGestureUnlock() {
    if (!this.hasGestureUnlock) return;
    this.hasGestureUnlock = false;
    window.removeEventListener("pointerdown", this.boundGestureUnlock);
    window.removeEventListener("touchstart", this.boundGestureUnlock);
    window.removeEventListener("touchend", this.boundGestureUnlock);
    window.removeEventListener("keydown", this.boundGestureUnlock);
  }

  handleGestureUnlock() {
    if (!this.music || !this.resumeOnGesture) return;
    const pending = this.pendingPlayback;
    if (pending?.music) {
      this.playSegment(pending.music, { ...pending.options, resumeOnGesture: false });
      return;
    }
    this.resume();
  }

  async ensureAudioGraph() {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return null;
    if (!isCorsSafeAudioUrl(this.music?.audio)) return null;

    if (!this.audioContext) {
      this.audioContext = new AudioContextClass();
    }

    if (!this.sourceNode) {
      this.sourceNode = this.audioContext.createMediaElementSource(this.getAudioElement());
      this.analyserNode = this.audioContext.createAnalyser();
      this.analyserNode.fftSize = 256;
      this.sourceNode.connect(this.analyserNode);
      this.analyserNode.connect(this.audioContext.destination);
    }

    if (this.audioContext.state === "suspended") {
      await this.audioContext.resume().catch(() => undefined);
    }

    return this.analyserNode;
  }

  getAnalyser() {
    return this.analyserNode;
  }

  load(music, options = {}) {
    const normalized = normalizeStoryMusic(music);
    const audio = this.getAudioElement();

    this.music = normalized;
    this.loop = options.loop ?? true;

    if (!normalized) {
      this.stop();
      return null;
    }

    if (this.loadedAudioUrl !== normalized.audio) {
      audio.pause();
      this.stopProgressLoop();
      audio.src = normalized.audio;
      this.loadedAudioUrl = normalized.audio;
      audio.load();
    }

    audio.volume = options.volume ?? 0.85;
    audio.loop = false;
    this.blockedByAutoplay = false;

    if (
      options.seek !== false &&
      (audio.currentTime < normalized.startTime || audio.currentTime >= normalized.endTime)
    ) {
      this.seekToSegmentStart();
    }

    this.emitState();
    return normalized;
  }

  waitForAudioReady(requestId, timeoutMs = 4500) {
    const audio = this.getAudioElement();
    if (audio.readyState >= 3 && Number.isFinite(audio.duration)) {
      return Promise.resolve(true);
    }

    window.clearTimeout(this.readyTimer);

    return new Promise((resolve) => {
      let settled = false;
      const cleanup = () => {
        audio.removeEventListener("loadedmetadata", onReady);
        audio.removeEventListener("durationchange", onReady);
        audio.removeEventListener("canplay", onReady);
        audio.removeEventListener("canplaythrough", onReady);
        audio.removeEventListener("error", onError);
        window.clearTimeout(this.readyTimer);
      };
      const settle = (value) => {
        if (settled) return;
        settled = true;
        cleanup();
        resolve(value);
      };
      const onReady = () => {
        if (requestId !== this.playRequestId) {
          settle(false);
          return;
        }
        if (audio.readyState >= 2 && Number.isFinite(audio.duration)) {
          settle(true);
        }
      };
      const onError = () => settle(false);

      audio.addEventListener("loadedmetadata", onReady);
      audio.addEventListener("durationchange", onReady);
      audio.addEventListener("canplay", onReady);
      audio.addEventListener("canplaythrough", onReady);
      audio.addEventListener("error", onError, { once: true });
      this.readyTimer = window.setTimeout(() => settle(audio.readyState >= 2), timeoutMs);
      audio.load?.();
      onReady();
    });
  }

  schedulePlaybackRetry(music, options, requestId) {
    window.clearTimeout(this.retryTimer);
    this.pendingPlayback = { music, options };
    this.retryTimer = window.setTimeout(() => {
      if (requestId !== this.playRequestId || !this.music) return;
      this.resume().catch(() => undefined);
    }, 350);
  }

  async playSegment(music, options = {}) {
    const requestId = ++this.playRequestId;
    const normalized = this.load(music, options);
    if (!normalized) return null;
    this.pendingPlayback = { music: normalized, options };

    const audio = this.getAudioElement();
    await this.ensureAudioGraph().catch(() => undefined);
    if (requestId !== this.playRequestId || !this.music) return normalized;

    await this.waitForAudioReady(requestId);
    if (requestId !== this.playRequestId || !this.music) return normalized;

    if (options.seek !== false) {
      this.seekToSegmentStart();
    }

    try {
      const playPromise = audio.play();
      if (playPromise?.catch) await playPromise;
      if (requestId !== this.playRequestId || !this.music) return normalized;
      this.isPlaying = !audio.paused;
      this.blockedByAutoplay = false;
      this.resumeOnGesture = false;
      this.pendingPlayback = null;
      window.clearTimeout(this.retryTimer);
      this.removeGestureUnlock();
      this.startProgressLoop();
    } catch {
      if (requestId !== this.playRequestId) return normalized;
      this.isPlaying = false;
      this.blockedByAutoplay = true;
      this.resumeOnGesture = options.resumeOnGesture !== false;
      this.schedulePlaybackRetry(normalized, options, requestId);
      if (this.resumeOnGesture) this.addGestureUnlock();
    }

    this.emitState();
    return normalized;
  }

  setSegment(music, options = {}) {
    const wasPlaying = this.isPlaying;
    const normalized = this.load(music, { ...options, seek: false });
    if (!normalized) return;

    const audio = this.getAudioElement();
    if (
      options.seekToStart ||
      audio.currentTime < normalized.startTime ||
      audio.currentTime >= normalized.endTime
    ) {
      this.seekToSegmentStart();
    }

    if (wasPlaying && options.keepPlaying !== false) {
      audio.play().catch(() => {
        this.blockedByAutoplay = true;
        this.resumeOnGesture = true;
        this.addGestureUnlock();
      });
      this.startProgressLoop();
    }

    this.emitProgress();
  }

  seekToSegmentStart() {
    if (!this.music || !this.audio) return;
    try {
      this.audio.currentTime = this.music.startTime;
    } catch {
      // Some browsers reject seeks before metadata. A later play attempt will retry.
    }
  }

  handleLoadedMetadata() {
    if (!this.music || !this.audio) return;
    if (
      this.audio.currentTime < this.music.startTime ||
      this.audio.currentTime >= this.music.endTime
    ) {
      this.seekToSegmentStart();
    }
    this.emitProgress();
  }

  enforceSegmentBounds() {
    if (!this.music || !this.audio) return false;

    if (this.audio.currentTime >= this.music.endTime - 0.02) {
      if (this.loop) {
        this.audio.currentTime = this.music.startTime;
        this.audio.play().catch(() => undefined);
      } else {
        this.audio.pause();
        this.audio.currentTime = this.music.startTime;
        this.isPlaying = false;
        this.stopProgressLoop();
        this.dispatchEvent(new CustomEvent("segmentended", { detail: this.getSnapshot() }));
      }
      return true;
    }

    if (this.audio.currentTime < this.music.startTime - 0.05) {
      this.audio.currentTime = this.music.startTime;
      return true;
    }

    return false;
  }

  pause() {
    this.audio?.pause();
    this.isPlaying = false;
    this.resumeOnGesture = false;
    this.stopProgressLoop();
    this.emitState();
  }

  async resume() {
    if (!this.music) return;
    const requestId = this.playRequestId;
    try {
      await this.ensureAudioGraph().catch(() => undefined);
      await this.waitForAudioReady(requestId, 2500);
      if (requestId !== this.playRequestId || !this.music) return;
      const audio = this.getAudioElement();
      if (audio.currentTime < this.music.startTime || audio.currentTime >= this.music.endTime) {
        this.seekToSegmentStart();
      }
      await audio.play();
      this.isPlaying = true;
      this.blockedByAutoplay = false;
      this.resumeOnGesture = false;
      this.pendingPlayback = null;
      window.clearTimeout(this.retryTimer);
      this.removeGestureUnlock();
      this.startProgressLoop();
    } catch {
      this.isPlaying = false;
      this.blockedByAutoplay = true;
      this.resumeOnGesture = true;
      this.addGestureUnlock();
    }
    this.emitState();
  }

  stop() {
    this.playRequestId += 1;
    this.removeGestureUnlock();
    window.clearTimeout(this.retryTimer);
    window.clearTimeout(this.readyTimer);
    this.retryTimer = null;
    this.readyTimer = null;
    this.pendingPlayback = null;
    if (this.audio) {
      this.audio.pause();
      this.audio.removeAttribute("src");
      this.audio.load();
    }
    this.music = null;
    this.loadedAudioUrl = "";
    this.isPlaying = false;
    this.blockedByAutoplay = false;
    this.resumeOnGesture = false;
    this.stopProgressLoop();
    this.emitState();
  }

  dispose() {
    this.stop();
    if (this.audio) {
      this.audio.removeEventListener("timeupdate", this.boundTimeUpdate);
      this.audio.removeEventListener("ended", this.boundEnded);
      this.audio.removeEventListener("loadedmetadata", this.boundLoadedMetadata);
      this.audio = null;
    }
    this.sourceNode?.disconnect();
    this.analyserNode?.disconnect();
    this.sourceNode = null;
    this.analyserNode = null;
    this.audioContext?.close?.().catch(() => undefined);
    this.audioContext = null;
  }

  handleTimeUpdate() {
    if (!this.music || !this.audio) return;

    this.enforceSegmentBounds();
    this.emitProgress();
  }

  handleEnded() {
    if (this.music && this.loop) {
      this.seekToSegmentStart();
      this.audio?.play().catch(() => undefined);
      return;
    }
    this.isPlaying = false;
    this.stopProgressLoop();
    this.emitState();
  }

  startProgressLoop() {
    if (this.rafId) return;
    const tick = () => {
      this.enforceSegmentBounds();
      this.emitProgress();
      if (this.audio && !this.audio.paused && this.music) {
        this.rafId = requestAnimationFrame(tick);
      } else {
        this.rafId = null;
      }
    };
    this.rafId = requestAnimationFrame(tick);
  }

  stopProgressLoop() {
    if (this.rafId) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
  }

  getSnapshot() {
    const currentTime = this.audio?.currentTime || this.music?.startTime || 0;
    const start = this.music?.startTime || 0;
    const duration = this.music?.duration || DEFAULT_SEGMENT_DURATION;
    const elapsed = Math.max(0, Math.min(duration, currentTime - start));

    return {
      music: this.music,
      currentTime,
      elapsed,
      duration,
      progress: duration > 0 ? elapsed / duration : 0,
      isPlaying: !!this.audio && !this.audio.paused,
      blockedByAutoplay: this.blockedByAutoplay,
    };
  }

  emitProgress() {
    this.dispatchEvent(new CustomEvent("progress", { detail: this.getSnapshot() }));
  }

  emitState() {
    this.dispatchEvent(new CustomEvent("statechange", { detail: this.getSnapshot() }));
  }

  subscribe(type, callback) {
    this.addEventListener(type, callback);
    return () => this.removeEventListener(type, callback);
  }
}

export const storyAudioManager = new StoryAudioManager();
