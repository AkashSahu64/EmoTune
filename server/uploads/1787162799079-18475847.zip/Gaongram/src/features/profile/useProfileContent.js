import { useInfiniteQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import { vibeService } from "../../services/vibe.service";

const PROFILE_CONTENT_KEY = "profile-content";

/* PAGE PARAM (NOT CURSOR) */
const getPageParams = (pageParam) => {
  if (!pageParam) return {};
  return { page: pageParam };
};

/* SAFE RESULT EXTRACTION */
const getResultsFromResponse = (response) => {
  // axios response
  const payload = response?.data?.data || response?.data || response;

  // paginated results
  if (Array.isArray(payload?.results)) {
    return payload.results;
  }

  // direct array
  if (Array.isArray(payload)) {
    return payload;
  }

  return [];
};

/* FIXED PAGINATION (PAGE BASED) */
const getNextPageParam = (response) => {
  const payload = response?.data?.data || response?.data || response;

  const nextUrl = payload?.next;

  if (!nextUrl) return undefined;

  try {
    const url = new URL(nextUrl);

    const page = url.searchParams.get("page");

    return page ? Number(page) : undefined;
  } catch {
    return undefined;
  }
};

/* ---------------- MEDIA HELPERS ---------------- */

/** Robust thumbnail extractor for posts & videos */
/** Robust thumbnail extractor for posts & videos */
const getPreviewImage = (item) => {
  // ---------------- IMAGES ----------------
  if (item.images?.length) {
    return (
      item.images[0]?.image ||
      item.images[0]?.url ||
      item.images[0]?.src ||
      null
    );
  }

  // ---------------- VIDEOS ----------------
  if (item.videos?.length || item.video) {
    const video = item.videos?.[0] || item.video;

    // ALL POSSIBLE VIDEO THUMBNAIL KEYS
    const thumbnail =
      video?.thumbnail ||
      video?.thumbnail_url ||
      video?.preview_frame ||
      video?.preview_image ||
      video?.preview ||
      video?.cover ||
      video?.cover_image ||
      video?.thumb ||
      video?.thumb_url ||
      video?.poster ||
      item?.preview_image ||
      item?.previewImage ||
      item?.thumbnail ||
      item?.thumbnail_url ||
      item?.cover_image ||
      null;

    if (thumbnail) return thumbnail;

    // fallback → use actual video url
    return (
      video?.video || video?.video_url || video?.url || video?.file || null
    );
  }

  // ---------------- AUDIO ----------------
  if (item.audio) {
    return (
      item.audio.cover_image ||
      item.audio.thumbnail ||
      item.audio.poster ||
      null
    );
  }

  // ---------------- DIRECT ----------------
  return (
    item.image ||
    item.thumbnail ||
    item.thumbnail_url ||
    item.preview_image ||
    item.previewImage ||
    null
  );
};

/** Determines media type from item structure */
const getMediaType = (item) => {
  // POLL FIRST
  if (
    item.poll ||
    item.poll_question ||
    (Array.isArray(item.poll_options) && item.poll_options.length > 0)
  ) {
    return "poll";
  }

  if (item.videos?.length || item.video) return "video";

  if (item.audio) return "audio";

  if (item.images?.length) return "image";

  return "text";
};

/** Robust duration extractor (supports seconds, "MM:SS" and "XmYs" strings) */
const extractVideoDuration = (item) => {
  // Gather possible raw values
  const sources = [
    item?.videos?.[0]?.duration,
    item?.duration,
    item?.videos?.[0]?.length,
    item?.videos?.[0]?.duration_seconds,
    item?.videos?.[0]?.play_time,
    item?.video_duration,
  ].filter((v) => v !== undefined && v !== null);

  if (sources.length === 0) return 0;

  const raw = sources[0]; // first found

  // If already a number, assume seconds
  if (typeof raw === "number") return raw > 0 ? raw : 0;

  // If string like "123" (just seconds)
  if (/^\d+$/.test(raw)) {
    const secs = parseInt(raw, 10);
    return secs > 0 ? secs : 0;
  }

  // If string like "4:32" or "1:02:03"
  const parts = raw.split(":").map(Number);
  if (parts.length === 2) {
    // m:ss
    return parts[0] * 60 + parts[1];
  }
  if (parts.length === 3) {
    // h:mm:ss
    return parts[0] * 3600 + parts[1] * 60 + parts[2];
  }

  // If string like "4m32s" or "4 m 32 s"
  const match = raw.match(/^(\d+)\s*m\s*(\d+)\s*s$/i);
  if (match) {
    return parseInt(match[1], 10) * 60 + parseInt(match[2], 10);
  }

  return 0;
};

/* ---------------- MAP ITEM ---------------- */
const mapProfileContentItem = (item) => {
  const mediaType = getMediaType(item);
  // Normalize videos (some APIs return item.video instead of item.videos)
  const videos = item.videos || (item.video ? [item.video] : []);

  return {
    id: item.id,
    is_sensitive: item.is_sensitive ?? item.isSensitive ?? false,
    userId: item.author ?? item.user?.id ?? null,

    username: item.user_name ?? item.user?.username ?? "",

    caption: item.content || item.caption || "",

    poll: item.poll || null,

    poll_question: item.poll_question || item.poll?.poll_question || "",

    poll_options: item.poll_options || item.poll?.poll_options || [],

    poll_votes: item.poll_votes || item.poll?.poll_votes || {},

    // ✅ IMPORTANT
    user_vote: item.user_vote ?? item.poll?.user_vote ?? null,

    previewImage: getPreviewImage(item),

    mediaType,

    images: item.images || [],

    videos,

    audio: item.audio || null,

    viewsCount: item.views_count ?? item.viewsCount ?? 0,

    likesCount: item.total_likes ?? item.likes_count ?? item.likesCount ?? 0,

    commentsCount: item.comments_count ?? item.commentsCount ?? 0,

    is_liked:
      item.is_liked === true || item.isLiked === true || item.liked === true,

    createdAt: item.created_at,

    isMultiAsset: (item.images?.length || 0) + videos.length > 1,

    videoDuration: extractVideoDuration(item),
  };
};

/* ---------------- FETCH ---------------- */
const fetchContentByTab = async (profileUserId, tab, pageParam) => {
  if (!profileUserId) {
    return { items: [], nextPageParam: undefined };
  }

  const params = getPageParams(pageParam);
  let response;

  if (tab === "videos") {
  response = await vibeService.getProfileUserVideos(
    profileUserId,
    params
  );
} else {
  response = await vibeService.getUserPosts(
    profileUserId,
    params
  );
}

  const results = getResultsFromResponse(response);

  // For audios tab, filter items that actually contain an audio file
  const filteredResults =
    tab === "audios"
      ? results.filter((item) => Boolean(item.audio?.audio))
      : results;

  return {
    items: filteredResults.map(mapProfileContentItem),
    nextPageParam: getNextPageParam(response),
  };
};

/* ---------------- HOOK ---------------- */
export const useProfileContent = (profileUserId, tab) => {
  const query = useInfiniteQuery({
    queryKey: [PROFILE_CONTENT_KEY, String(profileUserId || ""), tab],
    queryFn: ({ pageParam = 1 }) =>
      fetchContentByTab(profileUserId, tab, pageParam),
    enabled: Boolean(profileUserId && tab),
    initialPageParam: 1,
    getNextPageParam: (lastPage) => lastPage.nextPageParam,
    staleTime: 2 * 60 * 1000,
  });

  /* ✅ NO DUPLICATES */
  const items = useMemo(() => {
    const map = new Map();
    for (const page of query.data?.pages || []) {
      for (const item of page.items || []) {
        if (!map.has(item.id)) {
          map.set(item.id, item);
        }
      }
    }
    return Array.from(map.values());
  }, [query.data]);

  return {
    ...query,
    items,
  };
};
