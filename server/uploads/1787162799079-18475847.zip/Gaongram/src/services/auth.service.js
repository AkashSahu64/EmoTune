import api from "../config/axios.js";
import { TOKEN_KEYS } from "../config/env.js";

const clearLocalAuth = () => {
  if (typeof localStorage === "undefined") return;
  localStorage.removeItem(TOKEN_KEYS.ACCESS_TOKEN);
  localStorage.removeItem(TOKEN_KEYS.REFRESH_TOKEN);
  localStorage.removeItem(TOKEN_KEYS.USER_DATA);
};

export const authService = {
  register: async (userData) => {
    const payload = {
      full_name: userData.full_name || userData.username,
      email: userData.email,
      password: userData.password,
      phone: userData.phone || "",
    };
    const response = await api.post("/register/", payload);
    return response.data;
  },

  verifyOtp: async ({ email, otp }) => {
    const payload = {
      identifier: email,
      code: otp,
      fcmToken: "web",
      device_type: "web",
    };

    const response = await api.post("/verify-otp/", payload);

    if (response.data.access && response.data.refresh) {
      localStorage.setItem(TOKEN_KEYS.ACCESS_TOKEN, response.data.access);
      localStorage.setItem(TOKEN_KEYS.REFRESH_TOKEN, response.data.refresh);
      localStorage.setItem(
        TOKEN_KEYS.USER_DATA,
        JSON.stringify(response.data.user),
      );
    }

    return response.data;
  },

  login: async ({ email, password }) => {
    const payload = {
      identifier: email,
      password,
      device_type: "web",
      fcmToken: "web",
    };
    const response = await api.post("/login/", payload);
    const { data } = response.data;

    localStorage.setItem(TOKEN_KEYS.ACCESS_TOKEN, data.access);
    localStorage.setItem(TOKEN_KEYS.REFRESH_TOKEN, data.refresh);
    localStorage.setItem(TOKEN_KEYS.USER_DATA, JSON.stringify(data.user));

    return response.data;
  },

  googleAuth: async (token) => {
    const payload = {
      id_token: token,
      fcm_token: "web",
      device_type: "web",
    };
    const response = await api.post("/auth/google/", payload);

    localStorage.setItem(TOKEN_KEYS.ACCESS_TOKEN, response.data.access);
    localStorage.setItem(TOKEN_KEYS.REFRESH_TOKEN, response.data.refresh);
    localStorage.setItem(
      TOKEN_KEYS.USER_DATA,
      JSON.stringify(response.data.user),
    );

    return response.data;
  },

  logout: async () => {
    const refreshToken =
      typeof localStorage !== "undefined"
        ? localStorage.getItem(TOKEN_KEYS.REFRESH_TOKEN)
        : null;

    try {
      if (refreshToken) {
        await api.post("/logout/", {
          refresh: refreshToken,
          device_type: "web",
        });
      }
    } catch (error) {
      console.log("Logout API failed (ignored)");
    } finally {
      clearLocalAuth();
    }
  },

  logoutAll: async () => {
    const refreshToken =
      typeof localStorage !== "undefined"
        ? localStorage.getItem(TOKEN_KEYS.REFRESH_TOKEN)
        : null;
    const payload = {
      refresh: refreshToken,
      device_type: "web",
    };

    try {
      await api.post("/logout-all/", payload);
    } finally {
      clearLocalAuth();
    }
  },

  forgotPassword: async ({ identifier }) => {
    const response = await api.post("/forgot-password/", { identifier });
    return response.data;
  },

  changePassword: async ({ old_password, new_password }) => {
    const response = await api.post("/change-password/", {
      old_password,
      new_password,
    });
    return response.data;
  },

  resetPassword: async ({ token, new_password, confirm_password }) => {
    const response = await api.post(`/reset-password/${token}/`, {
      new_password,
      confirm_password,
    });
    return response.data;
  },

  verifyToken: async () => {
    const response = await api.post("/token/verify/", {
      token:
        typeof localStorage !== "undefined"
          ? localStorage.getItem(TOKEN_KEYS.ACCESS_TOKEN)
          : null,
    });
    return response.data;
  },

  getCurrentUser: () => {
    if (typeof localStorage === "undefined") return null;
    const userData = localStorage.getItem(TOKEN_KEYS.USER_DATA);
    if (!userData) return null;

    try {
      return JSON.parse(userData);
    } catch (error) {
      clearLocalAuth();
      return null;
    }
  },

  isAuthenticated: () => {
    if (typeof localStorage === "undefined") return false;
    return !!localStorage.getItem(TOKEN_KEYS.ACCESS_TOKEN);
  },

  getAuthHeaders: () => {
    const token =
      typeof localStorage !== "undefined"
        ? localStorage.getItem(TOKEN_KEYS.ACCESS_TOKEN)
        : null;
    return token ? { Authorization: `Bearer ${token}` } : {};
  },

  clearLocalAuth,
};