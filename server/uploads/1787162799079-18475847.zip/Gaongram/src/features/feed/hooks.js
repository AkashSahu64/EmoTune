import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { feedAPI } from './api.js';
import { showSuccess, showError } from '../../../utils/toast.js';

export const useFeed = (params = {}) => {
  return useQuery({
    queryKey: ['feed', params],
    queryFn: () => feedAPI.getFeed(params),
    staleTime: 2 * 60 * 1000, // 2 minutes
    gcTime: 5 * 60 * 1000, // 5 minutes
  });
};

export const useCreatePost = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: feedAPI.createPost,
    onSuccess: () => {
      showSuccess('Post created successfully!');
      queryClient.invalidateQueries(['feed']);
    },
    onError: (error) => {
      showError(error.response?.data?.message || 'Failed to create post');
    },
  });
};

export const useLikePost = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: feedAPI.likePost,
    onMutate: async (postId) => {
      // Cancel any outgoing refetches
      await queryClient.cancelQueries(['feed']);
      
      // Snapshot the previous value
      const previousFeed = queryClient.getQueryData(['feed']);
      
      // Optimistically update the feed
      queryClient.setQueryData(['feed'], (old) => {
        if (!old?.data) return old;
        
        return {
          ...old,
          data: old.data.map(post => {
            if (post.id === postId) {
              return {
                ...post,
                is_liked: true,
                likes_count: (post.likes_count || 0) + 1,
              };
            }
            return post;
          }),
        };
      });
      
      return { previousFeed };
    },
    onError: (error, postId, context) => {
      // Rollback on error
      if (context?.previousFeed) {
        queryClient.setQueryData(['feed'], context.previousFeed);
      }
      showError('Failed to like post');
    },
    onSettled: () => {
      // Refetch after mutation
      queryClient.invalidateQueries(['feed']);
    },
  });
};

export const useUnlikePost = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: feedAPI.unlikePost,
    onMutate: async (postId) => {
      await queryClient.cancelQueries(['feed']);
      
      const previousFeed = queryClient.getQueryData(['feed']);
      
      queryClient.setQueryData(['feed'], (old) => {
        if (!old?.data) return old;
        
        return {
          ...old,
          data: old.data.map(post => {
            if (post.id === postId) {
              return {
                ...post,
                is_liked: false,
                likes_count: Math.max(0, (post.likes_count || 1) - 1),
              };
            }
            return post;
          }),
        };
      });
      
      return { previousFeed };
    },
    onError: (error, postId, context) => {
      if (context?.previousFeed) {
        queryClient.setQueryData(['feed'], context.previousFeed);
      }
      showError('Failed to unlike post');
    },
    onSettled: () => {
      queryClient.invalidateQueries(['feed']);
    },
  });
};

export const useSavePost = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: feedAPI.savePost,
    onMutate: async (postId) => {
      await queryClient.cancelQueries(['feed']);
      
      const previousFeed = queryClient.getQueryData(['feed']);
      
      queryClient.setQueryData(['feed'], (old) => {
        if (!old?.data) return old;
        
        return {
          ...old,
          data: old.data.map(post => {
            if (post.id === postId) {
              return {
                ...post,
                is_saved: true,
              };
            }
            return post;
          }),
        };
      });
      
      return { previousFeed };
    },
    onSuccess: () => {
      showSuccess('Post saved');
    },
    onError: (error, postId, context) => {
      if (context?.previousFeed) {
        queryClient.setQueryData(['feed'], context.previousFeed);
      }
      showError('Failed to save post');
    },
    onSettled: () => {
      queryClient.invalidateQueries(['feed']);
    },
  });
};

export const useUnsavePost = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: feedAPI.unsavePost,
    onMutate: async (postId) => {
      await queryClient.cancelQueries(['feed']);
      
      const previousFeed = queryClient.getQueryData(['feed']);
      
      queryClient.setQueryData(['feed'], (old) => {
        if (!old?.data) return old;
        
        return {
          ...old,
          data: old.data.map(post => {
            if (post.id === postId) {
              return {
                ...post,
                is_saved: false,
              };
            }
            return post;
          }),
        };
      });
      
      return { previousFeed };
    },
    onSuccess: () => {
      showSuccess('Post removed from saved');
    },
    onError: (error, postId, context) => {
      if (context?.previousFeed) {
        queryClient.setQueryData(['feed'], context.previousFeed);
      }
      showError('Failed to unsave post');
    },
    onSettled: () => {
      queryClient.invalidateQueries(['feed']);
    },
  });
};

export const useDeletePost = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: feedAPI.deletePost,
    onSuccess: () => {
      showSuccess('Post deleted successfully');
      queryClient.invalidateQueries(['feed']);
    },
    onError: (error) => {
      showError(error.response?.data?.message || 'Failed to delete post');
    },
  });
};

export const usePost = (postId) => {
  return useQuery({
    queryKey: ['post', postId],
    queryFn: () => feedAPI.getPost(postId),
    enabled: !!postId,
    staleTime: 2 * 60 * 1000,
  });
};