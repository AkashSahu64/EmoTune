export const getDeviceProfile = () => {
  const userAgent = navigator.userAgent || "";
  const isIOS = /iPad|iPhone|iPod/.test(userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  const isSafari = /^((?!chrome|android).)*safari/i.test(userAgent);
  const isTouch = navigator.maxTouchPoints > 0 || "ontouchstart" in window;
  const memory = navigator.deviceMemory || 4;
  const cores = navigator.hardwareConcurrency || 4;
  const dpr = Math.min(window.devicePixelRatio || 1, 3);

  return {
    isIOS,
    isSafari,
    isTouch,
    dpr,
    memory,
    cores,
    isLowPower: memory <= 2 || cores <= 4,
    prefersReducedMotion: window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches || false,
  };
};

export const getViewportSize = () => ({
  width: window.visualViewport?.width || window.innerWidth,
  height: window.visualViewport?.height || window.innerHeight,
});

export const supportsVideoExport = () =>
  typeof MediaRecorder !== "undefined" &&
  Boolean(HTMLCanvasElement.prototype.captureStream);
