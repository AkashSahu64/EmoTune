import React from "react";
import { motion } from "framer-motion";

const compactNumberFormatter = new Intl.NumberFormat("en", {
  notation: "compact",
  maximumFractionDigits: 1,
});

const formatValue = (value) =>
  typeof value === "number" ? compactNumberFormatter.format(value) : value;

const ProfileStats = ({ stats, onStatClick }) => {
  const statItems = [
    { key: "posts", label: "Posts", value: stats.posts, clickable: false },
    {
      key: "followers",
      label: "Followers",
      value: stats.followers,
      clickable: true,
    },
    {
      key: "following",
      label: "Following",
      value: stats.following,
      clickable: true,
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.16 }}
      className="mx-auto max-w-sm"
    >
      <div className="grid grid-cols-3">
        {statItems.map((item) => {
          const content = (
            <>
              <span className="text-lg font-semibold tracking-[-0.02em] text-foreground dark:text-foreground-dark sm:text-xl">
                {formatValue(item.value)}
              </span>
              <span className="text-xs font-medium uppercase tracking-[0.14em] text-mutedForeground dark:text-mutedForeground-dark">
                {item.label}
              </span>
            </>
          );

          if (!item.clickable) {
            return (
              <div
                key={item.key}
                className="flex min-h-14 flex-col items-center justify-center gap-1 px-3 py-2"
              >
                {content}
              </div>
            );
          }

          return (
            <button
              key={item.key}
              type="button"
              onClick={() => onStatClick(item.key)}
              className="flex min-h-14 flex-col items-center justify-center gap-1 px-3 py-2 transition hover:bg-muted/20 dark:hover:bg-muted-dark/20 rounded-lg"
            >
              {content}
            </button>
          );
        })}
      </div>
    </motion.div>
  );
};

export default React.memo(ProfileStats);
