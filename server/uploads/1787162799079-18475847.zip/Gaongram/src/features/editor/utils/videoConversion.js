import { FFmpeg } from "@ffmpeg/ffmpeg";
import { fetchFile } from "@ffmpeg/util";

let ffmpegPromise = null;

const getFFmpeg = async () => {
  if (!ffmpegPromise) {
    ffmpegPromise = (async () => {
      const ffmpeg = new FFmpeg();
      await ffmpeg.load();
      return ffmpeg;
    })();
  }
  return ffmpegPromise;
};

export const convertImageAndAudioToMp4 = async ({
  imageBlob,
  audioUrl,
  duration = 15,
  fileName = "story.mp4",
  onProgress,
}) => {
  if (!imageBlob || !audioUrl) {
    throw new Error("Image and audio are required for video conversion");
  }

  const ffmpeg = await getFFmpeg();
  ffmpeg.on("progress", ({ progress }) => {
    onProgress?.({ progress: Math.round(35 + progress * 55), message: "Encoding video..." });
  });

  await ffmpeg.writeFile("frame.jpg", await fetchFile(imageBlob));
  await ffmpeg.writeFile("audio.mp3", await fetchFile(audioUrl));
  await ffmpeg.exec([
    "-loop",
    "1",
    "-i",
    "frame.jpg",
    "-i",
    "audio.mp3",
    "-t",
    String(Math.max(1, duration)),
    "-vf",
    "scale=720:1280:force_original_aspect_ratio=decrease,pad=720:1280:(ow-iw)/2:(oh-ih)/2",
    "-c:v",
    "libx264",
    "-pix_fmt",
    "yuv420p",
    "-c:a",
    "aac",
    "-shortest",
    "out.mp4",
  ]);

  const data = await ffmpeg.readFile("out.mp4");
  const blob = new Blob([data.buffer], { type: "video/mp4" });
  return new File([blob], fileName, { type: "video/mp4", lastModified: Date.now() });
};
