// src/features/story-editor/services/stickerService.js
const GIPHY_API_KEY = 'YOUR_GIPHY_KEY'; // move to env
const TENOR_API_KEY = 'YOUR_TENOR_KEY';  // move to env

export const searchStickers = async (query, limit = 20) => {
  // Try GIPHY first
  try {
    const res = await fetch(
      `https://api.giphy.com/v1/stickers/search?api_key=${GIPHY_API_KEY}&q=${encodeURIComponent(query)}&limit=${limit}`
    );
    const json = await res.json();
    if (json.data?.length) {
      return json.data.map((item) => ({
        id: item.id,
        url: item.images.fixed_height.url,
      }));
    }
  } catch (e) {
    console.warn('GIPHY failed, trying Tenor', e);
  }

  // Fallback to Tenor
  try {
    const res = await fetch(
      `https://tenor.googleapis.com/v2/search?q=${encodeURIComponent(query)}&key=${TENOR_API_KEY}&limit=${limit}&media_filter=sticker`
    );
    const json = await res.json();
    return json.results.map((item) => ({
      id: item.id,
      url: item.media_formats.gif.url,
    }));
  } catch (e) {
    console.error('Sticker search failed', e);
    return [];
  }
};