const url = require("node:url");
const { run } = require("react-snap");

const {
  reactSnap = {},
  homepage,
  devDependencies,
  dependencies,
} = require("../package.json");

const publicUrl = process.env.PUBLIC_URL || homepage;
const reactScriptsVersion = parseInt(
  (devDependencies && devDependencies["react-scripts"]) ||
    (dependencies && dependencies["react-scripts"]),
  10,
);

let fixWebpackChunksIssue;
switch (reactScriptsVersion) {
  case 1:
    fixWebpackChunksIssue = "CRA1";
    break;
  case 2:
    fixWebpackChunksIssue = "CRA2";
    break;
  default:
    fixWebpackChunksIssue = undefined;
}

const resolvedRoutes = (() => {
  try {
    const parsed = JSON.parse(process.env.GAONGRAM_PRERENDER_ROUTES_RESOLVED || "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
})();

run({
  publicPath: publicUrl ? url.parse(publicUrl).pathname : "/",
  fixWebpackChunksIssue,
  ...reactSnap,
  include: resolvedRoutes.length ? resolvedRoutes : reactSnap.include,
}).catch((error) => {
  console.error(error);
  process.exit(1);
});
