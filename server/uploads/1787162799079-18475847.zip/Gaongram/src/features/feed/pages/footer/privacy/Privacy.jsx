// src/pages/PrivacyPolicy.jsx
import React, { useRef, useState } from "react";
import { motion, useInView, useScroll, useTransform } from "framer-motion";
import {
  Shield,
  Lock,
  Server,
  Eye,
  FileText,
  UserCheck,
  Database,
  Globe,
  ChevronDown,
  CheckCircle,
  AlertTriangle,
  Smartphone,
  Users,
  HelpCircle,
} from "lucide-react";
import MinimalLayout from "../../../components/layout/MinimalLayout";
import Seo from "../../../../../components/seo/Seo.jsx";
import { buildStaticPageSeo } from "../../../../../seo/seoBuilders.js";

// Animation variants
const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
};

// Accordion component (Instagram style)
const PrivacyAccordion = ({
  title,
  icon: Icon,
  children,
  defaultOpen = false,
}) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="border-b border-border/50 dark:border-border-dark/50 last:border-0"
    >
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full py-5 flex items-center gap-4 text-left hover:bg-muted/30 dark:hover:bg-muted-dark/30 transition px-2 rounded-lg"
      >
        {Icon && (
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
            <Icon className="w-5 h-5 text-primary" />
          </div>
        )}
        <span className="text-lg font-medium text-foreground dark:text-foreground-dark flex-1">
          {title}
        </span>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.25 }}
        >
          <ChevronDown className="w-5 h-5 text-mutedForeground" />
        </motion.div>
      </button>
      <motion.div
        initial={false}
        animate={{ height: isOpen ? "auto" : 0, opacity: isOpen ? 1 : 0 }}
        transition={{ duration: 0.3 }}
        className="overflow-hidden"
      >
        <div className="pb-5 px-2 prose prose-base dark:prose-invert max-w-none text-mutedForeground dark:text-mutedForeground-dark">
          {children}
        </div>
      </motion.div>
    </motion.div>
  );
};

// Feature Card Grid (Instagram style small cards)
const PrivacyFeatureGrid = () => {
  const features = [
    {
      icon: Lock,
      title: "End‑to‑End Encryption",
      description: "AES‑256 encryption secures every message.",
      color: "from-blue-500 to-blue-600",
    },
    {
      icon: Server,
      title: "Data Residency",
      description: "Servers located exclusively in India.",
      color: "from-emerald-500 to-green-600",
    },
    {
      icon: UserCheck,
      title: "Granular Consent",
      description: "You decide what information to share.",
      color: "from-purple-500 to-purple-600",
    },
    {
      icon: Shield,
      title: "No Data Selling",
      description: "We never trade your personal data.",
      color: "from-amber-500 to-orange-600",
    },
  ];

  return (
    <section className="py-8">
      <div className="max-w-4xl mx-auto px-4">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="text-center mb-10"
        >
          <motion.h2
            variants={fadeUp}
            className="text-4xl font-semibold text-foreground dark:text-foreground-dark"
          >
            Privacy by design
          </motion.h2>
        </motion.div>
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={staggerContainer}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2"
        >
          {features.map((item, idx) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={idx}
                variants={fadeUp}
                whileHover={{ y: -4 }}
                className="bg-card dark:bg-card-dark rounded-xl p-5 border border-border dark:border-border-dark shadow-soft transition-all"
              >
                <div
                  className={`w-10 h-10 rounded-lg bg-gradient-to-br ${item.color} flex items-center justify-center mb-3 text-white`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="font-semibold text-foreground dark:text-foreground-dark mb-1">
                  {item.title}
                </h3>
                <p className="text-sm text-mutedForeground dark:text-mutedForeground-dark">
                  {item.description}
                </p>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
};

// Black Highlight (Instagram style)
const BlackHighlight = ({ text }) => {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });
  const y = useTransform(scrollYProgress, [0, 1], [30, -30]);
  const opacity = useTransform(
    scrollYProgress,
    [0, 0.3, 0.7, 1],
    [0.7, 1, 1, 0.7],
  );

  return (
    <section
      ref={ref}
      className="py-24 text-foreground dark:text-foreground-dark overflow-hidden"
    >
      <div className="max-w-4xl mx-auto px-4 text-center">
        <motion.h2
          style={{ y, opacity }}
          className="text-3xl md:text-5xl font-bold leading-tight"
        >
          {text}
        </motion.h2>
      </div>
    </section>
  );
};

// Image + Text Highlight (alternating sections, simplified)
const ImageTextBlock = ({
  label,
  title,
  content,
  imageUrl,
  reverse,
  bulletPoints,
}) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <motion.section
      ref={ref}
      initial="hidden"
      animate={isInView ? "visible" : "hidden"}
      className="py-12 md:py-16"
    >
      <div className="max-w-6xl mx-auto px-4">
        <div
          className={`grid md:grid-cols-2 gap-10 items-center ${reverse ? "md:flex-row-reverse" : ""}`}
        >
          <motion.div
            variants={staggerContainer}
            className={`space-y-4 ${reverse ? "md:order-2" : ""}`}
          >
            {label && (
              <motion.span
                variants={fadeUp}
                className="text-sm font-medium text-primary uppercase tracking-wide"
              >
                {label}
              </motion.span>
            )}
            <motion.h3
              variants={fadeUp}
              className="text-2xl md:text-3xl font-semibold text-foreground dark:text-foreground-dark"
            >
              {title}
            </motion.h3>
            <motion.div
              variants={fadeUp}
              className="text-mutedForeground dark:text-mutedForeground-dark space-y-3"
            >
              {typeof content === "string" ? <p>{content}</p> : content}
            </motion.div>
            {bulletPoints && (
              <motion.ul variants={staggerContainer} className="space-y-2">
                {bulletPoints.map((point, idx) => (
                  <motion.li
                    key={idx}
                    variants={fadeUp}
                    className="flex gap-2 text-sm text-mutedForeground dark:text-mutedForeground-dark"
                  >
                    <CheckCircle className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                    <span>{point}</span>
                  </motion.li>
                ))}
              </motion.ul>
            )}
          </motion.div>
          <motion.div
            variants={
              reverse
                ? {
                    hidden: { opacity: 0, x: -20 },
                    visible: { opacity: 1, x: 0 },
                  }
                : {
                    hidden: { opacity: 0, x: 20 },
                    visible: { opacity: 1, x: 0 },
                  }
            }
            transition={{ duration: 0.6 }}
            className={`${reverse ? "md:order-1" : ""}`}
          >
            <div className="rounded-2xl overflow-hidden border border-border dark:border-border-dark shadow-soft">
              <img
                src={imageUrl}
                alt={title}
                className="w-full h-auto"
                loading="lazy"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </motion.section>
  );
};

// Main Privacy Policy Page
const Privacy = () => {
  return (
    <MinimalLayout>
      <Seo {...buildStaticPageSeo("privacy")} />
      <div className="min-h-screen bg-background dark:bg-background-dark">
        {/* Hero */}
        <section className="pt-16 pb-8 md:pt-24 md:pb-12">
          <div className="max-w-3xl mx-auto px-4 text-center">
            <motion.h1
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-4xl md:text-6xl font-bold text-foreground dark:text-foreground-dark mb-3"
            >
              Privacy Policy
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-xl text-primary font-medium"
            >
              "Aapka Data, Aapki Amanat"
            </motion.p>
            <motion.p
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              className="text-mutedForeground dark:text-mutedForeground-dark mt-4 max-w-xl mx-auto"
            >
              Your Data, Your Trust. We protect what matters most.
            </motion.p>
          </div>
        </section>

        {/* Introduction as simple text block */}
        <section className="py-8">
          <div className="max-w-4xl mx-auto px-4">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={staggerContainer}
              className="prose prose-lg dark:prose-invert max-w-none text-mutedForeground dark:text-mutedForeground-dark"
            >
              <h2 className="text-2xl font-semibold text-foreground dark:text-foreground-dark mb-2">
                1. Introduction: The Privacy-First Mandate
              </h2>
              <p>
                At GaonGram, we believe privacy is a fundamental right, as
                upheld by the Supreme Court of India in the Justice K.S.
                Puttaswamy judgment. For the rural user, privacy is often
                synonymous with Dignity and Safety. Our platform is engineered
                with Privacy by Design, ensuring that data protection is not an
                "add-on" but a core structural component of our technology
                stack.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Instagram-style accordion for main policy sections */}
        <section className="py-8">
          <div className="max-w-4xl mx-auto px-4">
            <div className="bg-card dark:bg-card-dark rounded-2xl border border-border dark:border-border-dark overflow-hidden divide-y divide-border dark:divide-border-dark px-2">
              <PrivacyAccordion
                title="2. Statutory Compliance: The DPDP Act, 2023"
                icon={FileText}
                defaultOpen
              >
                <p>
                  GaonGram is fully aligned with the Digital Personal Data
                  Protection (DPDP) Act, 2023. We operate under the legal
                  definitions of a Data Fiduciary, while our users are
                  recognized as Data Principals.
                </p>
                <h4 className="font-semibold mt-4 mb-2">
                  2.1. The Principle of Purpose Limitation
                </h4>
                <p>
                  We collect data only for specified, clear, and legitimate
                  purposes. We do not engage in "Data Crawling" or unnecessary
                  harvesting of personal life details.
                </p>
                <h4 className="font-semibold mt-4 mb-2">
                  2.2. Lawful Consent (The "Notice" Protocol)
                </h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>
                    Linguistic Accessibility: Consent notices are provided in
                    the user's native language (Hindi, Marathi, Telugu, etc.).
                  </li>
                  <li>
                    Granular Consent: Users can choose to share their location
                    for "Mandi Prices" while denying access to their contact
                    list. Consent is not an "all-or-nothing" deal.
                  </li>
                </ul>
              </PrivacyAccordion>

              <PrivacyAccordion
                title="3. Data Collection Categories (The 'Minimum Data' Rule)"
                icon={Database}
              >
                <p>
                  We follow the Data Minimization principle. If we don't need it
                  to run the app, we don't ask for it.
                </p>
                <h4 className="font-semibold mt-4 mb-2">
                  3.1. Personal Identifiers
                </h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>
                    Verification: We collect and verify the Mobile Number via
                    OTP to prevent bot-led misinformation.
                  </li>
                  <li>
                    Profile Information: Name and Gender are collected to
                    personalize the interface and enforce safety protocols for
                    women.
                  </li>
                </ul>
                <h4 className="font-semibold mt-4 mb-2">
                  3.2. Technical Metadata
                </h4>
                <p>
                  To ensure the app runs on low-cost smartphones common in rural
                  areas, we collect:
                </p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Device Model and Operating System version.</li>
                  <li>
                    Network quality logs (to optimize video loading in 2G/3G
                    areas).
                  </li>
                </ul>
                <h4 className="font-semibold mt-4 mb-2">
                  3.3. Location Data (Dynamic Consent)
                </h4>
                <p>
                  GaonGram never tracks your location in the background.
                  Location access is requested only when:
                </p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>A farmer seeks local weather or crop advisories.</li>
                  <li>A user searches for "Nearby Gram Panchayats."</li>
                </ul>
              </PrivacyAccordion>

              <PrivacyAccordion
                title="4. Data Residency: Sovereignty Over the Soil"
                icon={Globe}
              >
                <p>
                  Unlike global social media giants that export Indian data to
                  foreign servers, GaonGram maintains Absolute Data
                  Localization.
                </p>
                <ul className="list-disc pl-5 space-y-1 mt-3">
                  <li>
                    Indian Servers: All user data is stored in Tier-4,
                    MeitY-empaneled data centers located within Indian
                    geographical boundaries.
                  </li>
                  <li>
                    Legal Shield: This ensures that your data is protected under
                    the Information Technology Rules of India and cannot be
                    accessed by foreign entities without the due process of
                    Indian Law.
                  </li>
                </ul>
              </PrivacyAccordion>

              <PrivacyAccordion
                title="5. Security Architecture: The 'Digital Quila'"
                icon={Shield}
              >
                <h4 className="font-semibold mb-2">
                  5.1. End-to-End Encryption (E2EE)
                </h4>
                <p>
                  All private messages, voice notes, and shared documents are
                  protected by AES-256 bit encryption.
                </p>
                <p>
                  The "Zero-Knowledge" Standard: GaonGram administrators cannot
                  read your private chats. The keys to decrypt the messages
                  exist only on the sender's and receiver's devices.
                </p>
                <h4 className="font-semibold mt-4 mb-2">
                  5.2. Protection Against "Social Engineering"
                </h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>
                    Hidden Mobile Numbers: By default, a user's mobile number is
                    hidden from non-contacts to prevent unsolicited calls and
                    harassment.
                  </li>
                  <li>
                    Anti-Scraping Technology: Our systems prevent automated bots
                    from "scraping" or stealing the photos and bio-data of our
                    users.
                  </li>
                </ul>
              </PrivacyAccordion>
            </div>
          </div>
        </section>

        {/* Privacy Feature Grid */}
        <PrivacyFeatureGrid />

        {/* Additional sections as accordion continuation */}
        <section className="py-8">
          <div className="max-w-4xl mx-auto px-4">
            <div className="bg-card dark:bg-card-dark rounded-2xl border border-border dark:border-border-dark shadow-soft overflow-hidden divide-y divide-border dark:divide-border-dark px-2">
              <PrivacyAccordion
                title="6. User Rights: Data Sovereignty in Your Hands"
                icon={UserCheck}
              >
                <p>As the "Data Principal," you hold the following rights:</p>
                <h4 className="font-semibold mt-4 mb-2">
                  6.1. Right to Access and Correction
                </h4>
                <p>
                  Users can request a summary of all data GaonGram holds about
                  them and correct any inaccuracies.
                </p>
                <h4 className="font-semibold mt-4 mb-2">
                  6.2. Right to Erasure ("The Right to be Forgotten")
                </h4>
                <p>If you choose to delete your GaonGram account:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Your data enters a 30-day "Cooling-off" period.</li>
                  <li>
                    After 30 days, the data is permanently purged from our
                    active servers, except where retention is legally mandated.
                  </li>
                </ul>
                <h4 className="font-semibold mt-4 mb-2">
                  6.3. Right to Withdraw Consent
                </h4>
                <p>
                  Users can revoke any permission (Camera, Microphone, Contacts)
                  at any time through the "Privacy Settings" menu.
                </p>
              </PrivacyAccordion>

              <PrivacyAccordion
                title="7. Third-Party Sharing and Commercial Privacy"
                icon={Eye}
              >
                <ul className="list-disc pl-5 space-y-1">
                  <li>
                    No-Sale Pledge: GaonGram never sells, rents, or trades your
                    personal identity to data brokers or third-party marketing
                    firms.
                  </li>
                  <li>
                    Privacy-Preserving Ads: If we show advertisements, we use
                    Anonymized Aggregated Data. The advertiser sees a "Group of
                    1000 Farmers," but never your name or number.
                  </li>
                </ul>
              </PrivacyAccordion>

              <PrivacyAccordion
                title="8. Grievance Redressal for Privacy"
                icon={AlertTriangle}
              >
                <p>If a user feels their privacy has been breached:</p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>
                    Privacy Officer: A dedicated officer reviews all
                    privacy-related complaints.
                  </li>
                  <li>
                    Reporting Timeline: Under the DPDP Act, we are committed to
                    responding to privacy grievances within the stipulated legal
                    window.
                  </li>
                </ul>
              </PrivacyAccordion>
            </div>
          </div>
        </section>

        {/* Conclusion */}
        <section className="py-8">
          <div className="max-w-4xl mx-auto px-4">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUp}
              className="prose prose-lg dark:prose-invert max-w-none text-mutedForeground dark:text-mutedForeground-dark"
            >
              <h2 className="text-2xl font-semibold text-foreground dark:text-foreground-dark">
                Conclusion: Trust is Our Foundation
              </h2>
              <p>
                In the villages of India, privacy is about Respect. GaonGram
                honors this by ensuring that your digital footprint is as safe
                as your family home. We don't just protect data; we protect the
                People behind the data.
              </p>
              <p className="font-semibold">
                GaonGram: Aapki Pehchan, Aapki Suraksha. (Your Identity, Your
                Security.)
              </p>
            </motion.div>
          </div>
        </section>

        {/* Black Highlight */}
        <BlackHighlight text="Your Data Belongs to You" />

        {/* Annexures as separate accordion group */}
        <section className="py-12">
          <div className="max-w-4xl mx-auto px-4">
            <motion.h2
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUp}
              className="text-3xl font-semibold mb-6 text-foreground dark:text-foreground-dark"
            >
              Technical Annexures
            </motion.h2>
            <div className="bg-card dark:bg-card-dark rounded-2xl border border-border dark:border-border-dark shadow-soft overflow-hidden divide-y divide-border dark:divide-border-dark px-2">
              <PrivacyAccordion
                title="Annexure G: Encryption Protocols"
                icon={Lock}
                defaultOpen
              >
                <h4 className="font-semibold">
                  The Technical Shield: Implementation of the Signal Protocol
                </h4>
                <p>
                  GaonGram utilizes the Double Ratchet Algorithm (famously known
                  as the Signal Protocol) to ensure End-to-End Encryption
                  (E2EE).
                </p>
                <ul className="list-disc pl-5 space-y-1 mt-2">
                  <li>
                    <strong>Initial Key Exchange:</strong> Diffie-Hellman Key
                    Exchange creates a shared secret without sending the key.
                  </li>
                  <li>
                    <strong>The Double Ratchet:</strong> Every message has a
                    unique, one-time-use key (Forward Secrecy).
                  </li>
                  <li>
                    <strong>Zero-Knowledge Storage:</strong> Servers cannot read
                    chats; data is mathematically unreadable.
                  </li>
                </ul>
              </PrivacyAccordion>

              <PrivacyAccordion
                title="Annexure H: Cookie & Local Storage Policy"
                icon={Smartphone}
              >
                <h4 className="font-semibold">
                  Data Efficiency: Protecting the User's Pocket
                </h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Local Caching: Saves up to 40% data costs.</li>
                  <li>Session Persistence: Tokens expire every 30 days.</li>
                  <li>
                    No Third-Party Tracking: Strictly First-Party storage.
                  </li>
                </ul>
              </PrivacyAccordion>

              <PrivacyAccordion
                title="Annexure I: Data Breach Response Plan (DBRP)"
                icon={AlertTriangle}
              >
                <h4 className="font-semibold">
                  The Emergency Protocol: 72-hour Response Timeline
                </h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>
                    Identification: AI detects anomalies; server isolation.
                  </li>
                  <li>Containment: Session tokens revoked, PIN reset.</li>
                  <li>
                    Mandatory Notification: CERT-In notified within 6 hours;
                    users informed.
                  </li>
                  <li>Forensic Audit: Independent third-party review.</li>
                </ul>
              </PrivacyAccordion>

              <PrivacyAccordion
                title="Annexure J: Specific Clauses for Minors"
                icon={Users}
              >
                <h4 className="font-semibold">The Bal-Suraksha Protocol</h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>
                    Verifiable Parental Consent via OTP-verified guardian.
                  </li>
                  <li>No Behavioral Tracking; ads are contextual only.</li>
                  <li>Default "High Privacy" settings for minors.</li>
                  <li>Absolute Right to Erasure for parents.</li>
                </ul>
              </PrivacyAccordion>
            </div>
          </div>
        </section>
      </div>
    </MinimalLayout>
  );
};

export default Privacy;
