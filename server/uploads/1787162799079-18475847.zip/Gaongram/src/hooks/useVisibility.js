// src/hooks/useVisibility.js
import { useEffect, useRef, useState, useCallback } from 'react';
import { useMediaStore } from '../store/mediaStore.js';

// ============================================
// ORIGINAL HOOK – Intersection Observer for posts
// (unchanged – no breaking changes)
// ============================================
export const useVisibility = (postId, options = {}) => {
  const elementRef = useRef(null);
  const [isVisible, setIsVisible] = useState(false);
  const { setActivePost, clearActivePost, shouldPlay } = useMediaStore();
  
  const {
    threshold = 0.6,
    rootMargin = '0px',
    root = null
  } = options;

  const handleIntersect = useCallback((entries) => {
    entries.forEach((entry) => {
      const isCurrentlyVisible = entry.intersectionRatio >= threshold;
      
      if (isCurrentlyVisible && !isVisible) {
        setIsVisible(true);
        
        // If this is a media post, set as active
        if (postId) {
          setActivePost(postId);
        }
      } else if (!isCurrentlyVisible && isVisible) {
        setIsVisible(false);
        
        // Only clear if this was the active post
        const store = useMediaStore.getState();
        if (store.activePostId === postId && !shouldPlay(postId)) {
          clearActivePost();
        }
      }
    });
  }, [postId, threshold, isVisible, setActivePost, clearActivePost, shouldPlay]);

  useEffect(() => {
    if (!elementRef.current || !postId) return;

    const observer = new IntersectionObserver(
      handleIntersect,
      {
        threshold: [0, threshold, 1],
        root,
        rootMargin
      }
    );

    observer.observe(elementRef.current);

    return () => {
      if (elementRef.current) {
        observer.unobserve(elementRef.current);
      }
    };
  }, [postId, threshold, root, rootMargin, handleIntersect]);

  return { elementRef, isVisible };
};

// ============================================
// NEW HOOK – Page Visibility for polling optimization
// (does not affect existing code)
// ============================================
export const usePageVisibility = () => {
  const [isTabVisible, setIsTabVisible] = useState(() =>
    typeof document === 'undefined' ? true : !document.hidden,
  );

  useEffect(() => {
    if (typeof document === 'undefined') return undefined;

    const handleVisibilityChange = () => {
      setIsTabVisible(!document.hidden);
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, []);

  return isTabVisible;
};
