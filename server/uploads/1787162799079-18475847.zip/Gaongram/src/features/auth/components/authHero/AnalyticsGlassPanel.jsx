import { motion } from "framer-motion";

const AnalyticsGlassPanel = () => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1, y: [0, -8, 0] }}
      transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
      className="
        hidden lg:block
        absolute
        left-[48%]
        top-[46%]
        -translate-x-1/2
        -translate-y-1/2
        w-[210px]
        h-[120px]
        rounded-[20px]
        backdrop-blur-xl
        bg-white/5
        border border-white/10
        shadow-premium
        p-2
        z-[25]
      "
    >
      {/* Notification badge */}
      <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-viral-pink/60 flex items-center justify-center text-[10px] text-white">
        3
      </div>

      <p className="text-xs font-semibold text-white/80 mb-3">
        📊 Analytics
      </p>

      <div className="space-y-2 text-xs text-light-subtext">
        <div className="flex justify-between">
          <span>Followers</span>
          <span className="text-viral-pink">+12%</span>
        </div>

        <div className="flex justify-between">
          <span>Reach</span>
          <span>3.2k</span>
        </div>

        <div className="flex justify-between">
          <span>Engagement</span>
          <span>8.4%</span>
        </div>
      </div>

      {/* premium gradient graph line */}
      <div className="absolute bottom-1 left-5 right-5 h-[2px] rounded-full bg-gradient-to-r from-viral-pink via-viral-orange to-viral-purple opacity-50" />
    </motion.div>
  );
};

export default AnalyticsGlassPanel;