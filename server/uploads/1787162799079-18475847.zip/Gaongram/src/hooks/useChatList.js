// src/hooks/useChatList.js
import { useEffect, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { messageService } from '../services/message.service';
import { useChatStore } from '../store/chatStore';

export const useChatList = () => {
  const { setChatList, updateChatList, updateUnreadCount, chatList } = useChatStore();
  
  const { data, isLoading, refetch } = useQuery({
    queryKey: ['chatList'],
    queryFn: async () => {
      const response = await messageService.getChatUsers();
      if (response.success && response.data?.results) {
        const chats = response.data.results;
        setChatList(chats);
        // Update unread counts
        chats.forEach(chat => {
          updateUnreadCount(chat.id, chat.unread_count || 0);
        });
        return chats;
      }
      return [];
    },
    refetchInterval: 5000, // Poll every 5 seconds
    staleTime: 2000,
  });
  
  const markChatAsRead = useCallback(async (userId) => {
    // Find latest unread message from this user and mark as read
    updateUnreadCount(userId, 0);
    // Optional: call API to mark messages as read
    // This would require fetching messages and patching
  }, [updateUnreadCount]);
  
  return {
    chatList,
    isLoading,
    refetchChatList: refetch,
    markChatAsRead,
  };
};