import { useQuery } from '@tanstack/react-query';
import { storyService } from '../services/story.service.js';
import { useAuthStore } from '../store/authStore.js';

export const useStoriesFeed = () => {
  const { user } = useAuthStore();
  return useQuery({
    queryKey: ['stories-feed'],
    queryFn: async () => {
      try {
        // Fetch both feeds in parallel
        const [myStoriesRes, feedRes] = await Promise.allSettled([
          storyService.getMyStories(),
          storyService.getStoriesFeed(),
        ]);

        const myStories = myStoriesRes.status === 'fulfilled' ? myStoriesRes.value : null;
        const feedStories = feedRes.status === 'fulfilled' ? feedRes.value : null;

        const carouselItems = [];

        // 1. Create Story card (always first)
        carouselItems.push({
          id: 'create-story',
          type: 'create',
          user: {
            id: user?.id,
            username: user?.username,
            avatar: user?.avatar,
          },
        });

        // 2. Current user's own story if exists
        if (myStories?.data?.results?.length > 0) {
          const stories = myStories.data.results;
          const latest = stories[0];

          carouselItems.push({
            id: `own-${latest.id}`,
            type: 'story',
            user: {
              id: user?.id,
              username: user?.username,
              avatar: latest.profile_image || user?.avatar,
            },
            preview: latest.story,
            storyId: latest.id,
            hasNew: false,
            isOwn: true,
            stories: stories, // ✅ IMPORTANT
          });
        }

        // 3. Followed users' stories
        if (feedStories?.data?.length) {
          feedStories.data.forEach((group) => {
            if (!group.stories?.length) return;
            const groupStories = group.stories;
            const latest = groupStories[0];
            carouselItems.push({
              id: `feed-${group.id || latest.user_id}`,
              type: 'story',
              user: {
                id: latest.user_id,
                username: group.username || latest.username,
                avatar: latest.profile_image,
              },
              preview: latest.story,
              storyId: latest.id,
              hasNew: group.has_unseen || false,
              isOwn: false,
              stories: groupStories, // optional for later use
            });
          });
        }

        return carouselItems;
      } catch (error) {
        console.error('useStoriesFeed error:', error);
        return [];
      }
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000,
    enabled: !!user?.id,
  });
};
