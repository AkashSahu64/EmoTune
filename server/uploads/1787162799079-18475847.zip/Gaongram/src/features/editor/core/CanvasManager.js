import EditorEngine from "./EditorEngine.js";

export class CanvasManager {
  constructor({ canvasEl, store, config, onReady, onError, onPreviewChange }) {
    this.engine = new EditorEngine({
      canvasEl,
      store,
      config,
      onReady,
      onError,
      onPreviewChange,
    });
    this.resizeHandler = null;
    this.resizeRaf = null;
  }

  init(file, aspectRatio) {
    const canvas = this.engine.init(aspectRatio);
    this.bindResize(aspectRatio);
    if (file) {
      window.setTimeout(() => {
        this.engine.loadBaseMedia(file, aspectRatio);
      }, 0);
    }
    return canvas;
  }

  bindResize(aspectRatio) {
    this.resizeHandler = () => {
      if (this.resizeRaf) cancelAnimationFrame(this.resizeRaf);
      this.resizeRaf = requestAnimationFrame(() => {
        this.resizeRaf = null;
        this.engine.resizeToAspectRatio(aspectRatio || this.engine.config.aspectRatio);
        this.engine.applyDeviceProfile();
        this.engine.requestRender({ preview: true });
      });
    };
    window.addEventListener("resize", this.resizeHandler, { passive: true });
    window.addEventListener("orientationchange", this.resizeHandler, { passive: true });
    window.visualViewport?.addEventListener("resize", this.resizeHandler, { passive: true });
  }

  dispose() {
    if (this.resizeRaf) {
      cancelAnimationFrame(this.resizeRaf);
      this.resizeRaf = null;
    }
    if (this.resizeHandler) {
      window.removeEventListener("resize", this.resizeHandler);
      window.removeEventListener("orientationchange", this.resizeHandler);
      window.visualViewport?.removeEventListener("resize", this.resizeHandler);
      this.resizeHandler = null;
    }
    this.engine.dispose();
  }
}

export default CanvasManager;
