import React from "react";
import { motion } from "framer-motion";

const TABS = [
  { id: "posts", label: "Posts" },
  { id: "videos", label: "Videos" },
  { id: "audios", label: "Audios" },
];

const ProfileTabs = ({ activeTab, onTabChange }) => (
  <motion.div
    initial={{ opacity: 0, y: 14 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay: 0.2 }}
    className="border-b border-border dark:border-border-dark"
  >
    <div className="mx-auto grid max-w-md grid-cols-3 gap-1">
      {TABS.map((tab) => {
        const isActive = activeTab === tab.id;

        return (
          <button
            key={tab.id}
            type="button"
            onClick={() => onTabChange(tab.id)}
            className={`relative px-3 py-2 text-sm font-semibold transition sm:text-[15px] ${
              isActive
                ? "text-primary"
                : "text-mutedForeground dark:text-mutedForeground-dark hover:text-primary dark:hover:text-primary"
            }`}
          >
            <span>{tab.label}</span>
            {isActive ? (
              <motion.span
                layoutId="profile-tab-indicator"
                className="absolute inset-x-8 bottom-0 h-0.5 rounded-full bg-primary"
                transition={{ type: "spring", stiffness: 360, damping: 30 }}
              />
            ) : null}
          </button>
        );
      })}
    </div>
  </motion.div>
);

export default React.memo(ProfileTabs);
