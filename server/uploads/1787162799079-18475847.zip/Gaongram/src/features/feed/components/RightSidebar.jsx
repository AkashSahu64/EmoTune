import React from "react";
import SidebarSuggestedUsers from "./SidebarSuggestedUsers.jsx";
import SidebarTrending from "./SidebarTrending.jsx";
import SidebarFooter from "./SidebarFooter.jsx";
import Button from "../../../components/common/Button.jsx";

const RightSidebar = ({ user, suggestedUsers }) => {
  return (
    <div className="sticky top-20 space-y-6">
      {/* User profile mini card */}
      {/* <div className="flex items-center justify-between p-4 bg-card dark:bg-card-dark border border-border dark:border-border-dark rounded-xl shadow-soft">
        <div className="flex items-center gap-3">
          <img
            src={user?.photo || `https://i.pravatar.cc/150?u=${user?.id}`}
            alt={user?.username}
            className="w-12 h-12 rounded-full object-cover"
          />
          <div>
            <p className="text-sm font-semibold text-foreground dark:text-foreground-dark">
              {user?.username}
            </p>
            <p className="text-xs text-mutedForeground dark:text-mutedForeground-dark">
              {user?.name}
            </p>
          </div>
        </div>
        <Button variant="ghost" size="small" className="text-primary">
          Switch
        </Button>
      </div> */}

      {/* Suggested users */}
      <SidebarSuggestedUsers users={suggestedUsers} />

      {/* Trending hashtags */}
      <SidebarTrending />

      {/* Footer */}
      <SidebarFooter />
    </div>
  );
};

export default RightSidebar;