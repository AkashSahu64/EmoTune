import React from "react";
import { useInfiniteQuery } from "@tanstack/react-query";
import { useInView } from "react-intersection-observer";

import { profileService } from "../../../services/profile.service";

import UserListItem from "./UserListItem";

import Loader, { SkeletonLoader } from "../../../components/common/Loader";

import EmptyState from "../../../components/common/EmptyState";

import { useTranslation } from "react-i18next";

const AccountsTab = ({ searchTerm }) => {
  const { t } = useTranslation();

  const { ref, inView } = useInView();

  const querySearch = searchTerm?.trim() || "";

  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    status,
    error,
  } = useInfiniteQuery({
    queryKey: ["search-accounts", querySearch],

    queryFn: ({ pageParam = 1 }) =>
      profileService.getProfiles({
        search: querySearch,
        page: pageParam,
      }),

    getNextPageParam: (lastPage) => lastPage?.next || undefined,

    enabled: true,

    staleTime: 5 * 60 * 1000,
  });

  React.useEffect(() => {
    if (inView && hasNextPage && !isFetchingNextPage) {
      fetchNextPage();
    }
  }, [inView, hasNextPage, isFetchingNextPage, fetchNextPage]);

  const rankedUsers = React.useMemo(() => {
    if (!data) return [];

    const rawUsers = data.pages.flatMap((page) => page?.users || []);

    // remove duplicate users
    const allUsers = Array.from(
      new Map(
        rawUsers.map((user) => [user.username?.trim()?.toLowerCase(), user]),
      ).values(),
    );

    if (!querySearch) {
        return allUsers;
      }

    // search ranking
    const term = querySearch.toLowerCase();

    const score = (user) => {
      const usernameLower = user.username?.toLowerCase() || "";

      const nameLower = user.name?.toLowerCase() || "";

      let score = 0;

      if (usernameLower === term) {
        score += 100;
      } else if (nameLower === term) {
        score += 90;
      } else if (usernameLower.startsWith(term)) {
        score += 80;
      } else if (nameLower.startsWith(term)) {
        score += 70;
      } else if (usernameLower.includes(term)) {
        score += 60;
      } else if (nameLower.includes(term)) {
        score += 50;
      }

      return score;
    };

    return [...allUsers].sort((a, b) => score(b) - score(a));
  }, [data, querySearch]);

  if (status === "loading") {
    return (
      <div>
        <SkeletonLoader count={5} type="text" />
      </div>
    );
  }

  if (status === "error") {
    return (
      <EmptyState
        icon="alert"
        title={t("something_went_wrong")}
        description={error?.message}
      />
    );
  }

  if (rankedUsers.length === 0) {
    return (
      <EmptyState
        icon="users"
        title={t("no_accounts_found")}
        description={
          querySearch
            ? t("no_results_for", {
                term: querySearch,
              })
            : t("search_accounts_prompt")
        }
      />
    );
  }

  return (
    <div
      className="
      w-full
      max-w-7xl
      mx-auto
    "
    >
      <div className="space-y-1">
        {rankedUsers.map((user) => (
          <div
            key={user.profile_id}
            className="
              sm:px-1
              rounded-xl
              hover:bg-muted/50
              dark:hover:bg-muted-dark/50
              transition
            "
          >
            <UserListItem user={user} searchTerm={querySearch} />
          </div>
        ))}
      </div>

      <div
        ref={ref}
        className="
          py-4
          flex
          justify-center
        "
      >
        {isFetchingNextPage && <Loader size="small" />}
      </div>
    </div>
  );
};

export default AccountsTab;