// components/common/FollowButton.jsx

import React from "react";
import { motion } from "framer-motion";

import { useFollow } from "../../hooks/useFollow";
import { useAuthStore } from "../../store/authStore";
import { useUIStore } from "../../store/uiStore";

import Button from "../../components/common/Button";

import { useTranslation } from "react-i18next";

const FollowButton = ({
  profileId,
  isPrivate = false,
  size = "medium",
  variant,
  className = "",
  showLabel = true,
  children,

  // ✅ NEW
  isFeed = false,
}) => {
  const { user } = useAuthStore();
  const { openModal } = useUIStore();

  const { toggleFollow, getFollowButtonState, isLoading } = useFollow(
    profileId,
    isPrivate,
  );

  const { t } = useTranslation();

  if (!profileId) return null;

  const currentUserId = user?.id || user?.user_id;

  if (currentUserId && currentUserId === profileId) {
    return null;
  }

  const handleClick = (e) => {
    e.stopPropagation();

    if (!user) {
      openModal("login");
      return;
    }

    toggleFollow();
  };

  const buttonState = getFollowButtonState();

  const getTranslatedLabel = () => {
    switch (buttonState.label) {
      case "Follow":
        return t("follow");

      case "Following":
        return t("following");

      case "Requested":
        return t("requested");

      default:
        return buttonState.label;
    }
  };

  return (
    <motion.div whileTap={{ scale: 0.92 }} className="inline-flex">
      <Button
        size={size}
        variant="ghost"
        onClick={handleClick}
        loading={isLoading}
        disabled={buttonState.disabled || isLoading}
        className={`
          px-1.5 py-1
          rounded-lg
          text-xs
          font-semibold
          backdrop-blur-md
          border
          transition-all
          duration-200
          active:scale-95

          ${
            buttonState.label === "Follow"
              ? `
                bg-primary
                border-primary
                text-white
                hover:bg-primary/90
              `
              : buttonState.label === "Following"
                ? `
                bg-muted/10
                border-border

                ${isFeed ? "text-foreground" : "text-foreground-dark"}

                hover:bg-muted/20
              `
                : `
                bg-muted/15
                border-border

                ${isFeed ? "text-foreground" : "text-foreground-dark"}

                hover:bg-muted/70
              `
          }

          ${className}
        `}
      >
        {isLoading ? "..." : children || getTranslatedLabel()}
      </Button>
    </motion.div>
  );
};

export default FollowButton;
