import { useState, useCallback } from 'react';

export const useModal = (initialState = false) => {
  const [isOpen, setIsOpen] = useState(initialState);
  const [modalData, setModalData] = useState(null);

  const open = useCallback((data = null) => {
    setIsOpen(true);
    setModalData(data);
    // Prevent body scroll when modal is open
    document.body.style.overflow = 'hidden';
  }, []);

  const close = useCallback(() => {
    setIsOpen(false);
    setModalData(null);
    // Restore body scroll
    document.body.style.overflow = 'unset';
  }, []);

  const toggle = useCallback(() => {
    setIsOpen(prev => !prev);
    if (!isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
  }, [isOpen]);

  return {
    isOpen,
    open,
    close,
    toggle,
    modalData,
    setModalData
  };
};

// Compound modal hook for multiple modals
export const useMultiModal = (modalNames = []) => {
  const [modals, setModals] = useState(
    modalNames.reduce((acc, name) => {
      acc[name] = { isOpen: false, data: null };
      return acc;
    }, {})
  );

  const open = useCallback((name, data = null) => {
    setModals(prev => ({
      ...prev,
      [name]: { isOpen: true, data }
    }));
    document.body.style.overflow = 'hidden';
  }, []);

  const close = useCallback((name) => {
    setModals(prev => ({
      ...prev,
      [name]: { isOpen: false, data: null }
    }));
    
    // Only restore scroll if all modals are closed
    const anyOpen = Object.values(modals).some(modal => modal.isOpen);
    if (!anyOpen) {
      document.body.style.overflow = 'unset';
    }
  }, [modals]);

  const closeAll = useCallback(() => {
    const closedModals = Object.keys(modals).reduce((acc, name) => {
      acc[name] = { isOpen: false, data: null };
      return acc;
    }, {});
    setModals(closedModals);
    document.body.style.overflow = 'unset';
  }, [modals]);

  const getModalState = useCallback((name) => {
    return modals[name] || { isOpen: false, data: null };
  }, [modals]);

  const setModalData = useCallback((name, data) => {
    setModals(prev => ({
      ...prev,
      [name]: { ...prev[name], data }
    }));
  }, []);

  return {
    modals,
    open,
    close,
    closeAll,
    getModalState,
    setModalData,
    isAnyOpen: Object.values(modals).some(modal => modal.isOpen)
  };
};

// Confirm modal hook
export const useConfirmModal = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [config, setConfig] = useState({
    title: 'Confirm Action',
    message: 'Are you sure you want to proceed?',
    confirmText: 'Confirm',
    cancelText: 'Cancel',
    onConfirm: () => {},
    onCancel: () => {},
    destructive: false
  });

  const open = useCallback((newConfig) => {
    setConfig({
      title: 'Confirm Action',
      message: 'Are you sure you want to proceed?',
      confirmText: 'Confirm',
      cancelText: 'Cancel',
      onConfirm: () => {},
      onCancel: () => {},
      destructive: false,
      ...newConfig
    });
    setIsOpen(true);
    document.body.style.overflow = 'hidden';
  }, []);

  const close = useCallback(() => {
    setIsOpen(false);
    document.body.style.overflow = 'unset';
  }, []);

  const confirm = useCallback(() => {
    config.onConfirm();
    close();
  }, [config, close]);

  const cancel = useCallback(() => {
    config.onCancel();
    close();
  }, [config, close]);

  return {
    isOpen,
    open,
    close,
    confirm,
    cancel,
    config
  };
};