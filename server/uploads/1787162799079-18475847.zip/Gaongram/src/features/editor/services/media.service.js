import { compressMediaFile } from "../utils/mediaCompression.js";
import { createObjectUrl, resolveMediaType, revokeObjectUrl } from "../core/MediaRenderer.js";

export const mediaService = {
  compress: compressMediaFile,
  createObjectUrl,
  revokeObjectUrl,
  resolveType: resolveMediaType,
};

export default mediaService;
