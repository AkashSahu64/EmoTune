import React, { useMemo } from "react";
import UnifiedCanvasEditor from "./UnifiedCanvasEditor.jsx";
import VideoEditor from "./VideoEditor.jsx";

const PostEditor = ({
  isOpen,
  onClose,
  mediaFile,
  onSave,
  mediaType,
  activeIndex = 0,
  setActiveIndex,
}) => {
  const mediaFiles = useMemo(() => (Array.isArray(mediaFile) ? mediaFile : [mediaFile].filter(Boolean)), [mediaFile]);
  const currentFile = mediaFiles[activeIndex] || mediaFiles[0];

  if (!isOpen || !currentFile) return null;

  const isVideo = mediaType === "video" || currentFile?.type?.startsWith("video/");

  if (isVideo) {
    return (
      <VideoEditor
        isOpen={isOpen}
        file={currentFile}
        title="Video options"
        onClose={onClose}
        onSave={({ file, metadata, thumbnail }) => {
          file.editorMetadata = {
            ...(file.editorMetadata || {}),
            mediaType: "video",
            video: metadata,
          };
          if (thumbnail) file.editorThumbnail = thumbnail;
          onSave?.(file);
        }}
      />
    );
  }

  const handleExport = async ({ file, storyType, metadata, previewUrl }) => {
    file.editorMetadata = {
      ...(file.editorMetadata || {}),
      mediaType: storyType === "video" || file.type?.startsWith("video/") ? "video" : "image",
      editor: metadata,
      previewUrl,
    };
    if (Array.isArray(mediaFile)) {
      const updatedFiles = [...mediaFiles];
      updatedFiles[activeIndex] = file;
      onSave?.(updatedFiles);
    } else {
      onSave?.(file);
    }
    onClose?.();
  };

  const goToPrevious = () => {
    if (!setActiveIndex || activeIndex <= 0) return;
    setActiveIndex((index) => Math.max(0, index - 1));
  };

  const goToNext = () => {
    if (!setActiveIndex || activeIndex >= mediaFiles.length - 1) return;
    setActiveIndex((index) => Math.min(mediaFiles.length - 1, index + 1));
  };

  return (
    <>
      <UnifiedCanvasEditor
        file={currentFile}
        mode="post"
        config={{
          title:
            mediaFiles.length > 1
              ? `Edit media ${activeIndex + 1} of ${mediaFiles.length}`
              : mediaType === "video"
                ? "Edit video"
                : "Edit photo",
          aspectRatio: mediaType === "video" ? "9:16" : "1:1",
        }}
        onCancel={onClose}
        onExport={handleExport}
      />
      {mediaFiles.length > 1 && (
        <div className="fixed bottom-4 left-1/2 z-[70] flex -translate-x-1/2 items-center gap-2 rounded-full bg-black/55 px-3 py-2 text-white backdrop-blur-xl">
          <button
            type="button"
            onClick={goToPrevious}
            disabled={activeIndex <= 0}
            className="rounded-full px-3 py-1.5 text-sm font-semibold disabled:opacity-40"
          >
            Previous
          </button>
          <span className="text-xs text-white/70">
            {activeIndex + 1}/{mediaFiles.length}
          </span>
          <button
            type="button"
            onClick={goToNext}
            disabled={activeIndex >= mediaFiles.length - 1}
            className="rounded-full px-3 py-1.5 text-sm font-semibold disabled:opacity-40"
          >
            Next
          </button>
        </div>
      )}
    </>
  );
};

export default PostEditor;
