// src/services/searchVibe.service.js
import api from '../config/axios'; // your configured axios instance

/**
 * Safely parse the backend search response.
 * Endpoint: GET /api/v1/vibe-posts/?search={term}&page={page}
 */
const searchPosts = async (searchTerm, page = 1) => {
  try {
    const response = await api.get('/vibe-posts/', {
      params: {
        search: searchTerm || undefined,
        page,
      },
    });

    // Expected response structure:
    // { success: true, data: { count, next, previous, results } }
    const payload = response.data;

    if (!payload?.success || !payload?.data) {
      throw new Error(payload?.message || 'Invalid response from server');
    }

    const { results = [], next, count } = payload.data;

    // Extract page number from the "next" URL if present
    let nextPage = null;
    if (next) {
      const url = new URL(next);
      nextPage = url.searchParams.get('page');
    }

    return {
      results,
      nextPage: nextPage ? parseInt(nextPage, 10) : null,
      hasMore: !!next,
      count: count || results.length,
    };
  } catch (error) {
    console.error('Search API error:', error);
    throw error;
  }
};

export const searchVibeService = {
  searchPosts,
};