// components/AudioWaveform.jsx - FIXED AudioContext issues
import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';

const AudioWaveform = ({ 
  audioRef, 
  isPlaying, 
  currentTime, 
  duration,
  isLoading,
  hasError,
  userInteracted
}) => {
  const canvasRef = useRef(null);
  const animationRef = useRef(null);
  const audioContextRef = useRef(null);
  const analyserRef = useRef(null);
  const sourceRef = useRef(null);
  const dataArrayRef = useRef(null);
  const [visualizationEnabled, setVisualizationEnabled] = useState(false);
  
  // Initialize audio context only after user interaction
  useEffect(() => {
    if (!audioRef.current || hasError || !userInteracted) {
      setVisualizationEnabled(false);
      return;
    }

    const initAudioAnalyser = async () => {
      try {
        // Check if AudioContext is already created
        if (audioContextRef.current && analyserRef.current) {
          // Check if the audio element is still connected
          if (sourceRef.current && sourceRef.current.mediaElement === audioRef.current) {
            setVisualizationEnabled(true);
            return;
          } else {
            // Clean up old connection
            if (sourceRef.current) {
              sourceRef.current.disconnect();
            }
            if (audioContextRef.current) {
              await audioContextRef.current.close();
            }
          }
        }

        // Create audio context (only after user interaction)
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        const audioContext = new AudioContext();
        audioContextRef.current = audioContext;

        // Create analyzer
        const analyser = audioContext.createAnalyser();
        analyser.fftSize = 128; // Reduced for better performance
        analyser.smoothingTimeConstant = 0.8;
        analyserRef.current = analyser;

        // Create data array for frequency data
        const bufferLength = analyser.frequencyBinCount;
        dataArrayRef.current = new Uint8Array(bufferLength);

        // Connect audio element to analyzer
        const source = audioContext.createMediaElementSource(audioRef.current);
        sourceRef.current = source;
        source.connect(analyser);
        analyser.connect(audioContext.destination);

        // Resume audio context (required by browsers)
        if (audioContext.state === 'suspended') {
          await audioContext.resume();
        }

        setVisualizationEnabled(true);
      } catch (error) {
        console.warn('Audio visualization setup failed (non-critical):', error);
        setVisualizationEnabled(false);
        
        // Clean up on error
        if (sourceRef.current) {
          sourceRef.current.disconnect();
        }
        if (audioContextRef.current) {
          await audioContextRef.current.close();
          audioContextRef.current = null;
        }
      }
    };

    initAudioAnalyser();

    return () => {
      // Cleanup animation frame
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      
      // Don't disconnect audio context immediately, keep it for reuse
      // We'll clean it up in the effect cleanup
    };
  }, [audioRef, hasError, userInteracted]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      
      // Clean up audio context
      if (sourceRef.current) {
        try {
          sourceRef.current.disconnect();
        } catch (e) {
          // Ignore disconnect errors
        }
      }
      
      if (audioContextRef.current) {
        try {
          audioContextRef.current.close();
        } catch (e) {
          // Ignore close errors
        }
      }
    };
  }, []);

  // Draw waveform with fallback to simulated waveform
  const drawWaveform = () => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    
    // Clear canvas
    ctx.clearRect(0, 0, width, height);
    
    // Calculate progress position
    const progressPosition = duration > 0 ? (currentTime / duration) * width : 0;
    
    // Draw bars - use actual frequency data if available, otherwise simulated
    const barCount = 64;
    const barWidth = (width / barCount) * 0.8;
    const barGap = (width / barCount) * 0.2;
    const maxBarHeight = height * 0.8;
    
    for (let i = 0; i < barCount; i++) {
      // Calculate bar position
      const x = i * (barWidth + barGap);
      
      // Determine if this bar is before or after current time
      const isBeforeProgress = x < progressPosition;
      
      // Calculate bar height (simulated if no frequency data)
      let barHeight;
      
      if (visualizationEnabled && analyserRef.current && dataArrayRef.current) {
        // Use actual frequency data
        analyserRef.current.getByteFrequencyData(dataArrayRef.current);
        const dataIndex = Math.floor((i / barCount) * dataArrayRef.current.length);
        const frequencyValue = dataArrayRef.current[dataIndex] / 255;
        barHeight = frequencyValue * maxBarHeight;
      } else {
        // Simulated waveform based on audio playback
        const timePosition = i / barCount;
        const playbackPosition = currentTime / duration;
        
        if (isPlaying) {
          // Animated waveform when playing
          const waveIntensity = 0.3 + 0.7 * Math.sin((Date.now() / 200) + (i * 0.3));
          const positionIntensity = 1 - Math.abs(timePosition - playbackPosition);
          barHeight = (0.2 + 0.8 * waveIntensity * positionIntensity) * maxBarHeight;
        } else {
          // Static waveform when paused
          barHeight = (0.2 + 0.3 * Math.sin(i * 0.5)) * maxBarHeight;
        }
      }
      
      // Ensure minimum height
      barHeight = Math.max(2, barHeight);
      
      const y = height - barHeight;
      
      // Bar color gradient (Instagram-style)
      const gradient = ctx.createLinearGradient(0, y, 0, height);
      
      if (isBeforeProgress) {
        // Played section - purple to pink gradient
        gradient.addColorStop(0, 'rgba(168, 85, 247, 0.8)');
        gradient.addColorStop(1, 'rgba(236, 72, 153, 0.8)');
      } else {
        // Unplayed section - gray gradient
        gradient.addColorStop(0, 'rgba(156, 163, 175, 0.6)');
        gradient.addColorStop(1, 'rgba(75, 85, 99, 0.6)');
      }
      
      // Draw bar with rounded corners
      ctx.fillStyle = gradient;
      drawRoundedRect(ctx, x, y, barWidth, barHeight, 2);
      ctx.fill();
      
      // Add subtle glow effect for active playing state
      if (isPlaying && barHeight > maxBarHeight * 0.4) {
        ctx.shadowColor = isBeforeProgress ? 'rgba(168, 85, 247, 0.5)' : 'rgba(156, 163, 175, 0.3)';
        ctx.shadowBlur = 4;
        drawRoundedRect(ctx, x, y, barWidth, barHeight, 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      }
    }
    
    // Draw progress indicator line
    // ctx.beginPath();
    // ctx.moveTo(progressPosition, 0);
    // ctx.lineTo(progressPosition, height);
    // ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
    // ctx.lineWidth = 1;
    // ctx.stroke();
    
    // Continue animation if playing
    if (isPlaying && !hasError && !isLoading) {
      animationRef.current = requestAnimationFrame(drawWaveform);
    }
  };
  
  // Helper function for rounded rectangles
  const drawRoundedRect = (ctx, x, y, width, height, radius) => {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
  };
  
  // Start/stop animation based on playing state
  useEffect(() => {
    if (isPlaying && !isLoading && !hasError) {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      animationRef.current = requestAnimationFrame(drawWaveform);
    } else {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
      }
      
      // Draw static waveform when paused
      if (!isLoading && !hasError && canvasRef.current) {
        drawWaveform();
      }
    }
    
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying, isLoading, hasError, currentTime, visualizationEnabled]);
  
  // Handle loading and error states
  if (hasError) {
    return null;
  }
  
  if (isLoading) {
    return (
      <div className="w-full h-12 mb-2 flex items-center justify-center">
        <div className="flex space-x-1">
          {[...Array(8)].map((_, i) => (
            <motion.div
              key={i}
              className="w-1.5 bg-gray-600 rounded-full"
              animate={{
                height: ['8px', '24px', '8px'],
              }}
              transition={{
                duration: 1.2,
                repeat: Infinity,
                delay: i * 0.1,
              }}
            />
          ))}
        </div>
      </div>
    );
  }
  
  return (
    <div className="w-full h-10 relative">
      <canvas
        ref={canvasRef}
        width={800}
        height={48}
        className="w-full h-full"
      />
      
      {/* Waveform overlay for better visual feedback */}
      {isPlaying && (
        <motion.div
          // className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent"
          animate={{
            x: ['-100%', '100%'],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "linear"
          }}
        />
      )}
    </div>
  );
};

export default AudioWaveform;