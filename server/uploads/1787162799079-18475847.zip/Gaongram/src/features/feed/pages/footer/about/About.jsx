// src/pages/About.jsx
import React, { useRef } from "react";
import { motion, useInView, useScroll, useTransform } from "framer-motion";
import {
  Globe,
  ChevronDown,
  Instagram,
  Facebook,
  Youtube,
  Twitter,
  Linkedin,
  Apple,
  Play,
  Menu,
} from "lucide-react";
import PostCard from "./PostCard";
import Avatar from "../../../../../components/common/Avatar";
import BlackSection from "./BlackSection";
import { FaApple } from "react-icons/fa";
// import playStore from "../../../../../../public/icon/playStore.png";
import PublicLayout from "../../../components/layout/PublicLayout";
import Seo from "../../../../../components/seo/Seo.jsx";
import { buildStaticPageSeo } from "../../../../../seo/seoBuilders.js";

const About = () => {
  // Refs for scroll animations
  const blackSectionRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: blackSectionRef,
    offset: ["start end", "end start"],
  });
  const leftX = useTransform(scrollYProgress, [0, 1], [-50, 0]);
  const rightX = useTransform(scrollYProgress, [0, 1], [50, 0]);
  const opacity = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0, 1, 1, 0]);

  // Animation variants
  const fadeUp = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: "easeOut" },
    },
  };

  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1, delayChildren: 0.2 },
    },
  };

  // Mock data for PostCards
  const heroPost = {
    avatar:
      "https://ui-avatars.com/api/?background=0E4D38&color=fff&name=GaonGram",
    username: "gaongram",
    timestamp: new Date().toISOString(),
    imageUrl:
      "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=600&h=600&fit=crop",
    caption: "Bringing Bharat closer, one story at a time. 🌾",
    likes: 12453,
    comments: 289,
  };

  const featurePosts = [
    {
      avatar:
        "https://ui-avatars.com/api/?background=E1306C&color=fff&name=Share",
      username: "gaongram",
      timestamp: new Date().toISOString(),
      imageUrl:
        "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&h=600&fit=crop",
      caption: "Share your traditions, your craft, your voice.",
      likes: 8720,
      comments: 156,
    },
    {
      avatar:
        "https://ui-avatars.com/api/?background=833AB4&color=fff&name=Safety",
      username: "gaongram",
      timestamp: new Date().toISOString(),
      imageUrl:
        "https://images.unsplash.com/photo-1563986768609-322da13575f3?w=600&h=600&fit=crop",
      caption: "Your safety is our priority. AI + human moderation.",
      likes: 15320,
      comments: 402,
    },
    {
      avatar:
        "https://ui-avatars.com/api/?background=F77737&color=fff&name=Local",
      username: "gaongram",
      timestamp: new Date().toISOString(),
      imageUrl:
        "https://images.unsplash.com/photo-1531206715517-5c0ba140b2b8?w=600&h=600&fit=crop",
      caption: "Discover hyper‑local content from your district.",
      likes: 11200,
      comments: 278,
    },
    {
      avatar:
        "https://ui-avatars.com/api/?background=3B82F6&color=fff&name=Language",
      username: "gaongram",
      timestamp: new Date().toISOString(),
      imageUrl:
        "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=600&h=600&fit=crop",
      caption: "Connect in Bhojpuri, Haryanvi, Maithili, and more.",
      likes: 9430,
      comments: 187,
    },
  ];

  // Discovery cards data
  const discoveryCards = [
    {
      image:
        "https://images.unsplash.com/photo-1598977125552-f1a5b4e6b2b4?w=400&h=300&fit=crop",
      category: "Impact",
      title: "Empowering Rural Artisans",
      date: "March 15, 2026",
    },
    {
      image:
        "https://images.unsplash.com/photo-1605000797499-95a51c5269ae?w=400&h=300&fit=crop",
      category: "Technology",
      title: "AI That Understands Dialects",
      date: "March 10, 2026",
    },
    {
      image:
        "https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?w=400&h=300&fit=crop",
      category: "Community",
      title: "Digital Chaupal: Stories from the Heartland",
      date: "February 28, 2026",
    },
    {
      image:
        "https://images.unsplash.com/photo-1593113598332-35d2013d3b7a?w=400&h=300&fit=crop",
      category: "Safety",
      title: "Keeping Women Safe Online",
      date: "February 20, 2026",
    },
  ];

  // Full story content (exact text preserved)
  const storySections = [
    {
      title: "1. The Genesis: Why GaonGram?",
      content: `In a world increasingly dominated by global digital giants, the unique and vibrant voice of rural and semi-urban India—often referred to as 'Bharat'—was getting lost in the noise of Westernized algorithms. Social media, which was supposed to be a tool for connection, had become a space where English-speaking urban elites set the trends, leaving the diverse, multi-lingual, and culturally rich populations of India's heartlands feeling like outsiders.

GaonGram was born from a simple yet powerful realization: India does not need another social media app; India needs its own digital ecosystem. Our journey began in the small towns and villages where stories are told in regional dialects, where traditions are centuries old, and where the community is the cornerstone of life. We realized that for technology to truly serve the people, it must speak their language—not just literally, but culturally.`,
    },
    {
      title: "2. Our Vision: A Digital Democracy",
      content: `Our vision is to build a "Digital Chaupal" (a communal meeting space) for the 21st century. We envision an India where a farmer in Uttar Pradesh, an artisan in Rajasthan, and a student in Bihar are as digitally empowered as a software engineer in Bangalore.

GaonGram aims to democratize the internet by making it accessible, relatable, and safe for every Indian. We are moving toward a future where "Digital India" is not just a slogan for the cities, but a lived reality for the villages. Our vision is rooted in Digital Loktantra (Digital Democracy)—a space where every voice has weight, and every story has a home.`,
    },
    {
      title: "3. Breaking the Language Barrier",
      content: `For too long, the English language has acted as a gatekeeper to the internet. At GaonGram, we are shattering this barrier. We believe that the most profound thoughts are often expressed in one’s mother tongue.

GaonGram is built from the ground up to support the linguistic diversity of India. From Hindi, Bengali, and Marathi to Bhojpuri, Haryanvi, and Maithili, our platform encourages users to post, comment, and interact in the language they are most comfortable with. Our proprietary translation and transliteration tools ensure that while you speak your local language, you stay connected to the national narrative.`,
    },
    {
      title: "4. Technology Optimized for Bharat",
      content: `Standard social media apps are designed for high-speed 5G networks and high-end smartphones. However, the reality of Bharat includes fluctuating 4G signals, low-bandwidth areas, and budget-friendly devices.

GaonGram’s Technical Innovation:
- Lite Engine Architecture: Our app is engineered to be lightweight, ensuring it occupies minimal space on a smartphone while delivering a lag-free experience.
- Adaptive Bitrate Streaming: We use advanced compression algorithms so that videos load smoothly even on 2G or unstable 3G/4G connections.
- Hyper-Local Discovery: Our algorithm doesn't just show you what is "trending" globally; it shows you what is happening in your district and your state. We prioritize local relevance over global noise.`,
    },
    {
      title: "5. Data Sovereignty: Our National Commitment",
      content: `In the digital age, data is the new oil. For years, Indian data has been harvested by foreign corporations and stored in offshore servers. GaonGram stands firmly against this practice.

We are committed to Data Sovereignty. Every byte of data generated on GaonGram stays within the sovereign borders of India. By building our own data infrastructure on Indian soil, we ensure that our users' privacy is protected by Indian laws. We are a "Made in India, For India" company, ensuring that the digital assets of our citizens contribute to the growth of our own national economy.`,
    },
    {
      title: "6. Empowering the Grassroots Economy",
      content: `GaonGram is more than just a place to share photos; it is an engine for economic growth.

- For the Farmer: We provide a space where farmers can share agricultural techniques, check market rates (Mandi Bhav), and connect with experts.
- For the Artisan: Local craftsmen and weavers can showcase their products to a national audience, bypassing middlemen and building their own brands.
- For the Small Business: Local shopkeepers can use GaonGram to update their community about new arrivals and offers, fostering a "Vocal for Local" economy.`,
    },
    {
      title: "7. A Sanctuary of Safety and Respect",
      content: `The internet can often be a hostile place. GaonGram is dedicated to maintaining the "Maryada" (dignity) of Indian social discourse. We have implemented:

- AI-Powered Content Moderation: Our AI is trained to recognize hate speech, harassment, and obscenity in multiple Indian languages and dialects.
- The Digital Shield for Women: We have introduced features that prevent unauthorized profile downloads and screenshots, ensuring that women can express themselves without the fear of misuse of their images.
- Zero Tolerance for Fake News: In a country where rumors can have real-world consequences, we work tirelessly to flag and remove misinformation that threatens social harmony.`,
    },
    {
      title: "8. Preserving Cultural Heritage",
      content: `India is a land of festivals, folk music, and traditional art forms that are often ignored by global media. GaonGram provides a dedicated stage for these cultural treasures. Whether it’s a local folk song from the hills of Uttarakhand or a traditional dance from the coasts of Kerala, GaonGram ensures that our heritage is archived and celebrated in the digital world for future generations.`,
    },
    {
      title: "9. The Roadmap Ahead: GaonGram 2.0",
      content: `Our journey has just begun. Looking forward, we are integrating:

- Voice-First Navigation: For users who may find typing difficult, we are building a completely voice-controlled interface.
- Integrated Education Feeds: Partnering with educators to provide free learning resources to rural students directly through the app.
- Community Governance: Giving our users a say in how the platform is moderated, ensuring that the community truly owns the space.`,
    },
    {
      title: "10. Conclusion: Join the Revolution",
      content: `GaonGram is a testament to the fact that Indian innovation can compete with the best in the world while staying rooted in its own soil. We invite every Indian—from the busiest metros to the quietest hamlets—to join this digital revolution.

GaonGram is not just an app on your phone; it is a movement to reclaim our digital identity. It is a celebration of who we are, where we come from, and where we are going.

GaonGram: Our Soil. Our Voice. Our App.`,
    },
    {
      title: "11. The Founder’s Story: From a Seed to a Revolution",
      content: `The story of GaonGram did not begin in a high-tech boardroom in a metropolitan city. It began on a dusty afternoon in a small village in Uttar Pradesh. While visiting my ancestral home, I noticed a local potter creating exquisite terracotta art. He was a master of his craft, yet his reach was limited to the few people who passed by his small stall on the main road.

I watched him try to use a global social media app to showcase his work. He struggled with the complex English interface, and when he finally posted, his art was buried under a mountain of celebrity gossip and urban trends. The algorithm didn't care about a potter in a remote village. That was the "Eureka" moment. I realized that millions of talented Indians were being digitally disenfranchised.

I envisioned a platform where the interface felt like home—where the local language was the default, not an afterthought. I returned with a singular mission: to build a digital bridge that connects the 'Real India' to the world. GaonGram was founded not just to be an app, but to be a tribute to the unsung heroes of our soil.`,
    },
    {
      title: "12. Impact in Action: Real Stories, Real People",
      content: `To understand GaonGram, one must look at the lives it has touched. We measure our success not in "likes," but in the smiles of our users.

Case Study 1: The Empowerment of Ramesh, a Small-Scale Farmer
Ramesh, from a small hamlet in Bihar, struggled with fluctuating crop prices and predatory middlemen. Through GaonGram’s hyper-local agriculture groups, he connected with a community of organic farmers. He learned new composting techniques through a short video shared in Bhojpuri. Today, Ramesh sells his produce directly to a collective of buyers he met on GaonGram, increasing his monthly income by 40%.

Case Study 2: Sunita’s Entrepreneurial Journey
Sunita, a homemaker in a small town in Rajasthan, was a gifted weaver but lacked a market. She started a GaonGram page called "Marwar Creations." Because our algorithm prioritizes regional heritage, her work was discovered by a boutique owner in Jaipur. Sunita now leads a group of ten women in her village, all of whom are earning a dignified living through orders received via GaonGram.

Case Study 3: Crisis Management in Uttarakhand
During a local cloudburst incident, GaonGram served as a lifeline. Local youth used the app to share real-time updates on blocked roads and safe shelters in the local dialect. This information reached the community faster than traditional news outlets, proving that GaonGram is a vital tool for community resilience.`,
    },
    {
      title: "13. The Technical Backbone: Built for Scale, Built for India",
      content: `GaonGram is a masterpiece of modern engineering, tailored specifically for the Indian landscape. We have combined high-level global technology with local optimization.

- The Power of Python & Django: Our backend is built on the robust Python/Django framework. We chose this for its unparalleled security features and its ability to handle massive, scalable databases. This ensures that even as we grow to hundreds of millions of users, the platform remains stable and secure.
- AI-Driven Content Curation: We utilize advanced Machine Learning (ML) models to understand regional dialects. Our AI doesn't just read text; it understands the sentiment of regional slangs, ensuring that our automated moderation is culturally sensitive yet strictly against hate speech.
- Indigenized Cloud Infrastructure: In line with our commitment to national security, GaonGram is hosted exclusively on Indian Cloud Servers. This minimizes latency for our domestic users and ensures that every byte of data remains under the protection of Indian Cyber Laws.
- Media Optimization: We have developed a custom video-transcoding engine that detects the user's signal strength in real-time. If you are on a weak 3G connection in a remote area, our tech automatically adjusts the video quality to ensure a buffer-free experience.`,
    },
    {
      title: "14. The GaonGram Manifesto: Our Promise to the Nation",
      content: `A platform is only as good as its values. The GaonGram Manifesto is our solemn promise to every citizen of India.

- The Promise of Privacy: We promise that your personal data will never be a commodity. We will never sell your information to foreign advertisers or third-party data brokers.
- The Promise of Language: We promise to constantly expand our linguistic support. No Indian shall ever feel like a stranger on our platform because of the language they speak.
- The Promise of Neutrality: Our algorithms will remain transparent and unbiased. We will never suppress voices for political gain or prioritize paid content over authentic community stories.
- The Promise of Safety: We promise to maintain a clean digital environment. We will continue to invest in AI and human moderation to keep GaonGram free from obscenity, communal hatred, and harassment.
- The Promise of Swadeshi: We promise to remain an Indian company, led by Indians, for the benefit of India. Our profits will be reinvested into the Indian digital ecosystem.
- The Promise of Accessibility: We promise to keep the app lightweight and accessible to those with basic smartphones, ensuring that the digital revolution includes everyone, not just the wealthy.`,
    },
    {
      title: "Conclusion: Writing the Next Chapter Together",
      content: `GaonGram is more than a product; it is a promise. It is the promise of an India that is modern yet traditional, global yet local. As we move forward, we invite you to be a part of this journey. Whether you are a creator, a consumer, or a silent observer, your presence on GaonGram strengthens the fabric of our digital nation.

Join us as we reclaim the digital narrative of Bharat. This is GaonGram—where your roots find their wings.`,
    },
  ];

  return (
    <PublicLayout>
      <Seo {...buildStaticPageSeo("about")} />
      <div className="min-h-screen bg-white dark:bg-background-dark">
        {/* Hero Section */}
        <section className="pt-12 pb-20 md:pt-20 md:pb-32 overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial="hidden"
                animate="visible"
                variants={staggerContainer}
                className="space-y-6"
              >
                <motion.h1
                  variants={fadeUp}
                  className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-foreground dark:text-foreground-dark leading-tight"
                >
                  GaonGram brings you closer to the people and culture of Bharat
                </motion.h1>
                <motion.div variants={fadeUp}>
                  <button className="group relative inline-flex items-center justify-center px-6 py-3 text-base font-medium text-foreground dark:text-foreground-dark bg-transparent rounded-full">
                    <span className="absolute inset-0 rounded-full bg-gradient-to-r from-green-800 via-green-500 to-viral-orange p-[2px]">
                      <span className="block h-full w-full rounded-full bg-white dark:bg-background-dark" />
                    </span>
                    <span className="relative px-4 py-1 bg-gradient-to-r from-green-800 via-green-500 to-viral-orange bg-clip-text text-transparent">
                      Learn more
                    </span>
                  </button>
                </motion.div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, rotate: -3, y: 20 }}
                animate={{ opacity: 1, rotate: 0, y: 0 }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="relative"
              >
                <motion.div
                  animate={{ y: [0, -10, 0] }}
                  transition={{
                    duration: 5,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                  className="w-full max-w-sm mx-auto"
                >
                  <PostCard {...heroPost} className="shadow-premium" />
                </motion.div>
                {/* Floating decoration */}
                <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-r from-viral-pink/20 to-viral-purple/20 rounded-full blur-3xl" />
              </motion.div>
            </div>
          </div>
        </section>

        {/* Split Feature Sections */}
        {[
          {
            title: "Share what you love",
            desc: "Express yourself with Vibes, photos, and audio stories. Your traditions, your voice.",
          },
          {
            title: "Protect your account",
            desc: "Advanced security features and AI moderation keep you safe.",
          },
          {
            title: "Discover local content",
            desc: "See what’s happening in your village, district, and state.",
          },
          {
            title: "Connect in your language",
            desc: "Post and comment in Bhojpuri, Haryanvi, Maithili, and more.",
          },
        ].map((feature, idx) => {
          const isEven = idx % 2 === 0;
          return (
            <section
              key={idx}
              className="py-16 md:py-24 border-t border-border dark:border-border-dark"
            >
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div
                  className={`grid md:grid-cols-2 gap-12 items-center ${!isEven ? "md:flex-row-reverse" : ""}`}
                >
                  <motion.div
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true, margin: "-100px" }}
                    variants={staggerContainer}
                    className={`space-y-4 ${!isEven ? "md:order-2" : ""}`}
                  >
                    <motion.h2
                      variants={fadeUp}
                      className="text-3xl md:text-4xl font-bold text-foreground dark:text-foreground-dark"
                    >
                      {feature.title}
                    </motion.h2>
                    <motion.p
                      variants={fadeUp}
                      className="text-lg text-mutedForeground dark:text-mutedForeground-dark"
                    >
                      {feature.desc}
                    </motion.p>
                  </motion.div>
                  <motion.div
                    initial={{ opacity: 0, x: isEven ? 30 : -30 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6 }}
                    className={!isEven ? "md:order-1" : ""}
                  >
                    <PostCard {...featurePosts[idx]} className="shadow-soft" />
                  </motion.div>
                </div>
              </div>
            </section>
          );
        })}

        {/* Black Section with Split Text */}
        <BlackSection />

        {/* Full Story Content Section */}
        <section className="py-16 md:py-24 bg-white dark:bg-background-dark">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-50px" }}
              variants={staggerContainer}
              className="space-y-16"
            >
              {storySections.map((section, idx) => (
                <motion.div key={idx} variants={fadeUp} className="space-y-4">
                  <h2 className="text-2xl md:text-3xl font-bold text-foreground dark:text-foreground-dark">
                    {section.title}
                  </h2>
                  <div className="prose prose-lg dark:prose-invert max-w-none text-mutedForeground dark:text-mutedForeground-dark">
                    {section.content.split("\n\n").map((para, i) => (
                      <p key={i} className="mb-4 leading-relaxed">
                        {para}
                      </p>
                    ))}
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 md:py-20 border-t border-border dark:border-border-dark">
          <div className="max-w-3xl mx-auto px-4 text-center">
            <motion.h2
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUp}
              className="text-3xl md:text-4xl font-bold text-foreground dark:text-foreground-dark mb-10"
            >
              Create, share and connect. Download now.
            </motion.h2>

            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={staggerContainer}
              className="flex flex-wrap justify-center gap-5"
            >
              {/* 🍎 App Store */}
              <motion.a
                variants={fadeUp}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                href="#"
                className="flex items-center gap-3 px-5 py-3 bg-black text-white rounded-xl shadow-md hover:shadow-lg transition-all duration-300"
              >
                <FaApple size={28} />

                <div className="text-left leading-tight">
                  <p className="text-[10px] opacity-70">Download on the</p>
                  <p className="text-sm font-semibold">App Store</p>
                </div>
              </motion.a>

              {/* ▶ Google Play */}
              <motion.a
                variants={fadeUp}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                href="https://play.google.com/store/apps/details?id=com.gaon.gaongram"
                target="_blank"
                className="flex items-center gap-3 px-5 py-3 bg-black text-white rounded-xl shadow-md hover:shadow-lg transition-all duration-300"
              >
                <img
                  src="/icon/playStore.png"
                  alt="Google Play"
                  className="w-6 h-6 object-contain"
                />

                <div className="text-left leading-tight">
                  <p className="text-[10px] opacity-70">GET IT ON</p>
                  <p className="text-sm font-semibold">Google Play</p>
                </div>
              </motion.a>
            </motion.div>
          </div>
        </section>
      </div>
    </PublicLayout>
  );
};

export default About;
