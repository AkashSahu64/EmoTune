// src/features/blogs/services/blogService.js
import api from "../config/axios.js";

const blogService = {
  /**
   * Get paginated list of blogs
   * @param {Object} params - Query parameters (page, page_size, search, etc.)
   */
  async getBlogs(params = {}) {
    const response = await api.get("/blogs/", { params });
    return response.data; // { success, message, data: { count, next, previous, results } }
  },

  /**
   * Get a single blog by ID
   */
  async getBlogById(id) {
    const response = await api.get(`/blogs/${id}/`);
    return response.data; // { success, message, data: blog }
  },

  /**
   * Create a new blog (multipart form data)
   */
  async createBlog(formData) {
    const response = await api.post("/blogs/", formData, {
      headers: { "Content-Type": "multipart/form-data" },
    });
    return response.data;
  },

  /**
   * Update an existing blog (multipart form data)
   */
  async updateBlog(id, formData) {
    const response = await api.patch(`/blogs/${id}/`, formData, {
      headers: { "Content-Type": "multipart/form-data" },
    });
    return response.data;
  },

  /**
   * Delete a blog
   */
  async deleteBlog(id) {
    const response = await api.delete(`/blogs/${id}/`);
    return response.data;
  },
};

export default blogService;