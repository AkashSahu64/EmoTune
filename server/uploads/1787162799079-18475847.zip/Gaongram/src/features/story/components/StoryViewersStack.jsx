import React from "react";

const StoryViewersStack = ({
  viewers = [],
  viewCount = 0,
  onOpen
}) => {

  const MAX_PREVIEW = 5;

  const preview = viewers.slice(0, MAX_PREVIEW);

  const extra = viewCount - preview.length;

  return (
    <button
      onClick={(e) => {
        e.stopPropagation();
        onOpen();
      }}
      className="absolute bottom-[calc(env(safe-area-inset-bottom)+1rem)] left-3 z-40 flex items-center sm:left-4"
      aria-label="Open story viewers"
    >

      {/* No views */}
      {viewCount === 0 ? (

        <span className="text-white text-xs font-semibold bg-black/50 px-3 py-1 rounded-full backdrop-blur-md">
          No views
        </span>

      ) : (

        <div className="flex items-center">

          <div className="flex -space-x-3">

            {preview.map((viewer) => (
              <img
                key={viewer.id}
                src={
                  viewer.profile_image ||
                  `https://ui-avatars.com/api/?name=${viewer.username}`
                }
                alt={viewer.username || "Viewer"}
                className="w-9 h-9 rounded-full border-2 border-white object-cover"
              />
            ))}

            {/* Remaining viewers badge */}
            {extra > 0 && (
              <div className="w-9 h-9 rounded-full bg-white text-black flex items-center justify-center text-xs font-semibold border-2 border-white">
                +{extra}
              </div>
            )}

          </div>

        </div>

      )}

    </button>
  );
};

export default React.memo(StoryViewersStack);
