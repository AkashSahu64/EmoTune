export const NAV_ITEMS = [
  { id: 1, name: 'Home', path: '/', icon: 'Home' },
  { id: 2, name: 'Search', path: '/search', icon: 'Search' },
  { id: 3, name: 'Create', path: '/create', icon: 'PlusSquare' },
  { id: 4, name: 'Reels', path: '/reels', icon: 'Video' },
  { id: 5, name: 'Profile', path: '/profile', icon: 'User' },
];

export const POST_TYPES = {
  IMAGE: 'image',
  VIDEO: 'video',
  CAROUSEL: 'carousel',
  POLL: 'poll',
  AUDIO: 'audio',
};

export const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
export const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
export const ALLOWED_VIDEO_TYPES = ['video/mp4', 'video/webm', 'video/ogg'];

export const INFINITE_SCROLL_LIMIT = 10;
export const COMMENTS_PER_PAGE = 5;

export const DATE_FORMATS = {
  POST: 'MMM D, YYYY',
  COMMENT: 'MMM D',
  TIME_AGO: 'timeAgo',
  FULL: 'MMM D, YYYY h:mm A',
};

export const ROUTES = {
  HOME: '/',
  LOGIN: '/login',
  REGISTER: '/register',
  VERIFY_OTP: '/verify-otp',
  PROFILE: '/profile/:username',
  SETTINGS: '/settings',
  NOTIFICATIONS: '/notifications',
  MESSAGES: '/messages',
  EXPLORE: '/explore',
  REELS: '/reels',
  SAVED: '/saved',
  TAGGED: '/tagged',
};

export const ERROR_MESSAGES = {
  NETWORK_ERROR: 'Network error. Please check your connection.',
  UNAUTHORIZED: 'Please login to continue.',
  FORBIDDEN: 'You do not have permission to perform this action.',
  NOT_FOUND: 'The requested resource was not found.',
  SERVER_ERROR: 'Server error. Please try again later.',
  VALIDATION_ERROR: 'Please check your input and try again.',
};

export const SUCCESS_MESSAGES = {
  POST_CREATED: 'Post created successfully!',
  POST_UPDATED: 'Post updated successfully!',
  POST_DELETED: 'Post deleted successfully!',
  COMMENT_ADDED: 'Comment added successfully!',
  COMMENT_DELETED: 'Comment deleted successfully!',
  LIKE_ADDED: 'Liked!',
  LIKE_REMOVED: 'Like removed!',
  PROFILE_UPDATED: 'Profile updated successfully!',
};