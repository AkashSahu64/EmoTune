import React, { useEffect, useMemo, useRef, useState } from "react";
import { motion as Motion } from "framer-motion";
import { Check, ImagePlus, Loader2, Volume2, VolumeX, X } from "lucide-react";
import VideoEngine from "../core/VideoEngine.js";

const VideoEditor = ({ isOpen = true, file, onClose, onSave, title = "Video options" }) => {
  const engineRef = useRef(null);
  const thumbnailInputRef = useRef(null);
  const videoRef = useRef(null);
  const [isSaving, setIsSaving] = useState(false);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [trimStart, setTrimStart] = useState(0);
  const [trimEnd, setTrimEnd] = useState(null);
  const [duration, setDuration] = useState(0);
  const [thumbnail, setThumbnail] = useState(null);

  useEffect(() => {
    if (!file) return undefined;
    engineRef.current?.dispose();
    engineRef.current = new VideoEngine(file);
    return () => {
      engineRef.current?.dispose();
      engineRef.current = null;
    };
  }, [file]);

  const videoUrl = engineRef.current?.url;
  const thumbnailPreview = useMemo(() => (thumbnail ? URL.createObjectURL(thumbnail) : ""), [thumbnail]);

  useEffect(() => () => {
    if (thumbnailPreview) URL.revokeObjectURL(thumbnailPreview);
  }, [thumbnailPreview]);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.volume = muted ? 0 : volume;
      videoRef.current.muted = muted;
    }
  }, [muted, volume]);

  if (!isOpen || !file) return null;

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const metadata = engineRef.current.buildMetadata({
        trimStart,
        trimEnd: trimEnd || duration || null,
        muted,
        volume,
        thumbnail,
      });
      file.editorMetadata = {
        ...(file.editorMetadata || {}),
        mediaType: "video",
        video: metadata,
      };
      onSave?.({ file, metadata, thumbnail });
      onClose?.();
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 p-3 backdrop-blur-sm"
    >
      <Motion.div
        initial={{ scale: 0.96, y: 18 }}
        animate={{ scale: 1, y: 0 }}
        className="flex max-h-[92dvh] w-full max-w-lg flex-col overflow-hidden rounded-3xl bg-white shadow-2xl dark:bg-gray-950"
      >
        <header className="flex h-14 items-center justify-between border-b border-border px-4 dark:border-border-dark">
          <div>
            <h2 className="text-base font-semibold text-foreground dark:text-foreground-dark">{title}</h2>
            <p className="text-xs text-mutedForeground dark:text-mutedForeground-dark">Trim, audio, and cover</p>
          </div>
          <button type="button" onClick={onClose} disabled={isSaving} className="flex h-10 w-10 items-center justify-center rounded-full bg-muted dark:bg-muted-dark" aria-label="Close video options">
            <X size={20} />
          </button>
        </header>

        <div className="min-h-0 flex-1 space-y-4 overflow-y-auto p-4">
          <div className="overflow-hidden rounded-2xl bg-black">
            <video
              ref={videoRef}
              src={videoUrl}
              controls
              playsInline
              muted={muted}
              onLoadedMetadata={(event) => {
                const nextDuration = event.currentTarget.duration || 0;
                setDuration(nextDuration);
                setTrimEnd(nextDuration);
              }}
              className="aspect-[9/16] max-h-[54dvh] w-full object-contain"
            />
          </div>

          <div className="rounded-2xl border border-border bg-card p-3 dark:border-border-dark dark:bg-card-dark">
            <div className="mb-3 flex items-center justify-between">
              <span className="text-sm font-semibold">Audio</span>
              <button
                type="button"
                onClick={() => setMuted((value) => !value)}
                className="flex h-9 items-center gap-2 rounded-full bg-muted px-3 text-sm font-semibold dark:bg-muted-dark"
              >
                {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
                {muted ? "Muted" : "Sound on"}
              </button>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={muted ? 0 : volume}
              onChange={(event) => {
                const nextVolume = Number(event.target.value);
                setVolume(nextVolume);
                setMuted(nextVolume === 0);
              }}
              className="w-full accent-primary"
            />
          </div>

          <div className="rounded-2xl border border-border bg-card p-3 dark:border-border-dark dark:bg-card-dark">
            <div className="mb-3 flex items-center justify-between text-sm font-semibold">
              <span>Trim</span>
              <span className="text-xs text-mutedForeground">{Math.round(trimStart)}s - {Math.round(trimEnd || duration)}s</span>
            </div>
            <label className="mb-2 block text-xs text-mutedForeground">Start</label>
            <input type="range" min="0" max={Math.max(duration - 1, 0)} step="0.1" value={trimStart} onChange={(event) => setTrimStart(Math.min(Number(event.target.value), (trimEnd || duration) - 0.5))} className="w-full accent-primary" />
            <label className="mb-2 mt-3 block text-xs text-mutedForeground">End</label>
            <input type="range" min="0.5" max={duration || 1} step="0.1" value={trimEnd || duration || 0.5} onChange={(event) => setTrimEnd(Math.max(Number(event.target.value), trimStart + 0.5))} className="w-full accent-primary" />
          </div>

          <div className="rounded-2xl border border-border bg-card p-3 dark:border-border-dark dark:bg-card-dark">
            <div className="mb-3 flex items-center justify-between">
              <span className="text-sm font-semibold">Cover thumbnail</span>
              <button type="button" onClick={() => thumbnailInputRef.current?.click()} className="flex h-9 items-center gap-2 rounded-full bg-muted px-3 text-sm font-semibold dark:bg-muted-dark">
                <ImagePlus size={16} />
                Choose
              </button>
            </div>
            {thumbnailPreview ? (
              <img src={thumbnailPreview} alt="" className="h-28 w-20 rounded-xl object-cover" />
            ) : (
              <p className="text-xs text-mutedForeground">Optional. If empty, the server/player can use the video frame.</p>
            )}
            <input
              ref={thumbnailInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(event) => setThumbnail(event.target.files?.[0] || null)}
            />
          </div>
        </div>

        <footer className="flex gap-3 border-t border-border bg-gray-50 p-4 dark:border-border-dark dark:bg-gray-900">
          <button type="button" onClick={onClose} disabled={isSaving} className="h-11 flex-1 rounded-full border border-border bg-white text-sm font-semibold dark:border-border-dark dark:bg-gray-950">
            Cancel
          </button>
          <button type="button" onClick={handleSave} disabled={isSaving} className="flex h-11 flex-1 items-center justify-center gap-2 rounded-full bg-primary text-sm font-semibold text-white">
            {isSaving ? <Loader2 size={18} className="animate-spin" /> : <Check size={18} />}
            Done
          </button>
        </footer>
      </Motion.div>
    </Motion.div>
  );
};

export default VideoEditor;
