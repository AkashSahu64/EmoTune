import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import {
  X,
  Image,
  Video,
  Smile,
  Tag,
  MapPin,
  Users,
  Globe,
  Loader2,
} from 'lucide-react';
import { useAuthStore } from '../../../store/authStore.js';
import { useUIStore } from '../../../store/uiStore.js';
import { feedService } from '../../../services/feed.service.js';
import { showSuccess, showError } from '../../../utils/toast.js';
import Avatar from '../../../components/common/Avatar.jsx';
import Button from '../../../components/common/Button.jsx';
import { FEED_EVENTS, publishFeedEvent } from '../../../utils/feedEvents.js';

const CreatePostModal = () => {
  const { user } = useAuthStore();
  const { closeModal } = useUIStore();
  const fileInputRef = useRef(null);
  
  const [content, setContent] = useState('');
  const [images, setImages] = useState([]);
  const [video, setVideo] = useState(null);
  const [location, setLocation] = useState('');
  const [tags, setTags] = useState([]);
  const [privacy, setPrivacy] = useState('public'); // 'public', 'friends', 'private'
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleFileUpload = (e) => {
    const files = Array.from(e.target.files);
    const imageFiles = files.filter(file => file.type.startsWith('image/'));
    const videoFiles = files.filter(file => file.type.startsWith('video/'));
    
    if (videoFiles.length > 0) {
      setVideo(videoFiles[0]);
      setImages([]);
    } else if (imageFiles.length > 0) {
      if (images.length + imageFiles.length <= 10) {
        setImages(prev => [...prev, ...imageFiles]);
      } else {
        showError('Maximum 10 images allowed');
      }
    }
  };

  const removeImage = (index) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const removeVideo = () => {
    setVideo(null);
  };

  const handleTagInput = (e) => {
    if (e.key === 'Enter' && e.target.value.trim()) {
      const tag = e.target.value.trim();
      if (!tags.includes(tag) && tags.length < 5) {
        setTags(prev => [...prev, tag]);
        e.target.value = '';
      }
    }
  };

  const removeTag = (tag) => {
    setTags(prev => prev.filter(t => t !== tag));
  };

  const handleSubmit = async () => {
    if (!content.trim() && images.length === 0 && !video) {
      showError('Please add some content to your post');
      return;
    }

    setIsSubmitting(true);

    try {
      const formData = new FormData();
      formData.append('content', content);
      formData.append('privacy', privacy);
      
      if (location) formData.append('location', location);
      if (tags.length > 0) formData.append('tags', JSON.stringify(tags));
      
      if (video) {
        formData.append('media', video);
        formData.append('media_type', 'video');
      } else if (images.length > 0) {
        images.forEach((image, index) => {
          formData.append(`media_${index}`, image);
        });
        formData.append('media_type', images.length > 1 ? 'carousel' : 'image');
      }

      await feedService.createBlog(formData);
      
      showSuccess('Post created successfully!');
      closeModal();
      publishFeedEvent({ type: FEED_EVENTS.CREATED });
    } catch (error) {
      showError('Failed to create post');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-h-[90vh] overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b z-10 p-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">Create Post</h2>
          <button
            onClick={closeModal}
            className="p-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {/* User Info */}
        <div className="flex items-center space-x-3 mb-6">
          <Avatar src={user?.avatar} alt={user?.username} size="large" />
          <div>
            <p className="font-semibold text-gray-900">{user?.username}</p>
            <select
              value={privacy}
              onChange={(e) => setPrivacy(e.target.value)}
              className="text-sm text-gray-600 bg-transparent border-none focus:ring-0"
            >
              <option value="public">🌍 Public</option>
              <option value="friends">👥 Friends</option>
              <option value="private">🔒 Private</option>
            </select>
          </div>
        </div>

        {/* Content Textarea */}
        <div className="mb-6">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder={`What's on your mind, ${user?.username}?`}
            className="w-full min-h-[150px] p-4 border-none text-lg focus:ring-0 resize-none"
            rows={4}
          />
        </div>

        {/* Media Preview */}
        {(images.length > 0 || video) && (
          <div className="mb-6">
            {video ? (
              <div className="relative rounded-xl overflow-hidden">
                <video
                  src={URL.createObjectURL(video)}
                  className="w-full h-64 object-cover"
                  controls
                />
                <button
                  onClick={removeVideo}
                  className="absolute top-2 right-2 p-2 bg-black/50 text-white rounded-full hover:bg-black/70"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : images.length === 1 ? (
              <div className="relative rounded-xl overflow-hidden">
                <img
                  src={URL.createObjectURL(images[0])}
                  alt="Post preview"
                  className="w-full h-64 object-cover"
                />
                <button
                  onClick={() => removeImage(0)}
                  className="absolute top-2 right-2 p-2 bg-black/50 text-white rounded-full hover:bg-black/70"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : images.length > 1 && (
              <div className={`grid gap-2 ${
                images.length === 2 ? 'grid-cols-2' :
                images.length === 3 ? 'grid-cols-2' :
                images.length === 4 ? 'grid-cols-2' :
                'grid-cols-3'
              }`}>
                {images.map((image, index) => (
                  <div key={index} className="relative aspect-square">
                    <img
                      src={URL.createObjectURL(image)}
                      alt={`Preview ${index + 1}`}
                      className="w-full h-full object-cover rounded-lg"
                    />
                    <button
                      onClick={() => removeImage(index)}
                      className="absolute top-1 right-1 p-1 bg-black/50 text-white rounded-full hover:bg-black/70"
                    >
                      <X className="w-3 h-3" />
                    </button>
                    {images.length > 4 && index === 3 && (
                      <div className="absolute inset-0 bg-black/50 rounded-lg flex items-center justify-center">
                        <span className="text-white font-bold text-lg">
                          +{images.length - 4}
                        </span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Tags */}
        {tags.length > 0 && (
          <div className="mb-6">
            <div className="flex flex-wrap gap-2">
              {tags.map((tag) => (
                <div
                  key={tag}
                  className="inline-flex items-center bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm"
                >
                  #{tag}
                  <button
                    onClick={() => removeTag(tag)}
                    className="ml-2 text-blue-600 hover:text-blue-800"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="border rounded-xl p-4 mb-6">
          <p className="font-medium text-gray-900 mb-3">Add to your post</p>
          <div className="flex items-center space-x-4">
            <label className="cursor-pointer p-2 text-green-600 hover:bg-green-50 rounded-lg">
              <Image className="w-6 h-6" />
              <input
                type="file"
                ref={fileInputRef}
                multiple
                accept="image/*,video/*"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
            
            <button className="p-2 text-red-600 hover:bg-red-50 rounded-lg">
              <Video className="w-6 h-6" />
            </button>
            
            <button className="p-2 text-yellow-600 hover:bg-yellow-50 rounded-lg">
              <Smile className="w-6 h-6" />
            </button>
            
            <div className="relative">
              <input
                type="text"
                placeholder="Add tag"
                onKeyPress={handleTagInput}
                className="px-3 py-2 border rounded-lg text-sm"
              />
              <Tag className="absolute right-3 top-2.5 w-4 h-4 text-gray-400" />
            </div>
            
            <button className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg">
              <MapPin className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Location */}
        <div className="mb-6">
          <div className="flex items-center space-x-2 text-gray-600">
            <MapPin className="w-5 h-5" />
            <input
              type="text"
              placeholder="Add location"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="flex-1 border-none focus:ring-0"
            />
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="sticky bottom-0 bg-white border-t p-6">
        <Button
          variant="primary"
          size="large"
          loading={isSubmitting}
          fullWidth
          onClick={handleSubmit}
          startIcon={isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : null}
        >
          {isSubmitting ? 'Posting...' : 'Post'}
        </Button>
      </div>
    </div>
  );
};

export default CreatePostModal;
