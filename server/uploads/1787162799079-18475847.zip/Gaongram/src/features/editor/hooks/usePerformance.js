import { useEffect, useMemo } from "react";
import { PerformanceManager } from "../core/PerformanceManager.js";

export const usePerformance = () => {
  const manager = useMemo(() => new PerformanceManager(), []);
  useEffect(() => () => manager.dispose(), [manager]);
  return manager;
};

export default usePerformance;
