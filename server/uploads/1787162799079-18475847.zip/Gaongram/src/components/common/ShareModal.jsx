// src/components/common/ShareModal.jsx
import React from 'react';
import { X, Copy, Twitter } from 'lucide-react';
import { FaWhatsapp } from 'react-icons/fa';
import { showSuccess } from '../../utils/toast.js';
import { useUIStore } from '../../store/uiStore.js';

const ShareModal = ({ audioId, title, cover, artist, url }) => {
  const { closeModal } = useUIStore();

  const shareText = `Listen to "${title || 'this audio'}" on GaonGram`;

  const copyLink = async () => {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(url);
        showSuccess('Link copied to clipboard!');
      } else {
        // fallback
        window.prompt('Copy this link:', url);
      }
    } catch (err) {
      console.error(err);
      showSuccess('Failed to copy link');
    }
  };

  const shareWhatsApp = () => {
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(
      `${shareText}\n${url}`
    )}`;
    window.open(whatsappUrl, '_blank');
  };

  const shareTwitter = () => {
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(
      shareText
    )}&url=${encodeURIComponent(url)}`;
    window.open(twitterUrl, '_blank');
  };

  return (
    <div
      className="
        w-full max-w-md mx-auto
        bg-white dark:bg-gray-900
        rounded-2xl shadow-xl
        overflow-hidden
        animate-fadeIn
      "
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          Share
        </h3>
        <button
          onClick={closeModal}
          className="p-1 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition"
          aria-label="Close"
        >
          <X className="w-5 h-5 text-gray-600 dark:text-gray-300" />
        </button>
      </div>

      {/* Content */}
      <div className="p-4 sm:p-5">
        {/* Audio Info */}
        <div className="flex items-center gap-3 mb-5">
          {cover ? (
            <img
              src={cover}
              alt={title}
              className="w-12 h-12 sm:w-14 sm:h-14 rounded-lg object-cover"
            />
          ) : (
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-lg bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
              <span className="text-xs text-gray-500 dark:text-gray-400">
                🎵
              </span>
            </div>
          )}

          <div className="flex-1 min-w-0">
            <p className="text-sm sm:text-base font-medium text-gray-900 dark:text-white truncate">
              {title || 'Untitled'}
            </p>
            <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 truncate">
              {artist || 'Unknown artist'}
            </p>
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-2 sm:space-y-3">
          {/* Copy */}
          <button
            onClick={copyLink}
            className="
              w-full flex items-center gap-3
              px-4 py-3
              bg-gray-100 dark:bg-gray-800
              hover:bg-gray-200 dark:hover:bg-gray-700
              rounded-xl transition
            "
          >
            <Copy className="w-5 h-5 text-gray-600 dark:text-gray-300" />
            <span className="text-gray-900 dark:text-white text-sm sm:text-base">
              Copy link
            </span>
          </button>

          {/* WhatsApp */}
          <button
            onClick={shareWhatsApp}
            className="
              w-full flex items-center gap-3
              px-4 py-3
              bg-green-500 hover:bg-green-600
              rounded-xl transition
            "
          >
            <FaWhatsapp className="w-5 h-5 text-white" />
            <span className="text-white text-sm sm:text-base">
              WhatsApp
            </span>
          </button>

          {/* Twitter */}
          <button
            onClick={shareTwitter}
            className="
              w-full flex items-center gap-3
              px-4 py-3
              bg-blue-500 hover:bg-blue-600
              rounded-xl transition
            "
          >
            <Twitter className="w-5 h-5 text-white" />
            <span className="text-white text-sm sm:text-base">
              Twitter (X)
            </span>
          </button>

          {/* Cancel */}
          <button
            onClick={closeModal}
            className="
              w-full mt-2
              px-4 py-3
              bg-gray-200 dark:bg-gray-700
              hover:bg-gray-300 dark:hover:bg-gray-600
              rounded-xl transition
              text-gray-900 dark:text-white
              text-sm sm:text-base
            "
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default ShareModal;