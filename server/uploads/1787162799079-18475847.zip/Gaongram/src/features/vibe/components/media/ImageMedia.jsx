import React, { useState, useRef } from "react";
import { motion } from "framer-motion";
import SensitiveContentOverlay from "../../../../components/vibe/SensitiveContentOverlay.jsx";

const ImageMedia = ({
  images = [],
  renderViewCount,
  isSensitiveBlocked = false,
  onSensitiveClick,
}) => {
  const [loaded, setLoaded] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const sliderRef = useRef(null);

  const finalImages = images?.length ? images : [];

  const handleScroll = () => {
    if (isSensitiveBlocked) return;
    if (!sliderRef.current) return;
    const index = Math.round(
      sliderRef.current.scrollLeft / sliderRef.current.clientWidth
    );
    setActiveIndex(index);
  };

  const scrollToImage = (index) => {
    if (isSensitiveBlocked) {
      onSensitiveClick?.();
      return;
    }

    if (!sliderRef.current) return;

    sliderRef.current.scrollTo({
      left: sliderRef.current.clientWidth * index,
      behavior: "smooth",
    });

    setActiveIndex(index);
  };

  return (
    <div className="relative w-full bg-black overflow-hidden">

      {!loaded && (
        <div className="absolute inset-0 animate-pulse bg-muted/20 z-10" />
      )}

      {/* Images */}
      <div
        ref={sliderRef}
        onScroll={handleScroll}
        className={`flex snap-x snap-mandatory scrollbar-hide scroll-smooth ${
          isSensitiveBlocked
            ? "overflow-hidden pointer-events-none"
            : "overflow-x-scroll"
        }`}
        style={{ scrollbarWidth: "none" }}
      >
        {finalImages.map((img, index) => (
          <div
            key={img.id || index}
            className="w-full shrink-0 snap-center flex items-center justify-center bg-black"
          >
            <motion.img
              src={img.image}
              alt={`post-${index}`}
              loading="lazy"
              onLoad={() => setLoaded(true)}
              initial={{ scale: 1.02 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.25 }}
              className={`
                w-full
                h-auto
                max-h-[700px]
                object-contain
                select-none
                transition-all
                duration-300
                ${isSensitiveBlocked ? "blur-xl scale-105 brightness-75" : ""}
              `}
              draggable={false}
            />
          </div>
        ))}
      </div>

      {/* Instagram Style Dots */}
      {finalImages.length > 1 && (
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-20">
          {finalImages.map((_, index) => (
            <button
              key={index}
              type="button"
              aria-label={`Show image ${index + 1}`}
              onClick={() => scrollToImage(index)}
              className={`rounded-full transition-all duration-300 ${
                activeIndex === index
                  ? "w-2.5 h-2.5 bg-white"
                  : "w-2 h-2 bg-white/50"
              }`}
            />
          ))}
        </div>
      )}

      {renderViewCount("image")}
      {isSensitiveBlocked && (
        <SensitiveContentOverlay onClick={onSensitiveClick} />
      )}
    </div>
  );
};

export default ImageMedia;
