import { feedService } from '../services/feed.service.js';

export const updateUserInterests = async (interests) => {
  try {
    // This uses POST /update-feed_interests/
    await feedService.updateFeedInterests(interests);
    console.log('Feed interests updated successfully');
    return true;
  } catch (error) {
    console.error('Failed to update feed interests:', error);
    return false;
  }
};

export const markFeedItemsAsSeen = async (feedItems) => {
  try {
    // This uses POST /feed/mark-seen/
    await feedService.markFeedSeen(feedItems);
    console.log('Feed items marked as seen');
    return true;
  } catch (error) {
    console.error('Failed to mark feed items as seen:', error);
    return false;
  }
};