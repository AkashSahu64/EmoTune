import React, { useEffect, useRef, useState } from "react";
import { useGlobalMedia } from "../../hooks/useGlobalMedia.js";
import { useInteractionTracker } from "../../hooks/useInteractionTracker.js";
import { mediaController } from "../../media/MediaController.js";
import { formatNumber } from "../../utils/formatTime.js";
import AudioMeta from "./components/AudioMeta.jsx";
import AudioCover from "./components/AudioCover.jsx";
import AudioControls from "./components/AudioControls.jsx";
import AudioSeekbar from "./components/AudioSeekbar.jsx";
import AudioActions from "./components/AudioActions.jsx";
import AudioWaveform from "../../components/audio/AudioWaveform.jsx";
import { usePlayerStore } from "../../store/playerStore.js";

const DEBUG = false;
const log = (...args) => {
  if (DEBUG) console.log("[AUDIO_CARD_DEBUG]:", ...args);
};

const AudioCard = React.memo(
  ({
    audioPost,
    playbackRate,
    audioError,
    user,
    isFirst,
    isLast,
    onEnded,
    onError,
    onPreviousCard,
    onNextCard,
    onSpeedChange,
    onShare,
    onLike,
    onTap,
    onComments,
    onOptions,
    sleepTimer,
    remainingTime,
    onSetSleepTimer,
    onCancelSleepTimer,
    feedTracks,
    currentIndex,
    isPlaylistMode,
  }) => {
    const { setQueue } = usePlayerStore();
    const {
      elementRef,
      isPlaying: globalIsPlaying,
      progress,
      isLoading,
      hasError,
      isMuted,
      toggleMute,
      seek,
      skipForward,
      skipBackward,
      progressPercentage,
      formatTime: formatAudioTime,
    } = useGlobalMedia(audioPost.id, "audio", audioPost.audio?.audio);

    const cardRef = useRef(null);
    const [isActuallyPlaying, setIsActuallyPlaying] = useState(false);
    const [isVisible, setIsVisible] = useState(false); // for interaction tracker

    // Intersection Observer for autoplay + visibility tracking
    useEffect(() => {
      if (!cardRef.current) return;

      const observer = new IntersectionObserver(
        ([entry]) => {
          const visible = entry.isIntersecting && entry.intersectionRatio >= 0.7;
          setIsVisible(visible);
          log(`audio ${audioPost.id} visibility:`, visible);
        },
        { threshold: [0, 0.3, 0.7, 1] }
      );

      observer.observe(cardRef.current);
      return () => observer.disconnect();
    }, [audioPost.id]);

    // Interaction tracker (replaces old view count)
    useInteractionTracker({
      postId: audioPost.id,
      isVisible,
      mediaType: "audio",
      mediaRef: elementRef, // useGlobalMedia returns elementRef (the audio element)
      duration: audioPost.audio?.duration || progress.duration || 0,
    });

    // Audio playback events (for local state)
    useEffect(() => {
      const audio = elementRef.current;
      if (!audio) return;
      const onPlay = () => setIsActuallyPlaying(true);
      const onPause = () => setIsActuallyPlaying(false);
      const handleEnded = () => {
        setIsActuallyPlaying(false);
        onEnded();
      };
      const handleError = () => onError();

      audio.addEventListener("play", onPlay);
      audio.addEventListener("pause", onPause);
      audio.addEventListener("ended", handleEnded);
      audio.addEventListener("error", handleError);
      return () => {
        audio.removeEventListener("play", onPlay);
        audio.removeEventListener("pause", onPause);
        audio.removeEventListener("ended", handleEnded);
        audio.removeEventListener("error", handleError);
      };
    }, [elementRef, onEnded, onError]);

    useEffect(() => {
      if (elementRef.current) {
        elementRef.current.playbackRate = playbackRate;
      }
    }, [elementRef, playbackRate]);

    useEffect(() => {
      setIsActuallyPlaying(globalIsPlaying);
    }, [globalIsPlaying]);

    useEffect(() => {
      const handlePlay = (data) => {
        if (String(data.mediaId) === String(audioPost.id)) {
          setQueue(feedTracks, currentIndex, { isPlaying: true, force: true });
        }
      };
      mediaController.on('mediaPlay', handlePlay);
      return () => mediaController.off('mediaPlay', handlePlay);
    }, [audioPost.id, feedTracks, currentIndex, setQueue]);

    const duration = audioPost.audio?.duration || progress.duration || 0;
    const currentTime = progress.current || 0;

    return (
      <div
        ref={cardRef}
        data-audio-id={audioPost.id}
        className="relative h-[calc(100vh-4rem)] md:h-screen w-full snap-center flex items-center justify-center"
      >
        <div className="relative w-full max-w-full lg:max-w-[410px] h-full max-h-screen overflow-hidden bg-gradient-to-b from-gray-800 to-gray-900 dark:from-gray-800 dark:to-gray-900 shadow-xl">
          <AudioCover
            audioId={audioPost.audio?.id}
            coverImage={audioPost.audio?.cover_image}
            audioTitle={audioPost.audio?.title}
            audioError={audioError}
            hasError={hasError}
            viewsCount={audioPost.views_count}
            isMuted={isMuted}
            onToggleMute={toggleMute}
            isInPlaylist={false}
            onPlaylistToggle={() => {}}
            isPlaylistMode={isPlaylistMode}
          >
            <AudioMeta
              audioTitle={audioPost.audio?.title}
              user={audioPost.user}
              authorId={audioPost.author}
              currentUserId={user?.id}
              timesAgo={audioPost.times_ago}
              createdAt={audioPost.created_at}
            />
          </AudioCover>

          <div className="px-2 lg:px-4">
            <div className="mb-0">
              <AudioWaveform
                audioRef={elementRef}
                isPlaying={isActuallyPlaying}
                currentTime={currentTime}
                duration={duration}
                isLoading={isLoading}
                hasError={audioError || hasError}
              />
            </div>
            <AudioSeekbar
              duration={duration}
              currentTime={currentTime}
              progressPercentage={progressPercentage}
              audioError={audioError}
              hasError={hasError}
              onSeek={seek}
              formatTime={formatAudioTime}
            />
            <AudioControls
              isActuallyPlaying={isActuallyPlaying}
              audioError={audioError}
              hasError={hasError}
              isLoading={isLoading}
              isFirst={isFirst}
              isLast={isLast}
              onTap={onTap}
              onSkipBackward={() => skipBackward(5)}
              onSkipForward={() => skipForward(5)}
              onPreviousCard={onPreviousCard}
              onNextCard={onNextCard}
            />
            <AudioActions
              audioPost={audioPost}
              isInPlaylist={false}
              playbackRate={playbackRate}
              audioError={audioError}
              hasError={hasError}
              onLike={onLike}
              onComments={onComments}
              onPlaylistToggle={() => {}}
              onSpeedChange={onSpeedChange}
              onShare={onShare}
              onOptions={onOptions}
              formatNumber={formatNumber}
              sleepTimer={sleepTimer}
              remainingTime={remainingTime}
              onSetSleepTimer={onSetSleepTimer}
              onCancelSleepTimer={onCancelSleepTimer}
            />
          </div>
        </div>
      </div>
    );
  }
);

AudioCard.displayName = "AudioCard";
export default AudioCard;
