// pages/Reels.jsx
import React, { useEffect, useState, useRef, useCallback } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Play, Music, Eye } from "lucide-react";
import { vibeService } from "../services/vibe.service.js";
import { useAuthStore } from "../store/authStore.js";
import { useMediaStore } from "../store/mediaStore.js";
import { useInteractionTracker } from "../hooks/useInteractionTracker.js";
import { formatNumber } from "../utils/formatTime.js";
import Avatar from "../components/common/Avatar.jsx";
import Loader from "../components/common/Loader.jsx";
import EmptyState from "../components/common/EmptyState.jsx";
import Seo from "../components/seo/Seo.jsx";
import FollowButton from "../components/common/FollowButton.jsx";
import PostActionButtons from "../components/common/PostActionButtons.jsx";
import SensitiveContentOverlay from "../components/vibe/SensitiveContentOverlay.jsx";
import SensitiveContentSettingsModal from "../components/modals/SensitiveContentSettingsModal.jsx";
import AgeRestrictedModal from "../components/modals/AgeRestrictedModal.jsx";
import { calculateAge } from "../utils/calculateAge.js";
import { useTranslation } from "react-i18next";
import Hls from "hls.js";

const DEBUG = true;

const formatTime = (seconds) => {
  if (isNaN(seconds)) return "0:00";
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs < 10 ? "0" : ""}${secs}`;
};

const getVideoSources = (videoPost) => {
  if (Array.isArray(videoPost.videos) && videoPost.videos.length > 0) {
    const first = videoPost.videos[0];
    if (first && typeof first === "object") {
      return {
        hls: first.hls_playlist || videoPost.hls_playlist || null,
        mp4: first.video || videoPost.video || null,
      };
    }
  }
  return {
    hls: videoPost.hls_playlist || null,
    mp4: videoPost.video || null,
  };
};

const ReelItem = React.memo(
  ({
    video,
    index,
    isVisible,
    onVideoTap,
    onPostUpdate,
    user,
    isOwner,
    thumbnail,
    userInteracted,
    navigate,
    preloadRef,
    videoSources,
    videoRefs,
    canViewSensitive,
    onSensitiveClick,
  }) => {
    const videoRef = useRef(null);
    const [isPlaying, setIsPlaying] = useState(false);
    const [orientation, setOrientation] = useState("portrait");
    const [currentVideoUrl, setCurrentVideoUrl] = useState(
      videoSources?.hls || videoSources?.mp4 || null,
    );

    const [currentTime, setCurrentTime] = useState(0);
    const isSensitiveBlocked = video.is_sensitive === true && !canViewSensitive;
    const [videoDuration, setVideoDuration] = useState(0);
    const scrubberRef = useRef(null);
    const fillRef = useRef(null);
    const thumbRef = useRef(null);
    const isSeeking = useRef(false);
    const dragTimeRef = useRef(0);

    useInteractionTracker({
      postId: video.id,
      isVisible,
      mediaType: "video",
      mediaRef: videoRef,
      duration: videoDuration,
    });

    const handleMetadata = () => {
      if (!videoRef.current) return;
      const video = videoRef.current;
      const aspect = video.videoWidth / video.videoHeight;
      setOrientation(aspect < 1 ? "portrait" : "landscape");
      setVideoDuration(video.duration || 0);
    };

    const animationFrameRef = useRef(null);
    const lastTimeRef = useRef(0);

    const handleDurationChange = () => {
      if (videoRef.current) {
        setVideoDuration(videoRef.current.duration);
      }
    };
    const smoothProgressUpdate = () => {
      const video = videoRef.current;

      if (!video || isSeeking.current) {
        animationFrameRef.current = requestAnimationFrame(smoothProgressUpdate);
        return;
      }

      const current = video.currentTime;
      const duration = video.duration || 0;

      // React state sirf timer ke liye
      if (Math.abs(current - lastTimeRef.current) > 0.1) {
        setCurrentTime(current);
        lastTimeRef.current = current;
      }

      // Direct DOM update = ultra smooth
      if (duration > 0) {
        const percent = (current / duration) * 100;

        if (fillRef.current) {
          fillRef.current.style.width = `${percent}%`;
        }
      }

      animationFrameRef.current = requestAnimationFrame(smoothProgressUpdate);
    };

    // Get time from mouse/touch position (0..duration)
    const getTimeFromEvent = (e) => {
      if (!scrubberRef.current || videoDuration === 0) return 0;
      const rect = scrubberRef.current.getBoundingClientRect();
      const clientX = e.clientX ?? e.touches?.[0]?.clientX ?? 0;
      let percent = (clientX - rect.left) / rect.width;
      percent = Math.min(Math.max(percent, 0), 1);
      return percent * videoDuration;
    };

    // Update DOM progress directly (no React state)
    const updateProgressDOM = (time) => {
      const percent = (time / videoDuration) * 100;
      if (fillRef.current) {
        fillRef.current.style.width = `${percent}%`;
      }
    };

    // Start drag / click seek
    const handleSeekStart = (e) => {
      e.stopPropagation();
      const newTime = getTimeFromEvent(e);
      // Update DOM instantly
      updateProgressDOM(newTime);
      // Update React state (optional, for timer display)
      setCurrentTime(newTime);
      isSeeking.current = true;

      const onMove = (moveEvent) => {
        const time = getTimeFromEvent(moveEvent);
        updateProgressDOM(time);
        setCurrentTime(time);
      };

      const onEnd = () => {
        // Apply final seek to video element
        if (videoRef.current && !isNaN(currentTime)) {
          videoRef.current.currentTime = currentTime;
        }
        isSeeking.current = false;
        document.removeEventListener("mousemove", onMove);
        document.removeEventListener("mouseup", onEnd);
        document.removeEventListener("touchmove", onMove);
        document.removeEventListener("touchend", onEnd);
      };

      document.addEventListener("mousemove", onMove);
      document.addEventListener("mouseup", onEnd);
      document.addEventListener("touchmove", onMove);
      document.addEventListener("touchend", onEnd);
    };

    useEffect(() => {
      const video = videoRef.current;

      if (!video) return;

      video.addEventListener("loadedmetadata", handleMetadata);
      video.addEventListener("durationchange", handleDurationChange);

      animationFrameRef.current = requestAnimationFrame(smoothProgressUpdate);

      return () => {
        video.removeEventListener("loadedmetadata", handleMetadata);

        video.removeEventListener("durationchange", handleDurationChange);

        if (animationFrameRef.current) {
          cancelAnimationFrame(animationFrameRef.current);
        }
      };
    }, []);

    // HLS / MP4 setup (unchanged)
    useEffect(() => {
      const video = videoRef.current;
      if (!video || !currentVideoUrl) return;
      let hls;
      const isHls = currentVideoUrl.includes(".m3u8");

      if (isHls) {
        let fallbackTimeout;
        if (video.canPlayType("application/vnd.apple.mpegurl")) {
          video.src = currentVideoUrl;
          video.load();
          if (isVisible) {
            video
              .play()
              .catch((err) => console.error("[SAFARI AUTOPLAY ERROR]", err));
          }
          fallbackTimeout = setTimeout(() => {
            if (
              video.readyState < 2 &&
              videoSources?.mp4 &&
              currentVideoUrl !== videoSources.mp4
            ) {
              setCurrentVideoUrl(videoSources.mp4);
            }
          }, 1000);
        } else if (Hls.isSupported()) {
          hls = new Hls({ enableWorker: true, lowLatencyMode: true });
          hls.loadSource(currentVideoUrl);
          hls.attachMedia(video);
          fallbackTimeout = setTimeout(() => {
            if (
              video.readyState < 2 &&
              videoSources?.mp4 &&
              currentVideoUrl !== videoSources.mp4
            ) {
              console.log("[TIMEOUT FALLBACK TO MP4]");
              hls.destroy();
              setCurrentVideoUrl(videoSources.mp4);
            }
          }, 1000);
          hls.on(Hls.Events.MANIFEST_PARSED, () => {
            clearTimeout(fallbackTimeout);
            if (isVisible) {
              video
                .play()
                .catch((err) => console.error("[HLS AUTOPLAY ERROR]", err));
            }
          });
          hls.on(Hls.Events.ERROR, (event, data) => {
            console.error("[HLS ERROR]", data);
            if (videoSources?.mp4 && currentVideoUrl !== videoSources.mp4) {
              clearTimeout(fallbackTimeout);
              hls.destroy();
              setCurrentVideoUrl(videoSources.mp4);
            }
          });
        }
      } else {
        video.src = currentVideoUrl;
        video.load();
        if (isVisible) {
          video
            .play()
            .catch((err) => console.error("[MP4 AUTOPLAY ERROR]", err));
        }
      }

      const onPlay = () => setIsPlaying(true);
      const onPause = () => setIsPlaying(false);
      video.addEventListener("play", onPlay);
      video.addEventListener("pause", onPause);

      return () => {
        video.removeEventListener("play", onPlay);
        video.removeEventListener("pause", onPause);
        video.pause();
        video.currentTime = 0;
        video.removeAttribute("src");
        video.load();
        if (hls) hls.destroy();
      };
    }, [currentVideoUrl]);

    const captionText =
      video.caption || video.content || video.audio?.title || "";

    // Sync DOM progress when React state updates (timeupdate)
    useEffect(() => {
      if (!isSeeking.current && videoDuration > 0) {
        const percent = (currentTime / videoDuration) * 100;
        if (fillRef.current) {
          fillRef.current.style.width = `${percent}%`;
        }
      }
    }, [currentTime, videoDuration]);

    return (
      <div
        ref={preloadRef}
        className="relative h-[calc(100dvh-4rem)] w-full shrink-0 snap-start snap-always overflow-hidden bg-background dark:bg-black md:h-[100dvh]"
        data-video-id={video.id}
      >
        <div
          className={`relative w-full mx-auto flex items-center justify-center overflow-hidden
          ${
            orientation === "portrait"
              ? "h-full max-h-full max-w-[420px]"
              : "h-full max-h-full max-w-[420px]"
          }`}
        >
          <video
            ref={(el) => {
              videoRef.current = el;
              if (el) videoRefs.current[index] = el;
            }}
            className={`w-full h-full bg-black transition-all duration-300
  ${orientation === "portrait" ? "object-cover" : "object-contain"}
  ${isSensitiveBlocked ? "blur-xl scale-105 brightness-75" : ""}
`}
            playsInline
            loop
            muted={!userInteracted}
            onLoadedMetadata={handleMetadata}
            onClick={() => {
              if (isSensitiveBlocked) {
                onSensitiveClick?.();
                return;
              }

              onVideoTap(video.id, index, videoRef);
            }}
            poster={thumbnail}
            preload="metadata"
            style={{ touchAction: "manipulation" }}
          />

          {isSensitiveBlocked && (
            <SensitiveContentOverlay onClick={onSensitiveClick} />
          )}

          {!isPlaying && (
            <div
              className="absolute inset-0 flex items-center justify-center cursor-pointer"
              onClick={() => {
                if (isSensitiveBlocked) {
                  onSensitiveClick?.();
                  return;
                }

                onVideoTap(video.id, index, videoRef);
              }}
            >
              <div className="p-2.5 rounded-full bg-black/40 backdrop-blur-sm">
                <Play className="w-8 h-8 ml-0.5 text-white/90" fill="white" />
              </div>
            </div>
          )}

          {/* Right action bar */}
          <div className="absolute right-0 bottom-6 flex flex-col items-center gap-5 z-[60] pr-1 pointer-events-auto">
            {video.views_count > 0 && (
              <div className="flex flex-col items-center text-white text-xs">
                <Eye className="w-5 h-5 mb-0.5" />
                <span>{formatNumber(video.views_count)}</span>
              </div>
            )}
            <PostActionButtons
              postId={video.feed_post || video.id}
              postType="reels"
              isLiked={video.is_liked}
              likeCount={video.likes_count || 0}
              commentCount={video.comments_count || 0}
              isOwner={isOwner}
              size="large"
              layout="vertical"
              onUpdate={(updates) =>
                onPostUpdate(video.feed_post || video.id, updates)
              }
              showViewCount={false}
              showCommentsCount
              className="space-y-0"
            />
          </div>

          {/* Bottom section */}
          <div className="absolute bottom-1 left-2 right-0 px-0 z-[40] pb-[env(safe-area-inset-bottom)] pointer-events-none">
            {/* User profile info */}
            <div className="flex items-start gap-3 max-w-[90%] pointer-events-auto">
              <div
                className="cursor-pointer"
                onClick={() =>
                  video.user?.id && navigate(`/profile/${video.user.id}`)
                }
              >
                <Avatar
                  src={video.user?.avatar}
                  alt={video.user?.username}
                  size="small"
                  className="border border-border"
                />
              </div>
              <div className="flex-1 min-w-0 mb-0">
                <div className="flex items-center gap-2 mb-0 flex-wrap">
                  <h3
                    className="font-semibold text-foreground-dark text-sm truncate cursor-pointer"
                    onClick={() =>
                      video.user?.id && navigate(`/profile/${video.user.id}`)
                    }
                  >
                    @{video.user?.username || "user"}
                  </h3>
                  {video.user?.id !== user?.id && (
                    <FollowButton
                      profileId={video.user?.id}
                      size="extra-small"
                      className="ml-2"
                    />
                  )}
                </div>
                {captionText ? (
                  <p className="text-foreground-dark/80 text-sm mb-1 line-clamp-2 break-words">
                    {captionText}
                  </p>
                ) : (
                  <p className="text-xs text-mutedForeground">No caption</p>
                )}
                {video.audio?.title &&
                  !captionText.includes(video.audio.title) && (
                    <div className="flex items-center space-x-1 text-foreground-dark/80 text-xs">
                      <Music className="w-3 h-3" />
                      <span className="truncate max-w-[120px]">
                        {video.audio.title}
                      </span>
                    </div>
                  )}
              </div>
            </div>

            {/* Seek bar – div based, direct DOM updates during drag */}
            {videoDuration > 0 && (
              <div className="w-full px-1 mt-1 pointer-events-auto">
                <div className="flex items-center gap-2 text-xs text-foreground-dark/80">
                  <div className="flex-1">
                    <div
                      ref={scrubberRef}
                      className="relative h-1 bg-white/20 rounded-full cursor-pointer group/progress overflow-visible"
                      onMouseDown={handleSeekStart}
                      onTouchStart={handleSeekStart}
                    >
                      <div
                        ref={fillRef}
                        className="absolute left-0 top-0 h-full bg-primary rounded-full"
                        style={{
                          width: "0%",
                        }}
                      >
                        <div
                          ref={thumbRef}
                          className="absolute right-0 top-1/2 w-3 h-3 bg-primary rounded-full shadow-lg
                        -translate-y-1/2 translate-x-1/2
                        opacity-0 group-hover/progress:opacity-100
                        transition-opacity duration-200"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  },
);

// ---------- Main Reels component (unchanged) ----------
const Reels = () => {
  const { user } = useAuthStore();
  const profileDob = user?.dob || user?.profile?.dob;

  const age = calculateAge(profileDob);

  const isUnder18 = typeof age === "number" && age < 18;

  const sensitiveAllowed =
    user?.is_sensitive_allowed ?? user?.profile?.is_sensitive_allowed;

  const canViewSensitive =
    sensitiveAllowed === true && typeof age === "number" && !isUnder18;
  const [showSensitiveSettingsModal, setShowSensitiveSettingsModal] =
    useState(false);

  const [showAgeRestrictedModal, setShowAgeRestrictedModal] = useState(false);
  const { setUserInteracted, userInteracted } = useMediaStore();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const [searchParams] = useSearchParams();
  const startVideoId = searchParams.get("start");
  const targetUserId = searchParams.get("user");

  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [error, setError] = useState(null);

  const [visibilityStates, setVisibilityStates] = useState({});
  const [videoDurations, setVideoDurations] = useState({});

  const videoRefs = useRef([]);
  const observerRef = useRef(null);
  const preloadObserverRef = useRef(null);
  const currentPage = useRef(1);

  const handleSensitiveClick = useCallback(() => {
    if (isUnder18) {
      setShowAgeRestrictedModal(true);
      return;
    }

    setShowSensitiveSettingsModal(true);
  }, [isUnder18]);

  const handlePostUpdate = (postId, updates) => {
    setVideos((prev) =>
      prev.map((v) =>
        v.id === postId
          ? {
              ...v,
              is_liked:
                typeof updates.is_liked !== "undefined"
                  ? updates.is_liked
                  : v.is_liked,
              likes_count:
                typeof updates.total_likes !== "undefined"
                  ? updates.total_likes
                  : v.likes_count,
              comments_count:
                typeof updates.comments_count === "function"
                  ? updates.comments_count(v.comments_count || 0)
                  : typeof updates.comments_count !== "undefined"
                    ? updates.comments_count
                    : v.comments_count,
            }
          : v,
      ),
    );
  };

  const fetchVideos = async (page, append = false) => {
    try {
      console.log(`[Reels] fetchVideos page=${page}`);
      let rawVideos = [];
      let hasMoreData = false;

      if (targetUserId) {
        const res = await vibeService.getUserVideos(targetUserId, { page });
        rawVideos = res?.results || [];
        hasMoreData = rawVideos.length > 0;
      } else {
        const res = await vibeService.getVideoPosts({ page, page_size: 10 });
        rawVideos = res.results || [];
        hasMoreData = res.hasMore;
      }

      const normalized = rawVideos
        .map((item) => {
          let videosArray = [];
          if (item.video || item.hls_playlist) {
            videosArray = [
              {
                video: item.video,
                hls_playlist: item.hls_playlist,
                thumbnail: item.thumbnail,
              },
            ];
          }
          return {
            id: item.id,
            is_sensitive: item.is_sensitive ?? false,
            feed_post: item.feed_post || item.id,
            user: {
              id: item.author,
              username: item.username || "user",
              avatar: item.profile_image || "",
              is_verified: item.is_verified ?? false,
            },
            caption: item.content || "",
            views_count: item.views_count ?? 0,
            likes_count: item.likes_count ?? 0,
            comments_count: item.comments_count ?? 0,
            is_liked: item.is_liked === true,
            videos: videosArray,
            video: item.video,
            hls_playlist: item.hls_playlist,
            audio: item.audio || null,
          };
        })
        .filter((v) => {
          const sources = getVideoSources(v);
          return sources.hls || sources.mp4;
        });

      setVideos((prev) => (append ? [...prev, ...normalized] : normalized));
      setHasMore(hasMoreData);
    } catch (err) {
      console.error("[Reels] fetchVideos error:", err);
      setError(err.message || t("failed_to_load_reels"));
    }
  };

  useEffect(() => {
    const init = async () => {
      setLoading(true);
      setError(null);
      setVideos([]);
      currentPage.current = 1;
      setHasMore(true);
      await fetchVideos(1, false);
      setLoading(false);
    };
    init();
  }, []);

  useEffect(() => {
    if (!loading && startVideoId && videos.length > 0) {
      const timer = setTimeout(() => {
        const el = document.querySelector(`[data-video-id="${startVideoId}"]`);
        if (el) el.scrollIntoView({ behavior: "auto", block: "start" });
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [loading, startVideoId, videos]);

  const loadMore = useCallback(async () => {
    if (loadingMore || !hasMore) return;
    try {
      setLoadingMore(true);
      currentPage.current += 1;
      await fetchVideos(currentPage.current, true);
    } catch (error) {
      console.error("loadMore error:", error);
    } finally {
      setLoadingMore(false);
    }
  }, [loadingMore, hasMore]);

  const preloadRef = useCallback(
    (node) => {
      if (loadingMore || !hasMore) return;
      if (preloadObserverRef.current) preloadObserverRef.current.disconnect();
      preloadObserverRef.current = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) loadMore();
        },
        { threshold: 0.5, rootMargin: "300px" },
      );
      if (node) preloadObserverRef.current.observe(node);
    },
    [loadingMore, hasMore, loadMore],
  );

  const handleIntersect = useCallback(
    (entries) => {
      entries.forEach((entry) => {
        const videoContainer = entry.target;
        const videoElement = videoContainer.querySelector("video");
        const videoId = videoContainer.dataset.videoId;
        if (!videoElement || !videoId) return;
        const isVisible =
          entry.isIntersecting && entry.intersectionRatio >= 0.7;
        setVisibilityStates((prev) => ({ ...prev, [videoId]: isVisible }));
        const currentVideo = videos.find(
          (v) => String(v.id) === String(videoId),
        );

        const blocked =
          currentVideo?.is_sensitive === true && !canViewSensitive;

        if (blocked) {
          videoElement.pause();
          return;
        }
        if (isVisible) {
          videoRefs.current.forEach((other) => {
            if (other && other !== videoElement) other.pause();
          });
          if (videoElement.paused) {
            videoElement
              .play()
              .catch((err) => console.error("[VISIBLE VIDEO PLAY ERROR]", err));
          }
        } else {
          videoElement.pause();
        }
      });
    },
    [videos],
  );

  useEffect(() => {
    if (!videos?.length) return;
    if (observerRef.current) observerRef.current.disconnect();
    observerRef.current = new IntersectionObserver(handleIntersect, {
      threshold: 0.7,
    });
    const containers = document.querySelectorAll("[data-video-id]");
    containers.forEach((container) => observerRef.current.observe(container));
    return () => observerRef.current?.disconnect();
  }, [videos, handleIntersect]);

  const handleVideoTap = (videoId, index, videoRef) => {
    const video = videoRef.current;
    if (!video) return;
    if (!userInteracted) {
      setUserInteracted();
      video.muted = false;
    }
    if (!video.paused) {
      video.pause();
      return;
    }
    videoRefs.current.forEach((other, idx) => {
      if (other && idx !== index) other.pause();
    });
    video.play().catch((err) => console.error("[TAP PLAY ERROR]", err));
  };

  useEffect(() => {
    return () => {
      videoRefs.current.forEach((video) => video?.pause());
      observerRef.current?.disconnect();
      preloadObserverRef.current?.disconnect();
    };
  }, []);

  if (loading) {
    return (
      <div className="flex h-[calc(100dvh-4rem)] items-center justify-center bg-background dark:bg-black md:h-[100dvh]">
        <Loader />
      </div>
    );
  }

  if (!loading && videos.length === 0) {
    return (
      <div className="flex h-[calc(100dvh-4rem)] items-center justify-center bg-background dark:bg-black md:h-[100dvh]">
        <EmptyState
          icon="video"
          title={t("no_reels")}
          description={t("be_first_reel")}
          darkMode
        />
      </div>
    );
  }

  return (
    <>
      <Seo title="Reels" description="Watch short videos on GaonGram" />
      <div className="relative h-[calc(100dvh-4rem)] w-full overflow-hidden bg-background dark:bg-black md:h-[100dvh]">
        <div
          className="
    h-full
    w-full
    overflow-y-auto
    snap-y
    snap-mandatory
    scroll-smooth
    overscroll-contain
    hide-scrollbar
  "
        >
          {videos.map((video, index) => {
            const videoSources = getVideoSources(video);
            const videoUrl = videoSources.hls || videoSources.mp4;
            if (!videoUrl) return null;
            const isPreloadTrigger = index === videos.length - 3;
            return (
              <ReelItem
                key={`reel-${video.id}-${index}`}
                video={video}
                index={index}
                isVisible={!!visibilityStates[video.id]}
                onVideoTap={handleVideoTap}
                onPostUpdate={handlePostUpdate}
                user={user}
                isOwner={video.user?.id === user?.id}
                videoSources={videoSources}
                videoRefs={videoRefs}
                thumbnail={video.videos?.[0]?.thumbnail}
                userInteracted={userInteracted}
                navigate={navigate}
                preloadRef={isPreloadTrigger ? preloadRef : null}
                canViewSensitive={canViewSensitive}
                onSensitiveClick={handleSensitiveClick}
              />
            );
          })}
          {loadingMore && (
            <div className="flex h-[calc(100dvh-4rem)] shrink-0 snap-start snap-always items-center justify-center bg-background dark:bg-black md:h-[100dvh]">
              <Loader />
              <p className="text-foreground dark:text-white/70 mt-4 text-sm">
                {t("loading_more_reels")}
              </p>
            </div>
          )}
        </div>
      </div>
      <SensitiveContentSettingsModal
        isOpen={showSensitiveSettingsModal}
        onClose={() => setShowSensitiveSettingsModal(false)}
      />

      <AgeRestrictedModal
        isOpen={showAgeRestrictedModal}
        onClose={() => setShowAgeRestrictedModal(false)}
      />
    </>
  );
};

export default Reels;
