/* eslint-env node */
/* global process, URL, AbortController, setTimeout, clearTimeout, Buffer */
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import dotenv from "dotenv";
import {
  buildAudioSeo,
  buildBlogSeo,
  buildHashtagSeo,
  buildPlaylistSeo,
  buildPostSeo,
  buildProfileSeo,
  buildReelSeo,
  buildStaticPageSeo,
  buildStorySeo,
  normalizeProfile,
} from "../seo/builders/index.mjs";
import {
  DEFAULT_DESCRIPTION,
  DEFAULT_KEYWORDS,
  DEFAULT_SITE_URL,
  SITE_NAME,
  getApiBaseUrl,
  getSiteUrl,
} from "../seo/metadata/config.mjs";
import {
  injectSeoHead,
  renderSeoHead,
  stripSeoHead,
} from "../seo/metadata/render.mjs";
import {
  cleanText,
  getSocialImage,
  resolveArrayPayload,
  unwrapApiPayload,
} from "../seo/metadata/utils.mjs";

dotenv.config();

export {
  DEFAULT_DESCRIPTION,
  DEFAULT_KEYWORDS,
  DEFAULT_SITE_URL,
  SITE_NAME,
  buildProfileSeo,
  getApiBaseUrl,
  getSiteUrl,
  injectSeoHead,
  normalizeProfile,
  renderSeoHead as renderProfileSeoHead,
  stripSeoHead,
};

const JSON_HEADERS = { Accept: "application/json" };

const getFetch = async () => {
  if (globalThis.fetch) return globalThis.fetch.bind(globalThis);
  const { default: fetch } = await import("node-fetch");
  return fetch;
};

export const apiUrl = (path) =>
  new URL(path.replace(/^\/+/, ""), `${getApiBaseUrl()}/`).href;

export const fetchJson = async (url) => {
  const fetch = await getFetch();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);

  try {
    const headers = { ...JSON_HEADERS };
    if (process.env.SEO_API_TOKEN) {
      headers.Authorization = `Bearer ${process.env.SEO_API_TOKEN}`;
    }

    const response = await fetch(url, { signal: controller.signal, headers });
    if (!response.ok) {
      throw new Error(`${response.status} ${response.statusText}`);
    }
    return response.json();
  } finally {
    clearTimeout(timer);
  }
};

export const inlineImageDataUri = async (value, { maxBytes = 2_000_000 } = {}) => {
  const imageUrl = getSocialImage(value);
  if (!imageUrl || imageUrl.startsWith("data:image/")) return imageUrl;

  const fetch = await getFetch();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 5000);

  try {
    const response = await fetch(imageUrl, {
      signal: controller.signal,
      headers: { Accept: "image/avif,image/webp,image/png,image/jpeg,image/*" },
    });
    if (!response.ok) return imageUrl;

    const contentType = response.headers.get("content-type") || "";
    if (!contentType.startsWith("image/")) return imageUrl;

    const arrayBuffer = await response.arrayBuffer();
    if (arrayBuffer.byteLength > maxBytes) return imageUrl;

    return `data:${contentType.split(";")[0]};base64,${Buffer.from(
      arrayBuffer,
    ).toString("base64")}`;
  } catch {
    return imageUrl;
  } finally {
    clearTimeout(timer);
  }
};

const exactUsernameMatch = (payload, username) => {
  const lower = String(username || "").toLowerCase();
  return resolveArrayPayload(payload).find(
    (item) => {
      const profile = normalizeProfile(item, username);
      return [profile.username, item.slug, item.user?.username, item.profile?.username]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase() === lower);
    },
  );
};

const firstUsablePayload = (payload) => {
  const unwrapped = unwrapApiPayload(payload);
  if (Array.isArray(unwrapped)) return unwrapped[0];
  if (Array.isArray(unwrapped?.results)) return unwrapped.results[0];
  return unwrapped;
};

const tryFetchAttempts = async (attempts) => {
  let lastError;

  for (const attempt of attempts) {
    try {
      const payload = await fetchJson(attempt.url);
      const resolved = attempt.resolve
        ? attempt.resolve(payload)
        : firstUsablePayload(payload);
      if (resolved) return resolved;
    } catch (error) {
      lastError = error;
    }
  }

  throw lastError || new Error("No SEO API endpoint returned usable data");
};

const mergeProfilePayloads = (base = {}, detail = {}) => ({
  ...base,
  ...detail,
  user: {
    ...(base.user || {}),
    ...(detail.user || {}),
  },
  stats: {
    ...(base.stats || {}),
    ...(detail.stats || {}),
  },
});

const enrichProfilePayload = async (profile, originalIdentifier) => {
  const normalized = normalizeProfile(profile, originalIdentifier);
  const detailIdentifiers = Array.from(
    new Set(
      [
        normalized.username,
        normalized.id,
        normalized.userId,
        profile.slug,
        originalIdentifier,
      ]
        .filter(Boolean)
        .map((value) => String(value)),
    ),
  );

  for (const value of detailIdentifiers) {
    try {
      const detail = await fetchJson(apiUrl(`/profiles/${encodeURIComponent(value)}/`));
      return mergeProfilePayloads(profile, firstUsablePayload(detail));
    } catch {
      // Keep the primary result when a detail endpoint is unavailable.
    }
  }

  return profile;
};

export const fetchProfileByIdentifier = async (identifier) => {
  const encoded = encodeURIComponent(identifier);
  const numeric = /^\d+$/.test(String(identifier));

  const attempts = numeric
    ? [
        { url: apiUrl(`/profiles/${encoded}/`) },
        {
          url: apiUrl(`/profiles/?user_id=${encoded}&limit=1`),
          resolve: firstUsablePayload,
        },
        {
          url: apiUrl(`/profiles/?search=${encoded}&limit=20`),
          resolve: (payload) =>
            resolveArrayPayload(payload).find(
              (item) =>
                String(item.id) === String(identifier) ||
                String(item.user_id) === String(identifier),
            ),
        },
      ]
    : [
        { url: apiUrl(`/profiles/username/${encoded}/`) },
        { url: apiUrl(`/profiles/slug/${encoded}/`) },
        { url: apiUrl(`/profiles/${encoded}/`) },
        {
          url: apiUrl(`/profiles/?username=${encoded}&limit=1`),
          resolve: (payload) => exactUsernameMatch(payload, identifier),
        },
        {
          url: apiUrl(`/profiles/?slug=${encoded}&limit=1`),
          resolve: (payload) => exactUsernameMatch(payload, identifier),
        },
        {
          url: apiUrl(`/profiles/?search=${encoded}&limit=20`),
          resolve: (payload) => exactUsernameMatch(payload, identifier),
        },
      ];

  const profile = await tryFetchAttempts(attempts);
  return enrichProfilePayload(profile, identifier);
};

export const fetchEntityById = async (entity, identifier) => {
  const encoded = encodeURIComponent(identifier);
  const endpointMap = {
    post: [`/vibe-posts/${encoded}/`, `/posts/${encoded}/`, `/feeds/${encoded}/`],
    reel: [
      `/vibe-posts/${encoded}/`,
      `/reels/${encoded}/`,
      `/feeds/${encoded}/`,
    ],
    audio: [
      `/feeds/${encoded}/`,
      `/audio/${encoded}/`,
      `/vibe-posts/${encoded}/`,
    ],
    blog: [`/blogs/${encoded}/`],
    playlist: [`/playlists/${encoded}/`],
    story: [`/stories/${encoded}/`],
    hashtag: [
      `/hashtags/${encoded}/`,
      `/api/hashtags/${encoded}`,
      `/trending/?search=${encoded}`,
    ],
  };

  return tryFetchAttempts((endpointMap[entity] || []).map((url) => ({ url: apiUrl(url) })));
};

export const fetchPublicProfiles = async () => {
  const attempts = [
    apiUrl("/profiles/public/"),
    apiUrl("/profiles/?is_public=true&limit=1000"),
    apiUrl("/profiles/?limit=1000"),
  ];

  for (const url of attempts) {
    try {
      const payload = await fetchJson(url);
      const profiles = resolveArrayPayload(payload);
      if (profiles.length) return profiles;
    } catch {
      // Try the next known public listing shape.
    }
  }

  return [];
};

export const profileSnapshotPath = (identifier, rootDir = "dist") => {
  const segment = decodeURIComponent(String(identifier || "")).trim();
  if (
    !segment ||
    segment.includes("/") ||
    segment.includes("\\") ||
    segment === ".."
  ) {
    return "";
  }

  return resolve(rootDir, "profile", segment, "index.html");
};

export const readProfileSnapshot = (identifier, rootDir = "dist") => {
  const snapshotPath = profileSnapshotPath(identifier, rootDir);
  if (!snapshotPath || !existsSync(snapshotPath)) return "";
  return readFileSync(snapshotPath, "utf8");
};

export const writeProfileSnapshot = (identifier, html, rootDir = "dist") => {
  const snapshotPath = profileSnapshotPath(identifier, rootDir);
  if (!snapshotPath) return "";

  mkdirSync(dirname(snapshotPath), { recursive: true });
  writeFileSync(snapshotPath, html);
  return snapshotPath;
};

export const buildProfileHtml = (templateHtml, profile, identifier) => {
  const seo = buildProfileSeo(profile, { identifier });
  return injectSeoHead(templateHtml, renderSeoHead(seo, `/profile/${identifier}`));
};

export const buildSeoHtml = (templateHtml, seo, requestPath = "/") =>
  injectSeoHead(templateHtml, renderSeoHead(seo, requestPath));

export const buildPlaceholderProfile = (identifier) => ({
  username: identifier,
  full_name: cleanText(identifier) || "GaonGram user",
  bio: "",
  profile_image: "/preview.png",
  followers_count: 0,
  following_count: 0,
  posts_count: 0,
});

export const buildPlaceholderEntitySeo = (entity, identifier, path = "/") => {
  if (entity === "profile") {
    return buildProfileSeo(buildPlaceholderProfile(identifier), { identifier });
  }
  if (entity === "post") return buildPostSeo({ id: identifier }, {}, { path });
  if (entity === "reel") return buildReelSeo({ id: identifier }, { path });
  if (entity === "audio") return buildAudioSeo({ id: identifier }, { path });
  if (entity === "blog") return buildBlogSeo({ id: identifier }, { path });
  if (entity === "playlist") return buildPlaylistSeo({ id: identifier }, { path });
  if (entity === "hashtag") {
    return buildHashtagSeo({ name: identifier }, { tag: identifier, path });
  }
  if (entity === "story") return buildStorySeo({ id: identifier }, { path });
  return buildStaticPageSeo("home", { path });
};

export const buildEntitySeo = (entity, payload, identifier, path) => {
  if (entity === "post") return buildPostSeo(payload, payload.user || {}, { postId: identifier, path });
  if (entity === "reel") return buildReelSeo(payload, { reelId: identifier, path });
  if (entity === "audio") return buildAudioSeo(payload, { audioId: identifier, path });
  if (entity === "blog") return buildBlogSeo(payload, { blogId: identifier, path });
  if (entity === "playlist") return buildPlaylistSeo(payload, { id: identifier, path });
  if (entity === "hashtag") return buildHashtagSeo(payload, { tag: identifier, path });
  if (entity === "story") return buildStorySeo(payload, { storyId: identifier, path });
  return buildPlaceholderEntitySeo(entity, identifier, path);
};
