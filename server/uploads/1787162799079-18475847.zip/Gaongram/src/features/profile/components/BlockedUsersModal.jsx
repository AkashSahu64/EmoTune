// components/BlockedUsersModal.jsx
import React, { useState, useEffect } from 'react';
import { X, UserX } from 'lucide-react';
import { motion } from 'framer-motion';
import Button from '../../../components/common/Button';
import { profileAPI } from '../profileApi';
import { showToast } from '../../../utils/toast';

const BlockedUsersModal = ({ isOpen, onClose }) => {
  const [blockedUsers, setBlockedUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [unblockingId, setUnblockingId] = useState(null);

  const loadBlockedUsers = async () => {
    setLoading(true);
    try {
      const response = await profileAPI.getBlockedUsers();
      setBlockedUsers(response.data.results);
    } catch (error) {
      showToast('Failed to load blocked users', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadBlockedUsers();
    }
  }, [isOpen]);

  const handleUnblock = async (userId) => {
    setUnblockingId(userId);
    try {
      await profileAPI.toggleBlockUser(userId);
      showToast('User unblocked successfully', 'success');
      // Remove from list
      setBlockedUsers(prev => prev.filter(item => item.user.id !== userId));
    } catch (error) {
      showToast(error.response?.data?.message || 'Failed to unblock user', 'error');
    } finally {
      setUnblockingId(null);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-6">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm"
          onClick={onClose}
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative bg-white dark:bg-card-dark rounded-xl shadow-xl w-full max-w-md overflow-hidden"
        >
          {/* Header */}
          <div className="px-6 py-3 border-b border-border dark:border-border-dark bg-gradient-to-r from-gaon-cream to-white dark:from-gray-800 dark:to-card-dark">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-foreground dark:text-foreground-dark">
                Blocked Users
              </h3>
              <button
                onClick={onClose}
                className="p-1.5 text-gray-400 hover:text-foreground dark:hover:text-foreground-dark hover:bg-gray-100 dark:hover:bg-muted-dark rounded-lg transition-colors"
              >
                <X size={20} />
              </button>
            </div>
          </div>

          {/* Body */}
          <div className="max-h-[60vh] md:max-h-[70vh] overflow-y-auto hide-scrollbar p-4">
            {loading && blockedUsers.length === 0 ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : blockedUsers.length === 0 ? (
              <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                <UserX className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No blocked users</p>
              </div>
            ) : (
              <div className="space-y-3">
                {blockedUsers.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-3 bg-gray-50 dark:bg-muted-dark rounded-lg border border-border dark:border-border-dark"
                  >
                    <div className="flex items-center space-x-3">
                      <img
                        src={item.user.photo || '/default-avatar.png'}
                        alt={item.user.fullname}
                        className="w-10 h-10 rounded-full object-cover"
                        onError={(e) => { e.target.src = '/default-avatar.png'; }}
                      />
                      <div>
                        <p className="font-medium text-foreground dark:text-foreground-dark">
                          {item.user.fullname}
                        </p>
                        <p className="text-xs text-mutedForeground dark:text-mutedForeground-dark">
                          @{item.user.username}
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleUnblock(item.user.id)}
                      loading={unblockingId === item.user.id}
                      disabled={unblockingId === item.user.id}
                      className="border-red-300 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 p-0.5"
                    >
                      Unblock
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="sticky bottom-0 bg-white dark:bg-card-dark border-t border-border dark:border-border-dark px-6 py-3">
            <div className="flex justify-end">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="border-gray-300 dark:border-border-dark text-foreground dark:text-foreground-dark hover:bg-gray-50 dark:hover:bg-muted-dark rounded-lg px-4"
              >
                Close
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default BlockedUsersModal;