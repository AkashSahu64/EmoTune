import { ASPECT_RATIOS } from "./filterPresets.js";
import { isCorsSafeAudioUrl, normalizeStoryMediaUrl } from "../../audio/storyAudioManager.js";
import { isFilterableObject } from "../engine/helpers/layerUtils.js";
import { validateCanvasExportSafety } from "../engine/helpers/dom.js";
import { exportImageMusicStoryVideo } from "./exportStoryVideo.js";

export { preloadStoryVideoExporter } from "./exportStoryVideo.js";

const getExportDimensions = (aspectRatio) => {
  const ratio = ASPECT_RATIOS[aspectRatio] || ASPECT_RATIOS["9:16"];
  return {
    width: ratio.width,
    height: ratio.height,
  };
};

const getMobileVideoExportDimensions = (aspectRatio) => {
  const ratio = ASPECT_RATIOS[aspectRatio] || ASPECT_RATIOS["9:16"];
  const scale = Math.min(720 / ratio.width, 1280 / ratio.height, 1);
  return {
    width: Math.max(2, Math.round((ratio.width * scale) / 2) * 2),
    height: Math.max(2, Math.round((ratio.height * scale) / 2) * 2),
  };
};

const dataUrlToBlob = async (dataUrl) => {
  const response = await fetch(dataUrl);
  return response.blob();
};

const canvasElementToBlob = (canvasElement, type = "image/jpeg", quality = 0.85) =>
  new Promise((resolve, reject) => {
    const timer = window.setTimeout(() => {
      reject(new Error("Story frame rendering took too long. Please retry."));
    }, 6_000);

    try {
      canvasElement.toBlob(
        (blob) => {
          window.clearTimeout(timer);
          if (!blob) {
            reject(new Error("Unable to render story frame"));
            return;
          }
          resolve(blob);
        },
        type,
        quality,
      );
    } catch (error) {
      window.clearTimeout(timer);
      reject(error);
    }
  });

const nextFrame = () =>
  new Promise((resolve) => {
    requestAnimationFrame(() => requestAnimationFrame(resolve));
  });

const safeProgress = (onProgress, progress, message) => {
  onProgress?.({
    progress: Math.min(100, Math.max(0, Math.round(progress))),
    message,
  });
};

const flushFilterableObjects = (canvas) => {
  canvas.getObjects().forEach((object) => {
    if (
      isFilterableObject(object) &&
      typeof object.applyFilters === "function"
    ) {
      object.objectCaching = false;
      object.dirty = true;
      if (object.filters?.length || object.__storyFilterSignature) {
        object.applyFilters();
      }
      object.dirty = true;
    }
  });
  canvas.renderAll();
};

export const exportStory = async ({
  canvas,
  aspectRatio = "9:16",
  type = "image/jpeg",
  quality = 0.94,
  fileName = "edited-story.jpg",
} = {}) => {
  if (!canvas) {
    throw new Error("Story canvas is not ready");
  }

  canvas.discardActiveObject();
  flushFilterableObjects(canvas);
  const safety = validateCanvasExportSafety(canvas);
  if (!safety.safe) {
    throw safety.error || new Error("Story contains media that cannot be exported safely");
  }
  await nextFrame();

  const { width, height } = getExportDimensions(aspectRatio);
  const multiplier = Math.max(width / canvas.getWidth(), height / canvas.getHeight());
  const exportType = type === "image/png" ? "png" : "jpeg";
  const dataUrl = canvas.toDataURL({
    format: exportType,
    quality,
    multiplier,
    enableRetinaScaling: true,
    left: 0,
    top: 0,
    width: canvas.getWidth(),
    height: canvas.getHeight(),
  });

  const blob = await dataUrlToBlob(dataUrl);
  const file = new File([blob], fileName, {
    type,
    lastModified: Date.now(),
  });

  return {
    blob,
    file,
    dataUrl,
    width,
    height,
    storyType: "image",
  };
};

export const exportImageStoryWithMusic = async ({
  canvas,
  aspectRatio = "9:16",
  fileName = "story.mp4",
  music,
  onProgress,
} = {}) => {
  if (!canvas) {
    throw new Error("Story canvas is not ready");
  }

  onProgress?.({ progress: 5, message: "Preparing media..." });
  canvas.discardActiveObject();
  flushFilterableObjects(canvas);
  const safety = validateCanvasExportSafety(canvas);
  if (!safety.safe) {
    throw safety.error || new Error("Story contains media that cannot be exported safely");
  }
  await nextFrame();

  onProgress?.({ progress: 25, message: "Rendering story..." });
  const { width, height } = getMobileVideoExportDimensions(aspectRatio);
  const multiplier = Math.max(width / canvas.getWidth(), height / canvas.getHeight());
  let exportCanvas = null;

  try {
    exportCanvas = canvas.toCanvasElement(multiplier, {
      left: 0,
      top: 0,
      width: canvas.getWidth(),
      height: canvas.getHeight(),
      enableRetinaScaling: false,
    });

    try {
      const fastExport = await recordCanvasWithMusic({
        canvasElement: exportCanvas,
        music,
        fileName,
        onProgress,
      });
      const previewUrl = URL.createObjectURL(fastExport.blob);
      return {
        ...fastExport,
        previewUrl,
        width,
        height,
        storyType: "video",
      };
    } catch (fastExportError) {
      if (import.meta.env.DEV) {
        console.debug("[StoryExport]", "fast-music-export-failed", {
          message: fastExportError?.message,
        });
      }
    }

    safeProgress(onProgress, 35, "Preparing video...");
    const frameBlob = await canvasElementToBlob(exportCanvas, "image/jpeg", 0.8);
    const videoExport = await exportImageMusicStoryVideo({
      imageBlob: frameBlob,
      music,
      fileName,
      onProgress,
    });
    const previewUrl = URL.createObjectURL(videoExport.blob);

    return {
      ...videoExport,
      previewUrl,
      width,
      height,
      storyType: "video",
    };
  } finally {
    if (exportCanvas) {
      exportCanvas.width = 0;
      exportCanvas.height = 0;
    }
  }
};

export const downloadExportedStory = ({ blob, fileName = "edited-story.jpg" }) => {
  if (!blob) return;

  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
};

const getSupportedVideoType = () => {
  if (typeof MediaRecorder === "undefined") return "";
  const types = [
    "video/mp4;codecs=h264,aac",
    "video/mp4;codecs=avc1.42E01E,mp4a.40.2",
    "video/mp4",
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm;codecs=vp9",
    "video/webm;codecs=vp8",
    "video/webm",
  ];
  return types.find((type) => MediaRecorder.isTypeSupported(type)) || "";
};

const getFileExtensionForMimeType = (mimeType) =>
  mimeType.includes("mp4") ? "mp4" : "webm";

const replaceFileExtension = (fileName, extension) =>
  fileName?.includes(".")
    ? fileName.replace(/\.[^.]+$/, `.${extension}`)
    : `${fileName || "story"}.${extension}`;

const waitForMediaReady = (media) =>
  new Promise((resolve, reject) => {
    if (!media) {
      resolve();
      return;
    }
    if (media.readyState >= 2) {
      resolve();
      return;
    }

    const cleanup = () => {
      media.removeEventListener("loadeddata", onReady);
      media.removeEventListener("canplay", onReady);
      media.removeEventListener("loadedmetadata", onReady);
      media.removeEventListener("error", onError);
    };
    const onReady = () => {
      cleanup();
      resolve();
    };
    const onError = () => {
      cleanup();
      reject(new Error("Unable to load media for export"));
    };

    media.addEventListener("loadeddata", onReady, { once: true });
    media.addEventListener("canplay", onReady, { once: true });
    media.addEventListener("loadedmetadata", onReady, { once: true });
    media.addEventListener("error", onError, { once: true });
    media.load?.();
  });

const addMusicTrack = async (combinedStream, music) => {
  const audioUrl = normalizeStoryMediaUrl(music?.audio);
  if (!audioUrl) return null;
  if (!isCorsSafeAudioUrl(audioUrl)) return null;

  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextClass) return null;

  const audio = new Audio();
  audio.preload = "auto";
  audio.src = audioUrl;
  audio.loop = false;

  await waitForMediaReady(audio);

  const audioContext = new AudioContextClass();
  const source = audioContext.createMediaElementSource(audio);
  const destination = audioContext.createMediaStreamDestination();
  source.connect(destination);
  destination.stream.getAudioTracks().forEach((track) => combinedStream.addTrack(track));

  return {
    audio,
    audioContext,
    source,
    start: async () => {
      if (audioContext.state === "suspended") {
        await audioContext.resume().catch(() => undefined);
      }
      audio.currentTime = music.startTime ?? 0;
      await audio.play();
    },
    stop: () => {
      audio.pause();
      source.disconnect();
      audioContext.close().catch(() => undefined);
    },
  };
};

const recordCanvasWithMusic = async ({
  canvasElement,
  music,
  fileName,
  onProgress,
}) => {
  if (!canvasElement?.captureStream) {
    throw new Error("Fast story export is not supported in this browser");
  }

  const mimeType = getSupportedVideoType();
  if (!mimeType) {
    throw new Error("Fast story export is not supported in this browser");
  }

  const durationSeconds = Math.max(1, Math.min(30, Number(music?.duration) || 15));
  const canvasStream = canvasElement.captureStream(24);
  const combinedStream = new MediaStream();
  canvasStream.getVideoTracks().forEach((track) => combinedStream.addTrack(track));

  let musicTrack = null;
  let drawTimer = null;
  let stopTimer = null;

  try {
    musicTrack = await addMusicTrack(combinedStream, music);
    if (!musicTrack) {
      throw new Error("Unable to load the selected audio for video export. Please try another track.");
    }

    const chunks = [];
    const mediaRecorder = new MediaRecorder(combinedStream, {
      mimeType,
      videoBitsPerSecond: 900_000,
      audioBitsPerSecond: 96_000,
    });

    const blobPromise = new Promise((resolve, reject) => {
      mediaRecorder.ondataavailable = (event) => {
        if (event.data?.size) chunks.push(event.data);
      };
      mediaRecorder.onerror = () => reject(new Error("Video export failed"));
      mediaRecorder.onstop = () => {
        resolve(new Blob(chunks, { type: mimeType.split(";")[0] || mimeType }));
      };
    });

    const context = canvasElement.getContext("2d");
    const startedAt = performance.now();
    const updateProgress = () => {
      const elapsedSeconds = (performance.now() - startedAt) / 1000;
      safeProgress(onProgress, 45 + (elapsedSeconds / durationSeconds) * 40, "Adding music...");
    };

    mediaRecorder.start(500);
    await musicTrack.start();
    updateProgress();

    drawTimer = window.setInterval(() => {
      context?.drawImage(canvasElement, 0, 0);
      updateProgress();
    }, 250);

    stopTimer = window.setTimeout(() => {
      if (mediaRecorder.state !== "inactive") {
        mediaRecorder.stop();
      }
    }, durationSeconds * 1000);

    const blob = await blobPromise;
    const extension = getFileExtensionForMimeType(blob.type || mimeType);
    const outputFileName = replaceFileExtension(fileName, extension);
    const file = new File([blob], outputFileName, {
      type: blob.type || mimeType.split(";")[0] || "video/webm",
      lastModified: Date.now(),
    });

    return {
      blob,
      file,
      duration: durationSeconds,
      storyType: "video",
      embeddedAudio: true,
      exportEngine: "mediarecorder",
    };
  } finally {
    if (stopTimer) window.clearTimeout(stopTimer);
    if (drawTimer) window.clearInterval(drawTimer);
    musicTrack?.stop();
    combinedStream.getTracks().forEach((track) => track.stop());
    canvasStream.getTracks().forEach((track) => track.stop());
  }
};

export async function exportStoryVideo({
  canvas,
  engine = null,
  video,
  aspectRatio = "9:16",
  fileName = "story.webm",
  music = null,
}) {
  if (!canvas) {
    throw new Error("Story canvas is not ready");
  }
  const { width, height } = getExportDimensions(aspectRatio);
  const compositeCanvas = document.createElement("canvas");
  compositeCanvas.width = width;
  compositeCanvas.height = height;
  const captureCanvas = engine?.renderVideoCompositeFrame ? compositeCanvas : canvas.getElement();

  if (!captureCanvas.captureStream) {
    throw new Error("Video export is not supported in this browser");
  }

  const mimeType = getSupportedVideoType();
  if (!mimeType) {
    throw new Error("MediaRecorder does not support WebM export in this browser");
  }

  canvas.discardActiveObject();
  flushFilterableObjects(canvas);
  const safety = validateCanvasExportSafety(canvas);
  if (!safety.safe) {
    throw safety.error || new Error("Story contains media that cannot be exported safely");
  }
  await waitForMediaReady(video);

  const previousVideoState = video
    ? {
        currentTime: video.currentTime,
        paused: video.paused,
        loop: video.loop,
      }
    : null;

  if (video) {
    video.loop = true;
    video.currentTime = 0;
    await video.play().catch(() => undefined);
  }

  engine?.renderVideoCompositeFrame?.(compositeCanvas);
  const canvasStream = captureCanvas.captureStream(30);
  const combinedStream = new MediaStream();
  canvasStream.getVideoTracks().forEach((track) => combinedStream.addTrack(track));

  let musicTrack = null;
  try {
    musicTrack = await addMusicTrack(combinedStream, music);
  } catch {
    musicTrack = null;
  }
  const chunks = [];
  const mediaRecorder = new MediaRecorder(combinedStream, { mimeType });
  let renderInterval = null;
  let stopTimer = null;

  const blobPromise = new Promise((resolve, reject) => {
    mediaRecorder.ondataavailable = (event) => {
      if (event.data?.size) chunks.push(event.data);
    };
    mediaRecorder.onerror = () => reject(new Error("Video export failed"));
    mediaRecorder.onstop = () => resolve(new Blob(chunks, { type: mimeType.split(";")[0] || mimeType }));
  });

  const videoDuration = Number.isFinite(video?.duration) && video.duration > 0 ? video.duration : 5;
  const durationSeconds = music?.duration ? Math.max(1, music.duration) : videoDuration;

  let blob;
  try {
    renderInterval = window.setInterval(() => {
      if (engine?.renderVideoCompositeFrame) {
        engine.renderVideoCompositeFrame(compositeCanvas);
      } else {
        flushFilterableObjects(canvas);
      }
    }, 1000 / 30);

    mediaRecorder.start(250);
    await musicTrack?.start();

    stopTimer = window.setTimeout(() => {
      if (mediaRecorder.state !== "inactive") {
        mediaRecorder.stop();
      }
    }, durationSeconds * 1000);

    blob = await blobPromise;
  } finally {
    if (stopTimer) window.clearTimeout(stopTimer);
    if (renderInterval) window.clearInterval(renderInterval);
    musicTrack?.stop();
    combinedStream.getTracks().forEach((track) => track.stop());
    canvasStream.getTracks().forEach((track) => track.stop());

    if (video && previousVideoState) {
      video.loop = previousVideoState.loop;
      video.currentTime = previousVideoState.currentTime;
      if (previousVideoState.paused) {
        video.pause();
      } else {
        video.play().catch(() => undefined);
      }
    }
  }

  if (engine?.renderVideoCompositeFrame) {
    engine.renderVideoCompositeFrame(compositeCanvas);
  } else {
    flushFilterableObjects(canvas);
  }
  let dataUrl = "";
  try {
    dataUrl = captureCanvas.toDataURL?.("image/jpeg", 0.82) || canvas.toDataURL({
      format: "jpeg",
      quality: 0.82,
      multiplier: 1,
      enableRetinaScaling: true,
    });
  } catch (error) {
    console.error("[StoryEditor] Video preview export failed", error);
  }
  const extension = getFileExtensionForMimeType(blob.type || mimeType);
  const outputFileName = replaceFileExtension(fileName, extension);
  const file = new File([blob], outputFileName, {
    type: blob.type || mimeType.split(";")[0] || "video/webm",
    lastModified: Date.now(),
  });
  compositeCanvas.width = 0;
  compositeCanvas.height = 0;

  return {
    blob,
    file,
    dataUrl,
    width,
    height,
    storyType: "video",
  };
}
