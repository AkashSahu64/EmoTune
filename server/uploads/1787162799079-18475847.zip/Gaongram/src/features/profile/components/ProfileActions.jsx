import React from "react";
import { Flag, PencilLine, UserMinus } from "lucide-react";
import { LuMessageSquareMore } from "react-icons/lu";
import { PiShareFatLight } from "react-icons/pi";
import Button from "../../../components/common/Button";
import KebabMenu from "../../../components/common/KebabMenu";

const ProfileActions = ({
  isOwnProfile,
  followButtonState,
  isFollowLoading,
  isMessageDisabled,
  onToggleFollow,
  onMessage,
  onShare,
  onEditProfile,
  onReport,
  isBlocked,
  onToggleBlock,
}) => {
  if (isBlocked) {
    return null;
  }

  const isFollowing = followButtonState?.label === "Following";
  const isRequested = followButtonState?.label === "Requested";
  const followVariant = isFollowing || isRequested ? "outline" : "primary";

  if (isOwnProfile) {
    return (
      <div className="flex items-center justify-end gap-2">
        <Button
          onClick={onEditProfile}
          size="small"
          variant="primary"
          className="flex h-9 w-9 items-center justify-center p-0 sm:w-auto sm:px-3"
        >
          <PencilLine size={18} />
          <span className="ml-2 hidden sm:inline">Edit</span>
        </Button>

        <Button
          onClick={onShare}
          size="small"
          variant="outline"
          className="flex h-9 w-9 items-center justify-center p-0 sm:w-auto sm:px-3"
        >
          <PiShareFatLight size={18} />
          <span className="ml-2 hidden sm:inline">Share</span>
        </Button>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-end gap-2">
      <Button
        onClick={onToggleFollow}
        loading={isFollowLoading}
        disabled={followButtonState?.disabled || isFollowLoading}
        size="small"
        variant={followVariant}
        className="h-9 rounded-full px-2 sm:px-3"
      >
        <span className="sm:hidden">
          {isFollowing ? "Following" : isRequested ? "Requested" : "Follow"}
        </span>
        <span className="hidden sm:inline">
          {followButtonState?.label || "Follow"}
        </span>
      </Button>

      <Button
        onClick={onMessage}
        disabled={isMessageDisabled}
        size="small"
        variant="outline"
        className="flex h-9 w-9 items-center justify-center p-0 sm:w-auto sm:px-3"
      >
        <LuMessageSquareMore size={18} />
        <span className="ml-2 hidden sm:inline">Message</span>
      </Button>

      <Button
        onClick={onShare}
        size="small"
        variant="outline"
        className="flex h-9 w-9 items-center justify-center p-0 sm:w-auto sm:px-3"
      >
        <PiShareFatLight size={18} />
        <span className="ml-2 hidden sm:inline">Share</span>
      </Button>

      <KebabMenu
        items={[
          {
            label: "Report User",
            icon: Flag,
            onClick: onReport,
          },
          {
            label: "Block User",
            icon: UserMinus,
            onClick: onToggleBlock,
            danger: true,
          },
        ]}
      />
    </div>
  );
};

export default React.memo(ProfileActions);
