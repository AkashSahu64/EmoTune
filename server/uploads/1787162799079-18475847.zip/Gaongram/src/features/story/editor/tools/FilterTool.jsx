// FilterTool.jsx
import React, { useEffect, useMemo, useState } from "react";
import { Layers, RotateCcw, SlidersHorizontal, Wand2 } from "lucide-react";
import { selectActiveLayer, useCanvasStore } from "../useCanvasStore.js";
import {
  clampFilterValue,
  DEFAULT_FILTERS,
  FILTER_PRESETS,
} from "../utils/filterPresets.js";
import { getSliderBackground } from "../engine/helpers/math.js";

const FILTER_CONTROLS = [
  { key: "brightness", label: "Brightness", min: -1, max: 1, step: 0.01 },
  { key: "contrast", label: "Contrast", min: -1, max: 1, step: 0.01 },
  { key: "saturation", label: "Saturation", min: -1, max: 1, step: 0.01 },
  { key: "blur", label: "Blur", min: 0, max: 1, step: 0.01 },
  { key: "sepia", label: "Sepia", min: 0, max: 1, step: 0.01 },
  { key: "grayscale", label: "Grayscale", min: 0, max: 1, step: 0.01 },
  { key: "vintage", label: "Vintage", min: 0, max: 1, step: 0.01 },
  { key: "warm", label: "Warm", min: 0, max: 1, step: 0.01 },
  { key: "cool", label: "Cool", min: 0, max: 1, step: 0.01 },
  { key: "cinematic", label: "Cinematic", min: 0, max: 1, step: 0.01 },
  { key: "vignette", label: "Vignette", min: 0, max: 0.8, step: 0.01 },
];

const filtersEqual = (a, b) =>
  FILTER_CONTROLS.every(
    (control) =>
      Number(a?.[control.key] || 0) === Number(b?.[control.key] || 0),
  );

const FilterTool = ({ engine }) => {
  const activeLayer = useCanvasStore(selectActiveLayer);
  const globalFilters = useCanvasStore((state) => state.filters);
  const setGlobalFilters = useCanvasStore((state) => state.setGlobalFilters);
  const setLayerFilters = useCanvasStore((state) => state.setLayerFilters);
  const resetGlobalFilters = useCanvasStore(
    (state) => state.resetGlobalFilters,
  );
  const [scope, setScope] = useState("global");

  const canFilterActiveLayer = activeLayer?.type === "base";

  useEffect(() => {
    if (scope === "layer" && !canFilterActiveLayer) {
      setScope("global");
    }
  }, [canFilterActiveLayer, scope]);

  const currentFilters = useMemo(() => {
    if (scope === "layer" && canFilterActiveLayer) {
      return { ...DEFAULT_FILTERS, ...(activeLayer.filters || {}) };
    }
    return { ...DEFAULT_FILTERS, ...globalFilters };
  }, [activeLayer, canFilterActiveLayer, globalFilters, scope]);

  const [draftFilters, setDraftFilters] = useState(currentFilters);

  useEffect(() => {
    setDraftFilters(currentFilters);
  }, [currentFilters]);

  useEffect(() => {
    if (filtersEqual(draftFilters, currentFilters)) return undefined;
    const timeoutId = window.setTimeout(() => {
      if (scope === "layer" && canFilterActiveLayer) {
        setLayerFilters(activeLayer.id, draftFilters, { recordHistory: false });
      } else {
        setGlobalFilters(draftFilters, { recordHistory: false });
      }
    }, 16);

    return () => window.clearTimeout(timeoutId);
  }, [
    activeLayer,
    canFilterActiveLayer,
    currentFilters,
    draftFilters,
    scope,
    setGlobalFilters,
    setLayerFilters,
  ]);

  const applyFilters = (filters, recordHistory = true) => {
    if (scope === "layer" && canFilterActiveLayer) {
      setLayerFilters(activeLayer.id, filters, { recordHistory });
      return;
    }
    setGlobalFilters(filters, { recordHistory });
  };

  const handleSliderChange = (key, value) => {
    const newValue = clampFilterValue(key, value);
    const nextFilters = {
      ...draftFilters,
      [key]: newValue,
    };

    setDraftFilters(nextFilters);
    engine?.applyTransientFilters({
      scope,
      layerId: activeLayer?.id,
      filters: nextFilters,
    });
  };

  const handleCommit = () => applyFilters(draftFilters, true);

  const handleReset = () => {
    setDraftFilters({ ...DEFAULT_FILTERS });
    if (scope === "layer" && canFilterActiveLayer) {
      setLayerFilters(activeLayer.id, { ...DEFAULT_FILTERS });
      return;
    }
    resetGlobalFilters();
  };

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-2 gap-2 rounded-lg border border-border dark:border-border-dark bg-card dark:bg-card-dark p-1">
        <button
          type="button"
          onClick={() => setScope("global")}
          className={`flex h-10 items-center justify-center gap-2 rounded-lg text-sm font-semibold transition ${
            scope === "global"
              ? "bg-primary text-white"
              : "text-foreground dark:text-foreground-dark hover:bg-gray-100 dark:hover:bg-muted-dark"
          }`}
        >
          <Wand2 size={16} />
          Global
        </button>
        <button
          type="button"
          onClick={() => setScope("layer")}
          disabled={!canFilterActiveLayer}
          className={`flex h-10 items-center justify-center gap-2 rounded-lg text-sm font-semibold transition disabled:opacity-35 ${
            scope === "layer"
              ? "bg-primary text-white"
              : "text-foreground dark:text-foreground-dark hover:bg-muted dark:hover:bg-muted-dark"
          }`}
        >
          <Layers size={16} />
          Layer
        </button>
      </div>

      <div className="grid grid-cols-3 gap-2">
        {FILTER_PRESETS.map((preset) => (
          <button
            type="button"
            key={preset.id}
            onClick={() => {
              setDraftFilters(preset.values);
              engine?.applyTransientFilters({
                scope,
                layerId: activeLayer?.id,
                filters: preset.values,
              });
              applyFilters(preset.values, true);
            }}
            className="rounded-lg border border-border dark:border-border-dark bg-gray-100 dark:bg-muted-dark px-3 py-1 text-left transition hover:bg-background dark:hover:bg-background-dark"
          >
            <span className="block text-sm font-semibold text-foreground dark:text-foreground-dark">
              {preset.label}
            </span>
            <span className="block text-xs text-mutedForeground dark:text-mutedForeground-dark">
              Preset
            </span>
          </button>
        ))}
      </div>

      <div className="rounded-lg border border-border dark:border-border-dark bg-card dark:bg-card-dark px-3 py-2">
        <div className="flex items-center justify-between">
          <p className="flex items-center gap-2 text-sm font-semibold text-foreground dark:text-foreground-dark">
            <SlidersHorizontal size={16} />
            Adjust
          </p>
          <button
            type="button"
            onClick={handleReset}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-gray-100 dark:bg-muted-dark text-foreground dark:text-foreground-dark transition hover:bg-border dark:hover:bg-border-dark"
            aria-label="Reset filters"
            title="Reset"
          >
            <RotateCcw size={18} />
          </button>
        </div>

        <div className="mt-2 space-y-1">
          {FILTER_CONTROLS.map((control) => (
            <label key={control.key} className="block">
              <span className="flex items-center justify-between text-xs font-medium text-mutedForeground dark:text-mutedForeground-dark -mb-2">
                <span>{control.label}</span>
                <span>{Number(draftFilters[control.key] || 0).toFixed(2)}</span>
              </span>
              <input
                type="range"
                min={control.min}
                max={control.max}
                step={control.step}
                value={draftFilters[control.key] || 0}
                onChange={(e) =>
                  handleSliderChange(control.key, e.target.value)
                }
                onPointerUp={handleCommit}
                className="custom-range w-full"
                style={{
                  background: getSliderBackground(
                    draftFilters[control.key] || 0,
                    control.min,
                    control.max,
                  ),
                }}
              />
            </label>
          ))}
        </div>
      </div>
    </div>
  );
};

export default React.memo(FilterTool);
