// src/features/blogs/components/BlogCard.jsx
import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { formatDistanceToNow } from "date-fns";
import Avatar from "../../../../../components/common/Avatar";
import Button from "../../../../../components/common/Button";
import BlogActions from "./BlogActions";
import { canEditBlog, canDeleteBlog } from "../../../../../utils/blogPermissions";

const BlogCard = ({ blog, onDelete, isDeleting }) => {
  const {
    id,
    title,
    meta_description,
    image,
    image_alt_text,
    author,
    category,
    created_at,
    is_published,
    is_featured,
    views,
  } = blog;

  const authorName = author?.username || author?.email || `User ${author}`;
  const isOwner = canEditBlog(blog);

  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className="group relative bg-card dark:bg-card-dark rounded-xl2 overflow-hidden shadow-soft hover:shadow-premium transition-all duration-300 border border-border dark:border-border-dark"
    >
      {/* Featured Badge */}
      {is_featured && (
        <div className="absolute top-3 left-3 z-10">
          <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium bg-accent text-white shadow-glow">
            ★ Featured
          </span>
        </div>
      )}

      {/* Image */}
      <Link
        to={`/blogs/${id}`}
        className="block aspect-[16/9] overflow-hidden bg-muted dark:bg-muted-dark"
      >
        {image ? (
          <img
            src={image}
            alt={image_alt_text || title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
            onError={(e) => {
              e.target.src =
                "https://via.placeholder.com/800x450?text=No+Image";
            }}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/10 to-viral-pink/10">
            <span className="text-4xl">📝</span>
          </div>
        )}
      </Link>

      {/* Content */}
      <div className="p-5">
        <div className="flex items-center gap-2 mb-3">
          <Avatar src={author?.avatar} size="sm" alt={authorName} />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-foreground dark:text-foreground-dark truncate">
              {authorName}
            </p>
            <div className="flex items-center gap-2 text-xs text-mutedForeground dark:text-mutedForeground-dark">
              <span>
                {formatDistanceToNow(new Date(created_at), { addSuffix: true })}
              </span>
              <span>•</span>
              <span>{views} views</span>
            </div>
          </div>
          <span
            className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
              is_published
                ? "bg-success/10 text-success"
                : "bg-warning/10 text-warning"
            }`}
          >
            {is_published ? "Published" : "Draft"}
          </span>
        </div>

        <Link to={`/blogs/${id}`}>
          <h3 className="text-lg font-semibold text-foreground dark:text-foreground-dark mb-2 line-clamp-2 group-hover:text-primary transition-colors">
            {title}
          </h3>
        </Link>

        {meta_description && (
          <p className="text-sm text-mutedForeground dark:text-mutedForeground-dark mb-4 line-clamp-2">
            {meta_description}
          </p>
        )}

        <div className="flex items-center justify-between">
          <span className="text-xs px-2 py-1 rounded-full bg-muted dark:bg-muted-dark text-foreground dark:text-foreground-dark">
            {category?.name || "Uncategorized"}
          </span>

          {/* Only show actions to owner */}
          {isOwner && (
            <BlogActions
              blogId={id}
              blog={blog}
              onDelete={onDelete}
              isDeleting={isDeleting}
            />
          )}
        </div>
      </div>
    </motion.article>
  );
};

export default BlogCard;
