import React from 'react';
import { motion } from 'framer-motion';
import { Camera, Video, FileText, Music, Grid, Clapperboard } from 'lucide-react';

const FeedHeader = ({ activeTab, onTabChange, user }) => {
  const tabs = [
    { id: 'feed', label: 'Feed', icon: Grid },
    { id: 'reels', label: 'Reels', icon: Clapperboard },
    { id: 'videos', label: 'Videos', icon: Video },
    { id: 'photos', label: 'Photos', icon: Camera },
    { id: 'audio', label: 'Audio', icon: Music },
    { id: 'blogs', label: 'Blogs', icon: FileText },
  ];

  return (
    <div className="bg-card dark:bg-card-dark border-b border-border dark:border-border-dark">
      <div className="max-w-4xl mx-auto">
        {/* User Info for Profile */}
        {user && (
          <div className="px-4 py-6">
            <div className="flex items-center space-x-6">
              <div className="w-24 h-24 rounded-full bg-gradient-to-r from-viral-purple to-viral-pink flex items-center justify-center text-white text-4xl font-bold">
                {user.username?.charAt(0)?.toUpperCase()}
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-light text-foreground dark:text-foreground-dark">{user.username}</h2>
                <div className="flex items-center space-x-6 mt-4">
                  <div className="text-center">
                    <p className="font-bold text-foreground dark:text-foreground-dark">{user.posts_count || 0}</p>
                    <p className="text-sm text-mutedForeground dark:text-mutedForeground-dark">Posts</p>
                  </div>
                  <div className="text-center">
                    <p className="font-bold text-foreground dark:text-foreground-dark">{user.followers_count || 0}</p>
                    <p className="text-sm text-mutedForeground dark:text-mutedForeground-dark">Followers</p>
                  </div>
                  <div className="text-center">
                    <p className="font-bold text-foreground dark:text-foreground-dark">{user.following_count || 0}</p>
                    <p className="text-sm text-mutedForeground dark:text-mutedForeground-dark">Following</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tabs Navigation */}
        <div className="px-4">
          <div className="flex overflow-x-auto no-scrollbar">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;

              return (
                <button
                  key={tab.id}
                  onClick={() => onTabChange(tab.id)}
                  className={`flex items-center space-x-2 px-4 py-3 border-b-2 transition-colors ${
                    isActive
                      ? 'border-primary text-primary'
                      : 'border-transparent text-mutedForeground dark:text-mutedForeground-dark hover:text-foreground dark:hover:text-foreground-dark'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-sm font-medium whitespace-nowrap">
                    {tab.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Create Post Button */}
        <div className="px-4 py-3 border-t border-border dark:border-border-dark">
          <div className="flex items-center space-x-4">
            <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center">
              <span className="text-lg font-semibold">
                {user?.username?.charAt(0)?.toUpperCase() || 'U'}
              </span>
            </div>
            <div className="flex-1">
              <button className="w-full text-left px-4 py-2 bg-muted dark:bg-muted-dark rounded-full text-mutedForeground dark:text-mutedForeground-dark hover:bg-muted/80 dark:hover:bg-muted-dark/80">
                What's on your mind?
              </button>
            </div>
            <button className="p-2 text-primary hover:bg-primary/10 rounded-full">
              <Camera className="w-6 h-6" />
            </button>
            <button className="p-2 text-primary hover:bg-primary/10 rounded-full">
              <Video className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeedHeader;