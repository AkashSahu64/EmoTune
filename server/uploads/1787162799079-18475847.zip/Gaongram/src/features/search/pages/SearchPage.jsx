import React, {
  useState,
  useEffect,
  useMemo,
} from "react";

import {
  motion,
} from "framer-motion";
import {
  useSearchParams,
  useNavigate,
} from "react-router-dom";

import {
  useSearchHistory,
} from "../../../hooks/useSearchHistory";

import {
  useDebounce,
} from "../../../hooks/useDebounce";

import SearchTabs from "../components/SearchTabs";

import SearchHistory from "../components/SearchHistory";

import AccountsTab from "../components/AccountsTab";

import PostsTab from "../components/PostsTab";

import HashtagsTab from "../components/HashtagsTab";

const SearchPage = () => {
  const [searchParams] =
    useSearchParams();

  // ✅ Search state
  const [searchTerm, setSearchTerm] =
    useState(
      searchParams.get("q") || ""
    );

  // ✅ Active tab
  const [activeTab, setActiveTab] =
    useState("hashtags");

  // ✅ Stable debounce
  const debouncedSearch =
    useDebounce(searchTerm, 300);

  // ✅ Normalized search
  const normalizedSearch =
    useMemo(
      () =>
        debouncedSearch.trim(),
      [debouncedSearch]
    );

  // ✅ Search history
  const {
    history,
    removeFromHistory,
    clearHistory,
  } = useSearchHistory();

  // ✅ Sync URL query safely
  useEffect(() => {
    const query =
      searchParams.get("q") || "";

    setSearchTerm(query);
  }, [searchParams]);

  // ✅ Recent profile select
  const navigate = useNavigate();

const handleSelectHistory = (
  user
) => {

  navigate(
    `/profile/${user.user_id}`
  );
};

  // ✅ Force fresh render on tab/search change
  const renderKey = `${activeTab}-${normalizedSearch}`;

  return (
    <div
      className="
        min-h-screen
        bg-background
        dark:bg-background-dark
      "
    >
      {/* HEADER */}

      <div
        className="
          sticky top-0 z-30
          bg-card
          dark:bg-card-dark
          border-b
          border-border
          dark:border-border-dark
        "
      >
        <div className="max-w-7xl mx-auto">
          <SearchTabs
            activeTab={activeTab}
            onTabChange={
              setActiveTab
            }
          />
        </div>
      </div>

      {/* CONTENT */}

      <div
        className="
          max-w-7xl
          mx-auto
          px-4
          py-4
        "
      >
        {/* ✅ ACCOUNTS EMPTY STATE */}

        {!normalizedSearch &&
        activeTab ===
          "accounts" ? (
          <div
            key="accounts-history"
            className="space-y-6"
          >
            {/* HISTORY */}

            {history.length >
              0 && (
              <SearchHistory
                history={history}
                onSelect={
                  handleSelectHistory
                }
                onRemove={
                  removeFromHistory
                }
                onClear={
                  clearHistory
                }
              />
            )}

            {/* SUGGESTED */}

            <div className="space-y-3">
              <h2
                className="
                  text-sm
                  font-semibold
                  text-foreground
                  dark:text-foreground-dark
                "
              >
                Suggested Profiles
              </h2>

              <AccountsTab
                key="suggested-accounts"
                searchTerm=""
              />
            </div>
          </div>
        ) : (
          // ✅ RESULTS
          <motion.div
            key={renderKey}
            initial={{
              opacity: 0,
            }}
            animate={{
              opacity: 1,
            }}
            transition={{
              duration: 0.15,
            }}
          >
            {/* ACCOUNTS */}

            {activeTab ===
              "accounts" && (
              <AccountsTab
                key={`accounts-${normalizedSearch}`}
                searchTerm={
                  normalizedSearch
                }
              />
            )}

            {/* POSTS */}

            {activeTab ===
              "posts" && (
              <PostsTab
                key={`posts-${normalizedSearch}`}
                searchTerm={
                  normalizedSearch
                }
              />
            )}

            {/* HASHTAGS */}

            {activeTab ===
              "hashtags" && (
              <HashtagsTab
                key={`hashtags-${normalizedSearch}`}
                searchTerm={
                  normalizedSearch
                }
              />
            )}
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default React.memo(
  SearchPage
);