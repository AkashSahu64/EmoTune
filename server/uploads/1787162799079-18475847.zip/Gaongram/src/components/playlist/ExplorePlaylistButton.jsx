import React from 'react';
import { ListMusic } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const ExplorePlaylistButton = ({ className = '' }) => {
  const navigate = useNavigate();

  return (
    <button
      onClick={() => navigate('/playlists')}
      className={`absolute top-4 left-4 p-1.5 bg-black/50 text-white rounded-full backdrop-blur-sm hover:bg-black/70 transition-colors z-10 ${className}`}
      aria-label="Explore playlists"
    >
      <ListMusic className="w-5 h-5" />
    </button>
  );
};

export default React.memo(ExplorePlaylistButton);