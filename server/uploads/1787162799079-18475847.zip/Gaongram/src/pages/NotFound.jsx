// src/pages/NotFound.jsx
import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Search } from "lucide-react";
import Seo from "../components/seo/Seo";
import error from "../assets/Error.mp4";
import { IoHome } from "react-icons/io5";

const NotFound = () => {
  const handleSearch = () => {
    const currentUrl = window.location.href;
    const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(currentUrl)}`;
    window.open(searchUrl, "_blank");
  };
  return (
    <>
      <Seo
        title="404 - Page Not Found"
        description="Oops! The page you're looking for doesn't exist."
        noindex
      />

      <div className="relative min-h-screen flex items-center justify-center bg-gray-200 overflow-hidden px-6">
        {/* 🔥 Background Glow */}
        <div className="absolute w-[400px] h-[400px] bg-blue-500/20 blur-[120px] rounded-full top-[-100px] left-[-100px]" />
        <div className="absolute w-[400px] h-[400px] bg-purple-500/20 blur-[120px] rounded-full bottom-[-100px] right-[-100px]" />

        {/* MAIN CONTENT */}
        <div className="relative z-10 text-center max-w-2xl w-full lg:-mt-12">
          {/* 404 BIG */}
          <motion.h1
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            className="text-[100px] md:text-[140px] font-extrabold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent drop-shadow-[0_0_40px_rgba(99,102,241,0.5)] mb-8"
          >
            404
          </motion.h1>

          {/* VIDEO CARD */}
          <motion.div className="mx-auto mt-[-30px] mb-6 w-[220px] md:w-[260px] p-3">
            <motion.video
              autoPlay
              loop
              muted
              playsInline
              src={error}
              className="w-full h-auto object-contain"
              style={{
                WebkitMaskImage:
                  "radial-gradient(circle, rgba(0,0,0,1) 60%, rgba(0,0,0,0) 100%)",
                maskImage:
                  "radial-gradient(circle, rgba(0,0,0,1) 60%, rgba(0,0,0,0) 100%)",
              }}
            />
          </motion.div>

          {/* TEXT */}
          <h2 className="text-2xl md:text-3xl font-semibold">
            Oops! Page not found
          </h2>

          <p className="mt-3 text-gray-600">
            The page you’re looking for doesn’t exist or has been moved.
          </p>

          {/* BUTTONS */}
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Link
              to="/"
              className="group flex items-center px-6 py-3 rounded-full bg-white text-black font-medium transition-all hover:scale-105 hover:shadow-xl"
            >
              <IoHome className="mr-2 h-4 w-4 group-hover:rotate-12 transition-transform" />
              Back to Home
            </Link>

            <button
              onClick={handleSearch}
              className="group flex items-center px-6 py-3 font-semibold rounded-full border border-gray-500/30 text-gray-800 backdrop-blur-md transition-all hover:bg-white/10"
            >
              <Search className="mr-2 h-4 w-4 group-hover:scale-110 transition-transform" />
              Search Site
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default NotFound;
