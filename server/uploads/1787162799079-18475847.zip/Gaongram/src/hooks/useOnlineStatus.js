// src/hooks/useOnlineStatus.js
import { useEffect } from 'react';
import { useChatStore } from '../store/chatStore';

export const useOnlineStatus = (userId) => {
  const { onlineUsers, setOnline } = useChatStore();
  
  useEffect(() => {
    // Polling for online status - can be improved with real endpoint
    // For now, we'll simulate based on last activity from messages
    const interval = setInterval(() => {
      // This would be replaced with actual API call
      // For demo, keep as is
    }, 30000);
    
    return () => clearInterval(interval);
  }, [userId]);
  
  return {
    isOnline: onlineUsers.has(userId),
  };
};