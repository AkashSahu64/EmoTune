// hooks/useMediaProgress.js
/**
 * Hook for managing media progress state and interactions
 */
import { useState, useCallback, useEffect } from 'react';

export const useMediaProgress = (initialState = { current: 0, duration: 0 }) => {
  const [progress, setProgress] = useState(initialState);
  const [isSeeking, setIsSeeking] = useState(false);
  
  const handleProgressClick = useCallback((event, duration) => {
    if (!duration) return;
    
    const progressBar = event.currentTarget;
    const rect = progressBar.getBoundingClientRect();
    const clickPosition = (event.clientX - rect.left) / rect.width;
    const newTime = Math.max(0, Math.min(duration, clickPosition * duration));
    
    setProgress(prev => ({ ...prev, current: newTime }));
    setIsSeeking(true);
    
    return newTime;
  }, []);
  
  const updateProgress = useCallback((current, duration) => {
    if (!isSeeking) {
      setProgress({ current, duration });
    }
  }, [isSeeking]);
  
  const endSeeking = useCallback(() => {
    setIsSeeking(false);
  }, []);
  
  const skipForward = useCallback((seconds = 5) => {
    const newTime = Math.min(
      progress.duration,
      progress.current + seconds
    );
    setProgress(prev => ({ ...prev, current: newTime }));
    return newTime;
  }, [progress]);
  
  const skipBackward = useCallback((seconds = 5) => {
    const newTime = Math.max(0, progress.current - seconds);
    setProgress(prev => ({ ...prev, current: newTime }));
    return newTime;
  }, [progress]);
  
  return {
    progress,
    isSeeking,
    handleProgressClick,
    updateProgress,
    endSeeking,
    skipForward,
    skipBackward,
    progressPercentage: progress.duration > 0 
      ? (progress.current / progress.duration) * 100 
      : 0,
    formatTime: (seconds) => {
      if (!seconds || isNaN(seconds)) return '0:00';
      const minutes = Math.floor(seconds / 60);
      const secs = Math.floor(seconds % 60);
      return `${minutes}:${secs.toString().padStart(2, '0')}`;
    }
  };
};