import React, { useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Loader2, AlertCircle, CheckCircle } from 'lucide-react';
import { useAuthStore } from '../../../store/authStore.js';
import { showError, showSuccess } from '../../../utils/toast.js';
import Seo from '../../../components/seo/Seo.jsx';
import { buildStaticPageSeo } from '../../../seo/seoBuilders.js';

const GoogleAuth = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { googleAuth } = useAuthStore();
  
  useEffect(() => {
    const handleGoogleAuth = async () => {
      const token = searchParams.get('token');
      
      if (!token) {
        showError('Authentication token is missing');
        // Redirect to login after a short delay
        setTimeout(() => navigate('/login', { replace: true }), 2000);
        return;
      }
      
      try {
        const result = await googleAuth(token);
        
        if (result.success) {
          showSuccess('Logged in successfully!');
          // Redirect to home
          setTimeout(() => {
            navigate('/', { replace: true });
          }, 1500);
        } else {
          showError(result.error || 'Authentication failed');
          setTimeout(() => navigate('/login', { replace: true }), 2000);
        }
      } catch (error) {
        showError('Google authentication failed');
        setTimeout(() => navigate('/login', { replace: true }), 2000);
      }
    };
    
    handleGoogleAuth();
  }, [searchParams, googleAuth, navigate]);
  
  const handleRetry = () => {
    window.location.href = `${process.env.REACT_APP_API_URL || '/api/v1'}/auth/google/`;
  };
  
  const handleManualLogin = () => {
    navigate('/login', { replace: true });
  };
  
  return (
    <>
      <Seo {...buildStaticPageSeo('googleAuth')} />
      
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-md"
        >
          <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
            {/* Status Icon */}
            <div className="mb-6 flex justify-center">
              {!searchParams.get('token') ? (
                <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center">
                  <AlertCircle className="w-8 h-8 text-red-600" />
                </div>
              ) : (
                <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center">
                  <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
                </div>
              )}
            </div>
            
            <h2 className="text-2xl font-bold text-gray-900 mb-3">
              {!searchParams.get('token') ? 'Missing Token' : 'Authenticating...'}
            </h2>
            
            <p className="text-gray-600 mb-8">
              {!searchParams.get('token')
                ? 'No authentication token received. Redirecting...'
                : 'Please wait while we complete your sign-in.'}
            </p>
            
            {/* Actions */}
            {!searchParams.get('token') && (
              <div className="space-y-4">
                <button
                  onClick={handleRetry}
                  className="w-full py-3 px-4 bg-instagram-pink text-white font-medium rounded-lg hover:bg-pink-600 transition-colors"
                >
                  Try Again
                </button>
                <button
                  onClick={handleManualLogin}
                  className="w-full py-3 px-4 border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Use Email Instead
                </button>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default GoogleAuth;
