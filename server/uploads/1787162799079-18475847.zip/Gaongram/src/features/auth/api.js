import api from '../../../config/axios.js';

export const authAPI = {
  // Register user
  register: async (userData) => {
    const response = await api.post('/register/', userData);
    return response.data;
  },

  // Verify OTP
  verifyOtp: async (otpData) => {
    const response = await api.post('/verify-otp/', otpData);
    return response.data;
  },

  // Login
  login: async (credentials) => {
    const response = await api.post('/login/', credentials);
    return response.data;
  },

  // Google Auth
  googleAuth: async (token) => {
    const response = await api.post('/auth/google/', { token });
    return response.data;
  },

  // Logout
  logout: async () => {
    const response = await api.post('/logout/');
    return response.data;
  },

  // Logout all devices
  logoutAll: async () => {
    const response = await api.post('/logout-all/');
    return response.data;
  },

  // Verify token
  verifyToken: async (token) => {
    const response = await api.post('/token/verify/', { token });
    return response.data;
  },

  // Refresh token
  refreshToken: async (refreshToken) => {
    const response = await api.post('/token/refresh/', { refresh: refreshToken });
    return response.data;
  },

  // Forgot password
  forgotPassword: async (email) => {
    const response = await api.post('/password/reset/', { email });
    return response.data;
  },

  // Reset password
  resetPassword: async (data) => {
    const response = await api.post('/password/reset/confirm/', data);
    return response.data;
  },

  // Change password
  changePassword: async (data) => {
    const response = await api.post('/password/change/', data);
    return response.data;
  },

  // Get user profile
  getProfile: async () => {
    const response = await api.get('/users/me/');
    return response.data;
  },

  // Update user profile
  updateProfile: async (profileData) => {
    const response = await api.put('/users/me/', profileData);
    return response.data;
  },

  // Upload profile picture
  uploadAvatar: async (formData) => {
    const response = await api.post('/users/me/avatar/', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },

  // Delete account
  deleteAccount: async () => {
    const response = await api.delete('/users/me/');
    return response.data;
  },

  // Check username availability
  checkUsername: async (username) => {
    const response = await api.get(`/users/check-username/?username=${username}`);
    return response.data;
  },

  // Check email availability
  checkEmail: async (email) => {
    const response = await api.get(`/users/check-email/?email=${email}`);
    return response.data;
  },
};