// src/utils/getCurrentUser.js
import { TOKEN_KEYS } from "../config/env";

/**
 * Retrieves and parses the current logged-in user from localStorage.
 * @returns {Object|null} User object or null if not found/invalid.
 */
export const getCurrentUser = () => {
  try {
    if (typeof localStorage === "undefined") return null;

    const userData = localStorage.getItem(TOKEN_KEYS.USER_DATA);
    if (!userData) return null;
    return JSON.parse(userData);
  } catch (error) {
    console.error("Failed to parse user data:", error);
    return null;
  }
};

/**
 * Returns the current user's ID.
 * @returns {number|string|null}
 */
export const getCurrentUserId = () => {
  const user = getCurrentUser();
  return user?.id || null;
};
