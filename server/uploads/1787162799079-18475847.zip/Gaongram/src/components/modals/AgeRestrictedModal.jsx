import React, { useEffect, useRef } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { AlertTriangle } from "lucide-react";

const AgeRestrictedModal = ({ isOpen, onClose }) => {
  const cancelButtonRef = useRef(null);

  useEffect(() => {
    if (!isOpen) return;

    const focusTimer = window.setTimeout(() => {
      cancelButtonRef.current?.focus();
    }, 50);

    return () => window.clearTimeout(focusTimer);
  }, [isOpen]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-[70] flex items-center justify-center bg-black/45 px-4 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          role="presentation"
          onClick={onClose}
        >
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-labelledby="age-restricted-title"
            aria-describedby="age-restricted-description"
            className="w-full max-w-md rounded-3xl bg-white p-6 text-center shadow-2xl dark:bg-card-dark"
            initial={{ opacity: 0, scale: 0.92, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.92, y: 20 }}
            transition={{ type: "spring", damping: 24, stiffness: 320 }}
            onClick={(event) => event.stopPropagation()}
          >
            <div className="mx-auto flex h-24 w-24 items-center justify-center rounded-full border border-amber-200 bg-amber-50 text-amber-500 dark:border-amber-500/30 dark:bg-amber-500/10">
              <AlertTriangle className="h-12 w-12" aria-hidden="true" />
            </div>

            <h2
              id="age-restricted-title"
              className="mt-6 text-xl font-bold text-gray-950 dark:text-foreground-dark"
            >
              Age Restricted
            </h2>
            <div className="mx-auto mt-3 h-1 w-14 rounded-full bg-amber-500" />

            <p
              id="age-restricted-description"
              className="mt-6 text-base leading-7 text-gray-800 dark:text-mutedForeground-dark"
            >
              This content is only available for users above 18.
            </p>
            <p className="mt-4 text-base leading-7 text-gray-800 dark:text-mutedForeground-dark">
              Your profile indicates you are under 18.
            </p>

            <button
              ref={cancelButtonRef}
              type="button"
              onClick={onClose}
              className="mt-7 w-full rounded-2xl border border-gray-200 bg-gray-50 px-4 py-3 font-semibold text-gray-950 transition hover:bg-gray-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary dark:border-border-dark dark:bg-muted-dark dark:text-foreground-dark"
            >
              Cancel
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default AgeRestrictedModal;
