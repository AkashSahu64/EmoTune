// src/features/blogs/components/BlogSkeleton.jsx
import React from "react";

const BlogSkeleton = ({ count = 6 }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          className="bg-card dark:bg-card-dark rounded-xl2 overflow-hidden shadow-soft animate-pulse"
        >
          <div className="aspect-[16/9] bg-muted dark:bg-muted-dark" />
          <div className="p-5 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-muted dark:bg-muted-dark" />
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-muted dark:bg-muted-dark rounded w-3/4" />
                <div className="h-3 bg-muted dark:bg-muted-dark rounded w-1/2" />
              </div>
            </div>
            <div className="h-6 bg-muted dark:bg-muted-dark rounded w-full" />
            <div className="h-6 bg-muted dark:bg-muted-dark rounded w-5/6" />
            <div className="h-4 bg-muted dark:bg-muted-dark rounded w-full" />
            <div className="h-4 bg-muted dark:bg-muted-dark rounded w-2/3" />
            <div className="flex justify-between pt-2">
              <div className="h-6 w-20 bg-muted dark:bg-muted-dark rounded-full" />
              <div className="h-8 w-24 bg-muted dark:bg-muted-dark rounded-lg" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default BlogSkeleton;