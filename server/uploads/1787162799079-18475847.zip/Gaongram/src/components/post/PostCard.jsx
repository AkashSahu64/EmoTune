import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Heart, 
  MessageCircle, 
  Share2, 
  Bookmark, 
  MoreVertical,
  Music,
  Play,
  Pause,
  Volume2,
  User,
  Image as ImageIcon,
  Video,
  MapPin,
  Hash,
  Globe,
  Users,
  Lock,
  BarChart
} from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  likePost, 
  unlikePost, 
  savePost, 
  unsavePost, 
  deletePost,
  reportPost
} from '../../features/posts/api';
import { useAuth } from '../../hooks/useAuth';
import { useNotifications } from '../../hooks/useNotifications';
import { useAudioPlayer } from '../../hooks/useAudioPlayer';
import { formatDistanceToNow } from 'date-fns';
import { PostMenu } from './PostMenu';
import { CommentSection } from './CommentSection';
import MusicMarquee from '../music/MusicMarquee.jsx';
import { getMusicMetadata } from '../music/musicMetadata.js';

export const PostCard = ({ post, showActions = true, compact = false }) => {
  const [showComments, setShowComments] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLiked, setIsLiked] = useState(post.isLiked || false);
  const [isSaved, setIsSaved] = useState(post.isSaved || false);
  const [likeCount, setLikeCount] = useState(post._count?.likes || post.likeCount || 0);
  const [commentCount, setCommentCount] = useState(post._count?.comments || post.commentCount || 0);
  
  const { user } = useAuth();
  const { showNotification } = useNotifications();
  const { playTrack, pauseTrack, currentTrack } = useAudioPlayer();
  const queryClient = useQueryClient();
  
  const isOwner = user?.id === post.user.id;
  const hasMedia = post.media && post.media.length > 0;
  const hasAudio = post.track || post.audio;
  const hasLocation = post.location;
  const hasTags = post.tags && post.tags.length > 0;
  const music = getMusicMetadata(post);
  
  // Like mutation
  const likeMutation = useMutation({
    mutationFn: () => likePost(post.id),
    onSuccess: () => {
      setIsLiked(true);
      setLikeCount(prev => prev + 1);
      queryClient.invalidateQueries(['posts']);
    },
    onError: (error) => {
      showNotification(error.response?.data?.message || 'Failed to like post', 'error');
    }
  });
  
  const unlikeMutation = useMutation({
    mutationFn: () => unlikePost(post.id),
    onSuccess: () => {
      setIsLiked(false);
      setLikeCount(prev => Math.max(0, prev - 1));
      queryClient.invalidateQueries(['posts']);
    },
    onError: (error) => {
      showNotification(error.response?.data?.message || 'Failed to unlike post', 'error');
    }
  });
  
  // Save mutation
  const saveMutation = useMutation({
    mutationFn: () => savePost(post.id),
    onSuccess: () => {
      setIsSaved(true);
      showNotification('Post saved to your collection', 'success');
      queryClient.invalidateQueries(['savedPosts']);
    },
    onError: (error) => {
      showNotification(error.response?.data?.message || 'Failed to save post', 'error');
    }
  });
  
  const unsaveMutation = useMutation({
    mutationFn: () => unsavePost(post.id),
    onSuccess: () => {
      setIsSaved(false);
      showNotification('Post removed from your collection', 'success');
      queryClient.invalidateQueries(['savedPosts']);
    },
    onError: (error) => {
      showNotification(error.response?.data?.message || 'Failed to unsave post', 'error');
    }
  });
  
  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: () => deletePost(post.id),
    onSuccess: () => {
      showNotification('Post deleted successfully', 'success');
      queryClient.invalidateQueries(['posts']);
    },
    onError: (error) => {
      showNotification(error.response?.data?.message || 'Failed to delete post', 'error');
    }
  });
  
  const handleLikeToggle = () => {
    if (isLiked) {
      unlikeMutation.mutate();
    } else {
      likeMutation.mutate();
    }
  };
  
  const handleSaveToggle = () => {
    if (isSaved) {
      unsaveMutation.mutate();
    } else {
      saveMutation.mutate();
    }
  };
  
  const handleDelete = () => {
    if (window.confirm('Are you sure you want to delete this post?')) {
      deleteMutation.mutate();
    }
  };
  
  const handlePlayAudio = () => {
    if (post.track || post.audio) {
      if (currentTrack?.id === post.track?.id && isPlaying) {
        pauseTrack();
        setIsPlaying(false);
      } else {
        playTrack(post.track || {
          id: post.id,
          title: post.caption || 'Audio post',
          url: post.audio,
          artist: post.user
        });
        setIsPlaying(true);
      }
    }
  };
  
  const getPrivacyIcon = () => {
    switch (post.privacy) {
      case 'public':
        return <Globe size={12} className="text-gray-500" />;
      case 'friends':
        return <Users size={12} className="text-gray-500" />;
      case 'private':
        return <Lock size={12} className="text-gray-500" />;
      default:
        return null;
    }
  };
  
  const formatDate = (dateString) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true });
    } catch {
      return 'Some time ago';
    }
  };
  
  if (compact) {
    return (
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <Link to={`/profile/${post.user.username}`}>
              {post.user.profileImage ? (
                <img
                  src={post.user.profileImage}
                  alt={post.user.username}
                  className="w-10 h-10 rounded-full object-cover"
                />
              ) : (
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-100 to-blue-100 flex items-center justify-center">
                  <User size={20} className="text-purple-400" />
                </div>
              )}
            </Link>
            <div>
              <Link to={`/profile/${post.user.username}`}>
                <p className="font-medium text-gray-900 hover:text-blue-600">
                  {post.user.displayName || post.user.username}
                </p>
              </Link>
              {music && (
                <MusicMarquee
                  title={music.title}
                  artist={music.artist}
                  className="max-w-[14rem] text-xs text-gray-600"
                  textClassName="font-medium"
                />
              )}
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <span>{formatDate(post.createdAt)}</span>
                {getPrivacyIcon()}
              </div>
            </div>
          </div>
          
          <button
            onClick={() => setShowMoreMenu(!showMoreMenu)}
            className="p-1 text-gray-400 hover:text-gray-600"
          >
            <MoreVertical size={20} />
          </button>
          
          {showMoreMenu && (
            <PostMenu
              post={post}
              isOwner={isOwner}
              onDelete={handleDelete}
              onReport={() => console.log('Report post')}
              onClose={() => setShowMoreMenu(false)}
            />
          )}
        </div>
        
        {/* Content */}
        {post.caption && (
          <div className="px-4 pb-3">
            <p className="text-gray-700 whitespace-pre-line">{post.caption}</p>
          </div>
        )}
        
        {/* Media */}
        {hasMedia && post.media[0] && (
          <div className="aspect-square overflow-hidden bg-gray-100">
            {post.media[0].type === 'video' ? (
              <video
                src={post.media[0].url}
                controls
                className="w-full h-full object-cover"
              />
            ) : (
              <img
                src={post.media[0].url}
                alt={post.caption || 'Post image'}
                className="w-full h-full object-cover"
              />
            )}
          </div>
        )}
        
        {/* Audio */}
        {hasAudio && (
          <div className="px-4 py-3">
            <div className="flex items-center gap-3 p-3 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg">
              <button
                onClick={handlePlayAudio}
                className="p-2 bg-white rounded-full shadow-sm hover:shadow-md transition-shadow"
              >
                {isPlaying && currentTrack?.id === post.track?.id ? (
                  <Pause size={16} className="text-purple-600" />
                ) : (
                  <Play size={16} className="text-purple-600" />
                )}
              </button>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-gray-900 truncate">
                  {post.track?.title || 'Audio post'}
                </p>
                {post.track?.artist && (
                  <p className="text-sm text-gray-600 truncate">
                    {post.track.artist.displayName || post.track.artist.username}
                  </p>
                )}
              </div>
              <Volume2 size={16} className="text-gray-400" />
            </div>
          </div>
        )}
        
        {/* Location and Tags */}
        {(hasLocation || hasTags) && (
          <div className="px-4 py-3 border-t border-gray-100">
            {hasLocation && (
              <div className="flex items-center gap-1 text-sm text-gray-600 mb-2">
                <MapPin size={12} />
                <span>{post.location}</span>
              </div>
            )}
            {hasTags && (
              <div className="flex flex-wrap gap-1">
                {post.tags.map(tag => (
                  <Link
                    key={tag}
                    to={`/explore/tags/${tag}`}
                    className="inline-flex items-center gap-1 px-2 py-1 bg-gray-100 text-gray-700 rounded-full text-sm hover:bg-gray-200"
                  >
                    <Hash size={10} />
                    {tag}
                  </Link>
                ))}
              </div>
            )}
          </div>
        )}
        
        {/* Stats */}
        <div className="px-4 py-3 border-t border-gray-100">
          <div className="flex items-center justify-between text-sm text-gray-600">
            <div className="flex items-center gap-4">
              <button
                onClick={handleLikeToggle}
                className="flex items-center gap-1 hover:text-red-600"
              >
                <Heart size={16} className={isLiked ? 'fill-red-500 text-red-500' : ''} />
                <span>{likeCount}</span>
              </button>
              <button
                onClick={() => setShowComments(!showComments)}
                className="flex items-center gap-1 hover:text-blue-600"
              >
                <MessageCircle size={16} />
                <span>{commentCount}</span>
              </button>
              <button className="flex items-center gap-1 hover:text-green-600">
                <Share2 size={16} />
                <span>{post._count?.shares || 0}</span>
              </button>
            </div>
            
            <button
              onClick={handleSaveToggle}
              className={`hover:text-yellow-600 ${isSaved ? 'text-yellow-600' : ''}`}
            >
              <Bookmark size={16} className={isSaved ? 'fill-yellow-500' : ''} />
            </button>
          </div>
        </div>
        
        {/* Comments Section */}
        {showComments && (
          <div className="border-t border-gray-100">
            <CommentSection postId={post.id} />
          </div>
        )}
      </div>
    );
  }
  
  // Full version (non-compact)
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-6">
        <div className="flex items-center gap-4">
          <Link to={`/profile/${post.user.username}`}>
            {post.user.profileImage ? (
              <img
                src={post.user.profileImage}
                alt={post.user.username}
                className="w-14 h-14 rounded-full object-cover border-2 border-white shadow-sm"
              />
            ) : (
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-purple-100 to-blue-100 border-2 border-white shadow-sm flex items-center justify-center">
                <User size={24} className="text-purple-400" />
              </div>
            )}
          </Link>
          <div>
            <div className="flex items-center gap-2">
              <Link to={`/profile/${post.user.username}`}>
                <p className="font-semibold text-gray-900 hover:text-blue-600">
                  {post.user.displayName || post.user.username}
                </p>
              </Link>
              {post.user.isVerified && (
                <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs font-medium rounded-full">
                  Verified
                </span>
              )}
              {post.user.role === 'ARTIST' && (
                <span className="px-2 py-1 bg-purple-100 text-purple-700 text-xs font-medium rounded-full">
                  Artist
                </span>
              )}
            </div>
            {music && (
              <MusicMarquee
                title={music.title}
                artist={music.artist}
                className="max-w-[18rem] text-sm text-gray-600"
                textClassName="font-medium"
              />
            )}
            <div className="flex items-center gap-3 text-sm text-gray-500">
              <span>{formatDate(post.createdAt)}</span>
              {getPrivacyIcon()}
              {post.views && (
                <div className="flex items-center gap-1">
                  <BarChart size={12} />
                  <span>{post.views.toLocaleString()} views</span>
                </div>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          {isOwner && (
            <button className="px-4 py-2 text-sm bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200">
              Edit
            </button>
          )}
          <button
            onClick={() => setShowMoreMenu(!showMoreMenu)}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full"
          >
            <MoreVertical size={20} />
          </button>
          
          {showMoreMenu && (
            <PostMenu
              post={post}
              isOwner={isOwner}
              onDelete={handleDelete}
              onReport={() => console.log('Report post')}
              onClose={() => setShowMoreMenu(false)}
            />
          )}
        </div>
      </div>
      
      {/* Content */}
      <div className="px-6 pb-6">
        {post.caption && (
          <div className="mb-6">
            <p className="text-gray-800 text-lg whitespace-pre-line leading-relaxed">
              {post.caption}
            </p>
          </div>
        )}
        
        {/* Media Gallery */}
        {hasMedia && (
          <div className={`mb-6 rounded-xl overflow-hidden ${
            post.media.length === 1 ? 'max-w-2xl mx-auto' : ''
          }`}>
            {post.media.length === 1 ? (
              <div className="relative">
                {post.media[0].type === 'video' ? (
                  <>
                    <video
                      src={post.media[0].url}
                      controls
                      className="w-full max-h-[600px] object-contain bg-black rounded-lg"
                    />
                    <div className="absolute bottom-4 right-4 p-2 bg-black/50 text-white text-xs rounded-lg">
                      Video
                    </div>
                  </>
                ) : (
                  <img
                    src={post.media[0].url}
                    alt={post.caption || 'Post image'}
                    className="w-full max-h-[600px] object-contain rounded-lg"
                  />
                )}
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                {post.media.slice(0, 4).map((media, index) => (
                  <div key={index} className="relative aspect-square">
                    {media.type === 'video' ? (
                      <>
                        <video
                          src={media.url}
                          className="w-full h-full object-cover rounded-lg"
                        />
                        <div className="absolute top-2 right-2 p-1 bg-black/50 text-white text-xs rounded">
                          <Video size={12} />
                        </div>
                      </>
                    ) : (
                      <img
                        src={media.url}
                        alt={`Post image ${index + 1}`}
                        className="w-full h-full object-cover rounded-lg"
                      />
                    )}
                    {index === 3 && post.media.length > 4 && (
                      <div className="absolute inset-0 bg-black/60 flex items-center justify-center rounded-lg">
                        <span className="text-white text-xl font-bold">
                          +{post.media.length - 4}
                        </span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
        
        {/* Audio Player */}
        {hasAudio && (
          <div className="mb-6">
            <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                    <Music size={24} className="text-white" />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 text-lg">
                      {post.track?.title || 'Audio post'}
                    </h4>
                    {post.track?.artist && (
                      <Link 
                        to={`/profile/${post.track.artist.username}`}
                        className="text-purple-600 hover:text-purple-700"
                      >
                        {post.track.artist.displayName || post.track.artist.username}
                      </Link>
                    )}
                  </div>
                </div>
                <button
                  onClick={handlePlayAudio}
                  className="p-4 bg-gradient-to-r from-purple-500 to-blue-600 rounded-full text-white hover:shadow-lg transition-shadow"
                >
                  {isPlaying && currentTrack?.id === post.track?.id ? (
                    <Pause size={24} />
                  ) : (
                    <Play size={24} fill="white" />
                  )}
                </button>
              </div>
              {post.track?.duration && (
                <div className="text-sm text-gray-600">
                  Duration: {Math.floor(post.track.duration / 60)}:
                  {(post.track.duration % 60).toString().padStart(2, '0')}
                </div>
              )}
            </div>
          </div>
        )}
        
        {/* Location and Tags */}
        {(hasLocation || hasTags) && (
          <div className="mb-6">
            {hasLocation && (
              <div className="flex items-center gap-2 text-gray-700 mb-3">
                <MapPin size={16} className="text-gray-500" />
                <span className="font-medium">{post.location}</span>
              </div>
            )}
            {hasTags && (
              <div className="flex flex-wrap gap-2">
                {post.tags.map(tag => (
                  <Link
                    key={tag}
                    to={`/explore/tags/${tag}`}
                    className="inline-flex items-center gap-1 px-3 py-1.5 bg-gradient-to-r from-purple-50 to-blue-50 text-purple-700 rounded-full hover:from-purple-100 hover:to-blue-100"
                  >
                    <Hash size={12} />
                    {tag}
                  </Link>
                ))}
              </div>
            )}
          </div>
        )}
        
        {/* Stats and Actions */}
        <div className="flex items-center justify-between border-t border-b border-gray-100 py-4 mb-6">
          <div className="flex items-center gap-6 text-gray-600">
            <div className="flex items-center gap-2">
              <Heart size={18} className={isLiked ? 'fill-red-500 text-red-500' : ''} />
              <span className="font-medium">{likeCount} likes</span>
            </div>
            <div className="flex items-center gap-2">
              <MessageCircle size={18} />
              <span className="font-medium">{commentCount} comments</span>
            </div>
            <div className="flex items-center gap-2">
              <Share2 size={18} />
              <span className="font-medium">{post._count?.shares || 0} shares</span>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <button
              onClick={handleSaveToggle}
              className={`p-2 rounded-lg ${isSaved ? 'bg-yellow-50 text-yellow-600' : 'hover:bg-gray-100 text-gray-600'}`}
            >
              <Bookmark size={20} className={isSaved ? 'fill-yellow-500' : ''} />
            </button>
            <button className="p-2 hover:bg-gray-100 text-gray-600 rounded-lg">
              <Share2 size={20} />
            </button>
          </div>
        </div>
        
        {/* Action Buttons */}
        <div className="grid grid-cols-3 gap-2 mb-6">
          <button
            onClick={handleLikeToggle}
            className={`flex items-center justify-center gap-2 py-3 rounded-xl font-medium transition-colors ${
              isLiked
                ? 'bg-red-50 text-red-600 hover:bg-red-100'
                : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
            }`}
          >
            <Heart size={20} className={isLiked ? 'fill-red-500' : ''} />
            {isLiked ? 'Liked' : 'Like'}
          </button>
          
          <button
            onClick={() => setShowComments(!showComments)}
            className="flex items-center justify-center gap-2 py-3 bg-gray-50 text-gray-700 rounded-xl font-medium hover:bg-gray-100"
          >
            <MessageCircle size={20} />
            Comment
          </button>
          
          <button className="flex items-center justify-center gap-2 py-3 bg-gray-50 text-gray-700 rounded-xl font-medium hover:bg-gray-100">
            <Share2 size={20} />
            Share
          </button>
        </div>
      </div>
      
      {/* Comments Section */}
      {showComments && (
        <div className="border-t border-gray-200">
          <CommentSection postId={post.id} />
        </div>
      )}
    </div>
  );
};

// PostMenu Component
const PostMenu = ({ post, isOwner, onDelete, onReport, onClose }) => {
  const menuItems = [
    ...(isOwner ? [
      { label: 'Edit Post', action: () => console.log('Edit') },
      { label: 'Delete Post', action: onDelete, destructive: true },
      { label: 'View Insights', action: () => console.log('Insights') },
      { label: 'Turn off commenting', action: () => console.log('Toggle comments') },
      { label: 'Archive', action: () => console.log('Archive') }
    ] : [
      { label: 'Save Post', action: () => console.log('Save') },
      { label: 'Report', action: onReport, destructive: true },
      { label: 'Block User', action: () => console.log('Block') },
      { label: 'Mute User', action: () => console.log('Mute') },
      { label: 'Copy Link', action: () => console.log('Copy link') }
    ])
  ];
  
  return (
    <div className="absolute right-0 top-12 z-10 w-56 bg-white rounded-xl shadow-lg border border-gray-200 py-2">
      {menuItems.map((item, index) => (
        <button
          key={index}
          onClick={() => {
            item.action();
            onClose();
          }}
          className={`w-full px-4 py-3 text-left text-sm transition-colors ${
            item.destructive
              ? 'text-red-600 hover:bg-red-50'
              : 'text-gray-700 hover:bg-gray-50'
          }`}
        >
          {item.label}
        </button>
      ))}
    </div>
  );
};

// CommentSection Component (simplified version)
const CommentSection = ({ postId }) => {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const { user } = useAuth();
  
  // In a real app, you would fetch comments for this post
  // This is a simplified version
  
  const handleSubmitComment = (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    
    // Add comment to state (in real app, this would be an API call)
    setComments(prev => [...prev, {
      id: Date.now(),
      content: newComment,
      user: user,
      createdAt: new Date().toISOString(),
      likes: 0
    }]);
    
    setNewComment('');
  };
  
  return (
    <div className="p-4">
      <h4 className="font-semibold text-gray-900 mb-4">Comments</h4>
      
      {/* Comment Input */}
      <form onSubmit={handleSubmitComment} className="mb-6">
        <div className="flex gap-3">
          {user?.profileImage ? (
            <img
              src={user.profileImage}
              alt={user.username}
              className="w-8 h-8 rounded-full"
            />
          ) : (
            <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
              <User size={14} className="text-gray-400" />
            </div>
          )}
          <div className="flex-1">
            <input
              type="text"
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Add a comment..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <button
            type="submit"
            disabled={!newComment.trim()}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Post
          </button>
        </div>
      </form>
      
      {/* Comments List */}
      <div className="space-y-4">
        {comments.map(comment => (
          <div key={comment.id} className="flex gap-3">
            {comment.user.profileImage ? (
              <img
                src={comment.user.profileImage}
                alt={comment.user.username}
                className="w-8 h-8 rounded-full"
              />
            ) : (
              <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                <User size={14} className="text-gray-400" />
              </div>
            )}
            <div className="flex-1">
              <div className="bg-gray-50 rounded-xl p-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-medium text-gray-900">
                    {comment.user.displayName || comment.user.username}
                  </span>
                  <span className="text-xs text-gray-500">
                    {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
                  </span>
                </div>
                <p className="text-gray-700">{comment.content}</p>
              </div>
              <div className="flex items-center gap-4 mt-2 ml-3 text-sm text-gray-500">
                <button className="hover:text-gray-700">Like</button>
                <button className="hover:text-gray-700">Reply</button>
              </div>
            </div>
          </div>
        ))}
        
        {comments.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            No comments yet. Be the first to comment!
          </div>
        )}
      </div>
    </div>
  );
};
