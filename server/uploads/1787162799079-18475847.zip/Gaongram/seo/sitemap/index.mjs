/* global URL */
import { getSiteUrl } from "../metadata/config.mjs";
import { escapeHtml, resolveArrayPayload, unwrapApiPayload } from "../metadata/utils.mjs";

export const SITEMAP_SECTIONS = [
  "static",
  "profiles",
  "posts",
  "reels",
  "blogs",
  "audio",
  "playlists",
  "hashtags",
];

const routeFor = (section, item) => {
  if (section === "profiles") return `/profile/${item.username || item.slug || item.id}`;
  if (section === "posts") return `/posts/${item.id}`;
  if (section === "reels") return `/reels/${item.id}`;
  if (section === "blogs") return `/blogs/${item.slug || item.id}`;
  if (section === "audio") return `/audio?start=${item.id}`;
  if (section === "playlists") return `/playlists/${item.id}`;
  if (section === "hashtags") return `/hashtags/${item.slug || item.name || item.tag || item.id}`;
  return "/";
};

const defaultEntries = [
  "/",
  "/feed",
  "/about",
  "/privacy",
  "/terms",
  "/help-center",
  "/contact",
  "/safety",
  "/community-guidelines",
  "/language",
  "/blogs",
  "/reels",
  "/audio",
  "/playlists",
  "/search",
  "/trending",
].map((path) => ({
  loc: new URL(path, getSiteUrl()).href,
  changefreq: path === "/" || path === "/feed" ? "daily" : "weekly",
  priority: path === "/" ? "1.0" : "0.7",
}));

export const renderSitemapIndex = () => {
  const now = new Date().toISOString();
  const children = SITEMAP_SECTIONS.map(
    (section) => `  <sitemap>
    <loc>${escapeHtml(`${getSiteUrl()}/sitemap-${section}.xml`)}</loc>
    <lastmod>${now}</lastmod>
  </sitemap>`,
  ).join("\n");
  return `<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${children}
</sitemapindex>`;
};

export const renderUrlSet = (entries) => {
  const body = entries
    .map(
      (entry) => `  <url>
    <loc>${escapeHtml(entry.loc)}</loc>
    <lastmod>${escapeHtml(entry.lastmod || new Date().toISOString())}</lastmod>
    <changefreq>${escapeHtml(entry.changefreq || "weekly")}</changefreq>
    <priority>${escapeHtml(entry.priority || "0.6")}</priority>
  </url>`,
    )
    .join("\n");

  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${body}
</urlset>`;
};

export const renderStaticSitemap = () => renderUrlSet(defaultEntries);

export const normalizeSitemapItems = (section, payload) => {
  if (section === "static") return defaultEntries;

  const items = resolveArrayPayload(unwrapApiPayload(payload));
  return items
    .map((item) => {
      const path = routeFor(section, item);
      if (!path || path.includes("undefined")) return null;
      return {
        loc: new URL(path, getSiteUrl()).href,
        lastmod: item.updated_at || item.updatedAt || item.created_at || item.createdAt,
        changefreq:
          section === "profiles" || section === "playlists" ? "weekly" : "daily",
        priority:
          section === "profiles" || section === "hashtags" ? "0.8" : "0.7",
      };
    })
    .filter(Boolean);
};

export const endpointForSitemapSection = (section) => {
  if (section === "static") return "";
  if (section === "profiles") return "/profiles/?is_public=true&limit=1000";
  if (section === "posts") return "/vibe-posts/?limit=1000";
  if (section === "reels") return "/vibe-posts/?media_type=video&limit=1000";
  if (section === "blogs") return "/blogs/?limit=1000";
  if (section === "audio") return "/feeds/?audio=true&limit=1000";
  if (section === "playlists") return "/playlists/?is_public=true&limit=1000";
  if (section === "hashtags") return "/hashtags/?limit=1000";
  return "";
};
