import {
  createPreviewUnavailableDataUrl,
  validateCanvasExportSafety,
} from "../helpers/dom.js";

export class PreviewManager {
  constructor(engine) {
    this.engine = engine;
    this.previewTimer = null;
    this.previewRaf = null;
  }

  emitPreview(delay = 80) {
    const { canvas, onPreviewChange, isDisposed } = this.engine;
    if (!canvas || !onPreviewChange || isDisposed) return;

    window.clearTimeout(this.previewTimer);
    if (this.previewRaf) {
      cancelAnimationFrame(this.previewRaf);
      this.previewRaf = null;
    }

    this.previewTimer = window.setTimeout(() => {
      this.previewRaf = requestAnimationFrame(() => {
        this.previewRaf = null;
        if (!this.engine.canvas || this.engine.isDisposed) return;

        try {
          validateCanvasExportSafety(this.engine.canvas);
          this.engine.canvas.renderAll();
          const dataUrl = this.engine.canvas.toDataURL({
            format: "jpeg",
            quality: 0.72,
            multiplier: 0.35,
            enableRetinaScaling: true,
          });
          onPreviewChange(dataUrl);
        } catch (error) {
          console.error("[StoryEditor] Preview export failed", error);
          onPreviewChange(
            createPreviewUnavailableDataUrl(
              this.engine.canvas.getWidth?.() || 320,
              this.engine.canvas.getHeight?.() || 568,
            ),
          );
        }
      });
    }, delay);
  }

  dispose() {
    window.clearTimeout(this.previewTimer);
    if (this.previewRaf) {
      cancelAnimationFrame(this.previewRaf);
      this.previewRaf = null;
    }
  }
}
