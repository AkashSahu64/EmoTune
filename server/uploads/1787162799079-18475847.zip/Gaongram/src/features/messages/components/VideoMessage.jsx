// src/features/messages/components/VideoMessage.jsx
import React, { useState, useRef } from 'react';
import { Play, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const VideoMessage = ({ src }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const videoRef = useRef(null);

  return (
    <>
      <div className="relative cursor-pointer group" onClick={() => setIsModalOpen(true)}>
        <video
          ref={videoRef}
          src={src}
          className="max-w-[260px] max-h-[200px] rounded-lg object-cover"
          poster={src + '?poster'} // if backend supports, else fallback
        />
        <div className="absolute inset-0 flex items-center justify-center bg-black/30 rounded-lg group-hover:bg-black/40 transition">
          <Play className="w-10 h-10 text-white opacity-80 group-hover:opacity-100" />
        </div>
      </div>

      <AnimatePresence>
        {isModalOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center"
            onClick={() => setIsModalOpen(false)}
          >
            <button className="absolute top-4 right-4 text-white p-2 rounded-full bg-white/20">
              <X className="w-6 h-6" />
            </button>
            <video
              src={src}
              controls
              autoPlay
              className="max-w-[90vw] max-h-[90vh] rounded-lg"
              onClick={(e) => e.stopPropagation()}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default VideoMessage;