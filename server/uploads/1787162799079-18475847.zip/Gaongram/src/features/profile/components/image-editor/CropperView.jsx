import React from 'react';
import { motion as Motion } from 'framer-motion';
import Cropper from 'react-easy-crop';
import Button from '../../../../components/common/Button';
import { Maximize2, RotateCw } from 'lucide-react';

const CropperView = ({
  selectedImage,
  crop,
  zoom,
  rotation,
  aspect,
  onCropChange,
  onZoomChange,
  onRotationChange,
  onAspectChange,
  onCropComplete,
  onNext,
  onReset,
  config
}) => (
  <Motion.div
    key="edit"
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    className="space-y-4"
  >
    {/* Cropper */}
    <div className="relative h-[min(68vh,430px)] overflow-hidden rounded-2xl bg-black/95 shadow-inner">
      <Cropper
        image={selectedImage}
        crop={crop}
        zoom={zoom}
        rotation={rotation}
        aspect={aspect || undefined}
        onCropChange={onCropChange}
        onZoomChange={onZoomChange}
        onRotationChange={onRotationChange}
        onCropComplete={onCropComplete}
        cropShape={config.cropShape}
        showGrid={config.type === 'cover'}
        objectFit="contain"
        restrictPosition={false}
        classes={{
          containerClassName: "touch-none",
        }}
      />
    </div>

    {/* Controls */}
    <div className="space-y-3">
      {/* Aspect Ratio */}
      <div className="flex gap-2 overflow-x-auto text-sm text-gray-600">
        {config.aspectRatios.map((ratio) => (
          <button
            key={ratio.label}
            onClick={() => onAspectChange(ratio.value)}
            className={`shrink-0 rounded-full px-3 py-1.5 transition ${
              aspect === ratio.value
                ? 'bg-gaon-green text-white font-medium'
                : 'bg-gray-100 hover:text-gray-800'
            }`}
          >
            {ratio.label}
          </button>
        ))}
      </div>

      {/* Zoom */}
      <div className="space-y-1.5">
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <Maximize2 size={12} />
          Zoom
        </div>
        <input
          type="range"
          min="1"
          max="3"
          step="0.1"
          value={zoom}
          onChange={(e) => onZoomChange(parseFloat(e.target.value))}
          className="w-full h-1 bg-gray-200 rounded cursor-pointer"
        />
      </div>

      {/* Rotation */}
      <div className="space-y-1.5">
        <div className="flex items-center gap-2 text-xs text-gray-500">
          <RotateCw size={12} />
          Rotation
        </div>
        <input
          type="range"
          min="-180"
          max="180"
          value={rotation}
          onChange={(e) => onRotationChange(parseInt(e.target.value))}
          className="w-full h-1 bg-gray-200 rounded cursor-pointer"
        />
      </div>

      {/* Actions */}
      <div className="flex justify-between items-center pt-3">
        <Button
          variant="ghost"
          size="small"
          onClick={onReset}
        >
          Reset
        </Button>

        <Button
          variant="primary"
          size="medium"
          onClick={onNext}
        >
          Continue
        </Button>
      </div>
    </div>
  </Motion.div>
);

export default CropperView;
