/* eslint-env node */
/* global process, console */
import { execFileSync } from "node:child_process";
import { resolve } from "node:path";
import react from "@vitejs/plugin-react";
import { build, defineConfig } from "vite";

const runNodeScript = (script, env = {}) => {
  execFileSync(process.execPath, [resolve(script)], {
    stdio: "inherit",
    env: {
      ...process.env,
      ...env,
    },
  });
};

const main = async () => {
  await build(
    defineConfig({
      configFile: false,
      plugins: [react()],
      build: {
        target: "es2015",
      },
    }),
  );

  runNodeScript("scripts/generate-profile-snapshots.mjs");

  const routes = JSON.stringify(
    [
      "/login",
      "/register",
      "/forgot-password",
      "/reels",
      "/audio",
      "/playlists",
      "/blogs",
      "/search",
      "/trending",
      "/privacy",
      "/terms",
      "/safety",
      "/help-center",
      "/contact",
      "/language",
      "/feed",
      "/about",
      "/community-guidelines",
    ].filter((route) => !route.startsWith("/profile")),
  );

  runNodeScript("scripts/prerender.mjs", {
    GAONGRAM_PRERENDER_ROUTES: routes,
  });
};

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
