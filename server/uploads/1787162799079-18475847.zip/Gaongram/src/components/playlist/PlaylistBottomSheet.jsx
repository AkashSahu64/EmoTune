import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Plus, Check } from 'lucide-react';
import { playlistService } from '../../services/playlist.service.js';
import { usePlaylistStore } from '../../store/playlistStore.js';
import CreatePlaylistSheet from './CreatePlaylistSheet.jsx';
import Avatar from '../common/Avatar.jsx';

const PlaylistBottomSheet = ({ isOpen, onClose, audioId, audioTitle }) => {
  const [showCreate, setShowCreate] = useState(false);
  const [loading, setLoading] = useState(false);
  const [addingId, setAddingId] = useState(null);
  const { playlists, setPlaylists, addPlaylistItem, removePlaylistItem } = usePlaylistStore();

  useEffect(() => {
    if (isOpen && playlists.length === 0) {
      fetchPlaylists();
    }
  }, [isOpen, playlists.length]);

  const fetchPlaylists = async () => {
    setLoading(true);
    const res = await playlistService.getPlaylists({ limit: 50 });
    if (res.success) {
      setPlaylists(res.data.results || []);
    }
    setLoading(false);
  };

  const handleAddToPlaylist = async (playlistId) => {
    try {
      setAddingId(playlistId);

      if (audioId) {
        const optimisticItem = {
          id: `temp-${playlistId}-${audioId}`,
          audio: { id: audioId, title: audioTitle },
          order: 0,
          is_liked: false,
          isOptimistic: true,
        };
        addPlaylistItem(playlistId, optimisticItem);
        const res = await playlistService.addAudioToPlaylist(playlistId, audioId);
        if (res.data?.id) {
          removePlaylistItem(playlistId, audioId);
          addPlaylistItem(playlistId, res.data);
        }
      }

      setAddingId(null);
      onClose();
    } catch (error) {
      console.error(error);
      if (audioId) removePlaylistItem(playlistId, audioId);
      setAddingId(null);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end justify-center">
        <motion.div
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        />

        <motion.div
          className="relative w-full max-w-[410px] bg-muted dark:bg-muted-dark rounded-t-xl max-h-[100vh] overflow-hidden"
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        >
          <div className="flex items-center justify-between px-4 py-3 border-b border-border dark:border-border-dark">
            <h2 className="text-lg font-semibold text-foreground dark:text-foreground-dark">Add to playlist</h2>
            <button
              onClick={onClose}
              className="p-1 hover:bg-foreground/10 rounded-full transition"
              aria-label="Close"
            >
              <X className="w-5 h-5 text-foreground dark:text-foreground-dark" />
            </button>
          </div>

          {showCreate ? (
            <CreatePlaylistSheet
              onBack={() => setShowCreate(false)}
              onCreated={(newPlaylist) => {
                handleAddToPlaylist(newPlaylist.id);
              }}
              audioId={audioId}
              audioTitle={audioTitle}
            />
          ) : (
            <div className="flex flex-col h-full">
              <div className="flex-1 overflow-y-auto p-4 space-y-2">
                {loading ? (
                  <div className="text-center py-8 text-foreground dark:text-foreground-dark">Loading...</div>
                ) : playlists.length === 0 ? (
                  <div className="text-center py-8 text-foreground dark:text-foreground-dark">No playlists yet</div>
                ) : (
                  playlists.map((playlist) => {
                    const isAdded = Boolean(audioId) && playlist.items?.some(
                      (item) => Number(item.audio?.id) === Number(audioId),
                    );
                    return (
                      <button
                        key={playlist.id}
                        onClick={() => handleAddToPlaylist(playlist.id)}
                        disabled={addingId === playlist.id || isAdded}
                        className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-foreground/10 transition disabled:opacity-60"
                      >
                        <Avatar
                          src={playlist.cover_image}
                          alt={playlist.title}
                          size="medium"
                          className="rounded-lg"
                        />
                        <div className="flex-1 text-left">
                          <div className="font-medium text-foreground dark:text-foreground-dark">{playlist.title}</div>
                          <div className="text-sm text-foreground dark:text-foreground-dark">
                            {playlist.items?.length || 0} tracks
                          </div>
                        </div>
                        {addingId === playlist.id ? (
                          <div className="w-5 h-5 border-2 border-border dark:bg-border-dark border-t-transparent rounded-full animate-spin" />
                        ) : isAdded ? (
                          <Check className="w-5 h-5 text-gaon-green" />
                        ) : (
                          <Plus className="w-5 h-5 text-foreground dark:text-foreground-dark" />
                        )}
                      </button>
                    );
                  })
                )}
              </div>

              <div className="px-4 py-3 border-t border-border dark:border-border-dark">
                <button
                  onClick={() => setShowCreate(true)}
                  className="w-full py-2 px-4 bg-muted dark:bg-muted-dark text-foreground dark:text-foreground-dark font-medium rounded-lg flex items-center justify-center gap-2"
                >
                  <Plus className="w-5 h-5" />
                  Create new playlist
                </button>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default React.memo(PlaylistBottomSheet);
