import React from 'react';
import { motion } from 'framer-motion';
import { Link, useLocation } from 'react-router-dom';
import { Home, Search, PlusSquare, User, Music } from 'lucide-react';
import { useAuthStore } from '../../store/authStore.js';
import { useUIStore } from '../../store/uiStore.js';
import { useTranslation } from 'react-i18next';
import { ImFire } from "react-icons/im";
import { PiCameraPlusBold } from "react-icons/pi";

const BottomNav = () => {
  const location = useLocation();
  const { isAuthenticated, user } = useAuthStore();
  const { openModal } = useUIStore();
  const { t } = useTranslation(); 

  const navItems = [
    {
      icon: Home,
      key: 'home',
      path: '/',
      active: location.pathname === '/',
    },
    {
      icon: Search,
      key: 'search',
      path: '/search',
      active: location.pathname.includes('/search'),
    },
    {
      icon: PiCameraPlusBold,
      key: 'create',
      path: '#',
      active: false,
      onClick: () => {
        if (isAuthenticated) {
          openModal('create-post-selector');
        } else {
          window.location.href = '/login';
        }
      },
    },
    {
      icon: ImFire,
      key: 'vibes',
      path: '/reels',
      active: location.pathname.includes('/reels'),
    },
    {
      icon: Music,
      key: 'audio',
      path: '/audio',
      active: location.pathname.includes('/audio'),
    },
    {
      icon: User,
      key: 'profile',
      path: isAuthenticated ? `/profile/${user?.username}` : '/login',
      active: location.pathname.includes('/profile'),
    },
  ];

  return (
    <motion.nav
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      className="fixed bottom-0 left-0 right-0 z-40 bg-card/80 dark:bg-card-dark/80 backdrop-blur-sm border-t border-border dark:border-border-dark md:hidden"
    >
      <div className="flex items-center justify-around h-16 px-2">
        {navItems.map((item) => {
          const Icon = item.icon;

          // 👉 Button (Create)
          if (item.onClick) {
            return (
              <button
                key={item.key}
                onClick={item.onClick}
                className="flex flex-col items-center justify-center flex-1 p-2 transition-colors hover:text-primary"
                aria-label={t(item.key)}
              >
                <div className="relative">
                  <Icon
                    className={`w-6 h-6 ${
                      item.active
                        ? 'text-primary'
                        : 'text-mutedForeground dark:text-mutedForeground-dark'
                    }`}
                  />
                  {item.active && (
                    <motion.div
                      layoutId="active-indicator"
                      className="absolute -top-1 -right-1 w-2 h-2 bg-primary rounded-full"
                    />
                  )}
                </div>
                <span
                  className={`text-xs mt-1 ${
                    item.active
                      ? 'text-primary'
                      : 'text-mutedForeground dark:text-mutedForeground-dark'
                  }`}
                >
                  {t(item.key)}
                </span>
              </button>
            );
          }

          // 👉 Link items
          return (
            <Link
              key={item.key}
              to={item.path}
              className="flex flex-col items-center justify-center flex-1 p-2 transition-colors hover:text-primary"
            >
              <div className="relative">
                <Icon
                  className={`w-6 h-6 ${
                    item.active
                      ? 'text-primary'
                      : 'text-mutedForeground dark:text-mutedForeground-dark'
                  }`}
                />
                {item.active && (
                  <motion.div
                    layoutId="active-indicator"
                    className="absolute -top-1 -right-1 w-2 h-2 bg-primary rounded-full"
                  />
                )}
              </div>
              <span
                className={`text-xs mt-1 ${
                  item.active
                    ? 'text-primary'
                    : 'text-mutedForeground dark:text-mutedForeground-dark'
                }`}
              >
                {t(item.key)}
              </span>
            </Link>
          );
        })}
      </div>
    </motion.nav>
  );
};

export default BottomNav;