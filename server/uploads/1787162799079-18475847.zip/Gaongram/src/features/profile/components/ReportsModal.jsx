// components/ReportsModal.jsx
import React, { useState, useEffect } from "react";
import { X, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";
import Button from "../../../components/common/Button";
import { profileAPI } from "../profileApi";
import { useNavigate } from "react-router-dom";
import { showToast } from "../../../utils/toast";

const ReportsModal = ({ isOpen, onClose, onNavigateAway }) => {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const navigate = useNavigate();

  const loadReports = async (pageNum = 1) => {
    setLoading(true);
    try {
      const data = await profileAPI.getReports(pageNum);
      if (pageNum === 1) {
        setReports(data.results);
      } else {
        setReports((prev) => [...prev, ...data.results]);
      }
      setHasMore(!!data.next);
    } catch (error) {
      showToast("Failed to load reports", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      setPage(1);
      loadReports(1);
    }
  }, [isOpen]);

  const loadMore = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    loadReports(nextPage);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      day: "numeric",
      month: "short",
      year: "numeric",
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "pending":
        return "bg-yellow-50 text-yellow-700 border border-yellow-200 dark:bg-yellow-900/20 dark:text-yellow-300 dark:border-yellow-800";

      case "resolved":
        return "bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-900/20 dark:text-emerald-300 dark:border-emerald-800";

      case "dismissed":
        return "bg-slate-100 text-slate-700 border border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700";

      default:
        return "bg-slate-100 text-slate-700 border border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700";
    }
  };

  const getTargetColor = (type) => {
    switch (type?.toLowerCase()) {
      case "post":
        return "bg-blue-50 text-blue-700 border border-blue-200 dark:bg-blue-900/20 dark:text-blue-300 dark:border-blue-800";

      case "comment":
        return "bg-purple-50 text-purple-700 border border-purple-200 dark:bg-purple-900/20 dark:text-purple-300 dark:border-purple-800";

      case "user":
        return "bg-orange-50 text-orange-700 border border-orange-200 dark:bg-orange-900/20 dark:text-orange-300 dark:border-orange-800";

      default:
        return "bg-slate-50 text-slate-700 border border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700";
    }
  };

  if (!isOpen) return null;
  const handleReportClick = async (report) => {
    try {
      if (report.report_target_text === "post") {
        const post = await profileAPI.getReportPost(report.object_id);

        onNavigateAway?.();

        navigate(`/profile/${post.user_name}/post/${post.id}`);

        return;
      }

      if (report.report_target_text === "user") {
        const user = await profileAPI.getReportUser(report.object_id);

        onNavigateAway?.();

        navigate(`/profile/${user.username}`);

        return;
      }
    } catch (error) {
      console.error(error);
      showToast("Unable to open report", "error");
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-6">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm"
          onClick={onClose}
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative bg-white dark:bg-card-dark rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-border dark:border-border-dark "
        >
          {/* Header */}
          <div
            className="px-4 py-2 border-b border-border dark:border-border-dark bg-card dark:bg-card-dark"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-semibold text-foreground dark:text-foreground-dark">
                Reports
              </h3>

              <button
                onClick={onClose}
                className="p-2 rounded-full text-foreground/80 dark:text-foreground-dark hover:text-foreground dark:hover:text-foreground-dark hover:bg-gray-100 dark:hover:bg-muted-dark transition-all"
              >
                <X size={20} />
              </button>
            </div>
          </div>

          {/* Body */}
          <div className="max-h-[60vh] md:max-h-[70vh] overflow-y-auto hide-scrollbar px-4 py-2">
            {loading && reports.length === 0 ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : reports.length === 0 ? (
              <div className="text-center py-12 text-gray-500 dark:text-gray-400">
                <AlertCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />

                <p className="font-medium text-base">No reports found</p>

                <p className="text-sm mt-1">
                  Reports you submit will appear here.
                </p>
              </div>
            ) : (
              <div className="space-y-1">
                {reports.map((report) => (
                  <motion.div
                    key={report.id}
                    whileHover={{ y: -1 }}
                    whileTap={{ scale: 0.99 }}
                    onClick={() => handleReportClick(report)}
                    className="cursor-pointer rounded-xl border border-border dark:border-border-dark bg-white dark:bg-card-dark px-3 py-1 shadow-sm transition-all hover:shadow-sm hover:border-primary/30"
                  >
                    {/* Header */}
                    <div className="flex items-start justify-between gap-2 mt-1">
                      <div className="min-w-0 flex-1">
                        <h4 className="font-semibold text-sm capitalize text-foreground dark:text-foreground-dark">
                          Reason: {report.reason}
                        </h4>
                      </div>
                       <span
                        className={`px-2.5 py-1 rounded-full text-xs font-medium capitalize ${getStatusColor(report.status)}`}
                      >
                        {report.status}
                      </span>

                      <span
                        className={`px-2.5 py-1 rounded-full text-xs font-medium capitalize whitespace-nowrap ${getTargetColor(report.report_target_text)}`}
                      >
                        {report.report_target_text}
                      </span>
                    </div>

                    {/* Description */}
                    {report.description && (
                      <p
                        className=" mt-1 text-sm text-foreground/80 dark:text-foreground-dark/80 line-clamp-3 break-words leading-tight"
                      >
                        {report.description}
                      </p>
                    )}

                    {/* Footer */}
                    <div className="mt-1 flex items-center justify-between gap-2">
                      <span className="text-xs text-mutedForeground dark:text-mutedForeground-dark">
                        Created: {formatDate(report.created_at)}
                      </span>
                    </div>
                  </motion.div>
                ))}

                {hasMore && (
                  <Button
                    variant="outline"
                    onClick={loadMore}
                    loading={loading}
                    className="w-full mt-2"
                  >
                    Load More
                  </Button>
                )}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="sticky bottom-0 bg-white dark:bg-card-dark border-t border-border dark:border-border-dark px-4 py-2">
            <div className="flex justify-end">
              <Button
                type="button"
                size="small"
                variant="outline"
                onClick={onClose}
                className="rounded-xl px-5 border-border dark:border-border-dark text-foreground dark:text-foreground-dark hover:bg-muted dark:hover:bg-muted-dark transition-all"
              >
                Close
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default ReportsModal;
