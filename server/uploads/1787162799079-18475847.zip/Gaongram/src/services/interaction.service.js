// services/interaction.service.js
import api from "../config/axios.js";

const DEBUG = true; // <-- enable logging for buffer operations
// const log = (...args) => {
//   if (DEBUG) console.log("[INTERACTION_SERVICE]:", ...args);
// };

let interactionBuffer = [];
let flushTimer = null;
const FLUSH_INTERVAL = 3000;
const BATCH_SIZE = 5;

const sendInteractions = async (payload) => {
  if (!payload.posts.length) return;
  try {
    const response = await api.post("/interactions/", payload);
    // log("API success – sent", payload.posts.length, "interactions", payload);
    return response.data;
  } catch (error) {
    // log("API error", error);
    // Optionally re‑queue? For now we drop.
  }
};

const flushBuffer = async () => {
  if (flushTimer) {
    clearTimeout(flushTimer);
    flushTimer = null;
  }
  if (interactionBuffer.length === 0) return;

  const payload = { posts: [...interactionBuffer] };
  interactionBuffer = [];
  await sendInteractions(payload);
};

const scheduleFlush = () => {
  if (flushTimer) clearTimeout(flushTimer);
  flushTimer = setTimeout(() => flushBuffer(), FLUSH_INTERVAL);
};

export const interactionService = {
  trackInteraction: (interaction) => {
    if (!navigator.onLine) return;
    interactionBuffer.push(interaction);
    // log("push interaction – buffer size:", interactionBuffer.length, interaction);

    if (interactionBuffer.length >= BATCH_SIZE) {
      flushBuffer();
    } else {
      scheduleFlush();
    }
  },
  flushAll: () => flushBuffer(),
};

if (typeof window !== "undefined") {
  window.addEventListener("beforeunload", () => {
    interactionService.flushAll();
  });
}