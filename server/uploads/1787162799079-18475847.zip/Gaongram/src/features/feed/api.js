// import api from '../../../config/axios.js';

// export const feedAPI = {
//   // Get feed posts
//   getFeed: async (params = {}) => {
//     const response = await api.get('/feed/', { params });
//     return response.data;
//   },

//   // Get single post
//   getPost: async (postId) => {
//     const response = await api.get(`/posts/${postId}/`);
//     return response.data;
//   },

//   // Create post
//   createPost: async (postData) => {
//     const response = await api.post('/posts/', postData);
//     return response.data;
//   },

//   // Update post
//   updatePost: async (postId, postData) => {
//     const response = await api.put(`/posts/${postId}/`, postData);
//     return response.data;
//   },

//   // Delete post
//   deletePost: async (postId) => {
//     const response = await api.delete(`/posts/${postId}/`);
//     return response.data;
//   },

//   // Like post
//   likePost: async (postId) => {
//     const response = await api.post(`/posts/${postId}/like/`);
//     return response.data;
//   },

//   // Unlike post
//   unlikePost: async (postId) => {
//     const response = await api.delete(`/posts/${postId}/like/`);
//     return response.data;
//   },

//   // Save post
//   savePost: async (postId) => {
//     const response = await api.post(`/posts/${postId}/save/`);
//     return response.data;
//   },

//   // Unsave post
//   unsavePost: async (postId) => {
//     const response = await api.delete(`/posts/${postId}/save/`);
//     return response.data;
//   },

//   // Report post
//   reportPost: async (postId, reason) => {
//     const response = await api.post(`/posts/${postId}/report/`, { reason });
//     return response.data;
//   },

//   // Get saved posts
//   getSavedPosts: async (params = {}) => {
//     const response = await api.get('/posts/saved/', { params });
//     return response.data;
//   },

//   // Get trending posts
//   getTrendingPosts: async (params = {}) => {
//     const response = await api.get('/posts/trending/', { params });
//     return response.data;
//   },

//   // Get explore posts
//   getExplorePosts: async (params = {}) => {
//     const response = await api.get('/posts/explore/', { params });
//     return response.data;
//   },

//   // Share post
//   sharePost: async (postId, platform) => {
//     const response = await api.post(`/posts/${postId}/share/`, { platform });
//     return response.data;
//   },
// };