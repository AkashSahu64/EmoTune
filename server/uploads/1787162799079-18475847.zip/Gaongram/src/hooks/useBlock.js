import { useCallback } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { blockService } from "../services/report.service";
import { profileKeys } from "../features/profile/profileKeys";
import { useBlockStore } from "../store/block.store";
import { showToast } from "../utils/toast";
import { FEED_EVENTS, publishFeedEvent } from "../utils/feedEvents";

const resolveUserId = (value) => {
  const candidate = value?.user_id ?? value?.userId ?? value?.id;

  if (candidate === undefined || candidate === null || candidate === "") {
    return null;
  }

  return String(candidate);
};

const resolveUsername = (value) => {
  const username = value?.username;

  return username ? String(username).toLowerCase() : null;
};

const matchesTargetProfile = (value, userId, username) => {
  if (!value || typeof value !== "object") {
    return false;
  }

  const recordUserId = resolveUserId(value);
  const recordUsername = resolveUsername(value);

  if (userId && recordUserId && recordUserId === userId) {
    return true;
  }

  if (username && recordUsername && recordUsername === username) {
    return true;
  }

  return false;
};

const toCount = (value, fallback = 0) => {
  const numericValue = Number(value);

  return Number.isFinite(numericValue) ? Math.max(0, numericValue) : fallback;
};

const applyBlockedStateToProfile = (profile, nextIsBlocked) => {
  if (!profile || typeof profile !== "object") {
    return profile;
  }

  return {
    ...profile,
    is_blocked: nextIsBlocked,
    blocked_by: nextIsBlocked ? false : Boolean(profile.blocked_by),
    followers_count: nextIsBlocked ? 0 : toCount(profile.followers_count),
    following_count: nextIsBlocked ? 0 : toCount(profile.following_count),
    posts_count: nextIsBlocked ? 0 : toCount(profile.posts_count),
    is_following: nextIsBlocked ? false : Boolean(profile.is_following),
    is_following_requested: nextIsBlocked
      ? false
      : Boolean(profile.is_following_requested),
  };
};

const mergeProfilePayload = (currentProfile, incomingProfile) => {
  if (!incomingProfile || typeof incomingProfile !== "object") {
    return currentProfile;
  }

  if (!currentProfile || typeof currentProfile !== "object") {
    return incomingProfile;
  }

  const mergedProfile = {
    ...currentProfile,
    ...incomingProfile,
  };

  if (!mergedProfile.full_name) {
    mergedProfile.full_name = [
      mergedProfile.first_name,
      mergedProfile.last_name,
    ]
      .filter(Boolean)
      .join(" ")
      .trim();
  }

  return mergedProfile;
};

const extractProfilePayload = (response) => {
  const payload = response?.data ?? response;

  if (!payload || typeof payload !== "object") {
    return null;
  }

  const candidates = [
    payload.profile,
    payload.user,
    payload.data,
    payload.result,
    payload,
  ];

  return (
    candidates.find(
      (candidate) =>
        candidate &&
        typeof candidate === "object" &&
        (candidate.user_id || candidate.id || candidate.username),
    ) || null
  );
};

const updateQueryDataForTarget = (queryData, userId, username, updater) => {
  if (queryData === null || queryData === undefined) {
    return queryData;
  }

  if (Array.isArray(queryData)) {
    let changed = false;

    const nextItems = queryData.map((item) => {
      const nextItem = updateQueryDataForTarget(item, userId, username, updater);

      if (nextItem !== item) {
        changed = true;
      }

      return nextItem;
    });

    return changed ? nextItems : queryData;
  }

  if (typeof queryData !== "object") {
    return queryData;
  }

  if (matchesTargetProfile(queryData, userId, username)) {
    return updater(queryData);
  }

  let changed = false;
  const nextObject = {};

  for (const [key, value] of Object.entries(queryData)) {
    const nextValue = updateQueryDataForTarget(value, userId, username, updater);

    nextObject[key] = nextValue;

    if (nextValue !== value) {
      changed = true;
    }
  }

  return changed ? nextObject : queryData;
};

const findProfileRecord = (queryData, userId, username) => {
  if (queryData === null || queryData === undefined) {
    return null;
  }

  if (Array.isArray(queryData)) {
    for (const item of queryData) {
      const match = findProfileRecord(item, userId, username);

      if (match) {
        return match;
      }
    }

    return null;
  }

  if (typeof queryData !== "object") {
    return null;
  }

  if (matchesTargetProfile(queryData, userId, username)) {
    return queryData;
  }

  for (const value of Object.values(queryData)) {
    const match = findProfileRecord(value, userId, username);

    if (match) {
      return match;
    }
  }

  return null;
};

const getDirectProfileKeys = (userId, username) => {
  const directKeys = [];

  if (userId) {
    directKeys.push(profileKeys.byId(userId));
  }

  if (username) {
    const usernameKey =
      typeof profileKeys.byUsername === "function"
        ? profileKeys.byUsername(username)
        : profileKeys.byIdentifier(username);

    directKeys.push(usernameKey);
  }

  return Array.from(
    new Map(directKeys.map((key) => [JSON.stringify(key), key])).values(),
  );
};

const patchProfileCaches = (queryClient, userId, username, updater) => {
  const previousSnapshots = [];
  const allProfileQueries = queryClient.getQueriesData({
    queryKey: profileKeys.all,
  });
  const seenKeys = new Set();

  for (const [queryKey, queryData] of allProfileQueries) {
    seenKeys.add(JSON.stringify(queryKey));

    const nextQueryData = updateQueryDataForTarget(
      queryData,
      userId,
      username,
      updater,
    );

    if (nextQueryData !== queryData) {
      previousSnapshots.push([queryKey, queryData]);
      queryClient.setQueryData(queryKey, nextQueryData);
    }
  }

  for (const queryKey of getDirectProfileKeys(userId, username)) {
    const keyHash = JSON.stringify(queryKey);

    if (seenKeys.has(keyHash)) {
      continue;
    }

    const queryData = queryClient.getQueryData(queryKey);
    const nextQueryData = updateQueryDataForTarget(
      queryData,
      userId,
      username,
      updater,
    );

    if (nextQueryData !== queryData) {
      previousSnapshots.push([queryKey, queryData]);
      queryClient.setQueryData(queryKey, nextQueryData);
    }
  }

  return previousSnapshots;
};

const restoreSnapshots = (queryClient, previousSnapshots = []) => {
  for (const [queryKey, snapshot] of previousSnapshots) {
    queryClient.setQueryData(queryKey, snapshot);
  }
};

const invalidateExactProfileKeys = (queryClient, userId, username) =>
  Promise.all(
    getDirectProfileKeys(userId, username).map((queryKey) =>
      queryClient.invalidateQueries({
        queryKey,
        exact: true,
      }),
    ),
  );

const invalidateBlockedUserSurfaces = (queryClient) =>
  Promise.all([
    queryClient.invalidateQueries({ queryKey: ["feed"] }),
    queryClient.invalidateQueries({ queryKey: ["suggested-users"] }),
    queryClient.invalidateQueries({ queryKey: ["all-suggested-users-modal"] }),
    queryClient.invalidateQueries({ queryKey: ["search-accounts"] }),
    queryClient.invalidateQueries({ queryKey: ["search-posts"] }),
    queryClient.invalidateQueries({ queryKey: ["notifications"] }),
    queryClient.invalidateQueries({ queryKey: ["chatList"] }),
    queryClient.invalidateQueries({ queryKey: ["messages"] }),
    queryClient.invalidateQueries({ queryKey: ["profile-content"] }),
    queryClient.invalidateQueries({ queryKey: ["hashtag-posts"] }),
    queryClient.invalidateQueries({ queryKey: ["trending-posts"] }),
  ]);

export const useBlock = () => {
  const queryClient = useQueryClient();
  const blockedUsers = useBlockStore((state) => state.blockedUsers);
  const blockedByUsers = useBlockStore((state) => state.blockedByUsers);
  const setBlocked = useBlockStore((state) => state.setBlocked);
  const setUnblocked = useBlockStore((state) => state.setUnblocked);
  const hydrateFromProfile = useBlockStore((state) => state.hydrateFromProfile);

  const blockMutation = useMutation({
    mutationFn: (userId) => blockService.toggleBlockUser(userId),
    onMutate: async (rawUserId) => {
      const userId = resolveUserId({ user_id: rawUserId });

      if (!userId) {
        return {
          nextIsBlocked: false,
          previousSnapshots: [],
          targetUsername: null,
        };
      }

      await queryClient.cancelQueries({ queryKey: profileKeys.all });

      const cachedQueries = queryClient.getQueriesData({
        queryKey: profileKeys.all,
      });
      const matchedProfile = cachedQueries
        .map(([, queryData]) => findProfileRecord(queryData, userId, null))
        .find(Boolean);
      const targetUsername = resolveUsername(matchedProfile);
      const isCurrentlyBlocked =
        Boolean(matchedProfile?.is_blocked) || blockedUsers.has(userId);
      const nextIsBlocked = !isCurrentlyBlocked;

      if (nextIsBlocked) {
        setBlocked(userId);
      } else {
        setUnblocked(userId);
      }

      const previousSnapshots = patchProfileCaches(
        queryClient,
        userId,
        targetUsername,
        (profile) => applyBlockedStateToProfile(profile, nextIsBlocked),
      );

      return {
        nextIsBlocked,
        previousSnapshots,
        targetUsername,
      };
    },
    onSuccess: async (response, rawUserId, context) => {
      const userId = resolveUserId({ user_id: rawUserId });

      if (!userId) {
        return;
      }

      const serverProfile = extractProfilePayload(response);
      const resolvedUsername =
        resolveUsername(serverProfile) ?? context?.targetUsername ?? null;

      if (serverProfile) {
        patchProfileCaches(queryClient, userId, resolvedUsername, (profile) =>
          applyBlockedStateToProfile(
            mergeProfilePayload(profile, serverProfile),
            context?.nextIsBlocked ?? Boolean(serverProfile.is_blocked),
          ),
        );

        hydrateFromProfile(
          applyBlockedStateToProfile(serverProfile, context?.nextIsBlocked),
        );
      } else if (!context?.nextIsBlocked) {
        await invalidateExactProfileKeys(queryClient, userId, resolvedUsername);
      }

      await Promise.all([
        queryClient.invalidateQueries({
          queryKey: profileKeys.followers(userId),
          exact: true,
        }),
        queryClient.invalidateQueries({
          queryKey: profileKeys.following(userId),
          exact: true,
        }),
        invalidateBlockedUserSurfaces(queryClient),
      ]);

      if (context?.nextIsBlocked) {
        publishFeedEvent({
          type: FEED_EVENTS.BLOCKED_USER,
          userId,
        });
      } else {
        publishFeedEvent({ type: FEED_EVENTS.REFRESH });
      }

      showToast(response?.message || "Block status updated", "success");
    },
    onError: (error, rawUserId, context) => {
      const userId = resolveUserId({ user_id: rawUserId });

      if (userId) {
        if (context?.nextIsBlocked) {
          setUnblocked(userId);
        } else {
          setBlocked(userId);
        }
      }

      restoreSnapshots(queryClient, context?.previousSnapshots);

      showToast(
        error?.response?.data?.message || "Failed to update block status",
        "error",
      );
    },
  });

  const handleToggleBlock = useCallback(
    async (userId) => {
      const normalizedUserId = resolveUserId({ user_id: userId });

      if (!normalizedUserId || blockMutation.isPending) {
        return;
      }

      await blockMutation.mutateAsync(normalizedUserId);
    },
    [blockMutation],
  );

  const isBlocked = useCallback(
    (userId) => {
      const normalizedUserId = resolveUserId({ user_id: userId });

      return normalizedUserId ? blockedUsers.has(normalizedUserId) : false;
    },
    [blockedUsers],
  );

  const isBlockedBy = useCallback(
    (userId) => {
      const normalizedUserId = resolveUserId({ user_id: userId });

      return normalizedUserId ? blockedByUsers.has(normalizedUserId) : false;
    },
    [blockedByUsers],
  );

  return {
    isBlocked,
    isBlockedBy,
    toggleBlock: handleToggleBlock,
    isToggling: blockMutation.isPending,
  };
};
