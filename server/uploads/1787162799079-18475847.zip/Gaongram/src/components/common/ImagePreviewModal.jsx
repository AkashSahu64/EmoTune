import React from "react";
import { X } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import Modal from "./Modal.jsx";

const ImagePreviewModal = ({
  isOpen,
  onClose,
  image,
  alt = "Preview",
}) => {
  if (!image) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.94 }}
            transition={{ duration: 0.2 }}
            className="
              relative
              w-full
              max-w-5xl
              mx-auto
              rounded-2xl
              overflow-hidden
              bg-black
              shadow-2xl
            "
          >
            {/* Close button */}
            <button
              onClick={onClose}
              className="
                absolute
                top-3
                right-3
                z-20
                flex
                items-center
                justify-center
                w-10
                h-10
                rounded-full
                bg-black/50
                text-white
                backdrop-blur
                hover:bg-black/70
                transition
              "
            >
              <X size={22} />
            </button>

            {/* Image */}
            <div className="flex items-center justify-center bg-black">
              <img
                src={image}
                alt={alt}
                className="
                  max-h-[90vh]
                  w-auto
                  max-w-full
                  object-contain
                "
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </Modal>
  );
};

export default ImagePreviewModal;