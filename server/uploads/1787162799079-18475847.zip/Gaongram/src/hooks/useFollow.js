import { useCallback } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { profileAPI } from "../features/profile/profileApi";
import { profileKeys } from "../features/profile/profileKeys";
import { useFollowStore } from "../store/useFollowStore";
import { useAuth } from "./useAuth";
import { useUIStore } from "../store/uiStore";
import { showToast } from "../utils/toast";

const DEFAULT_FOLLOW_STATE = {
  isFollowing: false,
  isRequested: false,
  isLoading: false,
};

const pickDefined = (...values) =>
  values.find((value) => value !== undefined && value !== null);

const getOptimisticFollowState = (currentState, isPrivateAccount) => {
  if (isPrivateAccount) {
    if (!currentState.isFollowing && !currentState.isRequested) {
      return { isFollowing: false, isRequested: true };
    }

    if (currentState.isRequested) {
      return { isFollowing: false, isRequested: false };
    }

    if (currentState.isFollowing) {
      return { isFollowing: false, isRequested: false };
    }
  }

  return currentState.isFollowing
    ? { isFollowing: false, isRequested: false }
    : { isFollowing: true, isRequested: false };
};

const getResolvedFollowState = (
  response,
  optimisticState,
  previousState,
) => {
  const payload = response?.data ?? response ?? {};
  const nestedPayload = payload?.data ?? {};
  const message = String(
    pickDefined(
      payload?.message,
      payload?.detail,
      nestedPayload?.message,
      nestedPayload?.detail,
      "",
    ),
  ).toLowerCase();

  const explicitFollowing = pickDefined(
    nestedPayload?.is_following,
    payload?.is_following,
    nestedPayload?.following,
    payload?.following,
    nestedPayload?.isFollowing,
    payload?.isFollowing,
  );
  const explicitRequested = pickDefined(
    nestedPayload?.is_following_requested,
    payload?.is_following_requested,
    nestedPayload?.requested,
    payload?.requested,
    nestedPayload?.isRequested,
    payload?.isRequested,
  );

  if (explicitFollowing !== undefined || explicitRequested !== undefined) {
    return {
      isFollowing: Boolean(explicitFollowing),
      isRequested: Boolean(explicitRequested),
    };
  }

  if (
    message.includes("request") &&
    !message.includes("cancel") &&
    !message.includes("withdraw") &&
    !message.includes("remove")
  ) {
    return { isFollowing: false, isRequested: true };
  }

  if (
    (message.includes("cancel") || message.includes("withdraw")) &&
    message.includes("request")
  ) {
    return { isFollowing: false, isRequested: false };
  }

  if (message.includes("unfollow") || message.includes("removed")) {
    return { isFollowing: false, isRequested: false };
  }

  if (message.includes("follow")) {
    return { isFollowing: true, isRequested: false };
  }

  return {
    isFollowing: optimisticState.isFollowing ?? previousState.isFollowing,
    isRequested: optimisticState.isRequested ?? previousState.isRequested,
  };
};

const updateUserRelationship = (record, userId, nextState) => {
  const recordId = record?.user_id ?? record?.id;

  if (!recordId || String(recordId) !== String(userId)) {
    return record;
  }

  return {
    ...record,
    is_following: nextState.isFollowing,
    is_following_requested: nextState.isRequested,
  };
};

const updateProfileRecord = (record, userId, nextState) => {
  const recordUserId = record?.user_id ?? record?.userId;

  if (!recordUserId || String(recordUserId) !== String(userId)) {
    return record;
  }

  const previousFollowing = Boolean(record.is_following ?? record.isFollowing);
  const followersCount =
    typeof record.followers_count === "number"
      ? Math.max(
          0,
          record.followers_count +
            (nextState.isFollowing === previousFollowing
              ? 0
              : nextState.isFollowing
              ? 1
              : -1),
        )
      : record.followers_count;

  return {
    ...record,
    is_following: nextState.isFollowing,
    is_following_requested: nextState.isRequested,
    followers_count: followersCount,
  };
};

const updateProfileQueryData = (queryData, userId, nextState) => {
  if (!queryData) return queryData;

  if (Array.isArray(queryData.pages)) {
    let pagesChanged = false;

    const pages = queryData.pages.map((page) => {
      if (Array.isArray(page?.results)) {
        let hasChanges = false;
        const results = page.results.map((item) => {
          const nextItem = updateUserRelationship(item, userId, nextState);
          if (nextItem !== item) hasChanges = true;
          return nextItem;
        });

        if (hasChanges) {
          pagesChanged = true;
          return { ...page, results };
        }
      }

      if (Array.isArray(page?.users)) {
        let hasChanges = false;
        const users = page.users.map((item) => {
          const nextItem = updateUserRelationship(item, userId, nextState);
          if (nextItem !== item) hasChanges = true;
          return nextItem;
        });

        if (hasChanges) {
          pagesChanged = true;
          return { ...page, users };
        }
      }

      return page;
    });

    return pagesChanged ? { ...queryData, pages } : queryData;
  }

  if (Array.isArray(queryData.results)) {
    let hasChanges = false;
    const results = queryData.results.map((item) => {
      const nextItem = updateUserRelationship(item, userId, nextState);
      if (nextItem !== item) hasChanges = true;
      return nextItem;
    });

    return hasChanges ? { ...queryData, results } : queryData;
  }

  if (queryData?.user_id || queryData?.userId) {
    return updateProfileRecord(queryData, userId, nextState);
  }

  return queryData;
};

const patchFollowCaches = (queryClient, userId, nextState) => {
  const queries = queryClient.getQueriesData({ queryKey: profileKeys.all });

  for (const [queryKey, queryData] of queries) {
    const nextQueryData = updateProfileQueryData(queryData, userId, nextState);

    if (nextQueryData !== queryData) {
      queryClient.setQueryData(queryKey, nextQueryData);
    }
  }
};

export const useFollow = (userId, userIsPrivate = false) => {
  const { user } = useAuth();
  const { openModal } = useUIStore();
  const queryClient = useQueryClient();
  const followEntry = useFollowStore((state) => state.followMap[userId]);
  const followState = followEntry || DEFAULT_FOLLOW_STATE;
  const getFollowState = useFollowStore((state) => state.getFollowState);
  const setFollowState = useFollowStore((state) => state.setFollowState);
  const syncFromProfile = useFollowStore((state) => state.syncFromProfile);

  const followMutation = useMutation({
    mutationKey: ["follow", String(userId)],
    mutationFn: () => profileAPI.toggleFollow(userId),
    onMutate: async () => {
      const previousState = getFollowState(userId);
      const optimisticState = getOptimisticFollowState(
        previousState,
        userIsPrivate,
      );

      setFollowState(userId, {
        ...optimisticState,
        isLoading: true,
      });
      patchFollowCaches(queryClient, userId, optimisticState);

      return { previousState, optimisticState };
    },
    onSuccess: (response, _variables, context) => {
      const nextState = getResolvedFollowState(
        response,
        context?.optimisticState || DEFAULT_FOLLOW_STATE,
        context?.previousState || DEFAULT_FOLLOW_STATE,
      );

      setFollowState(userId, {
        ...nextState,
        isLoading: false,
      });
      patchFollowCaches(queryClient, userId, nextState);
      queryClient.invalidateQueries({ queryKey: profileKeys.all });

      showToast(
        pickDefined(
          response?.message,
          response?.data?.message,
          "Follow state updated",
        ),
        "success",
      );
    },
    onError: (error, _variables, context) => {
      const rollbackState = context?.previousState || DEFAULT_FOLLOW_STATE;

      setFollowState(userId, {
        ...rollbackState,
        isLoading: false,
      });
      patchFollowCaches(queryClient, userId, rollbackState);

      showToast(
        error.response?.data?.message || "Unable to update follow state",
        "error",
      );
    },
  });

  const handleToggleFollow = useCallback(async () => {
    if (!user) {
      openModal("login");
      return;
    }

    if (!userId || followState.isLoading) {
      return;
    }

    if (
      String(user.user_id || user.id) === String(userId) ||
      String(user.id || user.user_id) === String(userId)
    ) {
      return;
    }

    await followMutation.mutateAsync();
  }, [
    followMutation,
    followState.isLoading,
    openModal,
    user,
    userId,
  ]);

  const getFollowButtonState = useCallback(() => {
    if (followState.isRequested) {
      return { label: "Requested", variant: "outline", disabled: false };
    }

    if (followState.isFollowing) {
      return { label: "Following", variant: "outline", disabled: false };
    }

    return { label: "Follow", variant: "primary", disabled: false };
  }, [followState.isFollowing, followState.isRequested]);

  return {
    hasState: Boolean(followEntry),
    isFollowing: followState.isFollowing,
    isFollowingRequested: followState.isRequested,
    isLoading: followState.isLoading || followMutation.isPending,
    toggleFollow: handleToggleFollow,
    getFollowButtonState,
    syncFromProfile,
    setFollowState,
  };
};
