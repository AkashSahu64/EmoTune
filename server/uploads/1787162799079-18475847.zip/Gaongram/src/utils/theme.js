export const THEME_STORAGE_KEY = "theme";

export const getStoredTheme = () => {
  if (typeof localStorage === "undefined") return null;
  const theme = localStorage.getItem(THEME_STORAGE_KEY);
  return theme === "dark" || theme === "light" ? theme : null;
};

export const getInitialTheme = () => {
  const storedTheme = getStoredTheme();
  if (storedTheme) return storedTheme;

  if (
    typeof window !== "undefined" &&
    window.matchMedia?.("(prefers-color-scheme: dark)").matches
  ) {
    return "dark";
  }

  return "light";
};

export const applyTheme = (theme) => {
  const normalizedTheme = theme === "dark" ? "dark" : "light";

  if (typeof document !== "undefined") {
    document.documentElement.classList.toggle(
      "dark",
      normalizedTheme === "dark",
    );
  }

  if (typeof localStorage !== "undefined") {
    localStorage.setItem(THEME_STORAGE_KEY, normalizedTheme);
  }

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("gaongram:theme-change", {
        detail: { theme: normalizedTheme },
      }),
    );
  }

  return normalizedTheme;
};

export const initializeTheme = () => applyTheme(getInitialTheme());