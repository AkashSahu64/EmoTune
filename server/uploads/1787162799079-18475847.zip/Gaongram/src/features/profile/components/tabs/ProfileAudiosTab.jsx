import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ChevronRight, Clock3, Disc3, Music2 } from "lucide-react";
import Button from "../../../../components/common/Button";
import { useMediaStore } from "../../../../store/mediaStore";
import { useProfileContent } from "../../useProfileContent";
import Loader from "../../../../components/common/Loader";

const formatDuration = (value) => {
  const totalSeconds = Math.max(0, Math.floor(Number(value || 0)));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${minutes}:${seconds.toString().padStart(2, "0")}`;
};

const AudioDuration = ({ audioUrl }) => {
  const [duration, setDuration] = useState(0);

  useEffect(() => {
    if (!audioUrl) return;

    const audio = new Audio(audioUrl);

    const handleLoadedMetadata = () => {
      setDuration(audio.duration || 0);
    };

    audio.addEventListener("loadedmetadata", handleLoadedMetadata);

    return () => {
      audio.removeEventListener("loadedmetadata", handleLoadedMetadata);
    };
  }, [audioUrl]);

  return (
    <div className="flex items-center gap-1 text-xs text-mutedForeground dark:text-mutedForeground-dark">
      <Clock3 className="h-3 w-3" />
      <span>{formatDuration(duration)}</span>
    </div>
  );
};

const AudioSkeleton = () => (
  <div className="space-y-3">
    {Array.from({ length: 5 }).map((_, idx) => (
      <div
        key={idx}
        className="flex items-center gap-3 rounded-xl border border-border dark:border-border-dark bg-muted dark:bg-muted-dark px-3 py-2 animate-pulse"
      >
        <div className="h-12 w-12 rounded-lg bg-muted dark:bg-muted-dark" />
        <div className="flex-1 space-y-2">
          <div className="h-4 w-3/4 rounded bg-muted dark:bg-muted-dark" />
          <div className="h-3 w-1/2 rounded bg-muted dark:bg-muted-dark " />
        </div>
        <div className="h-4 w-12 rounded bg-muted dark:bg-muted-dark" />
      </div>
    ))}
  </div>
);

const EmptyState = ({ username }) => (
  <div className="flex flex-col items-center px-6 py-14 text-center shadow-sm">
    <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted dark:bg-muted-dark text-foreground dark:text-foreground-dark">
      <Music2 className="h-7 w-7" />
    </div>
    <h3 className="mt-5 text-xl font-semibold tracking-[-0.02em] text-foreground dark:text-foreground-dark">
      No audios from @{username}
    </h3>
    <p className="mt-2 max-w-sm text-sm leading-6 text-mutedForeground dark:text-mutedForeground-dark">
      Audio uploads and sound snippets will appear here when they are posted.
    </p>
  </div>
);

const ProfileAudiosTab = ({ profileUserId, username }) => {
  const navigate = useNavigate();
  const setActivePost = useMediaStore((state) => state.setActivePost);

  const { items, isLoading, hasNextPage, fetchNextPage, isFetchingNextPage } =
    useProfileContent(profileUserId, "audios");

  const handleAudioClick = (audioId) => {
    setActivePost(audioId);
    navigate(`/audio?start=${audioId}&fromProfile=${profileUserId}`);
  };

  useEffect(() => {
if (hasNextPage && !isFetchingNextPage) {
fetchNextPage();
}
}, [hasNextPage, isFetchingNextPage, fetchNextPage]);

  if (isLoading && !items.length) {
    return <AudioSkeleton />;
  }

  if (!items.length) {
    return <EmptyState username={username} />;
  }

  return (
    <div className="space-y-1">
      {items.map((item) => {
        const title = item.audio?.title || item.caption || "Untitled audio";
        const coverImage = item.audio?.cover_image || item.previewImage;

        return (
          <motion.button
            key={item.id}
            type="button"
            whileTap={{ scale: 0.99 }}
            onClick={() => handleAudioClick(item.id)}
            className="flex w-full items-center gap-3 rounded-lg border border-border dark:border-border-dark bg-muted dark:bg-muted-dark px-3 py-2 text-left hover:bg-card dark:hover:bg-card-dark transition-colors"
          >
            <div className="relative h-12 w-12 flex-shrink-0 overflow-hidden rounded-lg bg-muted dark:bg-muted-dark">
              {coverImage ? (
                <img
                  src={coverImage}
                  alt=""
                  loading="lazy"
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center bg-[linear-gradient(135deg,rgba(14,77,56,0.95),rgba(17,97,73,0.78)_55%,rgba(198,167,94,0.5))] text-white">
                  <Disc3 className="h-7 w-7" />
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/35 to-transparent" />
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate text-base font-semibold tracking-[-0.01em] text-foreground dark:text-foreground-dark">
                    {title}
                  </p>
                  <p className="mt-1 truncate text-sm text-mutedForeground dark:text-mutedForeground-dark">
                    @{username}
                  </p>
                </div>
                <div className="flex items-center self-center">
                  {" "}
                  <AudioDuration audioUrl={item.audio?.audio} />{" "}
                </div>
              </div>
            </div>
          </motion.button>
        );
      })}

      {hasNextPage && ( <div className="flex justify-center py-4"> <Loader size="small" color="instagram-pink" text="Loading more audios..." /> </div> )}
    </div>
  );
};

export default React.memo(ProfileAudiosTab);
