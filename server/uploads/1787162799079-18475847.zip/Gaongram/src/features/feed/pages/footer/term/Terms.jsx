// src/pages/TermsAndConditions.jsx
import React, { useRef, useState, useEffect } from "react";
import { motion, useInView, useScroll, useTransform } from "framer-motion";
import {
  FileText,
  Shield,
  Lock,
  AlertTriangle,
  Scale,
  Ban,
  Gavel,
  ChevronDown,
  CheckCircle,
  HelpCircle,
  ArrowRight,
  Copy,
  Globe,
  Clock,
  Smartphone,
  ExternalLink,
  BookOpen,
} from "lucide-react";
import MinimalLayout from "../../../components/layout/MinimalLayout";
import Seo from "../../../../../components/seo/Seo.jsx";
import { buildStaticPageSeo } from "../../../../../seo/seoBuilders.js";

// Animation variants
const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
};

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.06 },
  },
};

// Instagram-style Accordion (enhanced)
const TermsAccordion = ({
  id,
  title,
  icon: Icon,
  children,
  defaultOpen = false,
  summary,
  onToggle,
}) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  const handleToggle = () => {
    setIsOpen(!isOpen);
    if (onToggle) onToggle(id, !isOpen);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="border-b border-border/30 dark:border-border-dark/30 last:border-0"
    >
      <button
        onClick={handleToggle}
        className="w-full py-5 flex items-start gap-4 text-left hover:bg-muted/20 dark:hover:bg-muted-dark/20 transition-all duration-200 px-3 rounded-lg group"
      >
        {Icon && (
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center flex-shrink-0 group-hover:from-primary/20 group-hover:to-primary/10 transition-colors">
            <Icon className="w-5 h-5 text-primary" />
          </div>
        )}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-base md:text-lg font-semibold text-foreground dark:text-foreground-dark">
              {title}
            </span>
            {!isOpen && summary && (
              <span className="text-xs text-mutedForeground/70 hidden sm:inline-block">
                —
              </span>
            )}
          </div>
          {!isOpen && summary && (
            <p className="text-sm text-mutedForeground dark:text-mutedForeground-dark mt-0.5 line-clamp-1 pr-4">
              {summary}
            </p>
          )}
        </div>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.25 }}
          className="p-1 rounded-full hover:bg-muted/30"
        >
          <ChevronDown className="w-5 h-5 text-mutedForeground" />
        </motion.div>
      </button>
      <motion.div
        initial={false}
        animate={{ height: isOpen ? "auto" : 0, opacity: isOpen ? 1 : 0 }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
        className="overflow-hidden"
      >
        <div className="pb-6 px-3 md:px-12 prose prose-sm md:prose-base dark:prose-invert max-w-none text-mutedForeground dark:text-mutedForeground-dark">
          {children}
        </div>
      </motion.div>
    </motion.div>
  );
};

// TL;DR Card (enhanced)
const TLDRCard = ({ title, points }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="bg-gradient-to-br from-primary/5 via-transparent to-viral-pink/5 dark:from-primary/10 dark:to-viral-pink/10 rounded-2xl p-6 border border-primary/20 shadow-soft"
    >
      <div className="flex items-center gap-3 mb-4">
        <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
          <Copy className="w-4 h-4 text-primary" />
        </div>
        <h4 className="font-bold text-foreground dark:text-foreground-dark">
          {title}
        </h4>
      </div>
      <div className="grid sm:grid-cols-2 gap-3">
        {points.map((point, idx) => (
          <div key={idx} className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
            <span className="text-sm text-mutedForeground dark:text-mutedForeground-dark">
              {point}
            </span>
          </div>
        ))}
      </div>
    </motion.div>
  );
};

// Quick Stats Bar (enhanced)
const QuickStatsBar = () => {
  const stats = [
    { icon: Clock, label: "Effective Date", value: "March 15, 2026" },
    { icon: Globe, label: "Governing Law", value: "Republic of India" },
    { icon: FileText, label: "Version", value: "GG-TOS-2026-V2" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-wrap items-center justify-center gap-6 md:gap-8 py-4 px-4 border-y border-border/50 dark:border-border-dark/50 my-6"
    >
      {stats.map((stat, idx) => {
        const Icon = stat.icon;
        return (
          <div key={idx} className="flex items-center gap-2 text-sm">
            <Icon className="w-4 h-4 text-primary/70" />
            <span className="text-mutedForeground">{stat.label}:</span>
            <span className="font-medium text-foreground dark:text-foreground-dark">
              {stat.value}
            </span>
          </div>
        );
      })}
    </motion.div>
  );
};

// Main Terms Page
const Terms = () => {
  const [activeSection, setActiveSection] = useState("acceptance");
  const [openSections, setOpenSections] = useState({ acceptance: true }); // 初始只打开第一个
  const sectionRefs = useRef({});
  const contentRef = useRef(null);

  const tocSections = [
    {
      id: "acceptance",
      shortTitle: "Acceptance",
      title: "1. Acceptance and Scope",
    },
    {
      id: "license",
      shortTitle: "License",
      title: "2. License Grant and Restrictions",
    },
    {
      id: "ip",
      shortTitle: "IP Rights",
      title: "3. Intellectual Property Rights",
    },
    { id: "ugc", shortTitle: "UGC", title: "4. User-Generated Content" },
    {
      id: "liability",
      shortTitle: "Liability",
      title: "5. Disclaimers and Liability",
    },
    {
      id: "indemnification",
      shortTitle: "Indemnity",
      title: " Indemnification",
    },
    {
      id: "termination",
      shortTitle: "Termination",
      title: "7. Account Termination",
    },
    { id: "governing", shortTitle: "Governing Law", title: "8. Governing Law" },
  ];

  const scrollToSection = (sectionId) => {
    const element = sectionRefs.current[sectionId];
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
      setActiveSection(sectionId);
      setOpenSections((prev) => ({ ...prev, [sectionId]: true }));
    }
  };

  const handleAccordionToggle = (id, isOpen) => {
    setOpenSections((prev) => ({ ...prev, [id]: isOpen }));
    if (isOpen) {
      setActiveSection(id);
    }
  };

  // Intersection Observer to highlight active section
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const id = entry.target.getAttribute("data-section-id");
            if (id) setActiveSection(id);
          }
        });
      },
      { rootMargin: "-20% 0px -60% 0px" },
    );

    Object.values(sectionRefs.current).forEach((el) => {
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const quickSummary = [
    "By using GaonGram, you agree to comply with these terms",
    "You retain ownership of your content while granting us permission to display it",
    "Our services are provided 'as is' without warranties",
    "Violations may lead to account suspension or termination",
    "These terms are governed by the laws of India",
  ];

  const beforeYouStart = [
    "You must be at least 13 years old to use GaonGram",
    "Review our Community Guidelines and Privacy Policy",
    "Keep your account secure and never share your password",
    "Contact our support team if you need assistance",
  ];

  return (
    <MinimalLayout>
      <Seo {...buildStaticPageSeo("terms")} />
      <div className="min-h-screen bg-background dark:bg-background-dark">
        {/* Hero — refined */}
        <section className="pt-16 pb-8 md:pb-12">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground dark:text-foreground-dark mb-4 tracking-tight">
                Terms & Conditions
              </h1>
              <p className="text-lg md:text-xl text-mutedForeground dark:text-mutedForeground-dark max-w-2xl mx-auto">
                Please read these terms carefully before using GaonGram.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Quick Stats Bar */}
        <div className="max-w-4xl mx-auto px-4">
          <QuickStatsBar />
        </div>

        {/* Main content area with sidebar on large screens */}
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="flex gap-8">
            {/* Main content column */}
            <div className="flex-1 min-w-0" ref={contentRef}>
              {/* Before You Start */}
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-card dark:bg-card-dark rounded-xl border border-border dark:border-border-dark p-5 mb-6 shadow-soft"
              >
                <div className="flex items-center gap-2 mb-3">
                  <HelpCircle className="w-5 h-5 text-primary" />
                  <h3 className="font-semibold text-foreground dark:text-foreground-dark">
                    Before You Start
                  </h3>
                </div>
                <div className="grid sm:grid-cols-2 gap-2">
                  {beforeYouStart.map((item, idx) => (
                    <div key={idx} className="flex items-start gap-2">
                      <CheckCircle className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-mutedForeground dark:text-mutedForeground-dark">
                        {item}
                      </span>
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* TL;DR Summary */}
              <TLDRCard title="In Simple Terms" points={quickSummary} />

              {/* Accordion Container */}
              <div className="mt-8 bg-card dark:bg-card-dark rounded-2xl border border-border dark:border-border-dark shadow-soft overflow-hidden divide-y divide-border dark:divide-border-dark">
                {/* Section 1 */}
                <div
                  ref={(el) => (sectionRefs.current["acceptance"] = el)}
                  data-section-id="acceptance"
                >
                  <TermsAccordion
                    id="acceptance"
                    title="1. Acceptance and Scope"
                    icon={FileText}
                    defaultOpen={openSections.acceptance}
                    onToggle={handleAccordionToggle}
                    summary="This document governs your access to and use of GaonGram."
                  >
                    <p>
                      This document governs your access to and use of the
                      GaonGram mobile application, website, and related
                      services. By creating an account, you enter into a binding
                      legal contract. If you do not agree to these terms, you
                      are prohibited from using the service. These terms apply
                      to all visitors, users, and others who access or use the
                      Service.
                    </p>
                  </TermsAccordion>
                </div>

                {/* Section 2 */}
                <div
                  ref={(el) => (sectionRefs.current["license"] = el)}
                  data-section-id="license"
                >
                  <TermsAccordion
                    id="license"
                    title="2. License Grant and Restrictions"
                    icon={Shield}
                    onToggle={handleAccordionToggle}
                    summary="GaonGram grants you a limited license to use the platform."
                  >
                    <p>
                      GaonGram Technologies Private Limited grants you a
                      personal, non-exclusive, non-transferable, revocable
                      license to use the platform strictly in accordance with
                      these terms.
                    </p>
                    <ul className="list-disc pl-5 space-y-2 mt-3">
                      <li>
                        <strong>Prohibited Use:</strong> You may not modify,
                        decompile, or reverse-engineer the application.
                      </li>
                      <li>
                        <strong>Commercial Use:</strong> You may not use
                        GaonGram for unauthorized commercial purposes, such as
                        mass-marketing (spam) or as a gateway for unregulated
                        financial lending.
                      </li>
                      <li>
                        <strong>Automation:</strong> The use of "bots,"
                        "spiders," or automated scripts to scrape data from the
                        platform is a violation of this license.
                      </li>
                    </ul>
                  </TermsAccordion>
                </div>

                {/* Section 3 */}
                <div
                  ref={(el) => (sectionRefs.current["ip"] = el)}
                  data-section-id="ip"
                >
                  <TermsAccordion
                    id="ip"
                    title="3. Intellectual Property (IP) Rights"
                    icon={Lock}
                    onToggle={handleAccordionToggle}
                    summary="GaonGram's name, logo, and AI are protected by law."
                  >
                    <ul className="list-disc pl-5 space-y-2">
                      <li>
                        <strong>Our Property:</strong> The GaonGram name, logo,
                        "Gram-Vigil" AI, and proprietary interfaces are
                        protected by Indian and International copyright and
                        trademark laws.
                      </li>
                      <li>
                        <strong>Your License to Us:</strong> While you own the
                        content you post, you grant GaonGram a non-exclusive,
                        royalty-free, worldwide license to host, display, and
                        distribute that content. This is necessary for us to
                        show your posts to your followers and store your data on
                        our servers.
                      </li>
                    </ul>
                  </TermsAccordion>
                </div>

                {/* Section 4 */}
                <div
                  ref={(el) => (sectionRefs.current["ugc"] = el)}
                  data-section-id="ugc"
                >
                  <TermsAccordion
                    id="ugc"
                    title="4. User-Generated Content (UGC) Warranty"
                    icon={CheckCircle}
                    onToggle={handleAccordionToggle}
                    summary="You are responsible for the content you post."
                  >
                    <p>
                      You are solely responsible for the content you post. You
                      represent and warrant that:
                    </p>
                    <ul className="list-disc pl-5 space-y-2 mt-3">
                      <li>
                        You own the content or have the necessary licenses to
                        share it.
                      </li>
                      <li>
                        The content does not violate the privacy or intellectual
                        property rights of any third party.
                      </li>
                      <li>
                        The content complies with our Community Guidelines
                        (Section 3 of the Master Manual).
                      </li>
                    </ul>
                  </TermsAccordion>
                </div>

                {/* Section 5 */}
                <div
                  ref={(el) => (sectionRefs.current["liability"] = el)}
                  data-section-id="liability"
                >
                  <TermsAccordion
                    id="liability"
                    title="5. Disclaimers and Limitation of Liability"
                    icon={AlertTriangle}
                    onToggle={handleAccordionToggle}
                    summary="GaonGram is provided 'as-is' with limited liability."
                  >
                    <ul className="list-disc pl-5 space-y-2">
                      <li>
                        <strong>"As-Is" Basis:</strong> GaonGram is provided
                        without any warranties, express or implied. We do not
                        guarantee that the app will always be functional or
                        error-free.
                      </li>
                      <li>
                        <strong>Intermediary Status:</strong> Under Section 79
                        of the Information Technology Act, 2000, GaonGram is an
                        intermediary. We are not liable for the individual
                        opinions, advice, or third-party links shared by users.
                      </li>
                      <li>
                        <strong>Damage Cap:</strong> To the maximum extent
                        permitted by law, GaonGram’s liability for any claim
                        shall not exceed ₹5,000 (Five Thousand Indian Rupees) or
                        the amount paid by you to use the service in the last
                        six months, whichever is lower.
                      </li>
                    </ul>
                  </TermsAccordion>
                </div>

                {/* Section 6 */}
                <div
                  ref={(el) => (sectionRefs.current["indemnification"] = el)}
                  data-section-id="indemnification"
                >
                  <TermsAccordion
                    id="indemnification"
                    title="6. Indemnification"
                    icon={Scale}
                    onToggle={handleAccordionToggle}
                    summary="You agree to protect GaonGram from claims arising from your actions."
                  >
                    <p>
                      You agree to indemnify and hold GaonGram Technologies
                      Private Limited harmless from any claims, losses, or legal
                      fees resulting from:
                    </p>
                    <ul className="list-disc pl-5 space-y-2 mt-3">
                      <li>Your violation of these Terms.</li>
                      <li>Your infringement of any third-party rights.</li>
                      <li>
                        Any harmful content you upload that causes real-world
                        damage or communal unrest.
                      </li>
                    </ul>
                  </TermsAccordion>
                </div>

                {/* Section 7 */}
                <div
                  ref={(el) => (sectionRefs.current["termination"] = el)}
                  data-section-id="termination"
                >
                  <TermsAccordion
                    id="termination"
                    title="7. Account Termination"
                    icon={Ban}
                    onToggle={handleAccordionToggle}
                    summary="We may suspend or terminate your account for violations."
                  >
                    <p>
                      We reserve the right to suspend or terminate your account
                      at our sole discretion, without notice, for conduct that
                      we believe violates these Terms or is harmful to other
                      users, us, or third parties, or for any other reason. Upon
                      termination, your right to use the Service will
                      immediately cease.
                    </p>
                  </TermsAccordion>
                </div>

                {/* Section 8 */}
                <div
                  ref={(el) => (sectionRefs.current["governing"] = el)}
                  data-section-id="governing"
                >
                  <TermsAccordion
                    id="governing"
                    title="8. Governing Law and Jurisdiction"
                    icon={Gavel}
                    onToggle={handleAccordionToggle}
                    summary="These terms are governed by the laws of India."
                  >
                    <p>
                      These Terms shall be governed and construed in accordance
                      with the laws of the Republic of India. Any disputes
                      arising under these terms shall be subject to the
                      exclusive jurisdiction of the courts located in the city
                      where GaonGram is registered.
                    </p>
                  </TermsAccordion>
                </div>
              </div>

              {/* Additional note */}
              <motion.p
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                className="text-xs text-mutedForeground text-center mt-6"
              >
                By using GaonGram, you acknowledge that you have read and
                understood these terms.
              </motion.p>
            </div>
          </div>
        </div>
      </div>
    </MinimalLayout>
  );
};

export default Terms;
