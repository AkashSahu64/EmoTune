import { useInfiniteQuery } from "@tanstack/react-query";
import { profileAPI } from "../features/profile/profileApi";
import { profileKeys } from "../features/profile/profileKeys";
import { useFollowStore } from "../store/useFollowStore";

export const useFollowersList = (userId, type = "followers") => {
  const batchUpdateFollowStates = useFollowStore(
    (state) => state.batchUpdateFollowStates,
  );

  return useInfiniteQuery({
    queryKey:
      type === "followers"
        ? profileKeys.followers(userId)
        : profileKeys.following(userId),
    queryFn: async ({ pageParam = 1 }) => {
      const params = {
        page: pageParam,
        limit: 20,
        user_id: userId,
      };

      if (type === "followers") {
        params.followers = true;
      } else {
        params.following = true;
      }

      const data = await profileAPI.getAllProfiles(params);

      if (data.results) {
        const followStates = {};

        data.results.forEach((user) => {
          if (user.user_id) {
            followStates[user.user_id] = {
              isFollowing: user.is_following || false,
              isRequested: user.is_following_requested || false,
              isLoading: false,
            };
          }
        });

        batchUpdateFollowStates(followStates);
      }

      return {
        results: data.results || [],
        nextPage: data.next ? pageParam + 1 : null,
        totalCount: data.count || 0,
      };
    },
    getNextPageParam: (lastPage) => lastPage.nextPage,
    enabled: Boolean(userId),
    initialPageParam: 1,
  });
};
