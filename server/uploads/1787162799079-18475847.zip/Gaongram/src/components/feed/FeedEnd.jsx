import React from "react";

const FeedEnd = () => (
  <p className="text-center py-4 text-sm text-muted-foreground">
    You’ve reached the end of the posts.
  </p>
);

export default FeedEnd;