// src/features/profile/tabs/ProfilePostsTab.jsx (updated)
import React, { useRef, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import Hls from "hls.js";
import {
  Heart,
  ImageIcon,
  MessageCircle,
  Music2,
  Play,
  Type,
  BarChart3,
} from "lucide-react";
import { useProfileContent } from "../../useProfileContent";
import { getTextGradient } from "../../../../utils/getTextGradient";
import SensitiveContentOverlay from "../../../../components/vibe/SensitiveContentOverlay.jsx";
import { useAuthStore } from "../../../../store/authStore.js";
import { calculateAge } from "../../../../utils/calculateAge.js";

const compactNumberFormatter = new Intl.NumberFormat("en", {
  notation: "compact",
  maximumFractionDigits: 1,
});

const formatCompactNumber = (value) =>
  compactNumberFormatter.format(Number(value || 0));

const GridSkeleton = () => (
  <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 sm:gap-3 auto-rows-[120px] sm:auto-rows-[150px]">
    {Array.from({ length: 6 }).map((_, index) => (
      <div key={index} className="animate-pulse rounded-2xl bg-muted dark:bg-muted-dark" />
    ))}
  </div>
);

const EmptyState = ({ isOwnProfile, username }) => (
  <div className="flex flex-col items-center px-6 py-14 text-center">
    <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted dark:bg-muted-dark text-foreground dark:text-foreground-dark">
      <ImageIcon className="h-7 w-7" />
    </div>
    <h3 className="mt-5 text-xl font-semibold tracking-[-0.02em] text-foreground dark:text-foreground-dark">
      {isOwnProfile
        ? "Your posts will show up here"
        : `No posts from @${username}`}
    </h3>
    <p className="mt-2 max-w-sm text-sm leading-6 text-mutedForeground dark:text-mutedForeground-dark">
      {isOwnProfile
        ? "Share a photo, video, audio, or thought and your profile grid will start filling in."
        : "This creator has not shared anything in this section yet."}
    </p>
  </div>
);

const ContentTypeBadge = ({ item }) => {
  const badgeClass =
    "flex h-8 w-8 items-center justify-center rounded-full bg-black/45 text-white backdrop-blur";

  // Multi Asset
  if (item.isMultiAsset) {
    return (
      <div className={badgeClass}>
        <ImageIcon className="h-4 w-4" />
      </div>
    );
  }

  // Poll
  if (item.mediaType === "poll") {
    return (
      <div className={badgeClass}>
        <BarChart3 className="h-4 w-4" />
      </div>
    );
  }

  // Video
  if (item.mediaType === "video") {
    return (
      <div className={badgeClass}>
        <Play className="h-4 w-4 fill-current" />
      </div>
    );
  }

  // Audio
  if (item.mediaType === "audio") {
    return (
      <div className={badgeClass}>
        <Music2 className="h-4 w-4" />
      </div>
    );
  }

  // Image
  if (item.mediaType === "image") {
    return (
      <div className={badgeClass}>
        <ImageIcon className="h-4 w-4" />
      </div>
    );
  }

  // Text
  if (item.mediaType === "text") {
    return (
      <div className={badgeClass}>
        <Type className="h-4 w-4" />
      </div>
    );
  }

  return null;
};

const ProfilePostsTab = ({ profileUserId, isOwnProfile, username }) => {
  const navigate = useNavigate();
  const loadMoreRef = useRef(null);
  const videoRefs = useRef({});
  const hlsRefs = useRef({});

  const { user } = useAuthStore();

  const profileDob = user?.dob || user?.profile?.dob;

  const age = calculateAge(profileDob);

  const isUnder18 = typeof age === "number" && age < 18;

  const sensitiveAllowed =
    user?.is_sensitive_allowed ?? user?.profile?.is_sensitive_allowed;

  const canViewSensitive =
    sensitiveAllowed === true && typeof age === "number" && !isUnder18;

  const { items, isLoading, hasNextPage, fetchNextPage, isFetchingNextPage } =
    useProfileContent(profileUserId, "posts");

  useEffect(() => {
    if (!loadMoreRef.current) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasNextPage && !isFetchingNextPage) {
          fetchNextPage();
        }
      },
      { threshold: 1 },
    );

    observer.observe(loadMoreRef.current);

    return () => observer.disconnect();
  }, [hasNextPage, isFetchingNextPage, fetchNextPage]);
  useEffect(() => {
    return () => {
      Object.values(hlsRefs.current).forEach((hls) => {
        if (hls) hls.destroy();
      });
    };
  }, []);

  // Hover Play
  const handleMouseEnter = async (item) => {
    const video = videoRefs.current[item.id];

    if (!video) return;

    const videoUrl =
      item.video || item.videoUrl || item.media_url || item.videos?.[0]?.video;

    if (!videoUrl) return;

    try {
      // HLS Support
      if (videoUrl.includes(".m3u8")) {
        if (Hls.isSupported()) {
          // Destroy old instance
          if (hlsRefs.current[item.id]) {
            hlsRefs.current[item.id].destroy();
          }

          const hls = new Hls({
            enableWorker: true,
            lowLatencyMode: true,
          });

          hls.loadSource(videoUrl);
          hls.attachMedia(video);

          hlsRefs.current[item.id] = hls;

          hls.on(Hls.Events.MANIFEST_PARSED, async () => {
            try {
              await video.play();
            } catch (err) {
              console.log("HLS autoplay blocked:", err);
            }
          });
        }

        // Safari Native HLS
        else if (video.canPlayType("application/vnd.apple.mpegurl")) {
          video.src = videoUrl;

          video.addEventListener(
            "loadedmetadata",
            async () => {
              try {
                await video.play();
              } catch (err) {
                console.log("Safari autoplay blocked:", err);
              }
            },
            { once: true },
          );
        }

        return;
      }

      // MP4 Play
      video.currentTime = 0;
      await video.play();
    } catch (err) {
      console.log("Autoplay blocked:", err);
    }
  };

  // Hover Pause
  const handleMouseLeave = (itemId) => {
    const video = videoRefs.current[itemId];

    if (!video) return;

    video.pause();
    video.currentTime = 0;

    // Destroy HLS instance
    if (hlsRefs.current[itemId]) {
      hlsRefs.current[itemId].destroy();
      delete hlsRefs.current[itemId];
    }
  };

  // ✅ Unified click handler for ALL post types
  const handleCardClick = useCallback(
    (item) => {
      navigate(`/profile/${username}/post/${item.id}`);
    },
    [navigate, username],
  );

  const handleSensitiveClick = useCallback(
    (event, item) => {
      event.stopPropagation();

      navigate(`/profile/${username}/post/${item.id}`);
    },
    [navigate, username],
  );

  // ---------- GRID PATTERN ----------
  const pattern = [
    "",
    "",
    "row-span-2",
    "",
    "",
    "lg:col-span-2",
    "row-span-2",
    "",
    "row-span-2",
    "",
    "",
  ];

  if (isLoading && !items.length) {
    return <GridSkeleton />;
  }

  if (!items.length) {
    return <EmptyState isOwnProfile={isOwnProfile} username={username} />;
  }

  return (
    <div className="space-y-5">
      {/* ---------- GRID ---------- */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-1.5 sm:gap-2 auto-rows-[140px] sm:auto-rows-[170px] auto-flow-dense">
        {items.map((item, index) => {
          const spanClass = pattern[index % pattern.length];
          const gradientStyle = getTextGradient(item.id);
          const isSensitiveBlocked =
            item.is_sensitive === true && !canViewSensitive;

          return (
            <motion.button
              key={item.id}
              type="button"
              whileTap={{ scale: 0.98 }}
              onClick={() => handleCardClick(item)}
              onMouseEnter={() => {
                if (!isSensitiveBlocked) {
                  handleMouseEnter(item);
                }
              }}
              onMouseLeave={() => handleMouseLeave(item.id)}
              className={`group relative overflow-hidden rounded-xl bg-muted dark:bg-muted-dark text-left ${spanClass}`}
            >
              {item.mediaType === "video" ? (
                <video
                  ref={(el) => {
                    videoRefs.current[item.id] = el;
                  }}
                  src={
                    item.video ||
                    item.videoUrl ||
                    item.media_url ||
                    item.videos?.[0]?.video
                  }
                  muted
                  loop
                  playsInline
                  preload="metadata"
                  poster={item.previewImage}
                  className={` h-full w-full object-cover transition duration-500 group-hover:scale-[1.03] ${isSensitiveBlocked ? "blur-xl scale-105 brightness-75" : ""}`}
                />
              ) : item.previewImage ? (
                <img
                  src={item.previewImage}
                  alt=""
                  className={`h-full w-full object-cover transition duration-500 group-hover:scale-[1.03] ${
                    isSensitiveBlocked ? "blur-xl scale-105 brightness-75" : ""
                  }`}
                  loading="lazy"
                />
              ) : (
                <div
                  style={gradientStyle}
                  className="relative flex h-full w-full items-center justify-center p-4"
                >
                  <div className="absolute inset-0 bg-black/10" />
                  <div
                    className={`relative flex h-full w-full flex-col items-center justify-center p-4 text-center ${
                      isSensitiveBlocked
                        ? "blur-xl scale-105 brightness-75"
                        : ""
                    }`}
                  >
                    {/* Poll Preview */}
                    {item.mediaType === "poll" ? (
                      <>
                        <p className="text-sm sm:text-base font-semibold leading-relaxed text-white line-clamp-4">
                          {item.poll?.poll_question ||
                            item.poll_question ||
                            item.caption ||
                            "Poll post"}
                        </p>

                        <div className="mt-1 flex items-center gap-2 text-[11px] text-white/80">
                          <span>
                            {item.poll?.poll_options?.length ||
                              item.poll_options?.length ||
                              0}{" "}
                            options
                          </span>

                          <span>•</span>

                          <span>
                            {Object.values(item.poll?.poll_votes || {}).reduce(
                              (sum, val) => sum + Number(val || 0),
                              0,
                            )}{" "}
                            votes
                          </span>
                        </div>
                      </>
                    ) : (
                      <p className="text-sm sm:text-base font-semibold leading-relaxed text-white line-clamp-4">
                        {item.caption || "Text post"}
                      </p>
                    )}
                  </div>
                </div>
              )}

              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />

              {isSensitiveBlocked && (
                <SensitiveContentOverlay
                  compact
                  onClick={(event) => handleSensitiveClick(event, item)}
                />
              )}

              <div className="absolute right-2 top-2">
                <ContentTypeBadge item={item} />
              </div>

              <div className="absolute inset-x-0 bottom-0 p-3">
                {item.mediaType !== "text" && (
                  <p className="max-h-10 overflow-hidden text-sm font-medium text-white/95">
                    {item.caption || "Untitled post"}
                  </p>
                )}

                <div className="flex items-center gap-3 text-[11px] font-medium text-white/80">
                  <span className="flex items-center gap-1">
                    <Heart className="h-3.5 w-3.5" />
                    {formatCompactNumber(item.likesCount)}
                  </span>

                  <span className="flex items-center gap-1">
                    <MessageCircle className="h-3.5 w-3.5" />
                    {formatCompactNumber(item.commentsCount)}
                  </span>
                </div>
              </div>
            </motion.button>
          );
        })}
      </div>

      <div ref={loadMoreRef} className="h-10" />
    </div>
  );
};

export default React.memo(ProfilePostsTab);
