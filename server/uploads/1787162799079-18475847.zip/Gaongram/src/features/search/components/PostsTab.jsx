// src/pages/search/tabs/PostsTab.jsx
import React from 'react';
import { useInfiniteQuery } from '@tanstack/react-query';
import { useInView } from 'react-intersection-observer';

import { searchVibeService } from '../../../services/searchVibe.service';
import PostGrid from './PostGrid';
import EmptyState from '../../../components/common/EmptyState';

import { useTranslation } from 'react-i18next';

const PostsTab = ({ searchTerm }) => {
  const { t } = useTranslation();

  const { ref, inView } = useInView({
    threshold: 0,
    rootMargin: '1000px',
  });

  const trimmedSearch = searchTerm?.trim() || '';

  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    status,
    error,
  } = useInfiniteQuery({
    queryKey: ['search-posts', trimmedSearch],
    queryFn: ({ pageParam = 1 }) =>
      searchVibeService.searchPosts(trimmedSearch, pageParam),
    initialPageParam: 1,
    getNextPageParam: (lastPage) => lastPage.nextPage,
    enabled: true,
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000,
    refetchOnWindowFocus: false,
    retry: 1,
  });

  // Infinite scroll trigger
  React.useEffect(() => {
    if (inView && hasNextPage && !isFetchingNextPage) {
      fetchNextPage();
    }
  }, [inView, hasNextPage, isFetchingNextPage, fetchNextPage]);

  // Flatten all posts from all pages
  const allPosts = React.useMemo(() => {
    if (!data?.pages) return [];
    return data.pages.flatMap((page) => page.results || []);
  }, [data]);

  // ––––– FILTERING RULES –––––
  // When searchTerm is empty -> show ONLY posts with media (images/videos/audio)
  // When searchTerm is present -> show ALL results from API (no extra filter)
  const filteredPosts = React.useMemo(() => {
    if (!trimmedSearch) {
      return allPosts.filter(
        (post) =>
          (post.images && post.images.length > 0) ||
          (post.videos && post.videos.length > 0) ||
          post.audio
      );
    }
    return allPosts;
  }, [allPosts, trimmedSearch]);

  // Loading skeleton
  if (status === 'pending' && filteredPosts.length === 0) {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
        {Array.from({ length: 12 }).map((_, i) => (
          <div
            key={i}
            className="aspect-square rounded-xl shimmer animate-pulse bg-muted"
          />
        ))}
      </div>
    );
  }

  // Error
  if (status === 'error') {
    return (
      <EmptyState
        icon="alert"
        title={t('something_went_wrong')}
        description={error?.message}
      />
    );
  }

  // No results
  if (status === 'success' && filteredPosts.length === 0) {
    return (
      <EmptyState
        icon="image"
        title={t('no_posts_found')}
        description={
          trimmedSearch
            ? t('no_results_for', { term: trimmedSearch })
            : 'No posts available'
        }
      />
    );
  }

  return (
    <div className="pb-5">
      <PostGrid posts={filteredPosts} />

      {/* Infinite scroll trigger */}
      <div ref={ref} className="h-20" />

      {/* Bottom loading indicator */}
      {isFetchingNextPage && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 mt-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <div
              key={i}
              className="aspect-square rounded-xl shimmer animate-pulse bg-muted"
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default React.memo(PostsTab);