import { useCallback, useState } from "react";
import { compressMediaFile } from "../utils/mediaCompression.js";

export const useMediaProcessor = () => {
  const [isProcessing, setIsProcessing] = useState(false);

  const processFile = useCallback(async (file, options) => {
    setIsProcessing(true);
    try {
      return await compressMediaFile(file, options);
    } finally {
      setIsProcessing(false);
    }
  }, []);

  return { isProcessing, processFile };
};

export default useMediaProcessor;
