// src/features/feed/createPost/components/editor/EditorSlider.jsx

import React from "react";

const EditorSlider = ({
  label,
  value,
  min,
  max,
  step = 1,
  onChange,
}) => {
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-[11px] text-gray-500">
        <span>{label}</span>
        <span>{value}</span>
      </div>

      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={onChange}
        className="
          w-full
          h-1
          rounded-full
          appearance-none
          bg-gray-200
          cursor-pointer
        "
      />
    </div>
  );
};

export default EditorSlider;