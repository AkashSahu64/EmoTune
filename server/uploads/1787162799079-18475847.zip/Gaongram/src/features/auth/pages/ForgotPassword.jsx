import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Mail } from 'lucide-react';
import { authService } from '../../../services/auth.service.js';
import { showSuccess, showError } from '../../../utils/toast.js';
import Button from '../../../components/common/Button.jsx';
import Seo from '../../../components/seo/Seo.jsx';
import { buildStaticPageSeo } from '../../../seo/seoBuilders.js';
import forgot from '../../../assets/forgot.png';
// import AuthCard from '../components/AuthCard.jsx'; // replaced with direct card

const ForgotPassword = () => {
  const [identifier, setIdentifier] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!identifier.trim()) {
      showError('Please enter your email or phone number');
      return;
    }

    setLoading(true);
    try {
      const response = await authService.forgotPassword({ identifier });
      showSuccess(response.message || 'Reset link sent to your email/phone');
      setSubmitted(true);
    } catch (error) {
      showError(error.response?.data?.message || 'Failed to send reset link');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Seo {...buildStaticPageSeo('forgotPassword')} />

      <div className="min-h-screen bg-login-hero flex items-center justify-center px-3 sm:px-4 lg:px-6">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="w-full max-w-sm"
        >
          <div className="backdrop-blur-md bg-light-card/10 shadow-premium border border-gray-100/30 rounded-xl3 px-6 py-8">
            {/* Illustration Image */}
            <div className="flex justify-center mb-4">
              <img
                src={forgot}
                alt="Reset password"
                className="w-36 h-36 object-contain drop-shadow-premium"
              />
            </div>

            {/* Headings */}
            <h2 className="text-2xl font-bold text-white">Reset Your Password 🔑</h2>
            <p className="text-light-subtext text-sm mb-6">
              Enter your registered email or mobile number and we’ll send you a reset link.
            </p>

            {!submitted ? (
              <form className="space-y-5" onSubmit={handleSubmit}>
                {/* Email/Phone Input */}
                <div>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Mail className="h-5 w-5 text-light-subtext" />
                    </div>
                    <input
                      id="identifier"
                      name="identifier"
                      type="text"
                      autoComplete="email"
                      value={identifier}
                      onChange={(e) => setIdentifier(e.target.value)}
                      className="block w-full pl-10 pr-3 py-2 border border-light-border/50 rounded-lg bg-light-card/20 placeholder-light-subtext text-light-text focus:outline-none focus:ring-2 focus:ring-instagram-pink focus:border-transparent transition-shadow"
                      placeholder="Email or phone number"
                    />
                  </div>
                </div>

                {/* Submit Button */}
                <Button
                  type="submit"
                  variant="primary"
                  size="medium"
                  loading={loading}
                  fullWidth
                  className="py-2.5 text-base font-semibold bg-green-950/80 hover:bg-green-950/100 text-white shadow-premium hover:shadow-emerald transition-all"
                >
                  Send Reset Link
                </Button>

                {/* Back to Login Link */}
                <div className="text-center">
                  <Link
                    to="/login"
                    className="text-sm font-medium text-viral-blue hover:text-viral-blue/80 transition-colors"
                  >
                    Back to login
                  </Link>
                </div>
              </form>
            ) : (
              <div className="text-center">
                {/* Success Icon */}
                <div className="mb-4 text-success">
                  <svg
                    className="mx-auto h-12 w-12"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <h3 className="text-lg font-medium text-white mb-2">Check your inbox</h3>
                <p className="text-sm text-light-subtext mb-6">
                  We've sent a password reset link to {identifier}.
                </p>
                <Link
                  to="/login"
                  className="text-sm font-medium text-viral-blue hover:text-viral-blue/80 transition-colors"
                >
                  Return to login
                </Link>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default ForgotPassword;
