import React, { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import {
  Play,
  Pause,
  X,
  SkipBack,
  SkipForward,
  Maximize2,
  Minimize2,
} from "lucide-react";
import { usePlayerStore } from "../../../store/playerStore";
import { mediaController } from "../../../media/MediaController";
import Avatar from "../../../components/common/Avatar";
import { ensureAudioElement } from "../../../utils/audioManager";

const MiniPlayer = () => {
  const navigate = useNavigate();
  const {
    currentTrack,
    isPlaying,
    isVisible,
    mode,
    position,
    setPlaying,
    hide,
    nextTrack,
    prevTrack,
    toggleMode,
    setPosition,
    setDragging,
  } = usePlayerStore();

  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const progressInterval = useRef(null);

  // All hooks must be called unconditionally
  // Sync play/pause state with MediaController
  useEffect(() => {
    // Skip if no currentTrack
    if (!currentTrack?.id) return;

    const onPlay = (data) => {
      if (String(data.mediaId) === String(currentTrack.id)) setPlaying(true);
    };
    const onPause = (data) => {
      if (String(data.mediaId) === String(currentTrack.id)) setPlaying(false);
    };
    const onEnded = (data) => {
      if (String(data.mediaId) === String(currentTrack.id)) {
        setPlaying(false);
        nextTrack();
      }
    };
    mediaController.on("mediaPlay", onPlay);
    mediaController.on("mediaPause", onPause);
    mediaController.on("mediaEnded", onEnded);
    return () => {
      mediaController.off("mediaPlay", onPlay);
      mediaController.off("mediaPause", onPause);
      mediaController.off("mediaEnded", onEnded);
    };
  }, [currentTrack?.id, setPlaying, nextTrack]);

  // Poll progress from MediaController instance
  useEffect(() => {
    if (!currentTrack?.id) return;
    const updateProgress = () => {
      const instance = mediaController.getMediaInstance(currentTrack.id);
      if (instance?.element) {
        setProgress(instance.element.currentTime || 0);
        setDuration(instance.element.duration || 0);
        // Sync playing state from the actual media instance
        if (instance.playing !== isPlaying) {
          setPlaying(instance.playing);
        }
      }
    };
    updateProgress();
    progressInterval.current = setInterval(updateProgress, 500);
    return () => clearInterval(progressInterval.current);
  }, [currentTrack?.id, setPlaying, isPlaying]);

  if (!isVisible || !currentTrack) return null;

  const handlePlayPause = () => {
    if (!currentTrack?.id) return;
    // Ensure the audio element exists
    ensureAudioElement(currentTrack.id, currentTrack.src, "audio");
    const instance = mediaController.getMediaInstance(currentTrack.id);
    const isActuallyPlaying = instance?.playing ?? false;

    if (isActuallyPlaying) {
      mediaController.pause(currentTrack.id);
      setPlaying(false);
    } else {
      mediaController.play(currentTrack.id, { manual: true }).then((played) => {
        setPlaying(Boolean(played));
      });
    }
  };

  const handleSeek = (e) => {
    if (!currentTrack?.id) return;
    ensureAudioElement(currentTrack.id, currentTrack.src, "audio");
    const newTime = parseFloat(e.target.value);
    mediaController.seek(currentTrack.id, newTime);
    setProgress(newTime);
  };

  const handleClick = () => {
    navigate(`/audio?start=${currentTrack.id}`);
  };

  const handleDragStart = (e) => {
    if (mode !== "card") return;

    e.preventDefault();

    const isTouch = e.type === "touchstart";

    const clientX = isTouch ? e.touches[0].clientX : e.clientX;
    const clientY = isTouch ? e.touches[0].clientY : e.clientY;

    const startX = clientX - position.x;
    const startY = clientY - position.y;

    const onMove = (moveEvent) => {
      const moveX = isTouch ? moveEvent.touches[0].clientX : moveEvent.clientX;

      const moveY = isTouch ? moveEvent.touches[0].clientY : moveEvent.clientY;

      setPosition({
        x: Math.max(0, Math.min(window.innerWidth - 320, moveX - startX)),
        y: Math.max(0, Math.min(window.innerHeight - 100, moveY - startY)),
      });
    };

    const onEnd = () => {
      if (isTouch) {
        window.removeEventListener("touchmove", onMove);
        window.removeEventListener("touchend", onEnd);
      } else {
        window.removeEventListener("mousemove", onMove);
        window.removeEventListener("mouseup", onEnd);
      }

      setDragging(false);
    };

    if (isTouch) {
      window.addEventListener("touchmove", onMove, { passive: false });
      window.addEventListener("touchend", onEnd);
    } else {
      window.addEventListener("mousemove", onMove);
      window.addEventListener("mouseup", onEnd);
    }

    setDragging(true);
  };

  const handleClosePlayer = (e) => {
    e?.stopPropagation();

    if (currentTrack?.id) {
      try {
        // pause audio
        mediaController.pause(currentTrack.id);

        // hard cleanup (if available)
        mediaController.destroy?.(currentTrack.id);

        // optional stop method
        mediaController.stop?.(currentTrack.id);

        // reset state
        setPlaying(false);
      } catch (error) {
        console.error("Failed to cleanup player:", error);
      }
    }

    // hide mini player
    hide();
  };

  const formatTime = (seconds) => {
    if (!seconds || isNaN(seconds)) return "0:00";
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  // ----- Spotify‑style bottom bar -----
  if (mode === "bar") {
    return (
      <div
        className="
    fixed bottom-0 z-50
    right-0
    left-0 md:left-[var(--sidebar-width)]
    bg-background/95 dark:bg-black/95
    backdrop-blur-md border-t border-border dark:border-border-dark
    shadow-lg safe-area-bottom
  "
      >
        <div className="flex items-center gap-3 sm:gap-4 px-3 sm:px-6 lg:px-10 py-2 w-full">
          {/* 🎵 LEFT: Track Info */}
          <div
            className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
            onClick={handleClick}
          >
            <Avatar
              src={currentTrack.cover}
              alt={currentTrack.title}
              size="small"
            />

            <div className="flex flex-col min-w-0">
              <p className="text-xs sm:text-sm font-medium text-mutedForeground dark:text-gray-200 truncate">
                {currentTrack.title || "Unknown track"}
              </p>
              <p className="text-[10px] sm:text-xs text-mutedForeground dark:text-gray-400 truncate">
                {currentTrack.artist || "Unknown artist"}
              </p>
            </div>
          </div>

          {/* 🎛 CENTER: Controls */}
          <div className="flex items-center gap-2 sm:gap-3 md:gap-4 flex-shrink-0 text-mutedForeground dark:text-gray-300">
            {/* Hide prev on very small screens */}
            <button
              onClick={prevTrack}
              className="hidden sm:flex p-2 rounded-full hover:bg-muted dark:hover:bg-gray-800"
            >
              <SkipBack size={16} />
            </button>

            {/* Play / Pause */}
            <button
              onClick={handlePlayPause}
              className="p-2 rounded-full bg-primary/10 hover:bg-primary/20 transition"
            >
              {isPlaying ? <Pause size={18} /> : <Play size={18} />}
            </button>

            {/* Hide next on very small screens */}
            <button
              onClick={nextTrack}
              className="hidden sm:flex p-2 rounded-full hover:bg-muted dark:hover:bg-gray-800"
            >
              <SkipForward size={16} />
            </button>
          </div>

          {/* ⏱ RIGHT: Seekbar + Actions */}
          <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0 text-mutedForeground dark:text-gray-300">
            {/* Seekbar → hide on mobile */}
            <div className="hidden md:flex items-center gap-2 w-40 lg:w-44">
              <span className="text-[11px] text-mutedForeground">
                {formatTime(progress)}
              </span>

              <input
                type="range"
                min="0"
                max={duration || 0}
                value={progress}
                onChange={handleSeek}
                className="flex-1 h-1 bg-gray-300 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />

              <span className="text-[11px] text-mutedForeground">
                {formatTime(duration)}
              </span>
            </div>

            {/* Mode toggle */}
            <button
              onClick={(e) => {
                e.stopPropagation(); // 🔥 IMPORTANT
                toggleMode();
              }}
              className="p-2 rounded-full hover:bg-muted dark:hover:bg-gray-800"
            >
              <Maximize2 size={14} />
            </button>

            {/* Close */}
            <button
              onClick={handleClosePlayer}
              className="p-2 rounded-full hover:bg-muted dark:hover:bg-gray-800"
            >
              <X size={16} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ----- YouTube‑style floating card -----
  return (
    <div
      className="fixed z-50 w-80 bg-background/95 dark:bg-black/95 backdrop-blur-md rounded-xl shadow-lg border border-border dark:border-border-dark overflow-hidden cursor-grab active:cursor-grabbing touch-none"
      style={{
        top: position.y,
        left: position.x,
      }}
      onMouseDown={handleDragStart}
      onTouchStart={handleDragStart}
    >
      <div className="p-3 flex items-center gap-3">
        <Avatar
          src={currentTrack.cover}
          alt={currentTrack.title}
          size="medium"
          className="rounded-lg"
        />
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium truncate text-mutedForeground dark:text-gray-200">
            {currentTrack.title || "Unknown track"}
          </p>
          <p className="text-xs text-mutedForeground dark:text-gray-400 truncate">
            {currentTrack.artist || "Unknown artist"}
          </p>
          <div className="flex items-center gap-2 mt-1 ">
            <span className="text-xs text-mutedForeground dark:text-gray-400">
              {formatTime(progress)}
            </span>
            <input
              type="range"
              min="0"
              max={duration || 0}
              value={progress}
              onChange={handleSeek}
              className="flex-1 h-1 bg-gray-300 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer"
            />
            <span className="text-xs text-mutedForeground dark:text-gray-400">
              {formatTime(duration)}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1 text-mutedForeground dark:text-gray-300">
          <button
            onClick={prevTrack}
            className="p-1 rounded-full hover:bg-muted dark:hover:bg-gray-800"
          >
            <SkipBack size={16} />
          </button>
          <button
            onClick={handlePlayPause}
            className="p-1 rounded-full hover:bg-muted dark:hover:bg-gray-800"
          >
            {isPlaying ? <Pause size={16} /> : <Play size={16} />}
          </button>
          <button
            onClick={nextTrack}
            className="p-1 rounded-full hover:bg-muted dark:hover:bg-gray-800"
          >
            <SkipForward size={16} />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation(); // 🔥 IMPORTANT
              toggleMode();
            }}
            className="p-1 rounded-full hover:bg-muted dark:hover:bg-gray-800"
            title="Switch to bar mode"
          >
            <Minimize2 size={14} />
          </button>
          <button
            onClick={hide}
            className="p-1 rounded-full hover:bg-muted dark:hover:bg-gray-800"
          >
            <X size={14} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default MiniPlayer;
