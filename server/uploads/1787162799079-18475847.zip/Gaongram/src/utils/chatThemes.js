export const CHAT_THEMES = {
  forest: {
    id: "forest",
    name: "Forest",
    wallpaper: "#F7F9F8",
    sentBubble:
      "linear-gradient(135deg,#008060,#00684A)",
    receivedBubble: "#ffffff",
    tailColor: "#00684A",
    textColor: "#ffffff",
  },

  sunset: {
    id: "sunset",
    name: "Sunset",
    wallpaper:
      "linear-gradient(180deg,#FFF0EA,#FFD7C8)",
    sentBubble:
      "linear-gradient(135deg,#FF7E5F,#FEB47B)",
    receivedBubble: "#ffffff",
    tailColor: "#FEB47B",
    textColor: "#ffffff",
  },

  purple: {
    id: "purple",
    name: "Purple",
    tailColor: "#7C3AED",
    wallpaper:
      "linear-gradient(180deg,#F3ECFF,#E5D8FF)",
    sentBubble:
      "linear-gradient(135deg,#8B5CF6,#7C3AED)",
    receivedBubble: "#ffffff",
    textColor: "#ffffff",
  },

  ocean: {
    id: "ocean",
    name: "Ocean",
    tailColor: "#0582CA",
    wallpaper:
      "linear-gradient(180deg,#E8F8FF,#D6F4FF)",
    sentBubble:
      "linear-gradient(135deg,#00A6FB,#0582CA)",
    receivedBubble: "#ffffff",
    textColor: "#ffffff",
  },

  love: {
    id: "love",
    name: "Love",
    tailColor: "#E91E63",
    wallpaper:
      "linear-gradient(180deg,#FFE6F0,#FFD6E8)",
    sentBubble:
      "linear-gradient(135deg,#FF4D8D,#E91E63)",
    receivedBubble: "#ffffff",
    textColor: "#ffffff",
  },
  midnight: {
  id: "midnight",
  name: "Midnight",
  category: "color",
  tailColor: "#0F172A",
  wallpaper: "#0F172A",
  sentBubble:
    "linear-gradient(135deg,#334155,#0F172A)",
  receivedBubble: "#1E293B",
  textColor: "#ffffff",
},

emerald: {
  id: "emerald",
  name: "Emerald",
  category: "color",
  wallpaper: "#ECFDF5",
  tailColor: "#059669",
  sentBubble:
    "linear-gradient(135deg,#10B981,#059669)",
  receivedBubble: "#ffffff",
  textColor: "#ffffff",
},

royal: {
  id: "royal",
  name: "Royal Blue",
  tailColor: "#1D4ED8",
  category: "color",
  wallpaper: "#EEF4FF",
  sentBubble:
    "linear-gradient(135deg,#2563EB,#1D4ED8)",
  receivedBubble: "#ffffff",
  textColor: "#ffffff",
},

roseGold: {
  id: "roseGold",
  name: "Rose Gold",
  category: "color",
  wallpaper: "#FFF1F2",
  tailColor: "#E11D48",
  sentBubble:
    "linear-gradient(135deg,#FB7185,#E11D48)",
  receivedBubble: "#ffffff",
  textColor: "#ffffff",
},
mountain: {
  id: "mountain",
  name: "Mountains",
  category: "wallpaper",
  tailColor: "#00684A",
  wallpaper: "url('https://images.unsplash.com/photo-1500530855697-b586d89ba3ee') center/cover",
  sentBubble: "linear-gradient(135deg,#008060,#00684A)",
  receivedBubble: "rgba(255,255,255,0.9)",
  textColor: "#ffffff",
},

oceanWave: {
  id: "oceanWave",
  name: "Ocean Wave",
  category: "wallpaper",
  tailColor: "#0369A1",
  wallpaper: "url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e') center/cover",
  sentBubble: "linear-gradient(135deg,#0284C7,#0369A1)",
  receivedBubble: "rgba(255,255,255,0.9)",
  textColor: "#ffffff",
},

sakura: {
  id: "sakura",
  name: "Sakura",
  category: "wallpaper",
  tailColor: "#DB2777",
  wallpaper: "linear-gradient(rgba(0,0,0,.1),rgba(0,0,0,.1)) , url('https://images.unsplash.com/photo-1522383225653-ed111181a951') center/cover",
  sentBubble: "linear-gradient(135deg,#EC4899,#DB2777)",
  receivedBubble: "rgba(255,255,255,0.9)",
  textColor: "#ffffff",
},

aurora: {
  id: "aurora",
  name: "Aurora",
  category: "animated",
  animated: true,
  tailColor: "#92FE9D",
  wallpaper: "linear-gradient(-45deg,#00C9FF,#92FE9D,#A18CD1,#FBC2EB)",
  sentBubble: "linear-gradient(135deg,#00C9FF,#92FE9D)",
  receivedBubble: "rgba(255,255,255,0.9)",
  textColor: "#ffffff",
},

neon: {
  id: "neon",
  name: "Neon Glow",
  category: "animated",
  animated: true,
  tailColor: "#00FFFF",
  wallpaper: "linear-gradient(-45deg,#ff00ff,#00ffff,#8b5cf6,#00ff95)",
  sentBubble: "linear-gradient(135deg,#ff00ff,#00ffff)",
  receivedBubble: "rgba(255,255,255,0.9)",
  textColor: "#ffffff",
},

sunrise: {
  id: "sunrise",
  name: "Animated Sunrise",
  category: "animated",
  animated: true,
  tailColor: "#FF5E62",
  wallpaper: "linear-gradient(-45deg,#ff9966,#ff5e62,#f9d423,#ff4e50)",
  sentBubble: "linear-gradient(135deg,#ff9966,#ff5e62)",
  receivedBubble: "rgba(255,255,255,0.9)",
  textColor: "#ffffff",
},

loveAnimated: {
  id: "loveAnimated",
  name: "Floating Hearts",
  category: "animated",
  tailColor: "#FF6BAA",
  wallpaper: "linear-gradient(180deg,#FFF0F6,#FFD8E8)",
  sentBubble: "linear-gradient(135deg,#FF4D8D,#FF6BAA)",
  receivedBubble: "#ffffff",
  animation: "hearts"
},

cloudsAnimated: {
  id: "cloudsAnimated",
  name: "Cloud Sky",
  category: "animated",
  tailColor: "#00F2FE",
  wallpaper: "linear-gradient(180deg,#BEE9FF,#F6FCFF)",
  sentBubble: "linear-gradient(135deg,#4FACFE,#00F2FE)",
  receivedBubble: "#ffffff",
  animation: "clouds"
},

starsAnimated: {
  id: "starsAnimated",
  name: "Stars Night",
  category: "animated",
  tailColor: "#8B5CF6",
  wallpaper: "linear-gradient(180deg,#0F172A,#1E293B)",
  sentBubble: "linear-gradient(135deg,#6366F1,#8B5CF6)",
  receivedBubble: "#1F2937",
  animation: "stars"
},

fireAnimated: {
  id: "fireAnimated",
  name: "Fire",
  category: "animated",
  tailColor: "#F97316",
  wallpaper: "linear-gradient(180deg,#FFF7ED,#FED7AA)",
  sentBubble: "linear-gradient(135deg,#EA580C,#F97316)",
  receivedBubble: "#ffffff",
  animation: "fire"
},

loveDoodle: {
  id: "loveDoodle",
  name: "Love Doodle",
  category: "wallpaper",
  tailColor: "#E91E63",
  wallpaper: "#FFF1F7",
  sentBubble: "linear-gradient(135deg,#FF4D8D,#E91E63)",
  receivedBubble: "#ffffff",
  pattern: "loveDoodle"
},

gaming: {
  id: "gaming",
  name: "Gaming",
  category: "wallpaper",
  tailColor: "#6366F1",
  wallpaper: "#0F172A",
  sentBubble: "linear-gradient(135deg,#8B5CF6,#6366F1)",
  receivedBubble: "#1E293B",
  pattern: "gaming"
},

whatsappDoodle: {
  id: "whatsappDoodle",
  name: "WhatsApp Doodle",
  category: "wallpaper",
  tailColor: "#008069",
  wallpaper: "#0B141A",
  sentBubble: "linear-gradient(135deg,#00A884,#008069)",
  receivedBubble: "#202C33",
  textColor: "#ffffff",
  pattern: "doodle"
},
};