// // src/hooks/useSuggestedUsers.js
// import { useQuery } from '@tanstack/react-query';
// import { profileService } from '../services/profile.service.js';

// export const useSuggestedUsers = () => {
//   const { data } = useQuery({
//     queryKey: ['suggested-users'],
//     queryFn: async () => {
//       let page = 1;
//       let allUsers = [];
//       let hasNext = true;

//       while (hasNext) {
//         const { results, next } = await profileService.getProfiles({
//           page,
//           page_size: 50,
//           _skipAuth: true, // 🔓 Public access – no token required
//         });

//         allUsers = [...allUsers, ...results];
//         hasNext = !!next;
//         page++;
//       }

//       // Shuffle and pick 6 random users for suggestions
//       const shuffled = [...allUsers].sort(() => 0.5 - Math.random());
//       return {
//         random: shuffled.slice(0, 6),
//         all: shuffled,
//       };
//     },
//     staleTime: 5 * 60 * 1000, // 5 minutes
//   });

//   return { suggestedUsers: data?.random || [] };
// };