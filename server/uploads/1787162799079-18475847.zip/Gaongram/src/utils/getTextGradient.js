export const getTextGradient = (id) => {
  const hue = (id * 47) % 360;

  return {
    background: `hsl(${hue}, 68%, 52%)`,
  };
};