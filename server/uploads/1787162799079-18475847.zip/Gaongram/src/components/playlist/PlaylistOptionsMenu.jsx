import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Music, Image, Edit2, Trash2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { playlistService } from "../../services/playlist.service.js";
import { usePlaylistStore } from "../../store/playlistStore.js";
import ConfirmModal from "../common/ConfirmModal.jsx";

const PlaylistOptionsMenu = ({ isOpen, onClose, playlist, onEdit }) => {
  const navigate = useNavigate();
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);
  const { removePlaylistFromStore } = usePlaylistStore();

  const handleDeletePlaylist = async () => {
    try {
      await playlistService.deletePlaylist(playlist.id);
      removePlaylistFromStore(playlist.id);
      setShowConfirmDelete(false);
      onClose();
      navigate("/playlists");
    } catch (error) {
      console.error("Delete failed:", error.response?.data || error);
    }
  };

  return (
    <AnimatePresence>
      <>
        {/* ================= DROPDOWN MENU ================= */}
        {isOpen && (
          <div className="fixed inset-0 z-50 flex items-end justify-center">
            {/* Backdrop */}
            <motion.div
              key="backdrop"
              className="absolute inset-0 bg-black/60"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onClose}
            />

            {/* Bottom Sheet */}
            <motion.div
              key="menu"
              className="relative w-full max-w-[410px] bg-muted dark:bg-muted-dark rounded-t-2xl px-4 py-2"
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ duration: 0.3 }}
            >
              <div className="flex items-center justify-between mb-2 border-b border-border dark:border-border-dark rounded-lg p-3">
                <h3 className="text-lg font-semibold text-foreground dark:text-foreground-dark">
                  Playlist options
                </h3>
                <button
                  onClick={onClose}
                  className="p-1 hover:bg-foreground/10 rounded-full"
                >
                  <X className="w-5 h-5 text-foreground dark:text-foreground-dark" />
                </button>
              </div>

              <div className="flex flex-col">
                {/* Add Audio */}
                <button
                  onClick={() => {
                    onClose();
                    navigate(`/playlists/${playlist.id}/add-audio`);
                  }}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-foreground/10 text-foreground dark:text-foreground-dark"
                >
                  <Music className="w-5 h-5 text-foreground dark:text-foreground-dark" />
                  <span>Add audio</span>
                </button>

                {/* Edit Cover */}
                <button
                  onClick={() => {
                    onClose();
                    onEdit("cover");
                  }}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-foreground/10 text-foreground dark:text-foreground-dark"
                >
                  <Image className="w-5 h-5 text-foreground dark:text-foreground-dark" />
                  <span>Edit cover</span>
                </button>

                {/* Edit Name */}
                <button
                  onClick={() => {
                    onClose();
                    onEdit("title");
                  }}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-foreground/10 text-foreground dark:text-foreground-dark"
                >
                  <Edit2 className="w-5 h-5 text-foreground dark:text-foreground-dark" />
                  <span>Edit name</span>
                </button>

                {/* Delete Playlist */}
                {!playlist.is_system && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setShowConfirmDelete(true);
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-red-400/20 text-red-400 hover:text-red-600"
                  >
                    <Trash2 className="w-5 h-5" />
                    <span>Delete playlist</span>
                  </button>
                )}
              </div>
            </motion.div>
          </div>
        )}

        {/* ================= CONFIRM DELETE MODAL ================= */}
        <ConfirmModal
          key="confirm"
          isOpen={showConfirmDelete}
          onClose={() => setShowConfirmDelete(false)}
          onConfirm={handleDeletePlaylist}
          title="Delete playlist?"
          message={`Are you sure you want to delete "${playlist?.title}"? This action cannot be undone.`}
          confirmText="Delete"
          cancelText="Cancel"
          type="error"
        />
      </>
    </AnimatePresence>
  );
};

export default React.memo(PlaylistOptionsMenu);
