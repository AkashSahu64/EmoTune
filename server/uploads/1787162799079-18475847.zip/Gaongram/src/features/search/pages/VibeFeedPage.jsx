import React, { useEffect, useState, useMemo, } from "react";
import { useParams,} from "react-router-dom";
import Loader from "../../../components/common/Loader";
import EmptyState from "../../../components/common/EmptyState";
import VibeCard from "../../vibe/components/VibeCard";
import { vibeService } from "../../../services/vibe.service";

const VibeFeedPage = () => {
  const { postId } = useParams();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [targetLoaded, setTargetLoaded] = useState(false);
  const fetchPosts = async ( pageNum = 1, append = false ) => {
  const res = await vibeService.getAllVibePosts(
        pageNum
      );
      setPosts((prev) => {
        const incomingPosts = append
        ? [...prev, ...res.data]
        : res.data;
      const targetIndex =
        incomingPosts.findIndex(
          (p) =>
            String(p.id) ===
            String(postId)
        );
      if (targetIndex > 0) {
        const targetPost = incomingPosts[targetIndex];

        incomingPosts.splice( targetIndex,1 );
        incomingPosts.unshift( targetPost );
      }
      return incomingPosts;
    });

    setHasMore(res.hasMore);
  };

  useEffect(() => {
    const init = async () => {
      setLoading(true);
      try {
        const singleRes = await vibeService.getVibePost(
            postId
          );

        const targetPost = singleRes?.data;
        const feedRes = await vibeService.getAllVibePosts(
            1
          );

        let allPosts = feedRes.data || [];
        allPosts =
          allPosts.filter(
            (p) =>
              String(p.id) !== String(postId)
          );
        setPosts([ targetPost, ...allPosts, ]);
        setHasMore(feedRes.hasMore);
        setTargetLoaded(true);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    init();
  }, [postId]);

  useEffect(() => {
    const handleScroll = async () => {
      if (
        window.innerHeight +
        window.scrollY >=
        document.body.offsetHeight -
        1000 &&
        hasMore &&
        !loading
      ) {

        const nextPage = page + 1;
        setPage(nextPage);
        await fetchPosts(nextPage, true );
      }
    };
    window.addEventListener(
      "scroll",
      handleScroll
    );

    return () =>
      window.removeEventListener(
        "scroll",
        handleScroll
      );

  }, [page, hasMore, loading]);


  if (loading) {
    return (
      <div className="py-20 flex justify-center">
        <Loader />
      </div>
    );
  }

  if (!posts.length) {
    return (
      <EmptyState title="No posts found" />
    );
  }

  return (
    <div className="max-w-[420px] mx-auto pb-20">
      {posts.map((post) => (
        <div
          key={post.id}
          data-post-id={post.id}
        >
          <VibeCard
          post={post}
          onUpdate={(postId, updates) => {
            setPosts((prev) =>
              prev.map((p) => {
                if (p.id !== postId) {
                  return p;
                }
                return {
                  ...p,
                  likes_count:
                    updates?.likes_count ??
                    updates?.total_likes ??
                    p.likes_count,
                  comments_count:
                    typeof updates?.comments_count ===
                    "function"
                      ? updates.comments_count(
                          p.comments_count || 0
                        )
                      : typeof updates?.comments_count ===
                        "object"
                      ? updates?.comments_count
                          ?.count ??
                        p.comments_count
                      : updates?.comments_count ??
                        p.comments_count,
                  is_liked:
                    updates?.is_liked ??
                    p.is_liked,
                  ...Object.fromEntries(
                    Object.entries(
                      updates || {}
                    ).filter(
                      ([key]) =>
                        ![
                          "likes_count",
                          "total_likes",
                          "comments_count",
                          "is_liked",
                        ].includes(key)
                    )
                  ),
                };
              })
            );

          }}
        />        
        </div>

      ))}
    </div>
  );
};

export default VibeFeedPage;