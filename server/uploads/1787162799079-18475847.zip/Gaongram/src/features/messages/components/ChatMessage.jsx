// src/features/messages/components/ChatMessage.jsx
import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check, CheckCheck, MoreVertical, AlertCircle, Reply, Trash2, Edit2, Heart, ThumbsUp, Laugh, X, } from "lucide-react";
import { useAuthStore } from "../../../store/authStore";
import { format, isToday } from "date-fns";
import AudioPlayer from "./AudioPlayer";
import VideoMessage from "./VideoMessage";
import ImagePreviewModal from "./ImagePreviewModal";
import { useTouchSwipe } from "../../../hooks/useTouchSwipe";
import Avatar from "../../../components/common/Avatar";
import { CHAT_THEMES } from "../../../utils/chatThemes";
import { useChatThemeStore } from "../../../store/chatThemeStore";

const formatTime = (timestamp) => {
  const date = new Date(timestamp);
  if (isToday(date)) return format(date, "hh:mm a");
  return format(date, "dd MMM, hh:mm a");
};
const ChatMessage = React.memo(
  ({ message, onEdit, onDelete, onRetry, isGrouped = false, showAvatar = true, avatarUrl, onReply, replyingToMessage, isFirstInGroup = false, isLastInGroup = false, }) => {
    const { user } = useAuthStore();
    const [showMenu, setShowMenu] = useState(false);
    const [imageModalOpen, setImageModalOpen] = useState(false);
    const menuRef = useRef(null);
    const isOwn = Number(message.sender) === Number(user?.id);
    const isFailed = message.isFailed;
    const swipeHandlers = useTouchSwipe({ onSwipeRight: () => onReply?.(message), threshold: 60, });
    const { currentTheme } = useChatThemeStore();
    const theme = CHAT_THEMES[currentTheme];
    useEffect(() => {
      const handleClickOutside = (e) => {
        if (menuRef.current && !menuRef.current.contains(e.target))
          setShowMenu(false);
      };
      document.addEventListener("mousedown", handleClickOutside);
      return () =>
        document.removeEventListener("mousedown", handleClickOutside);
    }, []);
    const getReadStatusIcon = () => {
      if (!isOwn || message.isTemp || isFailed) return null;
      if (message.seen_at) {
        return <CheckCheck className="w-3.5 h-3.5 text-blue-400" />;
      }
      if (message.delivered_at) {
        return <CheckCheck className="w-3.5 h-3.5 text-gray-400" />;
      }
      return <Check className="w-3.5 h-3.5 text-gray-400" />;
    };
    const renderContent = () => {
      if (message.deleted_for_me) {
        return (
          <div className="text-xs italic opacity-70">
            You deleted this message
          </div>
        );
      }
      if (isFailed) {
        return (
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400" />
            <span className="text-sm">Failed to send</span>
            <button
              onClick={onRetry}
              className="text-xs underline text-blue-300"
            >
              Retry
            </button>
          </div>
        );
      }
      switch (message.file_type) {
        case "image":
          return (
            <>
              <img
                src={message.file}
                alt="attachment"
                className="max-w-[260px] max-h-[300px] rounded-lg cursor-pointer object-cover"
                onClick={() => setImageModalOpen(true)}
                loading="lazy"
              />
              <ImagePreviewModal
                isOpen={imageModalOpen}
                onClose={() => setImageModalOpen(false)}
                images={[{ url: message.file, type: "image" }]}
                initialIndex={0}
              />
            </>
          );
        case "video":
          return <VideoMessage src={message.file} />;
        case "audio":
          return <AudioPlayer src={message.file} />;
        default:
          return (
            <p className="whitespace-pre-wrap break-words text-[14px] leading-5 font-medium">
              {message.message}
              {message.edited && (
                <span className="text-[10px] opacity-60 ml-1">(edited)</span>
              )}
            </p>
          );
      }
    };
    // Build reply preview if this message is a reply
    const replyPreview =
      typeof message.reply_to === "object" && message.reply_to !== null ? (
        <div className="mb-2 rounded-xl px-3 py-2 bg-black/10 dark:bg-white/10 backdrop-blur-md border-l-4 border-primary">
          <span className="text-[11px] font-semibold opacity-80 block">
            ↳ {message.reply_to.sender_name || "User"}
          </span>
          <p className="text-xs truncate opacity-70">
            {message.reply_to.message || "Attachment"}
          </p>
        </div>
      ) : null;

    return (
      <div {...swipeHandlers} onDoubleClick={() => onReply(message)} className={`flex ${isOwn ? "justify-end" : "justify-start"} mb-2 group relative px-3`}>
        {/* Avatar (only for first in group, left side) */}
        {!isOwn && showAvatar && !isGrouped && (
          <div className="flex-shrink-0 mr-2 self-end">
            <Avatar src={avatarUrl} alt="user" size="sm" fallbackText={message.sender_name} />
          </div>
        )}
        <div className={` w-fit max-w-[75%] sm:max-w-[70%] ${isGrouped ? (isOwn ? "mr-10" : "ml-10") : ""}`} >
          {/* Reply indicator */}
          {replyingToMessage && (
            <div className="text-xs text-gray-500 mb-1 ml-2">
              Replying to {replyingToMessage.sender_name}
            </div>
          )}
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.18 }}
            className={`relative px-5 py-[10px] shadow-[0_10px_30px_rgba(0,0,0,0.08)] ${isOwn ? "rounded-[28px]" : "rounded-[28px]"} overflow-visible
            ${isFailed ? "opacity-70" : ""}
            ${isOwn ? "rounded-[20px] rounded-br-sm" : "rounded-[20px] rounded-bl-sm"} `}
            style={{
              background: isOwn
                ? theme.sentBubble || "linear-gradient(135deg,#0E4D38 0%,#1B7A5A 100%)"
                : theme.receivedBubble || "#FFFFFF",
              color: isOwn ? theme.textColor : "#111827",
              border: isOwn ? "none" : "1px solid rgba(0,0,0,0.06)",
            }} >
            {isOwn ? (

              <svg
                className="absolute right-[-6px] bottom-[-1px]"
                width="8"
                height="14"
                viewBox="0 0 12 18"
                fill="none"
              >
                <path
                  d="M0 0C5 2 1 12 12 18H0V0Z"
                  fill={theme.tailColor || "#0E4D38"}
                />
              </svg>
            ) : (
              <svg
                className="absolute left-[-6px] bottom-[-1px] scale-x-[-1]"
                width="8"
                height="14"
                viewBox="0 0 12 18"
                fill="none"
              >
                <path
                  d="M0 0C5 2 1 12 12 18H0V0Z"
                  fill={theme.receivedBubble || "#FFFFFF"}
                />
              </svg>
            )}
            {replyPreview}
            <div className="flex items-end gap-2">
              <div className="flex-1">
                {renderContent()}
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <span className={`text-[11px] ${isOwn ? "text-white/80" : "text-gray-400"}`}>
                  {formatTime(message.created_at)}
                </span>

                {getReadStatusIcon()}
              </div>
            </div>
          </motion.div>
          {/* Hover menu (3 dots) */}
          {isOwn && !message.deleted_for_me && !message.isTemp && !isFailed && (
            <div className="absolute -top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <button onClick={() => setShowMenu(true)} className="p-1 rounded-full bg-white dark:bg-gray-800 shadow-md">
                <MoreVertical className="w-4 h-4 text-gray-600 dark:text-gray-300" />
              </button>
            </div>
          )}
          {/* Floating dropdown menu */}
          <AnimatePresence>
            {showMenu && (
              <motion.div
                ref={menuRef}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="absolute z-20 right-0 top-6 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700 w-36"
              >
                <button
                  onClick={() => { onReply(message); setShowMenu(false); }}
                  className="flex items-center gap-2 w-full px-3 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-700">
                  <Reply className="w-3.5 h-3.5" /> Reply
                </button>
                <button
                  onClick={() => { navigator.clipboard.writeText(message.message || ""); setShowMenu(false); }}
                  className="flex items-center gap-2 w-full px-3 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-700">
                  📋 Copy
                </button>
                <button onClick={() => {
                  alert(`Sent: ${message.created_at} Delivered: ${message.delivered_at || "Not delivered"}Seen: ${message.seen_at || "Not seen"} `);
                  setShowMenu(false);
                }}
                  className="flex items-center gap-2 w-full px-3 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  ℹ️ Info
                </button>
                <button
                  onClick={() => { onEdit(message); setShowMenu(false); }}
                  className="flex items-center gap-2 w-full px-3 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 rounded-t-lg"
                >
                  <Edit2 className="w-3.5 h-3.5" /> Edit
                </button>
                <button
                  onClick={() => {
                    if (!message?.id || String(message.id).startsWith("temp_")
                    ) {
                      return;
                    }
                    onDelete({ messageId: message.id, forEveryone: false, });
                    console.log("🧾 RENDER MESSAGE:", message);
                  }}
                  className="flex items-center gap-2 w-full px-3 py-2 text-sm hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Delete for me
                </button>
                <button onClick={() => {
                  if (!message?.id || String(message.id).startsWith("temp_")
                  ) {
                    return;
                  }
                  onDelete({ messageId: message.id, forEveryone: true, });
                }}
                  className="flex items-center gap-2 w-full px-3 py-2 text-sm text-red-500 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-b-lg"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Delete for everyone
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        {/* Right-side avatar for sender (optional) */}
        {isOwn && showAvatar && !isGrouped && (
          <div className="flex-shrink-0 ml-2 self-end">
            <Avatar src={avatarUrl || user?.profile_image} alt="you" size="sm" />
          </div>
        )}
      </div>
    );
  },
);

ChatMessage.displayName = "ChatMessage";
export default ChatMessage;