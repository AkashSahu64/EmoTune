import React, { useEffect, useMemo, useState } from "react";
import {
  Circle,
  Droplets,
  Eraser,
  FlipHorizontal,
  FlipVertical,
  Grid2X2,
  Hexagon,
  Minus,
  MousePointer2,
  MoveRight,
  Paintbrush,
  PenTool,
  Redo2,
  RotateCw,
  Slash,
  Sparkles,
  Square,
  Triangle,
  Undo2,
  ZoomIn,
} from "lucide-react";
import CropEngine from "../core/CropEngine.js";
import PaintEngine from "../core/PaintEngine.js";
import { useCanvasStore } from "../../story/editor/useCanvasStore.js";
import { getSliderBackground } from "../../story/editor/engine/helpers/math.js";

const PANEL_BUTTON =
  "flex min-h-[50px] flex-col items-center justify-center gap-1 rounded-lg border px-2 py-2 text-[11px] font-semibold transition";

const activeClass = "border-primary bg-primary text-white shadow-soft";
const idleClass =
  "border-border bg-white text-gray-700 hover:border-primary/60 dark:border-border-dark dark:bg-gray-950 dark:text-gray-200";

const AspectButton = ({ active, onClick, children }) => (
  <button
    type="button"
    onClick={onClick}
    className={`h-8 rounded-lg px-2.5 text-xs font-semibold transition ${
      active
        ? "bg-primary text-white shadow-soft"
        : "bg-muted text-foreground hover:bg-border dark:bg-muted-dark dark:text-foreground-dark"
    }`}
  >
    {children}
  </button>
);

export const CropPanel = ({ engine }) => {
  const cropEngine = useMemo(
    () => new CropEngine({ engine, store: useCanvasStore }),
    [engine],
  );
  const revision = useCanvasStore((state) => state.revision);
  const [localState, setLocalState] = useState(() => cropEngine.getState());

  useEffect(() => {
    setLocalState(cropEngine.getState());
  }, [cropEngine, revision]);

  const setZoom = (value) => {
    cropEngine.setZoom(value);
    setLocalState(cropEngine.getState());
  };

  return (
    <div className="space-y-4">
      <div>
        <p className="mb-2 text-xs font-semibold uppercase tracking-[0.14em] text-mutedForeground dark:text-mutedForeground-dark">
          Crop Ratio
        </p>
        <div className="flex flex-wrap gap-2">
          {["free", "1:1", "4:5", "16:9", "9:16"].map((ratio) => (
            <AspectButton
              key={ratio}
              active={
                (ratio === "free" && localState.aspectRatio === null) ||
                localState.aspectRatio === ratio
              }
              onClick={() => {
                cropEngine.setAspectRatio(ratio);
                setLocalState(cropEngine.getState());
              }}
            >
              {ratio === "free" ? "Free" : ratio}
            </AspectButton>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        <button
          type="button"
          onClick={() => cropEngine.flip("x")}
          className={`${PANEL_BUTTON} ${localState.flipX ? activeClass : idleClass}`}
        >
          <FlipHorizontal size={18} />
          Flip X
        </button>
        <button
          type="button"
          onClick={() => cropEngine.flip("y")}
          className={`${PANEL_BUTTON} ${localState.flipY ? activeClass : idleClass}`}
        >
          <FlipVertical size={18} />
          Flip Y
        </button>
        <button
          type="button"
          onClick={() => cropEngine.rotate(90)}
          className={`${PANEL_BUTTON} ${idleClass}`}
        >
          <RotateCw size={18} />
          Rotate
        </button>
      </div>

      <div className="rounded-lg border border-border bg-card p-3 dark:border-border-dark dark:bg-card-dark">
        <div className="flex items-center justify-between text-xs font-semibold text-mutedForeground dark:text-mutedForeground-dark">
          <span className="inline-flex items-center gap-2">
            <ZoomIn size={15} />
            Zoom
          </span>
          <span>{Math.abs(localState.zoom || 1).toFixed(2)}x</span>
        </div>

        <input
          type="range"
          min="0.2"
          max="5"
          step="0.05"
          value={Math.abs(localState.zoom || 1)}
          onChange={(event) => setZoom(Number(event.target.value))}
          className="custom-range w-full"
          style={{
            background: getSliderBackground(
              Math.abs(localState.zoom || 1),
              0.2,
              5,
            ),
          }}
        />
      </div>

      <button
        type="button"
        onClick={() => {
          cropEngine.reset();
          setLocalState(cropEngine.getState());
        }}
        className="h-10 w-full rounded-full bg-muted text-sm font-semibold text-foreground transition hover:bg-border dark:bg-muted-dark dark:text-foreground-dark"
      >
        Reset crop
      </button>
    </div>
  );
};

const PAINT_TOOLS = [
  { id: "draw", label: "Draw", icon: Paintbrush },
  { id: "soft", label: "Soft", icon: PenTool },
  { id: "dashed", label: "Dash", icon: Slash },
  { id: "dot", label: "Dots", icon: MousePointer2 },
  { id: "watercolor", label: "Water", icon: Droplets },
  { id: "neon", label: "Neon", icon: Sparkles },
  { id: "eraser", label: "Erase", icon: Eraser },
  { id: "blur", label: "Blur", icon: Droplets },
  { id: "pixel", label: "Pixel", icon: Grid2X2 },
];

const SHAPE_TOOLS = [
  { id: "line", label: "Line", icon: Minus },
  { id: "dashedLine", label: "Dash", icon: Slash },
  { id: "dottedLine", label: "Dots", icon: MousePointer2 },
  { id: "arrow", label: "Arrow", icon: MoveRight },
  { id: "rectangle", label: "Rect", icon: Square },
  { id: "circle", label: "Circle", icon: Circle },
  { id: "triangle", label: "Tri", icon: Triangle },
  { id: "hexagon", label: "Hex", icon: Hexagon },
];

export const PaintPanel = ({ engine }) => {
  const paintEngine = useMemo(
    () => new PaintEngine({ engine, store: useCanvasStore }),
    [engine],
  );
  const undo = useCanvasStore((state) => state.undo);
  const redo = useCanvasStore((state) => state.redo);
  const [tool, setTool] = useState("draw");
  const [color, setColor] = useState("#ffffff");
  const [fill, setFill] = useState("transparent");
  const [size, setSize] = useState(12);
  const [opacity, setOpacity] = useState(1);
  const [strokeWidth, setStrokeWidth] = useState(4);

  useEffect(() => {
    paintEngine.configure({ tool, color, size, opacity, fill, strokeWidth });
    paintEngine.enable(tool);
    return () => paintEngine.disable();
  }, [color, fill, opacity, paintEngine, size, strokeWidth, tool]);

  const selectBrush = (nextTool) => {
    setTool(nextTool);
    paintEngine.enable(nextTool);
  };

  const addShape = (shape) => {
    setTool(shape);
    paintEngine.configure({
      tool: shape,
      color,
      size,
      opacity,
      fill,
      strokeWidth,
    });
    paintEngine.addShape(shape);
  };

  return (
    <div className="space-y-2">
      <div>
        <p className="mb-2 text-xs font-semibold uppercase tracking-[0.14em] text-mutedForeground dark:text-mutedForeground-dark">
          Brushes
        </p>
        <div className="grid grid-cols-3 gap-2">
          {PAINT_TOOLS.map(({ id, label, icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => selectBrush(id)}
              className={`${PANEL_BUTTON} ${tool === id ? activeClass : idleClass}`}
            >
              {React.createElement(icon, { size: 18 })}
              {label}
            </button>
          ))}
        </div>
      </div>

      <div>
        <p className="mb-2 text-xs font-semibold uppercase tracking-[0.14em] text-mutedForeground dark:text-mutedForeground-dark">
          Shapes
        </p>
        <div className="grid grid-cols-3 gap-2">
          {SHAPE_TOOLS.map(({ id, label, icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => addShape(id)}
              className={`${PANEL_BUTTON} ${tool === id ? activeClass : idleClass}`}
            >
              {React.createElement(icon, { size: 18 })}
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 w-28 gap-3">
        <label className="space-y-1 text-xs font-semibold text-mutedForeground dark:text-mutedForeground-dark">
          Color
          <input
            type="color"
            value={color}
            onChange={(event) => setColor(event.target.value)}
            className="h-10 w-full rounded-lg border border-border bg-transparent p-1 dark:border-border-dark mt-1 cursor-pointer"
          />
        </label>
        <label className="space-y-1 text-xs font-semibold text-mutedForeground dark:text-mutedForeground-dark">
          Fill
          <input
            type="color"
            value={fill === "transparent" ? "#000000" : fill}
            onChange={(event) => setFill(event.target.value)}
            className="h-10 w-full rounded-lg border border-border bg-transparent p-1 dark:border-border-dark mt-1 cursor-pointer"
          />
        </label>
      </div>

      {[
        ["Brush size", size, 1, 90, 1, setSize, "px"],
        ["Opacity", opacity, 0.1, 1, 0.05, setOpacity, ""],
        ["Stroke width", strokeWidth, 1, 32, 1, setStrokeWidth, "px"],
      ].map(([label, value, min, max, step, setter, suffix]) => (
        <label
          key={label}
          className="block rounded-lg border border-border bg-card px-3 py-1.5 text-xs font-semibold text-mutedForeground dark:border-border-dark dark:bg-card-dark dark:text-mutedForeground-dark"
        >
          <span className="mb-1 flex items-center justify-between">
            {label}

            <span>
              {suffix ? `${value}${suffix}` : `${Math.round(value * 100)}%`}
            </span>
          </span>

          <input
            type="range"
            min={min}
            max={max}
            step={step}
            value={value}
            onChange={(event) => setter(Number(event.target.value))}
            className="custom-range w-full"
            style={{
              background: getSliderBackground(value, min, max),
            }}
          />
        </label>
      ))}

      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={undo}
          className="flex h-10 items-center justify-center gap-2 rounded-full bg-muted text-sm font-semibold dark:bg-muted-dark"
        >
          <Undo2 size={16} />
          Undo
        </button>
        <button
          type="button"
          onClick={redo}
          className="flex h-10 items-center justify-center gap-2 rounded-full bg-muted text-sm font-semibold dark:bg-muted-dark"
        >
          <Redo2 size={16} />
          Redo
        </button>
      </div>
    </div>
  );
};

export default {
  CropPanel,
  PaintPanel,
};
