import api from "../config/axios.js";

export const buildPostEditFormData = (payload = {}) => {
  const formData = new FormData();

  formData.append("content", payload.content ?? "");
  if (payload.privacy !== undefined) {
    formData.append("privacy", payload.privacy ?? "");
  }
  if (payload.location !== undefined) {
    formData.append("location", payload.location ?? "");
  }

  if (payload.isSensitive !== undefined) {
  formData.append("is_sensitive", payload.isSensitive);
}

  if (Array.isArray(payload.removedImageIds) && payload.removedImageIds.length) {
    formData.append("removed_images", JSON.stringify(payload.removedImageIds));
  }

  if (Array.isArray(payload.imageOrder)) {
    formData.append("image_order", JSON.stringify(payload.imageOrder));
  }

  payload.newImages?.forEach((file, index) => {
    if (file instanceof File || file instanceof Blob) {
      formData.append(`images[${index}][image]`, file);
    }
  });

  if (payload.video) {
    formData.append("videos[0][video]", payload.video);
  }

  if (payload.thumbnail) {
    formData.append("videos[0][thumbnail]", payload.thumbnail);
  }

  if (payload.audioTitle !== undefined) {
    formData.append("audio[title]", payload.audioTitle || "Untitled");
  }

  if (payload.audioFile) {
    formData.append("audio[audio]", payload.audioFile);
  }

  if (payload.coverImage) {
    formData.append("audio[cover_image]", payload.coverImage);
  }

  if (payload.pollQuestion !== undefined) {
    formData.append("poll_question", payload.pollQuestion);
  }

  if (Array.isArray(payload.pollOptions)) {
    formData.append(
      "poll_options",
      JSON.stringify(payload.pollOptions.map((option) => option.trim()).filter(Boolean)),
    );
  }

  return formData;
};

export const parseApiError = (error, fallback = "Request failed") => {
  const data = error?.response?.data;

  if (!data) {
    return error?.message || fallback;
  }

  if (typeof data === "string") {
    return data;
  }

  if (data.message || data.detail || data.error) {
    return data.message || data.detail || data.error;
  }

  const firstFieldError = Object.values(data).flat?.()[0];
  return firstFieldError ? String(firstFieldError) : fallback;
};

export const postEditService = {
  updatePost: async (id, payload, options = {}) => {
    if (!id) {
      throw new Error("Post ID is required");
    }

    const formData = payload instanceof FormData ? payload : buildPostEditFormData(payload);

    const response = await api.patch(`/vibe-posts/${id}/`, formData, {
      signal: options.signal,
    });

    return response.data;
  },

  deletePost: async (id, options = {}) => {
    if (!id) {
      throw new Error("Post ID is required");
    }

    const response = await api.delete(`/vibe-posts/${id}/`, {
      signal: options.signal,
    });
    return response.data;
  },
};