import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import {
  Heart,
  MessageCircle,
  Bookmark,
  Share2,
  Eye,
  MoreVertical,
  Calendar,
  User,
  Tag,
} from 'lucide-react';
import { sanitizeHtml, stripHtml, truncateText } from '../../utils/sanitizeHtml.js';
import { formatTime } from '../../utils/formatTime.js';
import { useAuthStore } from '../../store/authStore.js';
import { useUIStore } from '../../store/uiStore.js';
import Avatar from '../../components/common/Avatar.jsx';
import { showError } from '../../utils/toast.js';

const BlogCard = ({ blog, variant = 'grid' }) => {
  const { isAuthenticated } = useAuthStore();
  const { openModal } = useUIStore();
  
  const [isLiked, setIsLiked] = useState(blog.is_liked || false);
  const [likeCount, setLikeCount] = useState(blog.likes_count || 0);
  const [isSaved, setIsSaved] = useState(blog.is_saved || false);
  const [showMore, setShowMore] = useState(false);

  const handleLike = async () => {
    if (!isAuthenticated) {
      openModal('login');
      return;
    }

    const previousIsLiked = isLiked;
    const previousLikeCount = likeCount;

    setIsLiked(!isLiked);
    setLikeCount(prev => isLiked ? prev - 1 : prev + 1);

    try {
      // TODO: Call API to like/unlike blog
    } catch (error) {
      setIsLiked(previousIsLiked);
      setLikeCount(previousLikeCount);
      showError('Failed to like blog');
    }
  };

  const handleSave = async () => {
    if (!isAuthenticated) {
      openModal('login');
      return;
    }

    const previousIsSaved = isSaved;
    setIsSaved(!isSaved);

    try {
      // TODO: Call API to save/unsave blog
    } catch (error) {
      setIsSaved(previousIsSaved);
      showError('Failed to save blog');
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: blog.title,
          text: stripHtml(blog.content).substring(0, 100),
          url: `${window.location.origin}/blog/${blog.slug || blog.id}`,
        });
      } catch (error) {
        if (error.name !== 'AbortError') {
          await handleCopyLink();
        }
      }
    } else {
      await handleCopyLink();
    }
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(
        `${window.location.origin}/blog/${blog.slug || blog.id}`
      );
      showError('Link copied to clipboard!', 'success');
    } catch (error) {
      showError('Failed to copy link');
    }
  };

  const cleanContent = stripHtml(blog.content);
  const truncatedContent = truncateText(cleanContent, variant === 'grid' ? 150 : 300);
  const shouldTruncate = cleanContent.length > (variant === 'grid' ? 150 : 300);

  if (variant === 'grid') {
    return (
      <motion.article
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow duration-300"
      >
        {/* Blog Image */}
        {blog.cover_image && (
          <Link to={`/blog/${blog.slug || blog.id}`}>
            <div className="h-48 overflow-hidden">
              <img
                src={blog.cover_image}
                alt={blog.title}
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
          </Link>
        )}

        <div className="p-5">
          {/* Blog Meta */}
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-3">
              <Link to={`/profile/${blog.author?.username}`}>
                <Avatar
                  src={blog.author?.avatar}
                  alt={blog.author?.username}
                  size="sm"
                />
              </Link>
              <div>
                <Link
                  to={`/profile/${blog.author?.username}`}
                  className="text-sm font-medium text-gray-900 hover:text-instagram-pink"
                >
                  {blog.author?.username}
                </Link>
                <p className="text-xs text-gray-500 flex items-center">
                  <Calendar className="w-3 h-3 mr-1" />
                  {formatTime(blog.created_at)}
                </p>
              </div>
            </div>

            <button
              onClick={handleSave}
              className={`p-1 ${
                isSaved ? 'text-yellow-500' : 'text-gray-400 hover:text-yellow-500'
              }`}
              aria-label={isSaved ? 'Unsave' : 'Save'}
            >
              <Bookmark className={`w-5 h-5 ${isSaved ? 'fill-current' : ''}`} />
            </button>
          </div>

          {/* Blog Title */}
          <Link to={`/blog/${blog.slug || blog.id}`}>
            <h3 className="text-xl font-bold text-gray-900 mb-2 hover:text-instagram-pink line-clamp-2">
              {blog.title}
            </h3>
          </Link>

          {/* Blog Content */}
          <div className="mb-4">
            <div
              className="text-gray-600 text-sm line-clamp-3"
              dangerouslySetInnerHTML={{
                __html: sanitizeHtml(truncatedContent),
              }}
            />
            {shouldTruncate && (
              <Link
                to={`/blog/${blog.slug || blog.id}`}
                className="text-sm text-instagram-pink hover:text-pink-600 font-medium"
              >
                Read more
              </Link>
            )}
          </div>

          {/* Blog Tags */}
          {blog.tags && blog.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-4">
              {blog.tags.slice(0, 3).map((tag) => (
                <Link
                  key={tag.id || tag}
                  to={`/tag/${tag.slug || tag}`}
                  className="inline-flex items-center px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full hover:bg-gray-200"
                >
                  <Tag className="w-3 h-3 mr-1" />
                  {tag.name || tag}
                </Link>
              ))}
              {blog.tags.length > 3 && (
                <span className="text-xs text-gray-500">
                  +{blog.tags.length - 3} more
                </span>
              )}
            </div>
          )}

          {/* Blog Stats */}
          <div className="flex items-center justify-between pt-4 border-t">
            <div className="flex items-center space-x-4">
              <button
                onClick={handleLike}
                className={`flex items-center space-x-1 ${
                  isLiked ? 'text-red-500' : 'text-gray-500 hover:text-red-500'
                }`}
              >
                <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
                <span className="text-sm">{likeCount}</span>
              </button>

              <Link
                to={`/blog/${blog.slug || blog.id}#comments`}
                className="flex items-center space-x-1 text-gray-500 hover:text-gray-700"
              >
                <MessageCircle className="w-5 h-5" />
                <span className="text-sm">{blog.comments_count || 0}</span>
              </Link>

              <div className="flex items-center space-x-1 text-gray-500">
                <Eye className="w-5 h-5" />
                <span className="text-sm">{blog.views_count || 0}</span>
              </div>
            </div>

            <button
              onClick={handleShare}
              className="text-gray-500 hover:text-gray-700"
              aria-label="Share"
            >
              <Share2 className="w-5 h-5" />
            </button>
          </div>
        </div>
      </motion.article>
    );
  }

  // List View Variant
  return (
    <motion.article
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      className="bg-white rounded-xl border border-gray-200 p-6 mb-4"
    >
      <div className="flex flex-col md:flex-row gap-6">
        {/* Blog Image (List View) */}
        {blog.cover_image && (
          <Link
            to={`/blog/${blog.slug || blog.id}`}
            className="md:w-1/3 flex-shrink-0"
          >
            <div className="h-48 md:h-full rounded-lg overflow-hidden">
              <img
                src={blog.cover_image}
                alt={blog.title}
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
          </Link>
        )}

        {/* Blog Content (List View) */}
        <div className="flex-1">
          <div className="flex items-start justify-between mb-3">
            <div>
              <Link to={`/blog/${blog.slug || blog.id}`}>
                <h2 className="text-2xl font-bold text-gray-900 mb-2 hover:text-instagram-pink">
                  {blog.title}
                </h2>
              </Link>
              
              <div className="flex items-center space-x-4 text-sm text-gray-500 mb-4">
                <Link
                  to={`/profile/${blog.author?.username}`}
                  className="flex items-center space-x-1 hover:text-instagram-pink"
                >
                  <User className="w-4 h-4" />
                  <span>{blog.author?.username}</span>
                </Link>
                <div className="flex items-center space-x-1">
                  <Calendar className="w-4 h-4" />
                  <span>{formatTime(blog.created_at, 'full')}</span>
                </div>
              </div>
            </div>

            <button
              onClick={handleSave}
              className={`p-2 ${
                isSaved ? 'text-yellow-500' : 'text-gray-400 hover:text-yellow-500'
              }`}
              aria-label={isSaved ? 'Unsave' : 'Save'}
            >
              <Bookmark className={`w-5 h-5 ${isSaved ? 'fill-current' : ''}`} />
            </button>
          </div>

          {/* Blog Content */}
          <div className="mb-4">
            <div
              className="text-gray-600 mb-3"
              dangerouslySetInnerHTML={{
                __html: sanitizeHtml(showMore ? cleanContent : truncatedContent),
              }}
            />
            {shouldTruncate && (
              <button
                onClick={() => setShowMore(!showMore)}
                className="text-instagram-pink hover:text-pink-600 font-medium"
              >
                {showMore ? 'Show less' : 'Read more'}
              </button>
            )}
          </div>

          {/* Blog Tags */}
          {blog.tags && blog.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-4">
              {blog.tags.map((tag) => (
                <Link
                  key={tag.id || tag}
                  to={`/tag/${tag.slug || tag}`}
                  className="inline-flex items-center px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded-full hover:bg-gray-200"
                >
                  <Tag className="w-3 h-3 mr-1" />
                  {tag.name || tag}
                </Link>
              ))}
            </div>
          )}

          {/* Blog Stats */}
          <div className="flex items-center justify-between pt-4 border-t">
            <div className="flex items-center space-x-6">
              <button
                onClick={handleLike}
                className={`flex items-center space-x-2 ${
                  isLiked ? 'text-red-500' : 'text-gray-500 hover:text-red-500'
                }`}
              >
                <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
                <span>{likeCount} likes</span>
              </button>

              <Link
                to={`/blog/${blog.slug || blog.id}#comments`}
                className="flex items-center space-x-2 text-gray-500 hover:text-gray-700"
              >
                <MessageCircle className="w-5 h-5" />
                <span>{blog.comments_count || 0} comments</span>
              </Link>

              <div className="flex items-center space-x-2 text-gray-500">
                <Eye className="w-5 h-5" />
                <span>{blog.views_count || 0} views</span>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <button
                onClick={handleShare}
                className="flex items-center space-x-2 text-gray-500 hover:text-gray-700"
              >
                <Share2 className="w-5 h-5" />
                <span>Share</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </motion.article>
  );
};

export default BlogCard;