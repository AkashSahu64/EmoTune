// src/features/blogs/pages/BlogDetail.jsx
import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import DOMPurify from "dompurify";
import { format } from "date-fns";
import { useBlog } from "../../../../../hooks/useBlog";
import BlogMetaInfo from "./BlogMetaInfo";
import Button from "../../../../../components/common/Button";
import Avatar from "../../../../../components/common/Avatar";
import BlogSkeleton from "./BlogSkeleton";
import { canEditBlog, canDeleteBlog } from "../../../../../utils/blogPermissions";
import { showSuccess, showError } from "../../../../../utils/toast";
import blogService from "../../../../../services/blogService";
import PublicLayout from "../../../components/layout/PublicLayout";
import Seo from "../../../../../components/seo/Seo.jsx";
import { buildBlogSeo, buildStaticPageSeo } from "../../../../../seo/seoBuilders.js";

const BlogDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { blog, loading, error, refetch } = useBlog(id);

  const isOwner = blog ? canEditBlog(blog) : false;

  const handleDelete = async () => {
    if (!canDeleteBlog(blog)) {
      showError("You are not authorized to delete this blog.");
      return;
    }
    if (window.confirm("Are you sure you want to delete this blog?")) {
      try {
        const response = await blogService.deleteBlog(id);
        if (response.success) {
          showSuccess("Blog deleted successfully");
          navigate("/blogs");
        }
      } catch (err) {
        showError(err.message || "Failed to delete blog");
      }
    }
  };

  if (loading) {
    return (
      <>
        <Seo {...buildStaticPageSeo("blogs", { path: `/blogs/${id || ""}` })} />
        <div className="container mx-auto px-4 py-8 max-w-5xl">
          <BlogSkeleton count={1} />
        </div>
      </>
    );
  }

  if (error || !blog) {
    return (
      <>
        <Seo
          title="Blog Not Found"
          description="This GaonGram blog is unavailable or may have been removed."
          canonical={`/blogs/${id || ""}`}
          noindex
        />
        <div className="container mx-auto px-4 py-8 max-w-5xl text-center">
          <h2 className="text-2xl font-bold mb-4">Blog not found</h2>
          <Button onClick={() => navigate("/blogs")}>Back to Blogs</Button>
        </div>
      </>
    );
  }

  const sanitizedContent = DOMPurify.sanitize(blog.content || "");

  return (
    <PublicLayout>
      <Seo {...buildBlogSeo(blog, { blogId: id, path: `/blogs/${id || ""}` })} />
      <motion.article
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-screen bg-background dark:bg-background-dark"
    >
      {/* Hero Section */}
      <div className="relative w-full h-[50vh] md:h-[60vh] bg-gradient-to-b from-background-dark/80 to-background-dark">
        {blog.image ? (
          <img
            src={blog.image}
            alt={blog.image_alt_text || blog.title}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-viral-pink/20">
            <span className="text-8xl">📝</span>
          </div>
        )}
        <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]" />
        <div className="absolute bottom-0 left-0 right-0 p-6 md:p-12 text-white">
          <div className="container max-w-4xl mx-auto">
            <div className="flex flex-wrap gap-2 mb-4">
              {blog.is_featured && (
                <span className="px-3 py-1 bg-accent text-white text-sm font-medium rounded-full">
                  Featured
                </span>
              )}
              {!blog.is_published && (
                <span className="px-3 py-1 bg-warning/90 text-white text-sm font-medium rounded-full">
                  Draft
                </span>
              )}
              {!isOwner && (
                <span className="px-3 py-1 bg-muted/80 text-foreground dark:text-foreground-dark text-sm font-medium rounded-full">
                  View Only
                </span>
              )}
            </div>
            <h1 className="text-3xl md:text-5xl font-bold mb-4 drop-shadow-lg">
              {blog.title}
            </h1>
            <div className="flex items-center gap-4 text-white/90">
              <div className="flex items-center gap-2">
                <Avatar src={blog.author?.avatar} size="sm" />
                <span>{blog.author?.username || `User ${blog.author}`}</span>
              </div>
              <span>•</span>
              <span>{format(new Date(blog.created_at), "MMMM d, yyyy")}</span>
              <span>•</span>
              <span>{blog.views} views</span>
            </div>
          </div>
        </div>
      </div>

      {/* Content with Sidebar */}
      <div className="container max-w-6xl mx-auto px-4 py-10">
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="flex-1">
            <div className="bg-card dark:bg-card-dark rounded-xl2 p-6 md:p-8 shadow-soft border border-border dark:border-border-dark">
              <div
                className="prose prose-lg dark:prose-invert max-w-none"
                dangerouslySetInnerHTML={{ __html: sanitizedContent }}
              />
            </div>

            {(blog.content_hi || blog.content_ur) && (
              <div className="mt-8 space-y-6">
                {blog.content_hi && (
                  <div className="bg-card dark:bg-card-dark rounded-xl p-6 shadow-soft">
                    <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                      <span>🇮🇳</span> हिन्दी
                    </h3>
                    <div
                      className="prose prose-lg"
                      dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(blog.content_hi) }}
                    />
                  </div>
                )}
                {blog.content_ur && (
                  <div className="bg-card dark:bg-card-dark rounded-xl p-6 shadow-soft" dir="rtl">
                    <h3 className="text-lg font-semibold mb-3 flex items-center gap-2 justify-end">
                      <span>🇵🇰</span> اردو
                    </h3>
                    <div
                      className="prose prose-lg"
                      dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(blog.content_ur) }}
                    />
                  </div>
                )}
              </div>
            )}
          </div>

          <aside className="lg:w-80 shrink-0">
            <div className="sticky top-20">
              <BlogMetaInfo blog={blog} />
              <div className="mt-4 flex gap-2">
                {isOwner && (
                  <>
                    <Button
                      variant="outline"
                      fullWidth
                      onClick={() => navigate(`/blogs/edit/${blog.id}`)}
                    >
                      Edit Blog
                    </Button>
                    <Button variant="danger" onClick={handleDelete}>
                      Delete
                    </Button>
                  </>
                )}
                <Button variant="outline" onClick={() => navigate("/blogs")}>
                  Back to List
                </Button>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </motion.article>
    </PublicLayout>
  );
};

export default BlogDetail;
