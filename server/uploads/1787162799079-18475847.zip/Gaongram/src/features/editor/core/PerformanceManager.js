export const rafThrottle = (callback) => {
  let frame = null;
  let lastArgs = null;

  const throttled = (...args) => {
    lastArgs = args;
    if (frame) return;
    frame = requestAnimationFrame(() => {
      frame = null;
      callback(...lastArgs);
    });
  };

  throttled.cancel = () => {
    if (frame) cancelAnimationFrame(frame);
    frame = null;
  };

  return throttled;
};

export const idleCallback = (callback, timeout = 800) => {
  if ("requestIdleCallback" in window) {
    return window.requestIdleCallback(callback, { timeout });
  }
  return window.setTimeout(callback, 0);
};

export const cancelIdleCallbackSafe = (id) => {
  if ("cancelIdleCallback" in window) {
    window.cancelIdleCallback(id);
    return;
  }
  window.clearTimeout(id);
};

export class PerformanceManager {
  constructor() {
    this.disposers = new Set();
  }

  track(disposer) {
    if (typeof disposer === "function") this.disposers.add(disposer);
    return disposer;
  }

  dispose() {
    this.disposers.forEach((dispose) => dispose());
    this.disposers.clear();
  }
}
